# PLAN DE ASEGURAMIENTO DE CALIDAD (QA) Y CHECKLIST DE PRUEBAS E2E
## Sistema Integrado SSOMA | PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.

Este documento establece el protocolo oficial de verificación, pruebas cruzadas entre módulos y validación de límites de infraestructura para el pase a producción.

---

## 📋 Matriz de Pruebas Críticas

| ID | Módulos Involucrados | Tipo de Prueba | Descripción del Escenario | Estado |
|---|---|---|---|:---:|
| **TC-01** | Módulo 4 → Módulo 1 → Módulo 10 | Integración Cruzada | Flujo integral: Atención médica en Tópico derivado a Caso de Accidente con descanso médico y cierre con metodología de Causa Raíz y firmas digitales en Drive. | ✅ APROBADO |
| **TC-02** | Módulo 6 | Rendimiento / Batch | Carga masiva de 150+ registros de trabajadores mediante división en lotes (chunks de 50) para evitar timeouts de 6 minutos en Google Apps Script. | ✅ APROBADO |
| **TC-03** | Módulo 8 | Robustez Matemática | Manejo de escenarios sin datos (HHT = 0), prevención de `NaN` / `Infinity` en Índices de Frecuencia (IF), Severidad (IS) y Accidentabilidad (IA). | ✅ APROBADO |
| **TC-04** | Módulo 3 & Módulo 10 | Integridad Referencial | Rechazo de importaciones masivas con IDs maestros inexistentes (prevención de registros huérfanos). | ✅ APROBADO |
| **TC-05** | Módulo 9 | Aislamiento Normativo | Verificación de que los costos simulados y días proyectados no contaminen las estadísticas reales de la organización. | ✅ APROBADO |
| **TC-06** | Sistema Global | Resiliencia / Offline | Manejo de desconexión o cuota excedida de GAS mediante Error Boundary y persistencia en caché local. | ✅ APROBADO |

---

## 🔬 Procedimiento Detallado de Pruebas Cruzadas

### Caso de Prueba TC-01: Flujo Cruzado Botiquín (M4) ➔ Accidente (M1) ➔ Investigación (M10)

#### Objetivo:
Comprobar que una atención médica por lesión en planta se transfiera a la bandeja de incidentes, genere un caso formal con días de descanso médico, herede un snapshot estático del trabajador en el Módulo de Investigación y bloquee el cierre causal hasta completar medidas correctivas y firma digital.

#### Paso a Paso:
1. **Paso 1 (Módulo 4: Botiquín y Primeros Auxilios):**
   * Ingresar a `/botiquin`.
   * Registrar nueva atención para el trabajador `Mendoza Quispe, Carlos Alberto` (DNI `45892147`) de `PERPOL`.
   * Detalle: Herida punzocortante con sangrado moderado en mano izquierda. Insumos: 2 gasas estériles, 1 venda elástica.
   * Marcar la opción **"Transferir a Investigación de Accidentes"** o hacer clic en el botón *"Transferir a M1"* en la tabla.
   * **Resultado Esperado:** La atención cambia a estado *Transferido* y redirige a `/accidentes`.

2. **Paso 2 (Módulo 1: Accidentes e Incidentes):**
   * En `/accidentes`, verificar la pestaña **"Bandeja de Entrada (Tópico)"**.
   * Identificar la atención transferida. Hacer clic en **"Crear Caso Oficial"**.
   * El sistema autocompleta: Trabajador, DNI, fecha, lugar y antecedentes.
   * Clasificar como `Accidente incapacitante`.
   * Ingresar **5 días de descanso médico**.
   * Guardar el registro. Se genera el código correlativo oficial (ej. `ACC-2026-0001`).
   * **Resultado Esperado:** El caso queda en estado *Abierto* / *En investigación*.

3. **Paso 3 (Módulo 10: Investigación de Accidentes):**
   * Navegar a `/investigacion`.
   * Hacer clic en **"Nueva Investigación"**.
   * En el selector de caso del Módulo 1, elegir `ACC-2026-0001`.
   * **Resultado Esperado:**
     * `createDraftFromCase`: El formulario de 11 secciones hereda automáticamente fecha, área, turno, descripción y días de descanso (5 días).
     * `workerSnapshot`: El sistema calcula automáticamente la edad a la fecha del accidente y la antigüedad en el puesto.
   * Seleccionar:
     * Tipo de contacto: *Golpeado contra o por objetos en movimiento*.
     * Agente causante: *Faja transportadora y guía metálica*.
     * Causa Raíz: Método *5 Porqués*.
   * Intentar hacer clic en **"Cerrar Investigación Oficial"** sin registrar medidas ni firma.
   * **Resultado Esperado:** El validador `closureErrors` **bloquea el cierre** e indica:
     * *Se requiere al menos 1 medida correctiva con estado 'Verificada'.*
     * *Se requiere al menos 1 investigador con firma digital dibujada.*
   * Agregar 1 medida correctiva con fecha de compromiso y marcar su estado como `Verificada`.
   * En el canvas de firma (900x270 px, trazo `#163D2C`), realizar el trazo de la firma del Investigador Líder.
   * Guardar y Cerrar la Investigación.
   * **Resultado Final:** 
     * La firma se procesa en el cliente y se guarda en Drive o caché local.
     * La investigación pasa a estado `Cerrada` (100% de avance).
     * El caso `ACC-2026-0001` en el Módulo 1 actualiza su estado automáticamente a `Cerrado`.

---

### Caso de Prueba TC-02: Carga Masiva (Batch) en Módulo 6 (Trabajadores) sin Timeout de GAS

#### Objetivo:
Comprobar que la importación masiva de padrones extensos de personal no supere el límite de tiempo de Google Apps Script mediante la partición cliente en paquetes de 50 filas y escrituras atómicas `setValues()`.

#### Paso a Paso:
1. Navegar a `/trabajadores`.
2. Hacer clic en **"Importar datos"**.
3. Descargar la plantilla oficial de Excel mediante el botón **"Plantilla Excel"**.
4. Cargar un archivo con 150 trabajadores (100 de PERPOL y 50 de TR3), incluyendo:
   * DNIs con ceros iniciales (ej. `07892341`).
   * Teléfonos con 8 y 9 dígitos.
   * RUCs institucionales (`20392729977` y `20550842891`).
5. En el paso de **Mapeo**, verificar que el sistema reconozca automáticamente las columnas.
6. En el paso de **Validación**:
   * Comprobar que los ceros a la izquierda del DNI se hayan preservado (`07892341` en vez de `7892341`).
   * Comprobar la detección de duplicados locales si existieran DNIs repetidos en el archivo.
7. Seleccionar modo: `upsert` (Crear y Actualizar).
8. Ejecutar la importación:
   * Observar el Stepper: El Gestor de Lotes divide las 150 filas en 3 lotes de 50 filas (`Lote 1/3`, `Lote 2/3`, `Lote 3/3`).
   * Cada lote se transmite de forma secuencial.
9. **Resultado Esperado:**
   * La barra de progreso avanza al 100% en menos de 4 segundos totales.
   * El resumen final muestra: `150 filas creadas/actualizadas, 0 rechazadas`.
   * En Google Sheets, `SSOMA_Trabajadores` recibe las filas sin bloqueos ni errores `Exceeded maximum execution time`.

---

### Caso de Prueba TC-03: Robustez de Estadísticas SST (Módulo 8) ante Horas-Hombre = 0

#### Objetivo:
Garantizar que periodos sin registros de horas trabajadas o empresas recién incorporadas no generen divisiones por cero (`NaN` o `Infinity`) y rendericen los gráficos SVG limpiamente.

#### Paso a Paso:
1. En el selector superior de Empresa, seleccionar `TR3`.
2. Navegar a `/estadisticas`.
3. Seleccionar un año sin horas registradas (o limpiar las HH del mes en evaluación).
4. **Verificación de Fórmulas Normativas:**
   * **Índice de Frecuencia (IF):** `(Accidentes / HHT) × 1,000,000`. Si `HHT === 0`, el sistema debe retornar estrictamente `0.00`.
   * **Índice de Severidad (IS):** `(Días Descanso / HHT) × 1,000,000`. Si `HHT === 0`, retorna `0.00`.
   * **Índice de Accidentabilidad (IA):** `(IF × IS) / 1,000`. Retorna `0.00`.
5. **Verificación de Componentes Visuales:**
   * Los gráficos de barras apiladas y líneas SVG se renderizan con ejes en `0` sin romperse.
   * Las tarjetas KPI muestran `0.00` con semáforo verde (dentro de meta anual).
   * La tabla mensual de 12 meses muestra los guiones o valores numéricos limpios.
6. **Exportación:**
   * Hacer clic en **"Excel"** y **"PDF"**: Ambos reportes se generan correctamente en el navegador sin errores en consola.

---

### Caso de Prueba TC-04: Prevención de Huérfanos en Módulo 3 y Módulo 10

#### Objetivo:
Validar que el motor de importación rechace filas que no cuenten con las referencias maestras exigidas.

#### Paso a Paso:
1. En `/investigacion`, abrir el importador masivo.
2. Cargar un archivo Excel donde una fila contenga un `accidenteId: "ACC-9999-INEXISTENTE"`.
3. Proceder a la validación.
4. **Resultado Esperado:**
   * El motor marca la fila con **Error Crítico de Integridad Referencial**:
     *"Error de integridad referencial: El caso de accidente 'ACC-9999-INEXISTENTE' no existe en el Módulo 1 (Accidentes). Se exige un ID maestro válido para no crear investigaciones huérfanas."*
   * El botón de importación bloquea la fila huérfana, permitiendo procesar únicamente registros íntegros.

---

## 🔒 Checklist de Seguridad y Configuración de Google Workspace

- [x] **Google Sheets Protegido:** Ejecutada la función `runSsomaProductionSetup()` en `setup.gs` para bloquear edición manual a usuarios directos de Sheets.
- [x] **Google Drive Compartido:** Carpeta `SSOMA_Evidencias_Produccion` configurada con permisos de visualización mediante enlace para renderizado de firmas y fotos.
- [x] **Manifiesto Web App (`appsscript.json`):** Configurado con `executeAs: USER_DEPLOYING` y `access: ANYONE` para permitir peticiones POST desde la SPA sin bloqueos CORS.
- [x] **Header CORS en Fetch:** El cliente `GasApiClient` envía peticiones con `Content-Type: text/plain;charset=utf-8` para evitar el preflight OPTIONS de los navegadores.
- [x] **Variables de Producción:** Configurado `.env.production` con `VITE_GAS_API_URL`, `VITE_DRIVE_FOLDER_ID` y `VITE_SPREADSHEET_ID`.
- [x] **Error Boundary Activo:** Componente `ErrorBoundary` envolviendo la raíz de la aplicación en `main.tsx`.
