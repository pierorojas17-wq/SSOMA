export const config = {
  runtime: 'nodejs',
  maxDuration: 60,
};

const PERMANENT_GAS_URL = 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-gas-url');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    const headerUrl = req.headers['x-gas-url'];
    const queryUrl = req.query?.url;
    const targetUrl = (headerUrl && String(headerUrl).trim()) || (queryUrl && String(queryUrl).trim()) || process.env.VITE_GAS_API_URL || PERMANENT_GAS_URL;

    let bodyData: string | undefined;
    if (req.method !== 'GET') {
      if (typeof req.body === 'string') {
        bodyData = req.body;
      } else if (req.body && typeof req.body === 'object') {
        bodyData = JSON.stringify(req.body);
      } else {
        bodyData = JSON.stringify({ action: 'ping' });
      }
    }

    const gasResponse = await fetch(targetUrl, {
      method: req.method === 'GET' ? 'GET' : 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: bodyData,
      redirect: 'follow',
    });

    const responseText = await gasResponse.text();
    res.status(gasResponse.status);
    res.setHeader('Content-Type', gasResponse.headers.get('content-type') || 'application/json; charset=utf-8');
    res.send(responseText);
  } catch (err: unknown) {
    res.status(502).json({
      success: false,
      error: err instanceof Error ? err.message : 'Error comunicando con Google Apps Script',
      timestamp: new Date().toISOString(),
    });
  }
}
