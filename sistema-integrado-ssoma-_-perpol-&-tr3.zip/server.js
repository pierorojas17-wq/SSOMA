// server.ts
import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import rateLimit from "express-rate-limit";

// src/utils/antiCache.ts
function buildAntiCacheUrl(url, paramPrefix = "_t") {
  if (!url || typeof url !== "string") return url;
  const timestamp = Date.now();
  const nonce = Math.random().toString(36).substring(2, 9);
  const cacheQuery = `${paramPrefix}=${timestamp}&_cb=${nonce}`;
  const hashIndex = url.indexOf("#");
  let baseUrl = url;
  let hashPart = "";
  if (hashIndex !== -1) {
    baseUrl = url.substring(0, hashIndex);
    hashPart = url.substring(hashIndex);
  }
  const separator = baseUrl.includes("?") ? "&" : "?";
  return `${baseUrl}${separator}${cacheQuery}${hashPart}`;
}
var SERVER_ANTI_CACHE_HEADERS = {
  "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0",
  "Pragma": "no-cache",
  "Expires": "0",
  "Surrogate-Control": "no-store"
};

// server.ts
process.env.DISABLE_HMR = "true";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var rawPort = process.env.PORT ? String(process.env.PORT).trim() : "3000";
var parsedPort = parseInt(rawPort, 10);
var PORT = Number.isFinite(parsedPort) && parsedPort > 0 ? parsedPort : 3e3;
var DEFAULT_GAS_URL = "https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec";
function getClientIp(req) {
  const forwardedHeader = req.headers["forwarded"];
  if (typeof forwardedHeader === "string") {
    const match = /for="?([^";,\s]+)"?/i.exec(forwardedHeader);
    if (match && match[1]) {
      return match[1].replace(/^\[|\]$/g, "");
    }
  }
  const xForwardedFor = req.headers["x-forwarded-for"];
  if (typeof xForwardedFor === "string") {
    const clientIp = xForwardedFor.split(",")[0].trim();
    if (clientIp) return clientIp;
  } else if (Array.isArray(xForwardedFor) && xForwardedFor[0]) {
    const clientIp = xForwardedFor[0].split(",")[0].trim();
    if (clientIp) return clientIp;
  }
  return req.ip || req.socket.remoteAddress || "127.0.0.1";
}
var gasLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  // 15 minutos
  max: 120,
  // 120 solicitudes por IP cada 15 min
  standardHeaders: true,
  legacyHeaders: false,
  // Desactivar completamente las validaciones internas de headers para entornos proxy/Cloud Run
  validate: false,
  keyGenerator: (req) => getClientIp(req),
  message: {
    success: false,
    error: "Demasiadas solicitudes al servidor GAS. Por favor espere unos momentos.",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  }
});
async function startServer() {
  const app = express();
  app.set("trust proxy", true);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.text({ limit: "50mb", type: ["text/plain", "application/json"] }));
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, x-gas-url, Cache-Control, Pragma, Expires, X-Requested-With, If-Modified-Since"
    );
    res.setHeader("Access-Control-Expose-Headers", "Cache-Control, Pragma, Content-Length, Content-Type, Date");
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });
  app.use("/api", (_req, res, next) => {
    for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
      res.setHeader(key, value);
    }
    next();
  });
  app.all("/api/gas", gasLimiter, async (req, res) => {
    try {
      const headerUrl = req.headers["x-gas-url"];
      const queryUrl = req.query.url;
      const rawTargetUrl = headerUrl && headerUrl.trim() || queryUrl && queryUrl.trim() || process.env.VITE_GAS_API_URL || DEFAULT_GAS_URL;
      const targetUrl = buildAntiCacheUrl(rawTargetUrl);
      let bodyData;
      if (req.method !== "GET") {
        if (typeof req.body === "string") {
          bodyData = req.body;
        } else if (req.body && typeof req.body === "object") {
          bodyData = JSON.stringify(req.body);
        } else {
          bodyData = JSON.stringify({ action: "ping" });
        }
      }
      const gasResponse = await fetch(targetUrl, {
        method: req.method === "GET" ? "GET" : "POST",
        headers: {
          "Content-Type": "text/plain;charset=utf-8"
        },
        body: bodyData,
        redirect: "follow"
      });
      const responseText = await gasResponse.text();
      res.status(gasResponse.status);
      res.setHeader("Content-Type", gasResponse.headers.get("content-type") || "application/json; charset=utf-8");
      for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
        res.setHeader(key, value);
      }
      res.send(responseText);
    } catch (err) {
      console.error("[GAS Proxy Error]:", err);
      for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
        res.setHeader(key, value);
      }
      res.status(502).json({
        success: false,
        error: err instanceof Error ? err.message : "Error comunicando con Google Apps Script",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  });
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", serverTime: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get(["/favicon.ico", "/favicon.svg"], (_req, res) => {
    res.sendFile(path.resolve(__dirname, "public", "favicon.svg"));
  });
  const isProd = process.env.NODE_ENV === "production";
  const distPath = path.resolve(__dirname, "dist");
  const indexHtmlPath = path.resolve(distPath, "index.html");
  const hasDist = fs.existsSync(indexHtmlPath);
  if (isProd && hasDist) {
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(indexHtmlPath);
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false
      },
      appType: "spa"
    });
    app.use(vite.middlewares);
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SSOMA Server] Running on http://0.0.0.0:${PORT} (Proxy /api/gas enabled)`);
  });
}
startServer().catch((err) => {
  console.error("[SSOMA Server Startup Error]:", err);
  process.exit(1);
});
export {
  DEFAULT_GAS_URL
};
