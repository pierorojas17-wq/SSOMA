# GUÍA DE DESPLIEGUE, SEGURIDAD Y PUESTA EN PRODUCCIÓN
## Sistema Integrado SSOMA | PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.

Esta guía contiene las instrucciones paso a paso para compilar, configurar el backend en Google Apps Script y desplegar el frontend en entornos de producción.

---

## PARTE 1: Configuración y Publicación del Backend en Google Apps Script

### 1.1 Creación del Proyecto en Google Apps Script
1. Abra su Google Drive corporativo con la cuenta administradora de SSOMA (`ssoma.vkm@gmail.com` o la cuenta institucional asignada).
2. Cree una nueva hoja de cálculo llamada:
   `SSOMA_Database_Produccion_PERPOL_TR3`
3. En el menú superior de Google Sheets, diríjase a **Extensiones** > **Apps Script**.
4. Se abrirá el editor de Google Apps Script. Asigne el nombre al proyecto:
   `SSOMA_Backend_API_Produccion`

### 1.2 Incorporación del Código Fuente
1. En el panel izquierdo de archivos de Apps Script:
   * Abra el archivo `Código.gs` (o cree `Code.gs`) y pegue el contenido completo de `google-apps-script/Code.gs`.
   * Cree un nuevo archivo de script llamado `setup.gs` y pegue el contenido de `google-apps-script/setup.gs`.
2. En la barra lateral izquierda, haga clic en el ícono de engranaje ⚙️ (**Configuración del proyecto**).
   * Active la casilla: **"Mostrar el archivo de manifiesto 'appsscript.json' en el editor"**.
3. Regrese al editor de archivos, abra `appsscript.json` y reemplace su contenido con el de `google-apps-script/appsscript.json`:
   ```json
   {
     "timeZone": "America/Lima",
     "dependencies": { "enabledAdvancedServices": [] },
     "exceptionLogging": "STACKDRIVER",
     "runtimeVersion": "V8",
     "webapp": {
       "executeAs": "USER_DEPLOYING",
       "access": "ANYONE"
     },
     "oauthScopes": [
       "https://www.googleapis.com/auth/spreadsheets",
       "https://www.googleapis.com/auth/drive",
       "https://www.googleapis.com/auth/script.external_request"
     ]
   }
   ```

### 1.3 Ejecución del Script de Inicialización y Seguridad (`setup.gs`)
1. En el selector de funciones de la barra superior, seleccione la función:
   `runSsomaProductionSetup`
2. Haga clic en **Ejecutar**.
3. **Autorización de Permisos:** Al ser la primera ejecución, Google solicitará autorizar los permisos de acceso a Drive y Sheets. Conceda los permisos requeridos.
4. El script realizará automáticamente:
   * Creación y validación de las 10 hojas de cálculo SSOMA.
   * **Bloqueo y protección estructural:** Asigna permisos para que ningún usuario de la hoja pueda editar fórmulas ni eliminar filas directamente desde la interfaz de Sheets.
   * Creación de la carpeta en Drive: `SSOMA_Evidencias_Produccion` con permisos de lectura para visualización de firmas y fotos.
5. Al finalizar, revise el registro de ejecución (**Registro de ejecución**). Copie los valores generados:
   * `VITE_SPREADSHEET_ID`
   * `VITE_DRIVE_FOLDER_ID`

### 1.4 Publicación de la Aplicación Web (Web App)
1. En la esquina superior derecha del editor de Apps Script, haga clic en el botón azul **Implementar** > **Nueva implementación**.
2. En el engranaje de tipo de implementación, seleccione **Aplicación web**.
3. Configure los campos exactamente como sigue:
   * **Descripción:** `SSOMA Producción v1.0`
   * **Ejecutar como:** **"Yo (tu_cuenta@gmail.com)"** *(Execute as me)*  
     *(CRÍTICO: Esto permite que los usuarios de planta y supervisores guarden registros sin requerir permisos de edición individuales sobre la base de datos).*
   * **Quién tiene acceso:** **"Cualquier persona"** *(Anyone)*  
     *(CRÍTICO: Imprescindible para que las peticiones POST desde el cliente React funcionen sin bloqueos de CORS ni pantallas de login en Google).*
4. Haga clic en **Implementar**.
5. Copie la **URL de la aplicación web** generada (termina en `/exec`).
   * Ejemplo: `https://script.google.com/macros/s/AKfycb.../exec`

---

## PARTE 2: Configuración del Frontend (React/Vite)

### 2.1 Inyección de Variables en `.env.production`
Abra el archivo `.env.production` en la raíz del proyecto y configure los valores obtenidos en el paso anterior:
```bash
VITE_GAS_API_URL="https://script.google.com/macros/s/AKfycb.../exec"
VITE_DRIVE_FOLDER_ID="1aBcDeFgHiJkLmNoPqRsTuVwXyZ"
VITE_SPREADSHEET_ID="1xYz..."
VITE_EMPRESA_DEFAULT="PERPOL"
VITE_API_TIMEOUT_MS="35000"
```

### 2.2 Compilación Optimizada para Producción
Ejecute el comando de compilación:
```bash
npm run build
```
El compilador Vite ejecutará:
* `manualChunks`: Fragmentación de bibliotecas pesadas en bundles independientes (`vendor-react`, `vendor-excel-csv`, `vendor-icons`, `vendor-state`).
* `esbuild`: Eliminación completa de `console.log` y sentencias `debugger` para máxima seguridad y rendimiento.
* Generación del directorio `dist/` listo para distribución.

---

## PARTE 3: Opciones de Alojamiento y Despliegue del Frontend

### Opción A: Despliegue en Vercel (Recomendado)
El proyecto ya cuenta con el archivo `vercel.json` preconfigurado con reescritura SPA (`/* -> /index.html`) y encabezados de caché inmutable.
1. Instale Vercel CLI o conecte su repositorio de GitHub:
   ```bash
   npm i -g vercel
   vercel --prod
   ```
2. En el panel de Vercel (Project Settings > Environment Variables), configure la variable:
   * `VITE_GAS_API_URL`
   * `VITE_DRIVE_FOLDER_ID`

### Opción B: Despliegue en Netlify
El proyecto ya cuenta con `public/_redirects` (`/* /index.html 200`).
1. Mediante Netlify CLI o arrastrando la carpeta `dist/` a Netlify Drop:
   ```bash
   npm i -g netlify-cli
   netlify deploy --prod --dir=dist
   ```
2. Ingrese en Site Configuration > Build & deploy > Environment variables para añadir las variables `VITE_*`.

### Opción C: Embebido en Google Sites Corporativo (Intranet PERPOL / TR3)
Si la empresa requiere que el sistema viva dentro del Google Sites interno de la compañía:
1. En Google Sites, agregue un bloque de contenido tipo **"Insertar" (Embed)** > **Código**.
2. Inserte el iframe apuntando al dominio de hosting configurado:
   ```html
   <iframe 
     src="https://su-aplicacion-ssoma.vercel.app" 
     width="100%" 
     height="950px" 
     frameborder="0" 
     style="border:none; border-radius:12px;" 
     allow="camera; microphone; clipboard-write">
   </iframe>
   ```
3. El aplicativo cuenta con diseño responsivo y no utiliza `window.alert` ni `window.open` emergentes, por lo que opera al 100% dentro del marco seguro de Google Sites.

---

## PARTE 4: Verificación Post-Despliegue

1. Abra la URL de producción en una pestaña de incógnito.
2. Ingrese al módulo de **Ajustes y Conexión** (ícono de engranaje).
3. Verifique que el indicador de estado muestre:
   * **"Servidor Conectado (Google Apps Script)"** con punto verde.
4. Realice una prueba de guardado de una inspección o trabajador de prueba.
5. Verifique que la fila aparezca inmediatamente en Google Sheets y en la interfaz de usuario.
