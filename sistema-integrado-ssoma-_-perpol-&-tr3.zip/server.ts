import 'dotenv/config';
process.env.DISABLE_HMR = 'true';
import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import rateLimit from 'express-rate-limit';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Helper anti-caché self-contained para compatibilidad nativa Node ESM
export function buildAntiCacheUrl(url: string, paramPrefix: string = '_t'): string {
  if (!url || typeof url !== 'string') return url;
  const timestamp = Date.now();
  const nonce = Math.random().toString(36).substring(2, 9);
  const cacheQuery = `${paramPrefix}=${timestamp}&_cb=${nonce}`;
  const hashIndex = url.indexOf('#');
  let baseUrl = url;
  let hashPart = '';
  if (hashIndex !== -1) {
    baseUrl = url.substring(0, hashIndex);
    hashPart = url.substring(hashIndex);
  }
  const separator = baseUrl.includes('?') ? '&' : '?';
  return `${baseUrl}${separator}${cacheQuery}${hashPart}`;
}

export const SERVER_ANTI_CACHE_HEADERS: Record<string, string> = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
  'Pragma': 'no-cache',
  'Expires': '0',
  'Surrogate-Control': 'no-store'
};

const rawPort = process.env.PORT ? String(process.env.PORT).trim() : '3000';
const parsedPort = parseInt(rawPort, 10);
const PORT = Number.isFinite(parsedPort) && parsedPort > 0 ? parsedPort : 3000;
export const DEFAULT_GAS_URL = 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';

// Helper para obtener la IP del cliente considerando proxies y balanceadores (X-Forwarded-For / Forwarded)
function getClientIp(req: Request): string {
  const forwardedHeader = req.headers['forwarded'];
  if (typeof forwardedHeader === 'string') {
    // Formato RFC 7239: for=192.0.2.60;proto=http;by=203.0.113.43
    const match = /for="?([^";,\s]+)"?/i.exec(forwardedHeader);
    if (match && match[1]) {
      return match[1].replace(/^\[|\]$/g, '');
    }
  }

  const xForwardedFor = req.headers['x-forwarded-for'];
  if (typeof xForwardedFor === 'string') {
    const clientIp = xForwardedFor.split(',')[0].trim();
    if (clientIp) return clientIp;
  } else if (Array.isArray(xForwardedFor) && xForwardedFor[0]) {
    const clientIp = xForwardedFor[0].split(',')[0].trim();
    if (clientIp) return clientIp;
  }

  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

// Rate Limiter para mitigar abuso, DoS o saturación de cuotas de Google Apps Script
const gasLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 120, // 120 solicitudes por IP cada 15 min
  standardHeaders: true,
  legacyHeaders: false,
  // Desactivar completamente las validaciones internas de headers para entornos proxy/Cloud Run
  validate: false,
  keyGenerator: (req) => getClientIp(req),
  message: {
    success: false,
    error: 'Demasiadas solicitudes al servidor GAS. Por favor espere unos momentos.',
    timestamp: new Date().toISOString()
  }
});

async function startServer() {
  const app = express();

  // En Cloud Run / proxies inversos se recibe tráfico a través de balanceadores de carga
  app.set('trust proxy', true);

  // Parse JSON and text bodies with generous limits for sync and file uploads
  app.use(express.json({ limit: '50mb' }));
  app.use(express.text({ limit: '50mb', type: ['text/plain', 'application/json'] }));

  // Middleware CORS y Anti-Caché para máxima compatibilidad
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Content-Type, x-gas-url, Cache-Control, Pragma, Expires, X-Requested-With, If-Modified-Since'
    );
    res.setHeader('Access-Control-Expose-Headers', 'Cache-Control, Pragma, Content-Length, Content-Type, Date');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Anti-Caché estricto en respuestas de toda la API (/api/*)
  app.use('/api', (_req, res, next) => {
    for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
      res.setHeader(key, value);
    }
    next();
  });

  // Proxy seguro para Google Apps Script y Google Sheets con Rate Limiting
  // Resuelve 100% de los problemas de CORS, 302 redirects e iframes en el navegador
  app.all('/api/gas', gasLimiter, async (req: Request, res: Response) => {
    try {
      const headerUrl = req.headers['x-gas-url'] as string | undefined;
      const queryUrl = req.query.url as string | undefined;
      const rawTargetUrl = (headerUrl && headerUrl.trim()) || (queryUrl && queryUrl.trim()) || process.env.VITE_GAS_API_URL || DEFAULT_GAS_URL;
      const targetUrl = buildAntiCacheUrl(rawTargetUrl);

      let bodyData: string | undefined;
      if (req.method !== 'GET') {
        if (typeof req.body === 'string') {
          bodyData = req.body;
        } else if (req.body && typeof req.body === 'object') {
          bodyData = JSON.stringify(req.body);
        } else {
          bodyData = JSON.stringify({ action: 'ping' });
        }
      }

      const gasResponse = await fetch(targetUrl, {
        method: req.method === 'GET' ? 'GET' : 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: bodyData,
        redirect: 'follow'
      });

      const responseText = await gasResponse.text();
      res.status(gasResponse.status);
      res.setHeader('Content-Type', gasResponse.headers.get('content-type') || 'application/json; charset=utf-8');
      for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
        res.setHeader(key, value);
      }
      res.send(responseText);
    } catch (err: unknown) {
      console.error('[GAS Proxy Error]:', err);
      for (const [key, value] of Object.entries(SERVER_ANTI_CACHE_HEADERS)) {
        res.setHeader(key, value);
      }
      res.status(502).json({
        success: false,
        error: err instanceof Error ? err.message : 'Error comunicando con Google Apps Script',
        timestamp: new Date().toISOString()
      });
    }
  });

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // Favicon handler para evitar 404 en el navegador
  app.get(['/favicon.ico', '/favicon.svg'], (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'public', 'favicon.svg'));
  });

  const isProd = process.env.NODE_ENV === 'production';
  const distPath = path.resolve(__dirname, 'dist');
  const indexHtmlPath = path.resolve(distPath, 'index.html');
  const hasDist = fs.existsSync(indexHtmlPath);

  if (isProd && hasDist) {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(indexHtmlPath);
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SSOMA Server] Running on http://0.0.0.0:${PORT} (Proxy /api/gas enabled)`);
  });
}

startServer().catch((err) => {
  console.error('[SSOMA Server Startup Error]:', err);
  process.exit(1);
});
