import React, { useEffect } from 'react';
import { X, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { DriveImage } from './DriveImage';
import { getDriveImageSources } from '../../utils/imageUtils';

interface ImageLightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl?: string | null;
  title?: string;
  subtitle?: string;
}

export const ImageLightboxModal: React.FC<ImageLightboxModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  title = 'Evidencia Fotográfica',
  subtitle
}) => {
  const cleanUrl = imageUrl && typeof imageUrl === 'string' && imageUrl.trim().length > 0 ? imageUrl.trim() : null;
  const sources = getDriveImageSources(cleanUrl);

  useEffect(() => {
    if (!isOpen || !cleanUrl) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, cleanUrl, onClose]);

  if (!isOpen || !cleanUrl) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="image-lightbox-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className="relative max-w-4xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cabecera modal */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-100" aria-hidden="true">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 id="image-lightbox-title" className="text-sm font-bold text-[#0F172A]">{title}</h3>
              {subtitle && <p className="text-xs text-[#475569] line-clamp-1">{subtitle}</p>}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {sources.directWebUrl && (
              <a
                href={sources.directWebUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
                title="Abrir en pestaña nueva de Google Drive"
                aria-label="Abrir imagen original en nueva pestaña"
              >
                <ExternalLink className="w-4 h-4" aria-hidden="true" />
              </a>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors cursor-pointer"
              title="Cerrar visor (Esc)"
              aria-label="Cerrar visor de imagen"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Visor de imagen */}
        <div className="flex-1 bg-slate-900/95 p-4 flex items-center justify-center overflow-auto min-h-[300px]">
          <DriveImage
            src={cleanUrl}
            alt={title}
            className="max-h-[70vh] w-auto max-w-full object-contain rounded-lg shadow-lg"
            containerClassName="w-full h-full flex items-center justify-center bg-transparent"
          />
        </div>

        {/* Pie con opciones */}
        <div className="px-5 py-3 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500">
          <span className="truncate max-w-md text-[11px] font-mono">{imageUrl}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#1E293B] hover:bg-slate-800 text-white font-semibold text-xs transition-colors cursor-pointer shadow-2xs"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
