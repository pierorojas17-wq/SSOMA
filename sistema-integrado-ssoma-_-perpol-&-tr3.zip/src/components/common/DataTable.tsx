import React, { useState, useMemo } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { TablePagination } from './TablePagination';
import { TableEmptyState } from './TableEmptyState';
import { TableSkeleton } from './Loaders';

export interface ColumnDef<T> {
  key: string;
  header: React.ReactNode;
  accessor?: (row: T, index: number) => React.ReactNode;
  sortable?: boolean;
  sortKey?: keyof T | string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  className?: string;
  headerClassName?: string;
}

export interface DataTableProps<T> {
  columns: ColumnDef<T>[];
  data: T[];
  isLoading?: boolean;
  rowKey?: (row: T, index: number) => string;
  onRowClick?: (row: T) => void;

  // Ordenamiento
  sortable?: boolean;
  defaultSortKey?: string;
  defaultSortOrder?: 'asc' | 'desc';
  onSortChange?: (sortKey: string, order: 'asc' | 'desc') => void;

  // Paginación
  pagination?: boolean;
  currentPage?: number;
  pageSize?: number;
  totalItems?: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  pageSizeOptions?: number[];

  // Estados vacíos y acciones
  emptyTitle?: string;
  emptyDescription?: string;
  emptyActionLabel?: string;
  emptyActionIcon?: 'plus' | 'clear' | 'none';
  onEmptyAction?: () => void;
  actions?: (row: T, index: number) => React.ReactNode;
  actionsHeader?: string;
  actionsWidth?: string;

  // Estilos
  className?: string;
  striped?: boolean;
  dense?: boolean;
  stickyHeader?: boolean;
}

export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  isLoading = false,
  rowKey,
  onRowClick,
  sortable = true,
  defaultSortKey,
  defaultSortOrder = 'asc',
  onSortChange,
  pagination = true,
  currentPage: controlledPage,
  pageSize: controlledPageSize,
  totalItems: controlledTotalItems,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50, 100],
  emptyTitle = 'No se encontraron registros',
  emptyDescription = 'No hay datos disponibles para mostrar con los criterios actuales.',
  emptyActionLabel,
  emptyActionIcon = 'plus',
  onEmptyAction,
  actions,
  actionsHeader = 'Acciones',
  actionsWidth = 'w-24',
  className = '',
  striped = false,
  dense = false,
  stickyHeader = false
}: DataTableProps<T>) {
  // Estado local de ordenamiento si no es controlado
  const [internalSortKey, setInternalSortKey] = useState<string | undefined>(defaultSortKey);
  const [internalSortOrder, setInternalSortOrder] = useState<'asc' | 'desc'>(defaultSortOrder);

  // Estado local de paginación si no es controlado
  const [internalPage, setInternalPage] = useState<number>(1);
  const [internalPageSize, setInternalPageSize] = useState<number>(25);

  const currentPage = controlledPage !== undefined ? controlledPage : internalPage;
  const pageSize = controlledPageSize !== undefined ? controlledPageSize : internalPageSize;

  const handleSort = (colKey: string, explicitSortKey?: string) => {
    const key = explicitSortKey || colKey;
    let nextOrder: 'asc' | 'desc' = 'asc';
    if (internalSortKey === key) {
      nextOrder = internalSortOrder === 'asc' ? 'desc' : 'asc';
    }
    setInternalSortKey(key);
    setInternalSortOrder(nextOrder);
    if (onSortChange) {
      onSortChange(key, nextOrder);
    }
  };

  // Ordenamiento local cuando los datos se ordenan en cliente (no hay callback onSortChange externo)
  const sortedData = useMemo(() => {
    if (!internalSortKey || onSortChange) return data;
    return [...data].sort((a, b) => {
      const valA = a[internalSortKey];
      const valB = b[internalSortKey];

      if (valA === valB) return 0;
      if (valA === undefined || valA === null) return 1;
      if (valB === undefined || valB === null) return -1;

      let comparison = 0;
      if (typeof valA === 'number' && typeof valB === 'number') {
        comparison = valA - valB;
      } else {
        comparison = String(valA).localeCompare(String(valB), 'es', { numeric: true });
      }

      return internalSortOrder === 'asc' ? comparison : -comparison;
    });
  }, [data, internalSortKey, internalSortOrder, onSortChange]);

  // Paginación local si no está controlada externamente
  const paginatedData = useMemo(() => {
    if (!pagination || controlledPage !== undefined) {
      return sortedData;
    }
    const start = (currentPage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, pagination, controlledPage, currentPage, pageSize]);

  const totalItems = controlledTotalItems !== undefined ? controlledTotalItems : sortedData.length;

  const handlePageChange = (page: number) => {
    if (onPageChange) {
      onPageChange(page);
    } else {
      setInternalPage(page);
    }
  };

  const handlePageSizeChange = (newSize: number) => {
    if (onPageSizeChange) {
      onPageSizeChange(newSize);
    } else {
      setInternalPageSize(newSize);
      setInternalPage(1);
    }
  };

  if (isLoading) {
    return <TableSkeleton rows={pageSize > 15 ? 10 : pageSize} columns={columns.length + (actions ? 1 : 0)} />;
  }

  const totalCols = columns.length + (actions ? 1 : 0);

  return (
    <div className={`bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs ${className}`}>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-700">
          <thead
            className={`bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider select-none ${
              stickyHeader ? 'sticky top-0 z-10 shadow-2xs' : ''
            }`}
          >
            <tr>
              {columns.map((col) => {
                const isColSortable = sortable && col.sortable !== false;
                const activeSort = internalSortKey === (col.sortKey || col.key);

                const alignClass =
                  col.align === 'center'
                    ? 'text-center'
                    : col.align === 'right'
                    ? 'text-right'
                    : 'text-left';

                const ariaSortValue: 'ascending' | 'descending' | 'none' | undefined = isColSortable
                  ? activeSort
                    ? internalSortOrder === 'asc'
                      ? 'ascending'
                      : 'descending'
                    : 'none'
                  : undefined;

                const headerText = typeof col.header === 'string' ? col.header : String(col.key);

                return (
                  <th
                    key={col.key}
                    scope="col"
                    aria-sort={ariaSortValue}
                    tabIndex={isColSortable ? 0 : undefined}
                    aria-label={isColSortable ? `${headerText}, presione Enter o Espacio para ordenar` : undefined}
                    className={`px-4 ${dense ? 'py-2.5' : 'py-3'} ${col.width || ''} ${alignClass} ${
                      col.headerClassName || ''
                    } ${
                      isColSortable
                        ? 'cursor-pointer hover:bg-slate-100 transition-colors focus:outline-hidden focus:ring-2 focus:ring-[#10B981] focus:ring-inset'
                        : ''
                    }`}
                    onClick={() => {
                      if (isColSortable) {
                        handleSort(col.key, col.sortKey as string | undefined);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (isColSortable && (e.key === 'Enter' || e.key === ' ')) {
                        e.preventDefault();
                        handleSort(col.key, col.sortKey as string | undefined);
                      }
                    }}
                  >
                    <div
                      className={`inline-flex items-center gap-1.5 ${
                        col.align === 'right'
                          ? 'justify-end w-full'
                          : col.align === 'center'
                          ? 'justify-center w-full'
                          : 'justify-start'
                      }`}
                    >
                      <span>{col.header}</span>
                      {isColSortable && (
                        <span className="text-slate-400" aria-hidden="true">
                          {activeSort ? (
                            internalSortOrder === 'asc' ? (
                              <ArrowUp className="w-3 h-3 text-[#047857]" />
                            ) : (
                              <ArrowDown className="w-3 h-3 text-[#047857]" />
                            )
                          ) : (
                            <ArrowUpDown className="w-2.5 h-2.5 opacity-40 hover:opacity-100" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                );
              })}

              {actions && (
                <th
                  scope="col"
                  className={`px-4 ${dense ? 'py-2.5' : 'py-3'} ${actionsWidth} text-right whitespace-nowrap`}
                >
                  {actionsHeader}
                </th>
              )}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {paginatedData.length === 0 ? (
              <TableEmptyState
                isTableRow
                colSpan={totalCols}
                title={emptyTitle}
                description={emptyDescription}
                actionLabel={emptyActionLabel}
                actionIcon={emptyActionIcon}
                onAction={onEmptyAction}
              />
            ) : (
              paginatedData.map((row, rIdx) => {
                const key = rowKey ? rowKey(row, rIdx) : (row.id as string) || `row-${rIdx}`;
                const isClickable = Boolean(onRowClick);

                return (
                  <tr
                    key={key}
                    onClick={() => onRowClick && onRowClick(row)}
                    className={`transition-colors ${
                      striped && rIdx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'
                    } ${
                      isClickable
                        ? 'hover:bg-slate-50/90 cursor-pointer active:bg-slate-100'
                        : 'hover:bg-slate-50/60'
                    }`}
                  >
                    {columns.map((col) => {
                      const alignClass =
                        col.align === 'center'
                          ? 'text-center'
                          : col.align === 'right'
                          ? 'text-right'
                          : 'text-left';

                      const cellContent = col.accessor
                        ? col.accessor(row, rIdx)
                        : (row[col.key] as React.ReactNode);

                      return (
                        <td
                          key={`cell-${col.key}-${key}`}
                          className={`px-4 ${dense ? 'py-2' : 'py-3'} ${alignClass} ${
                            col.className || ''
                          }`}
                        >
                          {cellContent}
                        </td>
                      );
                    })}

                    {actions && (
                      <td
                        className={`px-4 ${dense ? 'py-2' : 'py-3'} text-right whitespace-nowrap`}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {actions(row, rIdx)}
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {pagination && totalItems > 0 && (
        <TablePagination
          currentPage={currentPage}
          totalItems={totalItems}
          pageSize={pageSize}
          onPageChange={handlePageChange}
          onPageSizeChange={handlePageSizeChange}
          pageSizeOptions={pageSizeOptions}
        />
      )}
    </div>
  );
}
