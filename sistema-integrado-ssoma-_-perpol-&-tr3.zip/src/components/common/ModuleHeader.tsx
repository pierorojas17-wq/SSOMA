import React from 'react';
import { useAppStore } from '../../store/appStore';
import { EMPRESAS } from '../../types';
import { Upload, Plus, RefreshCw } from 'lucide-react';

interface ModuleHeaderProps {
  codigo?: number;
  titulo: string;
  subtitulo: string;
  icono: React.ReactNode;
  onNuevo?: () => void;
  onImportar?: () => void;
  onRefrescar?: () => void;
  isLoading?: boolean;
  children?: React.ReactNode;
}

export const ModuleHeader: React.FC<ModuleHeaderProps> = ({
  titulo,
  subtitulo,
  icono,
  onNuevo,
  onImportar,
  onRefrescar,
  isLoading,
  children
}) => {
  const { empresaActiva } = useAppStore();
  const empresaInfo = empresaActiva === 'CONSOLIDADO' ? null : EMPRESAS[empresaActiva as 'PERPOL' | 'TR3'];

  return (
    <div className="mb-4 sm:mb-6 border border-[#E2E8F0] rounded-xl p-3.5 sm:p-5 shadow-xs transition-colors bg-white">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4">
        <div className="flex items-start gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-[#047857] shrink-0 mt-0.5">
            {icono}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base sm:text-lg md:text-xl font-bold tracking-tight text-[#0F172A] break-words">{titulo}</h1>
              {empresaInfo ? (
                <span className="text-[11px] sm:text-xs px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-[#047857] font-bold shrink-0">
                  {empresaInfo.id}
                </span>
              ) : (
                <span className="text-[11px] sm:text-xs px-2 py-0.5 rounded border font-semibold bg-[#F1F5F9] border-[#E2E8F0] text-[#475569] shrink-0">
                  Consolidado
                </span>
              )}
            </div>
            <p className="text-xs mt-1 text-[#475569] font-medium leading-relaxed">{subtitulo}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-stretch sm:self-auto justify-end">
          {children}

          {onRefrescar && (
            <button
              onClick={onRefrescar}
              disabled={isLoading}
              className="min-w-[36px] min-h-[36px] p-2 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] hover:bg-[#F1F5F9] text-[#1E293B] transition-colors disabled:opacity-50 cursor-pointer flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title="Refrescar datos desde Sheets"
              aria-label="Refrescar datos desde Google Sheets"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          )}

          {onImportar && (
            <button
              onClick={onImportar}
              className="min-h-[36px] flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] hover:bg-[#F1F5F9] text-[#1E293B] text-xs font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <Upload className="w-4 h-4 text-[#059669]" />
              <span className="hidden xs:inline">Importar Datos</span>
              <span className="xs:hidden">Importar</span>
            </button>
          )}

          {onNuevo && (
            <button
              onClick={onNuevo}
              className="min-h-[36px] flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <Plus className="w-4 h-4" />
              <span>Nuevo Registro</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
