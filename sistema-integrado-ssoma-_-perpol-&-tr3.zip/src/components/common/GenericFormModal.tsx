import React, { useState, useEffect } from 'react';
import { X, Save, AlertTriangle } from 'lucide-react';
import { Spinner } from './Loaders';

export type FormFieldType =
  | 'text'
  | 'number'
  | 'date'
  | 'time'
  | 'select'
  | 'textarea'
  | 'checkbox'
  | 'custom';

export interface FormFieldOption {
  value: string | number;
  label: string;
}

export interface FormField<T> {
  name: keyof T | string;
  label: string;
  type: FormFieldType;
  placeholder?: string;
  required?: boolean;
  options?: FormFieldOption[];
  helpText?: string;
  colSpan?: 1 | 2 | 3 | 4 | 'full';
  disabled?: boolean;
  min?: number | string;
  max?: number | string;
  step?: number | string;
  rows?: number;
  renderCustom?: (
    value: any,
    onChange: (val: any) => void,
    formData: Partial<T>,
    setFormData: React.Dispatch<React.SetStateAction<Partial<T>>>
  ) => React.ReactNode;
  validate?: (value: any, formData: Partial<T>) => string | null;
}

export interface GenericFormModalProps<T extends Record<string, any>> {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<T>) => Promise<void> | void;
  fields: FormField<T>[];
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  initialData?: Partial<T>;
  submitLabel?: string;
  cancelLabel?: string;
  columns?: 1 | 2 | 3 | 4;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl';
  isLoading?: boolean;
}

export function GenericFormModal<T extends Record<string, any>>({
  isOpen,
  onClose,
  onSave,
  fields,
  title,
  subtitle,
  icon,
  initialData,
  submitLabel = 'Guardar',
  cancelLabel = 'Cancelar',
  columns = 2,
  maxWidth = '2xl',
  isLoading = false
}: GenericFormModalProps<T>) {
  const [formData, setFormData] = useState<Partial<T>>(initialData || {});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Sincronizar estado cuando initialData cambie o el modal se abra
  useEffect(() => {
    if (isOpen) {
      setFormData(initialData || {});
      setErrors({});
      setGeneralError(null);
      setIsSubmitting(false);

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && !isSubmitting) {
          onClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, initialData, isSubmitting, onClose]);

  if (!isOpen) return null;

  const handleChange = (fieldKey: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [fieldKey]: value
    }));

    // Limpiar error del campo
    if (errors[fieldKey]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[fieldKey];
        return next;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    fields.forEach((f) => {
      const fieldKey = String(f.name);
      const val = formData[fieldKey];

      if (f.required) {
        if (val === undefined || val === null || String(val).trim() === '') {
          newErrors[fieldKey] = `El campo ${f.label} es obligatorio.`;
        }
      }

      if (f.validate) {
        const customErr = f.validate(val, formData);
        if (customErr) {
          newErrors[fieldKey] = customErr;
        }
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);

    if (!validateForm()) {
      setGeneralError('Por favor complete los campos obligatorios antes de continuar.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onSave(formData);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al procesar el formulario';
      setGeneralError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const maxWidthMap = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
    '3xl': 'max-w-3xl',
    '4xl': 'max-w-4xl'
  };

  const gridColsMap = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 md:grid-cols-4'
  };

  const getColSpanClass = (span?: 1 | 2 | 3 | 4 | 'full') => {
    if (span === 'full' || span === 4) return 'col-span-full';
    if (span === 3) return 'sm:col-span-2 md:col-span-3';
    if (span === 2) return 'sm:col-span-2';
    return 'col-span-1';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={() => !isSubmitting && onClose()}
        aria-hidden="true"
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="generic-form-modal-title"
        className={`relative z-10 bg-white border border-[#E2E8F0] rounded-2xl w-full ${maxWidthMap[maxWidth]} max-h-[calc(100dvh-2rem)] flex flex-col shadow-2xl overflow-hidden my-auto text-[#0F172A] cursor-default select-text`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="sticky top-0 z-20 px-4 sm:px-6 py-3 sm:py-4 bg-[#F8FAFC] border-b border-[#E2E8F0] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 pr-2">
            {icon && (
              <div className="w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-[#047857] flex items-center justify-center shrink-0" aria-hidden="true">
                {icon}
              </div>
            )}
            <div className="min-w-0">
              <h3 id="generic-form-modal-title" className="text-sm sm:text-base font-bold text-[#0F172A] truncate">{title}</h3>
              {subtitle && <p className="text-xs text-[#475569] font-medium truncate">{subtitle}</p>}
            </div>
          </div>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={onClose}
            className="min-w-[36px] min-h-[36px] flex items-center justify-center p-1.5 rounded-lg text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9] active:bg-[#E2E8F0] transition-colors cursor-pointer shrink-0 disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            title="Cerrar modal (Esc)"
            aria-label="Cerrar modal de formulario"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-4 sm:p-6 space-y-3.5 sm:space-y-4 text-xs text-[#475569] overflow-y-auto flex-1">
            {generalError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-[#DC2626] rounded-xl flex items-center gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 text-[#DC2626] shrink-0" />
                <span>{generalError}</span>
              </div>
            )}

            <div className={`grid ${gridColsMap[columns]} gap-4`}>
              {fields.map((f) => {
                const fieldKey = String(f.name);
                const inputId = `gform-field-${fieldKey}`;
                const errId = `gform-err-${fieldKey}`;
                const helpId = `gform-help-${fieldKey}`;
                const value = formData[fieldKey] ?? '';
                const fieldError = errors[fieldKey];
                const colSpanClass = getColSpanClass(f.colSpan);

                return (
                  <div key={fieldKey} className={`space-y-1.5 ${colSpanClass}`}>
                    {f.type !== 'checkbox' && (
                      <label htmlFor={inputId} className="block text-xs font-semibold text-[#0F172A]">
                        {f.label}
                        {f.required && <span className="text-[#DC2626] ml-0.5" aria-hidden="true">*</span>}
                      </label>
                    )}

                    {/* Custom renderer */}
                    {f.type === 'custom' && f.renderCustom ? (
                      f.renderCustom(
                        value,
                        (val) => handleChange(fieldKey, val),
                        formData,
                        setFormData
                      )
                    ) : f.type === 'select' ? (
                      <select
                        id={inputId}
                        value={value}
                        disabled={f.disabled || isSubmitting}
                        aria-invalid={Boolean(fieldError)}
                        aria-describedby={fieldError ? errId : f.helpText ? helpId : undefined}
                        onChange={(e) => handleChange(fieldKey, e.target.value)}
                        className={`w-full bg-white border ${
                          fieldError ? 'border-[#DC2626]' : 'border-[#CBD5E1]'
                        } rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] transition-all disabled:bg-[#F1F5F9] disabled:cursor-not-allowed`}
                      >
                        <option value="">{f.placeholder || 'Seleccione una opción...'}</option>
                        {f.options?.map((opt) => (
                          <option key={String(opt.value)} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    ) : f.type === 'textarea' ? (
                      <textarea
                        id={inputId}
                        rows={f.rows || 3}
                        value={value}
                        disabled={f.disabled || isSubmitting}
                        placeholder={f.placeholder}
                        aria-invalid={Boolean(fieldError)}
                        aria-describedby={fieldError ? errId : f.helpText ? helpId : undefined}
                        onChange={(e) => handleChange(fieldKey, e.target.value)}
                        className={`w-full bg-white border ${
                          fieldError ? 'border-[#DC2626]' : 'border-[#CBD5E1]'
                        } rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-none focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] transition-all disabled:bg-[#F1F5F9] disabled:cursor-not-allowed`}
                      />
                    ) : f.type === 'checkbox' ? (
                      <label htmlFor={inputId} className="flex items-center gap-2 cursor-pointer pt-1">
                        <input
                          id={inputId}
                          type="checkbox"
                          checked={Boolean(value)}
                          disabled={f.disabled || isSubmitting}
                          aria-invalid={Boolean(fieldError)}
                          aria-describedby={fieldError ? errId : f.helpText ? helpId : undefined}
                          onChange={(e) => handleChange(fieldKey, e.target.checked)}
                          className="w-4 h-4 text-[#047857] border-[#CBD5E1] rounded focus:ring-[#10B981]"
                        />
                        <span className="text-xs text-[#0F172A]">{f.helpText || f.label}</span>
                      </label>
                    ) : (
                      <input
                        id={inputId}
                        type={f.type}
                        value={value}
                        disabled={f.disabled || isSubmitting}
                        placeholder={f.placeholder}
                        min={f.min}
                        max={f.max}
                        step={f.step}
                        aria-invalid={Boolean(fieldError)}
                        aria-describedby={fieldError ? errId : f.helpText ? helpId : undefined}
                        onChange={(e) =>
                          handleChange(
                            fieldKey,
                            f.type === 'number'
                              ? e.target.value === ''
                                ? ''
                                : Number(e.target.value)
                              : e.target.value
                          )
                        }
                        className={`w-full bg-white border ${
                          fieldError ? 'border-[#DC2626]' : 'border-[#CBD5E1]'
                        } rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-none focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] transition-all disabled:bg-[#F1F5F9] disabled:cursor-not-allowed`}
                      />
                    )}

                    {fieldError ? (
                      <p id={errId} role="alert" className="text-[11px] text-[#DC2626] font-medium">{fieldError}</p>
                    ) : f.helpText && f.type !== 'checkbox' ? (
                      <p id={helpId} className="text-[11px] text-[#475569]">{f.helpText}</p>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Modal Footer */}
          <div className="px-4 sm:px-6 py-3 bg-[#F8FAFC] border-t border-[#E2E8F0] flex flex-wrap items-center justify-end gap-2 sm:gap-2.5 shrink-0">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={onClose}
              className="min-h-[38px] px-4 py-2 rounded-lg bg-white hover:bg-[#F1F5F9] active:bg-[#E2E8F0] border border-[#CBD5E1] text-[#1E293B] text-xs font-semibold transition-colors cursor-pointer shadow-2xs disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              {cancelLabel}
            </button>
            <button
              type="submit"
              disabled={isSubmitting || isLoading}
              className="min-h-[38px] flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white text-xs font-bold transition-colors shadow-2xs cursor-pointer disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              {isSubmitting ? (
                <>
                  <Spinner size="xs" color="white" />
                  <span>Guardando...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 text-white" />
                  <span>{submitLabel}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
