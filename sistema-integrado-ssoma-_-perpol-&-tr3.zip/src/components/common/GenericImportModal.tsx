import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ModuleImportSchema } from '../../utils/moduleImportSchemas';
import { BulkDataImporter, SpreadsheetInfo, ParseResult } from '../../utils/fileImporter';
import {
  ImportValidationEngine,
  ValidationSummary,
  BatchProgress,
  BatchImportResult
} from '../../utils/importValidationEngine';
import { useAppStore } from '../../store/appStore';
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  X,
  ArrowRight,
  ArrowLeft,
  Download,
  RefreshCw,
  Sliders,
  Check,
  Database
} from 'lucide-react';

interface GenericImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  schema: ModuleImportSchema;
  onImportSuccess?: (importedRows: Record<string, unknown>[]) => void;
  onSuccessImport?: (importedRows: Record<string, unknown>[]) => void;
  defaultEmpresa?: 'PERPOL' | 'TR3';
}

type ImportStep = 'upload' | 'mapping' | 'validation' | 'executing' | 'summary';

export const GenericImportModal: React.FC<GenericImportModalProps> = ({
  isOpen,
  onClose,
  schema,
  onImportSuccess,
  onSuccessImport,
  defaultEmpresa
}) => {
  const { empresaActiva, accidentes, trabajadores, inspecciones, addToast } = useAppStore();
  const effectiveEmpresa = (empresaActiva !== 'CONSOLIDADO' ? empresaActiva : defaultEmpresa || 'PERPOL') as 'PERPOL' | 'TR3';

  // Cerrar modal al pulsar tecla Escape
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Estados de flujo
  const [currentStep, setCurrentStep] = useState<ImportStep>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [spreadsheetInfo, setSpreadsheetInfo] = useState<SpreadsheetInfo | null>(null);
  const [selectedWorksheet, setSelectedWorksheet] = useState<string>('');
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);

  // Datos analizados
  const [parsedData, setParsedData] = useState<ParseResult | null>(null);
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({}); // fieldKey -> fileHeader

  // Modo de importación
  const [importMode, setImportMode] = useState<'upsert' | 'insertar' | 'actualizar'>('upsert');

  // Validación y progreso
  const [validationSummary, setValidationSummary] = useState<ValidationSummary | null>(null);
  const [batchProgress, setBatchProgress] = useState<BatchProgress | null>(null);
  const [batchResult, setBatchResult] = useState<BatchImportResult | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Conjuntos de claves maestras para validación relacional
  const masterRecords = useMemo(() => {
    const accIds = new Set<string>();
    accidentes.forEach((a) => {
      if (a.codigoCaso !== undefined && a.codigoCaso !== null) accIds.add(String(a.codigoCaso).trim());
      if (a.id !== undefined && a.id !== null) accIds.add(String(a.id).trim());
    });

    const trabDnis = new Set<string>();
    trabajadores.forEach((t) => {
      if (t.dni !== undefined && t.dni !== null) trabDnis.add(String(t.dni).trim());
      if (t.id !== undefined && t.id !== null) trabDnis.add(String(t.id).trim());
    });

    const inspIds = new Set<string>();
    inspecciones.forEach((i) => {
      if (i.codigoInspeccion !== undefined && i.codigoInspeccion !== null) inspIds.add(String(i.codigoInspeccion).trim());
      if (i.id !== undefined && i.id !== null) inspIds.add(String(i.id).trim());
    });

    return {
      accidentesIds: accIds,
      trabajadoresDnis: trabDnis,
      inspeccionesIds: inspIds
    };
  }, [accidentes, trabajadores, inspecciones]);

  // Si el modal está cerrado, no renderizar
  if (!isOpen) return null;

  // Descargar plantilla oficial
  const handleDownloadTemplate = () => {
    const headers = schema.fields.map((f) => f.key);
    BulkDataImporter.downloadTemplate(
      headers,
      `${schema.moduleId}_${empresaActiva}`,
      schema.sampleRow,
      schema.moduleName
    );
    addToast({
      type: 'info',
      title: 'Plantilla Descargada',
      message: `Plantilla Excel para ${schema.moduleName} generada.`
    });
  };

  // Manejar selección de archivo
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processSelectedFile(file);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    await processSelectedFile(file);
  };

  const processSelectedFile = async (file: File) => {
    setIsLoadingFile(true);
    setParseError(null);
    setSelectedFile(file);

    try {
      const info = await BulkDataImporter.inspectFile(file);
      setSpreadsheetInfo(info);
      setSelectedWorksheet(info.selectedSheet);

      // Parsear la primera hoja seleccionada
      const parsed = await BulkDataImporter.parseFileSheet(file, info.selectedSheet);
      setParsedData(parsed);

      // Sugerir auto-mapeo inteligente
      const suggested = ImportValidationEngine.autoSuggestMapping(parsed.headers, schema);
      setColumnMapping(suggested);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al procesar el archivo';
      setParseError(msg);
      addToast({ type: 'error', title: 'Error de Lectura', message: msg });
    } finally {
      setIsLoadingFile(false);
    }
  };

  // Cambiar hoja de trabajo de Excel
  const handleWorksheetChange = async (sheetName: string) => {
    if (!selectedFile) return;
    setSelectedWorksheet(sheetName);
    setIsLoadingFile(true);
    setParseError(null);

    try {
      const parsed = await BulkDataImporter.parseFileSheet(selectedFile, sheetName);
      setParsedData(parsed);
      const suggested = ImportValidationEngine.autoSuggestMapping(parsed.headers, schema);
      setColumnMapping(suggested);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al cambiar hoja de trabajo';
      setParseError(msg);
    } finally {
      setIsLoadingFile(false);
    }
  };

  // Pasar al paso de validación
  const handleProceedToValidation = () => {
    if (!parsedData || parsedData.rows.length === 0) {
      addToast({
        type: 'warning',
        title: 'Sin Datos',
        message: 'El archivo seleccionado no contiene filas para importar.'
      });
      return;
    }

    // Verificar que al menos los campos obligatorios estén mapeados
    const missingRequired = schema.fields
      .filter((f) => f.required && !columnMapping[f.key])
      .map((f) => f.label);

    if (missingRequired.length > 0) {
      addToast({
        type: 'error',
        title: 'Campos Obligatorios sin Mapear',
        message: `Debe asociar una columna para: ${missingRequired.slice(0, 3).join(', ')}${
          missingRequired.length > 3 ? ` y ${missingRequired.length - 3} más` : ''
        }`
      });
      return;
    }

    // Ejecutar motor de validación en el cliente
    const summary = ImportValidationEngine.validateRows(
      parsedData.rows,
      columnMapping,
      schema,
      masterRecords
    );

    setValidationSummary(summary);
    setCurrentStep('validation');
  };

  // Ejecutar importación por lotes
  const handleExecuteImport = async () => {
    if (!validationSummary) return;

    // Filtrar solo las filas válidas (o las que no tienen error crítico)
    const rowsToSend = validationSummary.transformedRows.filter((r) => !r.__hasError);

    if (rowsToSend.length === 0) {
      addToast({
        type: 'error',
        title: 'Sin Filas Válidas',
        message: 'No hay filas sin errores críticos para enviar al backend.'
      });
      return;
    }

    setCurrentStep('executing');
    setBatchProgress({
      currentBatch: 0,
      totalBatches: Math.ceil(rowsToSend.length / 50),
      percent: 0,
      processedRows: 0,
      totalRows: rowsToSend.length,
      status: 'transmitting',
      message: 'Iniciando transmisión segura por lotes...'
    });

    try {
      const result = await ImportValidationEngine.executeBatchImport(
        rowsToSend,
        schema,
        importMode,
        effectiveEmpresa,
        (progress) => setBatchProgress(progress),
        50 // tamaño del lote
      );

      setBatchResult(result);
      setCurrentStep('summary');

      if (result.success) {
        addToast({
          type: 'success',
          title: 'Importación Completada',
          message: `Se procesaron exitosamente ${result.createdCount + result.updatedCount} registros.`
        });

        if (onImportSuccess) {
          onImportSuccess(rowsToSend);
        }
        if (onSuccessImport) {
          onSuccessImport(rowsToSend);
        }
      } else {
        addToast({
          type: 'warning',
          title: 'Importación Parcial',
          message: 'Hubo observaciones en algunos lotes enviados al backend.'
        });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error en la transmisión por lotes';
      addToast({ type: 'error', title: 'Fallo de Importación', message: msg });
      setCurrentStep('validation');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="generic-import-title"
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto"
      >
        {/* Cabecera del Modal */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700" aria-hidden="true">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="generic-import-title" className="text-base font-bold text-slate-900 tracking-tight">
                  Importador Masivo — {schema.moduleName}
                </h2>
                <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px] font-mono text-emerald-700 font-semibold">
                  {schema.sheetName}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Procesamiento local 100% en el cliente con PapaParse y SheetJS (evita timeouts de GAS)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Descargar plantilla de Excel formateada"
              aria-label="Descargar plantilla de Excel formateada"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
              <span>Plantilla Excel</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-500 hover:text-slate-800 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              title="Cerrar modal de importación (Esc)"
              aria-label="Cerrar modal de importación"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Barra de Pasos (Stepper) */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'upload'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
              }`}
            >
              1
            </div>
            <span className={currentStep === 'upload' ? 'text-slate-900 font-bold' : 'text-slate-600 font-medium'}>
              Cargar Archivo
            </span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />

          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'mapping'
                  ? 'bg-emerald-600 text-white'
                  : currentStep === 'validation' || currentStep === 'executing' || currentStep === 'summary'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              2
            </div>
            <span className={currentStep === 'mapping' ? 'text-slate-900 font-bold' : 'text-slate-600 font-medium'}>
              Mapeo y Vista Previa
            </span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />

          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'validation'
                  ? 'bg-emerald-600 text-white'
                  : currentStep === 'executing' || currentStep === 'summary'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              3
            </div>
            <span className={currentStep === 'validation' ? 'text-slate-900 font-bold' : 'text-slate-600 font-medium'}>
              Validación
            </span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />

          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'executing' || currentStep === 'summary'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              4
            </div>
            <span className={currentStep === 'executing' || currentStep === 'summary' ? 'text-slate-900 font-bold' : 'text-slate-600 font-medium'}>
              Lotes y Resumen
            </span>
          </div>
        </div>

        {/* Cuerpo del Modal con Scroll */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* ========================================================================= */}
          {/* PASO 1: SELECCIÓN DE ARCHIVO Y HOJA DE CÁLCULO                             */}
          {/* ========================================================================= */}
          {currentStep === 'upload' && (
            <div className="space-y-5">
              {/* Zona Drag & Drop */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50 hover:bg-emerald-50/20 rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileSpreadsheet className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  Arrastre su archivo Excel (.xlsx, .xls) o CSV aquí
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Haga clic para examinar desde su equipo. Los datos se leerán íntegramente en su navegador para máxima velocidad y seguridad.
                </p>
                <div className="mt-4 flex items-center justify-center gap-3 text-[11px] text-slate-400 font-mono">
                  <span>• Compatible con PapaParse</span>
                  <span>• Compatible con SheetJS</span>
                  <span>• Preserva 0 en DNI/RUC</span>
                </div>
              </div>

              {/* Archivo cargado con éxito */}
              {selectedFile && parsedData && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-700 border border-emerald-200">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">
                        {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Detectadas <strong className="text-emerald-700">{parsedData.totalRows} filas</strong> y{' '}
                        <strong className="text-emerald-700">{parsedData.headers.length} columnas</strong>
                      </div>
                    </div>
                  </div>

                  {/* Selector de hoja si el archivo es Excel */}
                  {spreadsheetInfo && spreadsheetInfo.isExcel && spreadsheetInfo.sheetNames.length > 1 && (
                    <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-xs">
                      <span className="text-slate-500">Hoja Excel:</span>
                      <select
                        value={selectedWorksheet}
                        onChange={(e) => handleWorksheetChange(e.target.value)}
                        className="bg-transparent text-slate-900 font-semibold focus:outline-none cursor-pointer"
                      >
                        {spreadsheetInfo.sheetNames.map((sheet) => (
                          <option key={sheet} value={sheet} className="bg-white text-slate-900">
                            {sheet}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}

              {parseError && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-2.5">
                  <AlertOctagon className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold">Error de lectura del archivo</div>
                    <div className="mt-0.5 text-rose-400/90">{parseError}</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASO 2: MAPEO DE COLUMNAS Y VISTA PREVIA                                  */}
          {/* ========================================================================= */}
          {currentStep === 'mapping' && parsedData && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-emerald-600" />
                    <span>Mapeo Inteligente de Columnas</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Haga coincidir las columnas de su archivo con los campos esperados por el sistema SSOMA
                  </p>
                </div>

                <div className="text-[11px] text-slate-600 bg-slate-100 px-3 py-1 rounded-lg border border-slate-200">
                  Archivo:{' '}
                  <strong className="text-slate-900 font-semibold">{parsedData.fileName}</strong>{' '}
                  ({parsedData.totalRows} filas)
                </div>
              </div>

              {/* Tabla de Mapeo */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-2.5 px-4">Campo Esperado en SSOMA</th>
                      <th className="py-2.5 px-3">Tipo / Regla</th>
                      <th className="py-2.5 px-4">Columna en su Archivo</th>
                      <th className="py-2.5 px-3 text-center">Estado de Mapeo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {schema.fields.map((field) => {
                      const selectedHeader = columnMapping[field.key] || '';
                      const isMapped = !!selectedHeader;

                      return (
                        <tr key={field.key} className="hover:bg-slate-50 transition-colors">
                          <td className="py-2 px-4">
                            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                              <span>{field.label}</span>
                              {field.required && (
                                <span className="text-rose-500 text-xs font-bold" title="Campo obligatorio">
                                  *
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              clave: {field.key}
                            </div>
                          </td>

                          <td className="py-2 px-3">
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-600">
                              {field.type}
                              {field.preserveZeros ? ' [0 inicial]' : ''}
                            </span>
                          </td>

                          <td className="py-2 px-4">
                            <select
                              value={selectedHeader}
                              aria-label={`Mapear columna de origen para el campo ${field.label}`}
                              onChange={(e) =>
                                setColumnMapping({
                                  ...columnMapping,
                                  [field.key]: e.target.value
                                })
                              }
                              className={`w-full bg-white border rounded-lg px-2.5 py-1.5 text-xs focus:outline-none transition-colors ${
                                isMapped
                                  ? 'border-emerald-500 text-emerald-800 font-semibold'
                                  : field.required
                                  ? 'border-rose-400 text-rose-700 bg-rose-50'
                                  : 'border-slate-200 text-slate-600'
                              }`}
                            >
                              <option value="">-- Omitir este campo --</option>
                              {parsedData.headers.map((hdr) => (
                                <option key={hdr} value={hdr} className="bg-white text-slate-900">
                                  {hdr}
                                </option>
                              ))}
                            </select>
                          </td>

                          <td className="py-2 px-3 text-center">
                            {isMapped ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded text-[10px] font-bold">
                                <Check className="w-3 h-3" />
                                Mapeado
                              </span>
                            ) : field.required ? (
                              <span className="inline-flex items-center gap-1 text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded text-[10px] font-bold">
                                Requerido
                              </span>
                            ) : (
                              <span className="text-slate-600 text-[10px]">Opcional</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Vista Previa de Primeras Filas */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800">
                    Vista Previa de Transformación (Primeras 5 filas)
                  </span>
                  <span className="text-[11px] text-slate-600 font-medium">
                    Se importará en modo:{' '}
                    <strong className="text-emerald-700 uppercase font-bold">{importMode}</strong>
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-x-auto p-3 text-[11px] font-mono">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-600 pb-1 font-bold">
                        <th className="pr-3 pb-1">#</th>
                        {schema.fields.map((f) => (
                          <th key={f.key} className="pr-4 pb-1 font-bold text-slate-800">
                            {f.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-slate-800">
                      {parsedData.rows.slice(0, 5).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-100/60">
                          <td className="pr-3 py-1.5 text-slate-600 font-bold">{idx + 1}</td>
                          {schema.fields.map((f) => {
                            const mappedCol = columnMapping[f.key];
                            const val = mappedCol ? row[mappedCol] : '-';
                            return (
                              <td key={f.key} className="pr-4 py-1.5 whitespace-nowrap">
                                {val !== undefined && val !== null && String(val).trim() !== ''
                                  ? String(val)
                                  : <span className="text-slate-500 font-normal italic">vacío</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASO 3: VALIDACIÓN EN CLIENTE Y DETECCIÓN DE ERRORES                      */}
          {/* ========================================================================= */}
          {currentStep === 'validation' && validationSummary && (
            <div className="space-y-6">
              {/* Tarjetas de Métricas de Validación */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-center">
                  <div className="text-[10px] text-slate-600 font-bold uppercase">Total Filas</div>
                  <div className="text-2xl font-bold text-slate-900 mt-0.5">
                    {validationSummary.totalRows}
                  </div>
                </div>

                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-center">
                  <div className="text-[10px] text-emerald-700 font-bold uppercase flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Filas Válidas</span>
                  </div>
                  <div className="text-2xl font-bold text-emerald-700 mt-0.5">
                    {validationSummary.validRowsCount}
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-center">
                  <div className="text-[10px] text-amber-700 font-bold uppercase flex items-center justify-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-amber-600" />
                    <span>Advertencias</span>
                  </div>
                  <div className="text-2xl font-bold text-amber-700 mt-0.5">
                    {validationSummary.warningRowsCount}
                  </div>
                </div>

                <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-center">
                  <div className="text-[10px] text-rose-700 font-bold uppercase flex items-center justify-center gap-1">
                    <AlertOctagon className="w-3 h-3 text-rose-600" />
                    <span>Rechazadas</span>
                  </div>
                  <div className="text-2xl font-bold text-rose-700 mt-0.5">
                    {validationSummary.criticalRowsCount}
                  </div>
                </div>
              </div>

              {/* Selector de Modo de Importación */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Estrategia de Persistencia (Upsert / Inserción):</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <label
                    className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer text-xs transition-colors ${
                      importMode === 'upsert'
                        ? 'border-emerald-500 bg-white text-slate-900 shadow-2xs'
                        : 'border-slate-200 bg-white/60 text-slate-600 hover:text-slate-900 hover:bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="upsert"
                      checked={importMode === 'upsert'}
                      onChange={() => setImportMode('upsert')}
                      className="mt-0.5 text-emerald-600"
                    />
                    <div>
                      <div className="font-bold text-slate-900">Upsert (Recomendado)</div>
                      <div className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                        Inserta nuevos registros y actualiza los existentes según la clave primaria ({schema.primaryKey}).
                      </div>
                    </div>
                  </label>

                  <label
                    className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer text-xs transition-colors ${
                      importMode === 'insertar'
                        ? 'border-emerald-500 bg-white text-slate-900 shadow-2xs'
                        : 'border-slate-200 bg-white/60 text-slate-600 hover:text-slate-900 hover:bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="insertar"
                      checked={importMode === 'insertar'}
                      onChange={() => setImportMode('insertar')}
                      className="mt-0.5 text-emerald-600"
                    />
                    <div>
                      <div className="font-bold text-slate-900">Solo Nuevos</div>
                      <div className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                        Omite las filas cuya clave primaria ya exista en la hoja de cálculo.
                      </div>
                    </div>
                  </label>

                  <label
                    className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer text-xs transition-colors ${
                      importMode === 'actualizar'
                        ? 'border-emerald-500 bg-white text-slate-900 shadow-2xs'
                        : 'border-slate-200 bg-white/60 text-slate-600 hover:text-slate-900 hover:bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="actualizar"
                      checked={importMode === 'actualizar'}
                      onChange={() => setImportMode('actualizar')}
                      className="mt-0.5 text-emerald-600"
                    />
                    <div>
                      <div className="font-bold text-slate-900">Solo Actualizar</div>
                      <div className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                        Actualiza únicamente registros existentes. Omite nuevos registros no encontrados.
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Lista Detallada de Observaciones y Errores */}
              {validationSummary.errors.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">
                      Detalle de Validaciones ({validationSummary.errors.length} observaciones)
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Las filas con errores críticos serán excluidas automáticamente.
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl max-h-48 overflow-y-auto divide-y divide-slate-200 text-xs">
                    {validationSummary.errors.map((err, idx) => (
                      <div key={idx} className="p-2.5 flex items-start gap-2.5 hover:bg-slate-100/60">
                        {err.isCritical ? (
                          <AlertOctagon className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        )}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold font-mono text-slate-800">
                              Fila {err.rowNumber}
                            </span>
                            <span className="text-slate-400">•</span>
                            <span className="text-slate-600">{err.fieldLabel}</span>
                          </div>
                          <p className={`text-[11px] mt-0.5 ${err.isCritical ? 'text-rose-600' : 'text-amber-600'}`}>
                            {err.message}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASO 4: TRANSMISIÓN POR LOTES Y PROGRESO                                  */}
          {/* ========================================================================= */}
          {currentStep === 'executing' && batchProgress && (
            <div className="py-8 px-4 text-center space-y-5">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 animate-pulse">
                <RefreshCw className="w-8 h-8 animate-spin" />
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Procesando Importación por Lotes
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  {batchProgress.message}
                </p>
              </div>

              {/* Barra de progreso */}
              <div className="max-w-md mx-auto space-y-2">
                <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${batchProgress.percent}%` }}
                  />
                </div>

                <div className="flex justify-between text-xs font-mono text-slate-600 font-medium">
                  <span>
                    Lote {batchProgress.currentBatch} de {batchProgress.totalBatches}
                  </span>
                  <span>{batchProgress.percent}%</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 max-w-sm mx-auto">
                Los registros se envían en bloques de 50 filas directamente a{' '}
                <strong className="text-slate-700">{schema.sheetName}</strong> mediante{' '}
                <code>setValues()</code> atómico en Google Apps Script.
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASO 5: RESUMEN FINAL                                                     */}
          {/* ========================================================================= */}
          {currentStep === 'summary' && batchResult && (
            <div className="space-y-6 text-center py-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-700 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  ¡Importación por Lotes Finalizada con Éxito!
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  Los datos han sido incorporados en la base de datos de {schema.moduleName}.
                </p>
              </div>

              {/* Resumen de conteos */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto">
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5">
                  <div className="text-[10px] text-emerald-700 uppercase font-bold">Creados</div>
                  <div className="text-2xl font-bold text-emerald-800 mt-0.5">
                    {batchResult.createdCount}
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5">
                  <div className="text-[10px] text-blue-700 uppercase font-bold">Actualizados</div>
                  <div className="text-2xl font-bold text-blue-800 mt-0.5">
                    {batchResult.updatedCount}
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                  <div className="text-[10px] text-slate-600 uppercase font-bold">Omitidos</div>
                  <div className="text-2xl font-bold text-slate-800 mt-0.5">
                    {batchResult.skippedCount}
                  </div>
                </div>

                <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5">
                  <div className="text-[10px] text-rose-700 uppercase font-bold">Rechazados</div>
                  <div className="text-2xl font-bold text-rose-800 mt-0.5">
                    {batchResult.rejectedCount}
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-slate-600 font-mono font-medium">
                Tiempo de procesamiento: {(batchResult.executionTimeMs / 1000).toFixed(2)}s | Modo: {importMode}
              </div>
            </div>
          )}
        </div>

        {/* Pie del Modal con Botones de Navegación */}
        <div className="p-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            {currentStep === 'mapping' && (
              <button
                onClick={() => setCurrentStep('upload')}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Volver a Archivo</span>
              </button>
            )}
            {currentStep === 'validation' && (
              <button
                onClick={() => setCurrentStep('mapping')}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Ajustar Mapeo</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {currentStep !== 'summary' && currentStep !== 'executing' && (
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold cursor-pointer transition-colors"
              >
                Cancelar
              </button>
            )}

            {currentStep === 'upload' && (
              <button
                disabled={!parsedData || isLoadingFile}
                onClick={() => setCurrentStep('mapping')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
              >
                <span>Configurar Mapeo</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}

            {currentStep === 'mapping' && (
              <button
                onClick={handleProceedToValidation}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                <span>Validar Datos</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}

            {currentStep === 'validation' && (
              <button
                onClick={handleExecuteImport}
                disabled={!validationSummary || validationSummary.validRowsCount === 0}
                className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>
                  Confirmar e Importar {validationSummary?.validRowsCount || 0} Filas
                </span>
              </button>
            )}

            {currentStep === 'summary' && (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                <span>Finalizar y Ver Registros</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
