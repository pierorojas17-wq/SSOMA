import React from 'react';
import { ShieldCheck, Loader2 } from 'lucide-react';

export interface LoadingScreenProps {
  message?: string;
  subMessage?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({
  message = 'Cargando módulo SSOMA...',
  subMessage = 'Preparando entorno de gestión'
}) => {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-200">
      <div className="relative mb-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] flex items-center justify-center text-white shadow-lg border border-slate-700/30">
          <ShieldCheck className="w-8 h-8 text-[#10B981]" />
        </div>
        <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full shadow-md border border-slate-200">
          <Loader2 className="w-4 h-4 animate-spin text-[#047857]" />
        </div>
      </div>
      <h3 className="text-sm font-bold text-[#0F172A] tracking-tight">{message}</h3>
      <p className="text-xs text-[#475569] mt-1">{subMessage}</p>
    </div>
  );
};
