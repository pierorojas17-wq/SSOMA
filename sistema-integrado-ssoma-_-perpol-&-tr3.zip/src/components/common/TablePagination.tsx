import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react';

interface TablePaginationProps {
  currentPage: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (newPage: number) => void;
  onPageSizeChange?: (newPageSize: number) => void;
  pageSizeOptions?: number[];
  className?: string;
}

export const TablePagination: React.FC<TablePaginationProps> = ({
  currentPage,
  totalItems,
  pageSize,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50, 100],
  className = ''
}) => {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(Math.max(1, currentPage), totalPages);

  const startItem = totalItems === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const endItem = Math.min(safePage * pageSize, totalItems);

  // Generar números de página visibles
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 5;

    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (safePage <= 3) {
        pages.push(1, 2, 3, 4, '...', totalPages);
      } else if (safePage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', safePage - 1, safePage, safePage + 1, '...', totalPages);
      }
    }
    return pages;
  };

  if (totalItems === 0) {
    return null;
  }

  return (
    <nav
      role="navigation"
      aria-label="Paginación de tabla"
      className={`flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-3 bg-white border-t border-[#E2E8F0] text-xs text-[#475569] ${className}`}
    >
      {/* Resumen de registros y selector de tamaño */}
      <div className="flex items-center gap-3 flex-wrap">
        <span aria-live="polite" aria-atomic="true">
          Mostrando{' '}
          <strong className="text-[#0F172A] font-semibold">{startItem}</strong> a{' '}
          <strong className="text-[#0F172A] font-semibold">{endItem}</strong> de{' '}
          <strong className="text-[#0F172A] font-semibold">{totalItems}</strong> registros
        </span>

        {onPageSizeChange && (
          <div className="flex items-center gap-1.5 pl-3 border-l border-[#E2E8F0]">
            <label htmlFor="table-page-size-select" className="text-[#475569] text-[11px]">Por página:</label>
            <select
              id="table-page-size-select"
              aria-label="Registros por página"
              value={pageSize}
              onChange={(e) => onPageSizeChange(Number(e.target.value))}
              className="bg-white border border-[#CBD5E1] text-[#0F172A] text-xs rounded-md px-2 py-1 focus:ring-1 focus:ring-[#10B981] focus:outline-hidden cursor-pointer"
            >
              {pageSizeOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Controles de navegación */}
      <div className="flex items-center gap-1">
        {/* Ir al inicio */}
        <button
          type="button"
          onClick={() => onPageChange(1)}
          disabled={safePage === 1}
          className="min-w-[32px] min-h-[32px] p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          title="Primera página"
          aria-label="Ir a la primera página"
        >
          <ChevronsLeft className="w-3.5 h-3.5" aria-hidden="true" />
        </button>

        {/* Anterior */}
        <button
          type="button"
          onClick={() => onPageChange(safePage - 1)}
          disabled={safePage === 1}
          className="min-w-[32px] min-h-[32px] p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          title="Página anterior"
          aria-label="Ir a la página anterior"
        >
          <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
        </button>

        {/* Números de página */}
        <div className="hidden sm:flex items-center gap-1 px-1">
          {getPageNumbers().map((page, idx) =>
            typeof page === 'number' ? (
              <button
                key={idx}
                type="button"
                onClick={() => onPageChange(page)}
                aria-current={safePage === page ? 'page' : undefined}
                aria-label={`Ir a la página ${page}`}
                className={`min-w-[32px] min-h-[32px] px-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                  safePage === page
                    ? 'bg-[#1E293B] !text-white shadow-2xs active'
                    : 'bg-white border border-[#CBD5E1] text-[#1E293B] hover:bg-[#F1F5F9]'
                }`}
              >
                {page}
              </button>
            ) : (
              <span key={idx} className="px-1 text-slate-400" aria-hidden="true">
                {page}
              </span>
            )
          )}
        </div>

        {/* Indicador móvil */}
        <span className="sm:hidden text-xs px-2 text-[#475569] font-semibold" aria-label={`Página actual ${safePage} de ${totalPages}`}>
          {safePage} / {totalPages}
        </span>

        {/* Siguiente */}
        <button
          type="button"
          onClick={() => onPageChange(safePage + 1)}
          disabled={safePage === totalPages}
          className="min-w-[32px] min-h-[32px] p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          title="Página siguiente"
          aria-label="Ir a la página siguiente"
        >
          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>

        {/* Ir al final */}
        <button
          type="button"
          onClick={() => onPageChange(totalPages)}
          disabled={safePage === totalPages}
          className="min-w-[32px] min-h-[32px] p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          title="Última página"
          aria-label="Ir a la última página"
        >
          <ChevronsRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
      </div>
    </nav>
  );
};
