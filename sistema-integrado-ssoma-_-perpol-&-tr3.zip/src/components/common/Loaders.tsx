import React from 'react';
import { Loader2 } from 'lucide-react';

/**
 * Spinner simple adaptable con tamaños y colores corporativos
 */
export interface SpinnerProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  color?: 'brand' | 'white' | 'muted' | 'teal' | 'amber';
  label?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({
  size = 'md',
  className = '',
  color = 'brand',
  label
}) => {
  const sizeMap = {
    xs: 'w-3 h-3',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  };

  const colorMap = {
    brand: 'text-[#047857]',
    white: 'text-white',
    muted: 'text-slate-400',
    teal: 'text-[#059669]',
    amber: 'text-[#D97706]'
  };

  return (
    <div className={`inline-flex items-center gap-2 ${className}`} role="status">
      <Loader2 className={`animate-spin ${sizeMap[size]} ${colorMap[color]}`} />
      {label && <span className="text-xs text-slate-500 font-medium">{label}</span>}
      <span className="sr-only">Cargando...</span>
    </div>
  );
};

/**
 * Overlay de carga a pantalla completa o contenedor relativo
 */
export interface LoadingOverlayProps {
  message?: string;
  subMessage?: string;
  isFixed?: boolean;
}

export const LoadingOverlay: React.FC<LoadingOverlayProps> = ({
  message = 'Sincronizando información...',
  subMessage = 'Por favor espere un momento',
  isFixed = false
}) => {
  const positionClass = isFixed
    ? 'fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs'
    : 'absolute inset-0 z-20 bg-white/70 backdrop-blur-2xs';

  return (
    <div className={`${positionClass} flex flex-col items-center justify-center p-4 transition-all duration-200`}>
      <div className="bg-white px-6 py-5 rounded-2xl shadow-xl border border-slate-200/80 flex flex-col items-center text-center max-w-xs animate-in fade-in zoom-in-95 duration-200">
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-[#047857] rounded-xl mb-3">
          <Loader2 className="w-6 h-6 animate-spin text-[#047857]" />
        </div>
        <p className="text-xs font-bold text-[#0F172A]">{message}</p>
        {subMessage && <p className="text-[11px] text-[#475569] mt-1">{subMessage}</p>}
      </div>
    </div>
  );
};

/**
 * Skeleton Loader para Tablas de Datos
 */
export interface TableSkeletonProps {
  rows?: number;
  columns?: number;
  showHeader?: boolean;
  className?: string;
}

export const TableSkeleton: React.FC<TableSkeletonProps> = ({
  rows = 6,
  columns = 7,
  showHeader = true,
  className = ''
}) => {
  return (
    <div className={`bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs animate-pulse ${className}`}>
      {showHeader && (
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex gap-4">
          {Array.from({ length: columns }).map((_, i) => (
            <div
              key={`th-skel-${i}`}
              className="h-3 bg-slate-200 rounded-md"
              style={{ width: `${Math.max(45, 90 - (i % 3) * 15)}px` }}
            />
          ))}
        </div>
      )}
      <div className="divide-y divide-slate-100">
        {Array.from({ length: rows }).map((_, rIdx) => (
          <div key={`tr-skel-${rIdx}`} className="px-4 py-3.5 flex items-center gap-4">
            {Array.from({ length: columns }).map((_, cIdx) => (
              <div
                key={`td-skel-${rIdx}-${cIdx}`}
                className="h-3.5 bg-slate-100 rounded"
                style={{
                  width: cIdx === 0 ? '70px' : cIdx === 1 ? '90px' : cIdx === columns - 1 ? '60px' : '100%',
                  opacity: 1 - (rIdx % 3) * 0.15
                }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

/**
 * Skeleton Loader para Tarjetas KPI / Métricas
 */
export interface CardSkeletonProps {
  count?: number;
  columns?: 2 | 3 | 4 | 5;
  className?: string;
}

export const CardSkeleton: React.FC<CardSkeletonProps> = ({
  count = 4,
  columns = 4,
  className = ''
}) => {
  const colGridMap = {
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-3',
    4: 'grid-cols-2 md:grid-cols-4',
    5: 'grid-cols-2 md:grid-cols-5'
  };

  return (
    <div className={`grid ${colGridMap[columns]} gap-3 ${className}`}>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={`card-skel-${i}`}
          className="bg-white border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between shadow-xs animate-pulse space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="h-3 bg-slate-200 rounded w-20" />
            <div className="w-5 h-5 bg-slate-200 rounded-md" />
          </div>
          <div className="h-7 bg-slate-300 rounded w-16" />
          <div className="h-2.5 bg-slate-100 rounded w-28" />
        </div>
      ))}
    </div>
  );
};

/**
 * Skeleton Loader para Formularios
 */
export interface FormSkeletonProps {
  fields?: number;
  columns?: 1 | 2 | 3;
  className?: string;
}

export const FormSkeleton: React.FC<FormSkeletonProps> = ({
  fields = 6,
  columns = 2,
  className = ''
}) => {
  const gridMap = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-3'
  };

  return (
    <div className={`bg-white border border-slate-200 rounded-2xl p-6 shadow-xs animate-pulse space-y-6 ${className}`}>
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div className="space-y-1.5">
          <div className="h-4 bg-slate-300 rounded w-48" />
          <div className="h-3 bg-slate-200 rounded w-72" />
        </div>
        <div className="h-8 bg-slate-200 rounded-lg w-28" />
      </div>

      <div className={`grid ${gridMap[columns]} gap-4`}>
        {Array.from({ length: fields }).map((_, i) => (
          <div key={`field-skel-${i}`} className="space-y-1.5">
            <div className="h-3 bg-slate-200 rounded w-24" />
            <div className="h-9 bg-slate-100 border border-slate-200 rounded-lg w-full" />
          </div>
        ))}
      </div>

      <div className="pt-4 border-t border-slate-100 flex justify-end gap-2.5">
        <div className="h-9 bg-slate-200 rounded-lg w-20" />
        <div className="h-9 bg-slate-300 rounded-lg w-32" />
      </div>
    </div>
  );
};

/**
 * Skeleton Loader para Fichas y Modales de Detalle
 */
export const DetailSkeleton: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`space-y-4 animate-pulse ${className}`}>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={`detail-cell-${i}`} className="space-y-1">
            <div className="h-2.5 bg-slate-200 rounded w-16" />
            <div className="h-4 bg-slate-300 rounded w-24" />
          </div>
        ))}
      </div>
      <div className="space-y-2">
        <div className="h-3 bg-slate-200 rounded w-32" />
        <div className="h-20 bg-slate-100 rounded-xl border border-slate-200" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="h-32 bg-slate-50 rounded-xl border border-slate-200" />
        <div className="h-32 bg-slate-50 rounded-xl border border-slate-200" />
      </div>
    </div>
  );
};
