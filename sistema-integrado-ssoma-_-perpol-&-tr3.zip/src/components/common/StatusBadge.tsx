import React from 'react';

export type StatusVariant =
  | 'success' // Verde suave: Cerrado, Subsanado, Apto, Cumplido, Operativo
  | 'warning' // Ámbar suave: En Proceso, Pendiente, Observado, Riesgo Medio
  | 'danger'  // Rojo suave: Abierto, Vencido, No Apto, Grave, Crítico, Fatal
  | 'info'    // Azul/Cian suave: Registrado, Informativo, Bajo Riesgo
  | 'neutral'; // Gris suave: Borrador, No Aplica, Desconocido

interface StatusBadgeProps {
  status: string;
  variant?: StatusVariant;
  size?: 'xs' | 'sm' | 'md';
  showDot?: boolean;
  className?: string;
  onClick?: () => void;
}

/**
 * Mapeo inteligente automático de estados y severidades comunes del sistema SSOMA
 */
export function getStatusVariant(status: string): StatusVariant {
  const s = (status || '').toLowerCase().trim();

  // Estados de éxito / cerrados / aptos
  if (
    s.includes('cerrad') ||
    s.includes('subsanad') ||
    s.includes('apto') ||
    s.includes('cumplid') ||
    s.includes('operativ') ||
    s.includes('completad') ||
    s.includes('activo') ||
    s.includes('bajo') ||
    s.includes('leve')
  ) {
    return 'success';
  }

  // Estados de advertencia / en proceso
  if (
    s.includes('proceso') ||
    s.includes('seguimiento') ||
    s.includes('pendient') ||
    s.includes('observad') ||
    s.includes('medio') ||
    s.includes('moderado') ||
    s.includes('regular') ||
    s.includes('en curso')
  ) {
    return 'warning';
  }

  // Estados de peligro / abiertos / críticos / vencidos
  if (
    s.includes('abiert') ||
    s.includes('vencid') ||
    s.includes('no apto') ||
    s.includes('grave') ||
    s.includes('alto') ||
    s.includes('crític') ||
    s.includes('critic') ||
    s.includes('fatal') ||
    s.includes('incapacitant') ||
    s.includes('urgente')
  ) {
    return 'danger';
  }

  // Estados informativos
  if (
    s.includes('registrad') ||
    s.includes('programad') ||
    s.includes('evaluacion') ||
    s.includes('evaluación') ||
    s.includes('revis')
  ) {
    return 'info';
  }

  return 'neutral';
}

const variantStyles: Record<StatusVariant, { badge: string; dot: string }> = {
  success: {
    badge: 'bg-emerald-50 text-emerald-900 border-emerald-200',
    dot: 'bg-[#059669]'
  },
  warning: {
    badge: 'bg-amber-50 text-amber-900 border-amber-200',
    dot: 'bg-[#D97706]'
  },
  danger: {
    badge: 'bg-red-50 text-red-900 border-red-200',
    dot: 'bg-[#DC2626]'
  },
  info: {
    badge: 'bg-sky-50 text-sky-900 border-sky-200',
    dot: 'bg-[#0284C7]'
  },
  neutral: {
    badge: 'bg-slate-100 text-slate-800 border-slate-200',
    dot: 'bg-slate-500'
  }
};

const sizeStyles = {
  xs: 'text-[10px] px-2 py-0.5 gap-1',
  sm: 'text-xs px-2.5 py-0.5 gap-1.5',
  md: 'text-xs px-3 py-1 gap-1.5 font-medium'
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  variant,
  size = 'xs',
  showDot = true,
  className = '',
  onClick
}) => {
  const chosenVariant = variant || getStatusVariant(status);
  const styles = variantStyles[chosenVariant];
  const sizeClass = sizeStyles[size];

  const clickableClasses = onClick
    ? 'cursor-pointer hover:opacity-85 active:scale-95 transition-all focus:outline-hidden focus:ring-2 focus:ring-[#10B981] focus:ring-offset-1'
    : '';

  return (
    <span
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      aria-label={onClick ? `Estado: ${status || 'Sin Estado'}. Clic para ver o editar seguimiento` : undefined}
      onClick={onClick}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
      className={`inline-flex items-center font-semibold rounded-full border tracking-wide whitespace-nowrap shadow-2xs ${styles.badge} ${sizeClass} ${clickableClasses} ${className}`}
    >
      {showDot && (
        <span
          className={`w-1.5 h-1.5 rounded-full shrink-0 ${styles.dot}`}
          aria-hidden="true"
        />
      )}
      <span>{status || 'Sin Estado'}</span>
    </span>
  );
};
