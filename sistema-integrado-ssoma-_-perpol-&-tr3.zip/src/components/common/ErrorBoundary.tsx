import { Component, ErrorInfo, ReactNode } from 'react';
import {
  RefreshCw,
  RotateCcw,
  WifiOff,
  ServerCrash,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  showDetails: boolean;
  isRecovering: boolean;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
      isRecovering: false
    };
  }

  public static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      error
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    this.setState({ errorInfo });
    // Registrar error silenciosamente para trazabilidad
    try {
      console.error('[SSOMA Error Boundary] Excepción no controlada:', error, errorInfo);
    } catch {
      // Ignorar en entornos donde console está bloqueado
    }
  }

  private handleReset = (): void => {
    this.setState({ isRecovering: true });
    setTimeout(() => {
      this.setState({
        hasError: false,
        error: null,
        errorInfo: null,
        isRecovering: false
      });
    }, 400);
  };

  private handleReload = (): void => {
    window.location.reload();
  };

  private handleContinueLocal = (): void => {
    try {
      // Limpiar datos transitorios que pudieron causar conflicto
      sessionStorage.removeItem('ssoma_temp_state');
    } catch {
      // Ignorar
    }
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
      isRecovering: false
    });
    window.location.hash = '#/';
  };

  public render(): ReactNode {
    if (this.state.hasError) {
      const errorMessage = this.state.error?.message || 'Error desconocido';
      const isDynamicImportError =
        errorMessage.toLowerCase().includes('dynamically imported module') ||
        errorMessage.toLowerCase().includes('importing a module script failed') ||
        errorMessage.toLowerCase().includes('loading chunk');

      const isNetworkOrGasError =
        !isDynamicImportError &&
        (errorMessage.toLowerCase().includes('fetch') ||
        errorMessage.toLowerCase().includes('network') ||
        errorMessage.toLowerCase().includes('timeout') ||
        errorMessage.toLowerCase().includes('apps script') ||
        errorMessage.toLowerCase().includes('gas') ||
        errorMessage.toLowerCase().includes('cuota') ||
        errorMessage.toLowerCase().includes('quota'));

      return (
        <div className="min-h-screen bg-slate-50 text-slate-800 flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-xl p-6 sm:p-8 space-y-6 animate-fadeIn">
            {/* Cabecera con Icono */}
            <div className="flex items-start gap-4">
              <div
                className={`p-3 rounded-2xl shrink-0 ${
                  isDynamicImportError
                    ? 'bg-blue-50 border border-blue-200 text-blue-600'
                    : isNetworkOrGasError
                    ? 'bg-amber-50 border border-amber-200 text-amber-600'
                    : 'bg-rose-50 border border-rose-200 text-rose-600'
                }`}
              >
                {isDynamicImportError ? (
                  <RefreshCw className="w-8 h-8 animate-spin" />
                ) : isNetworkOrGasError ? (
                  <WifiOff className="w-8 h-8" />
                ) : (
                  <ServerCrash className="w-8 h-8" />
                )}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px] font-mono uppercase text-slate-600 font-semibold tracking-wider">
                    {isDynamicImportError ? 'Actualización' : isNetworkOrGasError ? 'Servicio Externo' : 'Error en Interfaz'}
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">SSOMA Platform</span>
                </div>
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
                  {isDynamicImportError
                    ? 'Actualización de Componentes Detectada'
                    : isNetworkOrGasError
                    ? 'Dificultad de Conexión con Google Apps Script'
                    : 'Interrupción Temporal de la Interfaz'}
                </h1>
                <p className="text-xs text-slate-600 mt-1">
                  {isDynamicImportError
                    ? 'Se compilaron nuevos cambios en el servidor. Presione el botón de recarga para cargar la versión más reciente en su navegador sin afectar sus datos.'
                    : isNetworkOrGasError
                    ? 'El servidor de Google Apps Script tardó en responder o se excedió la cuota de peticiones. La información en caché local se encuentra protegida.'
                    : 'Ocurrió una excepción inesperada en el renderizado de la pantalla. Puede reiniciar la vista o continuar en modo fuera de línea.'}
                </p>
              </div>
            </div>

            {/* Aviso de Continuidad Operativa */}
            <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3.5 flex items-start gap-3 text-xs text-emerald-900">
              <ShieldAlert className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-emerald-950">Sus datos están seguros:</span> El sistema cuenta con
                persistencia en almacenamiento local para PERPOL y TR3. Las operaciones pendientes se conservan en memoria para su sincronización posterior.
              </div>
            </div>

            {/* Detalle Técnico Plegable */}
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
              <button
                type="button"
                onClick={() => this.setState({ showDetails: !this.state.showDetails })}
                className="w-full px-4 py-2.5 flex items-center justify-between text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <span className="font-mono text-[11px]">Detalle técnico del error</span>
                {this.state.showDetails ? (
                  <ChevronUp className="w-3.5 h-3.5" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5" />
                )}
              </button>

              {this.state.showDetails && (
                <div className="p-4 border-t border-slate-200 bg-white text-[11px] font-mono text-rose-700 space-y-2 max-h-48 overflow-y-auto">
                  <div className="font-bold text-rose-800">
                    {this.state.error?.name}: {this.state.error?.message}
                  </div>
                  {this.state.errorInfo?.componentStack && (
                    <pre className="text-[10px] text-slate-500 whitespace-pre-wrap">
                      {this.state.errorInfo.componentStack}
                    </pre>
                  )}
                </div>
              )}
            </div>

            {/* Botones de Recuperación */}
            <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={this.handleReset}
                disabled={this.state.isRecovering}
                className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${this.state.isRecovering ? 'animate-spin' : ''}`} />
                <span>Reintentar Operación</span>
              </button>

              <button
                type="button"
                onClick={this.handleReload}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Recargar Aplicación</span>
              </button>

              <button
                type="button"
                onClick={this.handleContinueLocal}
                className="w-full sm:w-auto px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-600 hover:text-slate-900 text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Ir al Panel Principal</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
