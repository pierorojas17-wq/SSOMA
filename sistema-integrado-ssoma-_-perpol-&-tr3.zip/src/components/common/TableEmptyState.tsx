import React from 'react';
import { SearchX, Plus, RotateCcw } from 'lucide-react';

interface TableEmptyStateProps {
  title?: string;
  description?: string;
  icon?: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  actionIcon?: 'clear' | 'plus' | 'none';
  isTableRow?: boolean;
  colSpan?: number;
  className?: string;
}

export const TableEmptyState: React.FC<TableEmptyStateProps> = ({
  title = 'No se encontraron registros',
  description = 'No hay datos disponibles para mostrar con los criterios actuales.',
  icon,
  actionLabel,
  onAction,
  actionIcon = 'clear',
  isTableRow = false,
  colSpan = 8,
  className = ''
}) => {
  const content = (
    <div className={`py-12 px-4 flex flex-col items-center justify-center text-center ${className}`}>
      <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200/80 flex items-center justify-center text-slate-400 mb-3 shadow-2xs">
        {icon || <SearchX className="w-6 h-6 text-slate-400" />}
      </div>
      <h3 className="text-sm font-semibold text-slate-800">{title}</h3>
      <p className="text-xs text-slate-500 max-w-sm mt-1 mb-4 leading-relaxed">
        {description}
      </p>

      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
        >
          {actionIcon === 'clear' && <RotateCcw className="w-3.5 h-3.5 text-slate-500" />}
          {actionIcon === 'plus' && <Plus className="w-3.5 h-3.5 text-emerald-600" />}
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );

  if (isTableRow) {
    return (
      <tr>
        <td colSpan={colSpan} className="p-0">
          {content}
        </td>
      </tr>
    );
  }

  return <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">{content}</div>;
};
