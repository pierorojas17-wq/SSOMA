import React from 'react';
import { Search, X, FileSpreadsheet, FileText, Plus } from 'lucide-react';

export interface FilterChipOption {
  id: string;
  label: string;
  count?: number;
}

interface ModuleToolbarProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  searchPlaceholder?: string;
  // Chips de filtro rápido por estado (opcional)
  statusFilter?: string;
  onStatusFilterChange?: (statusId: string) => void;
  statusOptions?: FilterChipOption[];
  // Botones de exportación y nuevo
  onExportExcel?: () => void;
  onExportPdf?: () => void;
  onNewRecord?: () => void;
  newRecordLabel?: string;
  // Botones y filtros adicionales
  totalCount?: number;
  filteredCount?: number;
  isLoading?: boolean;
  children?: React.ReactNode;
  className?: string;
}

export const ModuleToolbar: React.FC<ModuleToolbarProps> = ({
  searchQuery,
  onSearchChange,
  searchPlaceholder = 'Buscar...',
  statusFilter,
  onStatusFilterChange,
  statusOptions,
  onExportExcel,
  onExportPdf,
  onNewRecord,
  newRecordLabel = 'Nuevo Registro',
  totalCount,
  filteredCount,
  isLoading = false,
  children,
  className = ''
}) => {
  return (
    <div className={`space-y-3 mb-4 ${className}`}>
      {/* Fila principal: Buscador + Controles de acción */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 sm:gap-3">
        {/* Input de búsqueda */}
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#64748B] pointer-events-none" aria-hidden="true" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={searchPlaceholder}
            aria-label={searchPlaceholder || "Buscar registros en este módulo"}
            className="w-full pl-9 pr-8 py-2 min-h-[38px] rounded-lg bg-white border border-[#CBD5E1] text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] focus:border-[#10B981] shadow-2xs transition-all font-medium"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#64748B] hover:text-[#0F172A] cursor-pointer p-1 rounded-md focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title="Limpiar búsqueda"
              aria-label="Limpiar campo de búsqueda"
            >
              <X className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          )}
        </div>

        {/* Grupo de acciones: Exportar + Nuevo Registro */}
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {children}

          {onExportExcel && (
            <button
              type="button"
              onClick={onExportExcel}
              disabled={isLoading}
              className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] text-xs font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title="Exportar registros a archivo Excel"
              aria-label="Exportar registros a archivo Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-[#059669]" aria-hidden="true" />
              <span>Excel</span>
            </button>
          )}

          {onExportPdf && (
            <button
              type="button"
              onClick={onExportPdf}
              disabled={isLoading}
              className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] text-xs font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title="Exportar reporte a formato PDF"
              aria-label="Exportar reporte a formato PDF"
            >
              <FileText className="w-3.5 h-3.5 text-[#DC2626]" aria-hidden="true" />
              <span>PDF</span>
            </button>
          )}

          {onNewRecord && (
            <button
              type="button"
              onClick={onNewRecord}
              aria-label={newRecordLabel}
              className="min-h-[36px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-semibold text-xs transition-colors shadow-2xs cursor-pointer active:scale-98 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>{newRecordLabel}</span>
            </button>
          )}
        </div>
      </div>

      {/* Fila secundaria: Chips de filtrado rápido y conteo (opcional) */}
      {(statusOptions && statusOptions.length > 0) || totalCount !== undefined ? (
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#E2E8F0]">
          {/* Chips */}
          {statusOptions && onStatusFilterChange && (
            <div className="flex items-center gap-1.5 flex-wrap" role="group" aria-label="Filtrar por estado">
              <span className="text-[11px] font-semibold text-[#475569] mr-1" id="filter-group-label">Filtrar:</span>
              {statusOptions.map((opt) => {
                const isActive = statusFilter === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    aria-pressed={isActive}
                    onClick={() => onStatusFilterChange(opt.id)}
                    className={`min-h-[30px] inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                      isActive
                        ? 'bg-[#1E293B] text-white shadow-2xs'
                        : 'bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#475569] border border-[#CBD5E1]'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {opt.count !== undefined && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                          isActive
                            ? 'bg-white/20 text-white'
                            : 'bg-white text-[#0F172A] border border-[#CBD5E1]'
                        }`}
                      >
                        {opt.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Conteo de registros */}
          {totalCount !== undefined && (
            <div className="text-[11px] text-[#475569] font-medium ml-auto">
              Total:{' '}
              <strong className="text-[#0F172A] font-semibold">
                {filteredCount !== undefined && filteredCount !== totalCount
                  ? `${filteredCount} de ${totalCount}`
                  : totalCount}
              </strong>{' '}
              registros
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
};
