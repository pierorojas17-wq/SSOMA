import React, { useState, useEffect } from 'react';
import { ExternalLink, ImageOff, RefreshCw, Eye } from 'lucide-react';
import { getDriveImageSources } from '../../utils/imageUtils';

interface DriveImageProps {
  src?: string | null;
  driveId?: string | null;
  alt?: string;
  className?: string;
  containerClassName?: string;
  onClick?: () => void;
  showOpenButton?: boolean;
}

export const DriveImage: React.FC<DriveImageProps> = ({
  src,
  driveId,
  alt = 'Evidencia fotográfica',
  className = 'max-h-full max-w-full object-contain rounded-lg',
  containerClassName = 'w-full h-full flex items-center justify-center relative group',
  onClick,
  showOpenButton = true
}) => {
  const sources = getDriveImageSources(src, driveId);
  const [currentSrc, setCurrentSrc] = useState<string>(sources.primaryUrl);
  const [hasError, setHasError] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [retryCount, setRetryCount] = useState<number>(0);

  // Reiniciar estados si cambian las propiedades de origen
  useEffect(() => {
    const s = getDriveImageSources(src, driveId);
    setCurrentSrc(s.primaryUrl);
    setHasError(false);
    setIsLoading(true);
    setRetryCount(0);
  }, [src, driveId]);

  const handleError = () => {
    if (sources.isDrive) {
      if (retryCount === 0 && currentSrc !== sources.secondaryUrl) {
        // Intento 2: Conmutar al servicio de miniaturas de Google Drive
        setRetryCount(1);
        setCurrentSrc(sources.secondaryUrl);
        return;
      }
      if (retryCount === 1 && currentSrc !== sources.tertiaryUrl) {
        // Intento 3: Conmutar a export view de Google Drive
        setRetryCount(2);
        setCurrentSrc(sources.tertiaryUrl);
        return;
      }
    }
    // Agotados los intentos automáticos
    setIsLoading(false);
    setHasError(true);
  };

  const handleLoad = () => {
    setIsLoading(false);
    setHasError(false);
  };

  // Si no se proporcionó URL ni ID válido
  if (!src && !driveId) {
    return (
      <div className={`bg-slate-100 text-slate-400 p-4 rounded-xl border border-dashed border-slate-300 flex flex-col items-center justify-center gap-1.5 text-center ${containerClassName}`}>
        <ImageOff className="w-6 h-6 text-slate-400" />
        <span className="text-[11px] font-medium text-slate-500">Sin evidencia adjunta</span>
      </div>
    );
  }

  // Si la imagen no pudo ser incrustada directamente (por restricciones de dominio corporativo de Drive)
  if (hasError) {
    return (
      <div className={`bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col items-center justify-center gap-2 text-center ${containerClassName}`}>
        <div className="w-9 h-9 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center">
          <Eye className="w-5 h-5 text-emerald-600" />
        </div>
        <div className="space-y-0.5">
          <p className="text-xs font-bold text-slate-800">{alt}</p>
          <p className="text-[10px] text-slate-500 leading-tight">
            Almacenada con seguridad en Google Drive
          </p>
        </div>
        {sources.directWebUrl && (
          <a
            href={sources.directWebUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-1 inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Ver Imagen en Drive</span>
          </a>
        )}
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-slate-100/80 rounded-xl ${containerClassName}`}>
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-100 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin text-emerald-600" />
        </div>
      )}

      <img
        src={currentSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        loading="lazy"
        onLoad={handleLoad}
        onError={handleError}
        onClick={onClick}
        className={`${className} ${isLoading ? 'opacity-0' : 'opacity-100 transition-opacity duration-200'} ${onClick ? 'cursor-pointer hover:opacity-95' : ''}`}
      />

      {/* Botón flotante para abrir en Drive si es archivo de Drive */}
      {!isLoading && !hasError && showOpenButton && sources.directWebUrl && (
        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
          <a
            href={sources.directWebUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-1.5 bg-slate-900/80 hover:bg-slate-900 text-white rounded-md text-[11px] font-medium flex items-center gap-1 backdrop-blur-xs shadow-md"
            title="Abrir imagen original en Google Drive"
            onClick={(e) => e.stopPropagation()}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Drive</span>
          </a>
        </div>
      )}
    </div>
  );
};
