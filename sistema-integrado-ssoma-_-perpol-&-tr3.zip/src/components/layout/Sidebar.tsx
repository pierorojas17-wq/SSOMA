import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAppStore } from '../../store/appStore';
import {
  LayoutDashboard,
  AlertOctagon,
  HeartPulse,
  ClipboardCheck,
  ShieldAlert,
  Cross,
  Users,
  Clock,
  CalendarCheck2,
  BarChart3,
  Calculator,
  Search,
  Settings,
  Lock,
  X
} from 'lucide-react';
import { isValidAdminPin } from '../../config/secrets';

interface NavItem {
  id: string;
  codigo: number;
  nombre: string;
  ruta: string;
  icono: React.ReactNode;
  badge?: string;
  badgeColor?: string;
}

export const MODULOS_SSOMA: NavItem[] = [
  {
    id: 'accidentes',
    codigo: 1,
    nombre: 'Accidentes de Trabajo',
    ruta: '/accidentes',
    icono: <AlertOctagon className="w-4 h-4 text-rose-500" />
  },
  {
    id: 'atenciones-medicas',
    codigo: 2,
    nombre: 'Atenciones Médicas',
    ruta: '/atenciones-medicas',
    icono: <HeartPulse className="w-4 h-4 text-teal-400" />
  },
  {
    id: 'inspecciones',
    codigo: 3,
    nombre: 'Inspecciones SST',
    ruta: '/inspecciones',
    icono: <ClipboardCheck className="w-4 h-4 text-emerald-500" />
  },
  {
    id: 'actos-condiciones',
    codigo: 4,
    nombre: 'Actos y Condiciones',
    ruta: '/actos-condiciones',
    icono: <ShieldAlert className="w-4 h-4 text-amber-500" />
  },
  {
    id: 'botiquin',
    codigo: 5,
    nombre: 'Consumo de Botiquín',
    ruta: '/botiquin',
    icono: <Cross className="w-4 h-4 text-teal-500" />
  },
  {
    id: 'trabajadores',
    codigo: 6,
    nombre: 'Base de Trabajadores',
    ruta: '/trabajadores',
    icono: <Users className="w-4 h-4 text-blue-500" />
  },
  {
    id: 'horas-hombre',
    codigo: 7,
    nombre: 'Horas-Hombre (HH)',
    ruta: '/horas-hombre',
    icono: <Clock className="w-4 h-4 text-cyan-400" />
  },
  {
    id: 'programa-anual',
    codigo: 8,
    nombre: 'Programa Anual SST',
    ruta: '/programa-anual',
    icono: <CalendarCheck2 className="w-4 h-4 text-indigo-500" />
  },
  {
    id: 'estadisticas',
    codigo: 9,
    nombre: 'Estadísticas SST',
    ruta: '/estadisticas',
    icono: <BarChart3 className="w-4 h-4 text-violet-500" />
  },
  {
    id: 'simulacion-costos',
    codigo: 10,
    nombre: 'Simulación de Costos',
    ruta: '/simulacion-costos',
    icono: <Calculator className="w-4 h-4 text-emerald-500" />
  },
  {
    id: 'investigacion',
    codigo: 11,
    nombre: 'Investigación de Accidentes',
    ruta: '/investigacion',
    icono: <Search className="w-4 h-4 text-red-500" />
  }
];

export const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { sidebarOpen, setSidebarOpen } = useAppStore();

  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinValue, setPinValue] = useState('');
  const [pinError, setPinError] = useState('');

  // Cerrar el drawer en pantallas pequeñas al navegar
  const handleNavClick = () => {
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleConfigClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setPinValue('');
    setPinError('');
    setPinModalOpen(true);
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isValidAdminPin(pinValue)) {
      setPinModalOpen(false);
      setPinValue('');
      setPinError('');
      navigate('/configuracion');
      handleNavClick();
    } else {
      setPinError('Código PIN incorrecto. Acceso denegado.');
      setPinValue('');
    }
  };

  return (
    <>
      {/* Backdrop para dispositivos móviles */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 bg-slate-900/50 z-20 md:hidden backdrop-blur-xs transition-opacity"
          aria-hidden="true"
        />
      )}

      {/* Contenedor de la barra lateral */}
      <aside
        id="main-sidebar"
        aria-label="Navegación principal del sistema"
        className={`fixed top-[53px] bottom-0 left-0 z-20 w-64 border-r flex flex-col transition-transform duration-300 ease-in-out shadow-lg md:shadow-none bg-white border-[#E2E8F0] text-[#1E293B] ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <nav aria-label="Secciones del sistema" className="flex flex-col flex-1 overflow-hidden">
          <div className="p-3">
            {/* Espacio reservado que ocupaba la etiqueta General */}
            <div className="h-6" aria-hidden="true" />
            <NavLink
              to="/"
              end
              onClick={handleNavClick}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 min-h-[38px] rounded-lg text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                  isActive
                    ? 'bg-[#1E293B] !text-white shadow-xs active'
                    : 'text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <LayoutDashboard
                    className={`w-4 h-4 shrink-0 ${isActive ? '!text-white' : 'text-[#059669]'}`}
                    style={isActive ? { color: '#ffffff', stroke: '#ffffff' } : undefined}
                    aria-hidden="true"
                  />
                  <span
                    className={isActive ? '!text-white font-semibold' : ''}
                    style={isActive ? { color: '#ffffff' } : undefined}
                  >
                    Panel General / Portada
                  </span>
                </>
              )}
            </NavLink>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-1 space-y-1">
            <div className="text-[11px] font-bold uppercase tracking-wider px-3 py-1.5 flex items-center justify-between text-[#475569]">
              <span>Módulos del Sistema</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded font-mono bg-[#F1F5F9] text-[#0F172A] font-bold border border-[#E2E8F0]">
                {MODULOS_SSOMA.length}
              </span>
            </div>

            {MODULOS_SSOMA.map((modulo) => (
            <NavLink
              key={modulo.id}
              to={modulo.ruta}
              onClick={handleNavClick}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 min-h-[38px] rounded-lg text-xs font-semibold transition-all group focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                  isActive
                    ? 'bg-[#1E293B] !text-white shadow-xs active'
                    : 'text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="flex items-center gap-2.5 truncate">
                    <span
                      className={`shrink-0 ${isActive ? '!text-white [&>svg]:!text-white [&>svg]:!stroke-white' : ''}`}
                      style={isActive ? { color: '#ffffff' } : undefined}
                    >
                      {modulo.icono}
                    </span>
                    <span
                      className={`truncate ${isActive ? '!text-white font-semibold' : ''}`}
                      style={isActive ? { color: '#ffffff' } : undefined}
                    >
                      {modulo.nombre}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-mono font-bold ${
                      isActive
                        ? '!text-white'
                        : 'text-[#64748B] group-hover:text-[#0F172A]'
                    }`}
                    style={isActive ? { color: '#ffffff' } : undefined}
                  >
                    {modulo.codigo < 10 ? `0${modulo.codigo}` : modulo.codigo}
                  </span>
                </>
              )}
            </NavLink>
          ))}
        </div>

        {/* Sección inferior: Configuración y estado (Protegido por PIN) */}
        <div className="p-3 border-t space-y-1 bg-[#F8FAFC] border-[#E2E8F0]">
          <button
            type="button"
            onClick={handleConfigClick}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 min-h-[38px] rounded-lg text-xs font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
              location.pathname === '/configuracion'
                ? 'bg-[#1E293B] !text-white shadow-xs active'
                : 'text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
            }`}
          >
            <Settings
              className={`w-4 h-4 shrink-0 ${location.pathname === '/configuracion' ? '!text-white' : 'text-[#475569]'}`}
              style={location.pathname === '/configuracion' ? { color: '#ffffff', stroke: '#ffffff' } : undefined}
            />
            <span
              className={location.pathname === '/configuracion' ? '!text-white font-semibold' : ''}
              style={location.pathname === '/configuracion' ? { color: '#ffffff' } : undefined}
            >
              Configuración del Sistema
            </span>
          </button>

          <div className="px-3 pt-2 text-[10px] text-[#64748B] font-semibold flex items-center justify-between">
            <span>PERPOL & TR3 SSOMA</span>
            <span className="font-mono">Fase 1</span>
          </div>
        </div>
        </nav>
      </aside>

      {/* Modal de Autorización por Código PIN en Sidebar */}
      {pinModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
          aria-labelledby="sidebar-pin-modal-title"
        >
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-[#E2E8F0] overflow-hidden text-[#0F172A]">
            {/* Header del modal */}
            <div className="flex items-center justify-between px-5 py-4 bg-[#F8FAFC] border-b border-[#E2E8F0]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#1E293B]/10 text-[#1E293B] flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <h3 id="sidebar-pin-modal-title" className="font-bold text-sm text-[#0F172A]">
                  Autorizar Configuración
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                className="p-1 rounded-md text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9] cursor-pointer"
                title="Cerrar modal de autorización"
                aria-label="Cerrar modal de autorización"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Formulario de PIN */}
            <form onSubmit={handlePinSubmit} className="p-6 space-y-4">
              <p id="sidebar-pin-desc" className="text-xs text-[#475569] leading-relaxed text-center">
                Ingrese el código PIN de seguridad de 4 dígitos para acceder a la configuración:
              </p>

              <div className="flex justify-center">
                <input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  autoFocus
                  aria-label="Código PIN de 4 dígitos"
                  aria-describedby="sidebar-pin-desc"
                  value={pinValue}
                  onChange={(e) => {
                    setPinValue(e.target.value.replace(/\D/g, ''));
                    setPinError('');
                  }}
                  placeholder="••••"
                  className="w-36 text-center text-3xl font-mono tracking-[0.4em] py-2.5 px-3 rounded-xl border border-[#CBD5E1] focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all outline-hidden shadow-inner bg-[#F8FAFC] text-[#0F172A] font-bold"
                />
              </div>

              {pinError && (
                <div role="alert" className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-[#DC2626] text-xs text-center font-medium animate-in fade-in">
                  {pinError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setPinModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg text-[#475569] hover:bg-[#F1F5F9] transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={pinValue.length !== 4}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#1E293B] hover:bg-[#0F172A] text-white shadow-xs disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
                >
                  Confirmar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
