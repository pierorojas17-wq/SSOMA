import React, { useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';
import { ToastContainer } from '../common/ToastContainer';
import { useAppStore } from '../../store/appStore';
import { GasApiClient } from '../../services/api';

export const Layout: React.FC = () => {
  const { sidebarOpen, gasWebAppUrl, setIsBackendConnected, themeBackground } = useAppStore();
  const isLight = themeBackground === 'light';

  // Verificación y auto-reconexión silenciosa en segundo plano al montar o actualizar la app
  useEffect(() => {
    if (gasWebAppUrl && gasWebAppUrl.trim().length > 0) {
      GasApiClient.testConnection(gasWebAppUrl.trim())
        .then((result) => {
          setIsBackendConnected(result.success);
        })
        .catch(() => {
          setIsBackendConnected(false);
        });
    }
  }, [gasWebAppUrl, setIsBackendConnected]);

  return (
    <div className={`min-h-screen flex flex-col font-sans antialiased transition-colors ${
      isLight ? 'bg-slate-50 text-slate-800' : 'bg-slate-950 text-slate-100'
    }`}>
      {/* Salto accesible directo al contenido principal (WCAG 2.4.1 Bypass Blocks) */}
      <a href="#main-content" className="skip-link">
        Saltar al contenido principal
      </a>

      <Navbar />

      <div className="flex-1 flex overflow-hidden min-w-0">
        <Sidebar />

        <main
          id="main-content"
          tabIndex={-1}
          className={`flex-1 transition-all duration-300 overflow-y-auto overflow-x-hidden outline-none min-w-0 ${
            sidebarOpen ? 'md:ml-64' : 'ml-0'
          } p-3 sm:p-5 lg:p-6 min-h-[calc(100vh-53px)] ${
            isLight ? 'bg-slate-50' : 'bg-slate-950'
          }`}
        >
          <div className="w-full max-w-[1680px] mx-auto min-w-0">
            <Outlet />
          </div>
        </main>
      </div>

      <ToastContainer />
    </div>
  );
};
