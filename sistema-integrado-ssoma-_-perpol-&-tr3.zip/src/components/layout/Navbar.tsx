import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAppStore } from '../../store/appStore';
import { GasApiClient } from '../../services/api';
import { EMPRESAS, EmpresaId } from '../../types';
import {
  Menu,
  Building2,
  CloudCheck,
  CloudOff,
  RefreshCw,
  Settings,
  ShieldCheck,
  Lock,
  X
} from 'lucide-react';
import { PIN_CONFIG, isValidAdminPin, isValidSyncPin } from '../../config/secrets';

export const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const {
    empresaActiva,
    setEmpresaActiva,
    sidebarOpen,
    toggleSidebar,
    isBackendConnected,
    gasWebAppUrl,
    pendingSyncCount,
    isSyncingWithSheets,
    setIsSyncingWithSheets,
    cargarDatosDesdeSheets,
    addToast,
    themeBackground
  } = useAppStore();

  const isLight = themeBackground === 'light';

  // Modal de autorización por código PIN
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinAction, setPinAction] = useState<'sync' | 'config' | null>(null);
  const [pinValue, setPinValue] = useState('');
  const [pinError, setPinError] = useState('');

  const ejecutarSincronizacionSheets = async () => {
    const effectiveUrl = gasWebAppUrl?.trim() || GasApiClient.getGasUrl();
    if (!effectiveUrl) {
      addToast({
        type: 'warning',
        title: 'Google Sheets Desconectado',
        message: 'Configure la URL de Google Apps Script en Configuración para sincronizar.'
      });
      return;
    }
    try {
      setIsSyncingWithSheets(true);
      const res = await GasApiClient.obtenerDatosGoogleSheets();
      if (res && res.success && res.data) {
        cargarDatosDesdeSheets(res.data);
        const total = useAppStore.getState().totalSincronizadosSheets;
        addToast({
          type: 'success',
          title: 'Sincronización Exitosa',
          message: `Datos actualizados directamente desde Google Sheets (${total} registros cargados).`
        });
      } else {
        addToast({
          type: 'error',
          title: 'Error al sincronizar',
          message: res?.error || res?.message || 'No se pudo obtener datos de Google Sheets.'
        });
      }
    } catch (err: unknown) {
      addToast({
        type: 'error',
        title: 'Error de Red',
        message: err instanceof Error ? err.message : 'Fallo en la comunicación con Google Sheets'
      });
    } finally {
      setIsSyncingWithSheets(false);
    }
  };

  const handleOpenConfigPin = () => {
    setPinAction('config');
    setPinValue('');
    setPinError('');
    setPinModalOpen(true);
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const isAuthorized = pinAction === 'sync'
      ? (isValidSyncPin(pinValue) || isValidAdminPin(pinValue))
      : isValidAdminPin(pinValue);

    if (isAuthorized) {
      const action = pinAction;
      setPinModalOpen(false);
      setPinValue('');
      setPinError('');
      if (action === 'sync') {
        ejecutarSincronizacionSheets();
      } else if (action === 'config') {
        navigate('/configuracion');
      }
    } else {
      setPinError('Código PIN incorrecto. Acceso denegado.');
      setPinValue('');
    }
  };

  const activeEmpresaInfo =
    empresaActiva === 'CONSOLIDADO' ? null : EMPRESAS[empresaActiva as 'PERPOL' | 'TR3'];

  return (
    <header className="sticky top-0 z-30 transition-colors bg-white border-b border-[#E2E8F0] text-[#1E293B] shadow-xs">
      <div className="flex items-center justify-between px-3 sm:px-4 py-2 sm:py-2.5 gap-2">
        {/* Lado izquierdo: Toggle menú + Marca SSOMA */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            type="button"
            onClick={toggleSidebar}
            className={`min-w-[38px] min-h-[38px] p-2 rounded-lg transition-all cursor-pointer active:scale-95 flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
              sidebarOpen
                ? 'bg-[#F1F5F9] text-[#0F172A] border border-[#CBD5E1] shadow-xs'
                : 'bg-[#F8FAFC] hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] border border-[#E2E8F0]'
            }`}
            title={sidebarOpen ? 'Ocultar menú lateral [ ≡ ]' : 'Mostrar menú lateral [ ≡ ]'}
            aria-label={sidebarOpen ? 'Ocultar menú de navegación lateral' : 'Mostrar menú de navegación lateral'}
            aria-controls="main-sidebar"
            aria-expanded={sidebarOpen}
          >
            <Menu className="w-5 h-5 shrink-0" aria-hidden="true" />
          </button>

          <Link to="/" className="flex items-center gap-2 sm:gap-2.5 group min-w-0" aria-label="Ir al Panel General de SSOMA">
            <div className="w-8 sm:w-9 h-8 sm:h-9 rounded-lg bg-[#1E293B] flex items-center justify-center text-white shadow-xs font-bold tracking-wider shrink-0" aria-hidden="true">
              <ShieldCheck className="w-4 sm:w-5 h-4 sm:h-5 text-[#10B981]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs sm:text-sm tracking-wide text-[#0F172A] group-hover:text-[#047857] transition-colors truncate max-w-[140px] xs:max-w-[200px] sm:max-w-none">
                  SISTEMA INTEGRADO SSOMA
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] hidden md:block text-[#475569] font-medium truncate">
                Seguridad, Salud Ocupacional y Medio Ambiente
              </p>
            </div>
          </Link>
        </div>

        {/* Centro: Selector de Razón Social (PERPOL / TR3 / Consolidado) */}
        <div className="hidden lg:flex flex-col items-center shrink-0">
          <div
            role="radiogroup"
            aria-label="Seleccionar razón social activa"
            className="inline-flex p-1 rounded-lg border shadow-inner bg-[#F1F5F9] border-[#E2E8F0]"
          >
            <button
              type="button"
              role="radio"
              aria-checked={empresaActiva === 'CONSOLIDADO'}
              onClick={() => setEmpresaActiva('CONSOLIDADO')}
              className={`px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                empresaActiva === 'CONSOLIDADO'
                  ? 'bg-[#1E293B] !text-white shadow-xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#E2E8F0]'
              }`}
            >
              CONSOLIDADO
            </button>
            <button
              type="button"
              role="radio"
              aria-checked={empresaActiva === 'PERPOL'}
              onClick={() => setEmpresaActiva('PERPOL')}
              className={`px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                empresaActiva === 'PERPOL'
                  ? 'bg-[#1E293B] !text-white shadow-xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#E2E8F0]'
              }`}
            >
              PERPOL IDEAS S.A.C.
            </button>
            <button
              type="button"
              role="radio"
              aria-checked={empresaActiva === 'TR3'}
              onClick={() => setEmpresaActiva('TR3')}
              className={`px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                empresaActiva === 'TR3'
                  ? 'bg-[#1E293B] !text-white shadow-xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#E2E8F0]'
              }`}
            >
              TR3 ALIMENTOS S.A.C.
            </button>
          </div>
          {activeEmpresaInfo ? (
            <div className="flex items-center gap-2 text-[10px] mt-1 text-[#475569] font-medium">
              <span className="font-bold text-[#0F172A]">RUC: {activeEmpresaInfo.ruc}</span>
              <span>•</span>
              <span className="truncate max-w-xs">{activeEmpresaInfo.actividadEconomica}</span>
            </div>
          ) : (
            <span className="text-[10px] mt-1 text-[#475569] font-medium">
              Vista combinada: Ambas razones sociales
            </span>
          )}
        </div>

        {/* Lado derecho: Botones de acción compactos (solo iconos) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Indicador de sincronización en progreso */}
          {pendingSyncCount > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-amber-50 border border-amber-200 text-[#B45309] text-xs animate-pulse">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span className="text-[11px] font-semibold">{pendingSyncCount}</span>
            </div>
          )}

          {/* Botón sólo icono: Sincronización directa con Google Sheets */}
          <button
            type="button"
            onClick={ejecutarSincronizacionSheets}
            disabled={isSyncingWithSheets}
            className={`min-w-[38px] min-h-[38px] p-2 rounded-lg border transition-all cursor-pointer flex items-center justify-center active:scale-95 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
              isSyncingWithSheets
                ? 'bg-emerald-50 text-[#047857] border-emerald-200 animate-pulse'
                : 'bg-[#F8FAFC] hover:bg-[#F1F5F9] text-[#1E293B] border-[#CBD5E1]'
            }`}
            title="Sincronizar datos con Google Sheets (Descargar cambios)"
            aria-label={isSyncingWithSheets ? "Sincronizando con Google Sheets..." : "Sincronizar datos con Google Sheets"}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncingWithSheets ? 'animate-spin text-[#047857]' : ''}`} aria-hidden="true" />
          </button>

          {/* Botón sólo icono: Estado de Conexión con Google Sheets y Acceso a Configuración */}
          <button
            type="button"
            onClick={() => navigate('/configuracion')}
            className={`min-w-[38px] min-h-[38px] p-2 rounded-lg border transition-all cursor-pointer flex items-center justify-center active:scale-95 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
              gasWebAppUrl && isBackendConnected
                ? 'bg-emerald-50 border-emerald-200 text-[#047857] hover:bg-emerald-100'
                : 'bg-amber-50 border-amber-200 text-[#B45309] hover:bg-amber-100'
            }`}
            title={
              gasWebAppUrl && isBackendConnected
                ? 'Conexión Permanente con Google Sheets Activa (PERPOL & TR3)'
                : 'Conexión con Google Sheets en verificación (Clic para configurar)'
            }
            aria-label={
              gasWebAppUrl && isBackendConnected
                ? 'Conexión permanente con Google Sheets activa'
                : 'Conexión con Google Sheets no configurada. Clic para configurar'
            }
          >
            {gasWebAppUrl && isBackendConnected ? (
              <CloudCheck className="w-4 h-4 text-[#047857]" aria-hidden="true" />
            ) : (
              <CloudOff className="w-4 h-4 text-[#B45309]" aria-hidden="true" />
            )}
          </button>

          {/* Botón de configuración general (Protegido por PIN) */}
          <button
            type="button"
            onClick={handleOpenConfigPin}
            className="min-w-[38px] min-h-[38px] p-2 rounded-lg transition-all cursor-pointer active:scale-95 flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden bg-[#F8FAFC] hover:bg-[#F1F5F9] text-[#1E293B] hover:text-[#0F172A] border border-[#CBD5E1]"
            title="Configuración del Sistema"
            aria-label="Abrir configuración del sistema (Protegido por PIN)"
          >
            <Settings className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Modal de Autorización por Código PIN de 4 dígitos */}
      {pinModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
          aria-labelledby="navbar-pin-modal-title"
        >
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-[#E2E8F0] overflow-hidden text-[#0F172A]">
            {/* Header del modal */}
            <div className="flex items-center justify-between px-5 py-4 bg-[#F8FAFC] border-b border-[#E2E8F0]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#1E293B]/10 text-[#1E293B] flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <h3 id="navbar-pin-modal-title" className="font-bold text-sm text-[#0F172A]">
                  {pinAction === 'sync' ? 'Autorizar Sincronización' : 'Autorizar Configuración'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                className="p-1 rounded-md text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9] cursor-pointer"
                title="Cerrar modal de autorización"
                aria-label="Cerrar modal de autorización"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Formulario de PIN */}
            <form onSubmit={handlePinSubmit} className="p-6 space-y-4">
              <p id="navbar-pin-modal-desc" className="text-xs text-[#475569] leading-relaxed text-center">
                Ingrese el código PIN de seguridad de 4 dígitos para autorizar esta operación:
              </p>

              <div className="flex justify-center">
                <input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  autoFocus
                  aria-label="Código PIN de 4 dígitos"
                  aria-describedby="navbar-pin-modal-desc"
                  value={pinValue}
                  onChange={(e) => {
                    setPinValue(e.target.value.replace(/\D/g, ''));
                    setPinError('');
                  }}
                  placeholder="••••"
                  className="w-36 text-center text-3xl font-mono tracking-[0.4em] py-2.5 px-3 rounded-xl border border-[#CBD5E1] focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all outline-hidden shadow-inner bg-[#F8FAFC] text-[#0F172A] font-bold"
                />
              </div>

              {pinError && (
                <div role="alert" className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-[#DC2626] text-xs text-center font-medium animate-in fade-in">
                  {pinError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setPinModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg text-[#475569] hover:bg-[#F1F5F9] transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={pinValue.length !== 4}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#1E293B] hover:bg-[#0F172A] text-white shadow-xs disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
                >
                  Confirmar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Selector móvil para pantallas pequeñas */}
      <div className="md:hidden flex items-center justify-between px-3 py-1.5 border-t text-xs bg-[#F8FAFC] border-[#E2E8F0] text-[#475569]">
        <span className="flex items-center gap-1 font-medium">
          <Building2 className="w-3.5 h-3.5" /> Empresa:
        </span>
        <select
          value={empresaActiva}
          onChange={(e) => setEmpresaActiva(e.target.value as EmpresaId)}
          className="border rounded px-2 py-0.5 text-xs bg-white border-[#CBD5E1] text-[#0F172A] focus:border-[#10B981]"
        >
          <option value="CONSOLIDADO">Consolidado (PERPOL & TR3)</option>
          <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
          <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
        </select>
      </div>
    </header>
  );
};
