/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { lazy, Suspense } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './services/queryClient';
import { Layout } from './components/layout/Layout';
import { LoadingScreen } from './components/common/LoadingScreen';

// Helper para carga diferida de módulos con reintento automático y auto-recuperación ante cambios de compilación
function lazyWithRetry<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>
) {
  return lazy(async () => {
    try {
      const component = await factory();
      sessionStorage.removeItem('ssoma_chunk_retry');
      return component;
    } catch (error) {
      console.warn('[Vite Lazy] Fallo inicial al cargar módulo dinámico, reintentando...', error);
      await new Promise((resolve) => setTimeout(resolve, 350));
      try {
        const component = await factory();
        sessionStorage.removeItem('ssoma_chunk_retry');
        return component;
      } catch (secondError) {
        console.error('[Vite Lazy] Segundo intento fallido al cargar módulo:', secondError);
        const alreadyRetried = sessionStorage.getItem('ssoma_chunk_retry');
        if (!alreadyRetried) {
          sessionStorage.setItem('ssoma_chunk_retry', '1');
          window.location.reload();
        }
        throw secondError;
      }
    }
  });
}

// Code Splitting con lazy loading resiliente por módulo
const DashboardPage = lazyWithRetry(() =>
  import('./modules/dashboard/DashboardPage').then((m) => ({ default: m.DashboardPage }))
);
const AccidentesPage = lazyWithRetry(() =>
  import('./modules/accidentes/AccidentesPage').then((m) => ({ default: m.AccidentesPage }))
);
const AtencionesMedicasPage = lazyWithRetry(() =>
  import('./modules/atenciones-medicas/AtencionesMedicasPage').then((m) => ({
    default: m.AtencionesMedicasPage
  }))
);
const InspeccionesPage = lazyWithRetry(() =>
  import('./modules/inspecciones/InspeccionesPage').then((m) => ({ default: m.InspeccionesPage }))
);
const ActosCondicionesPage = lazyWithRetry(() =>
  import('./modules/actos-condiciones/ActosCondicionesPage').then((m) => ({
    default: m.ActosCondicionesPage
  }))
);
const BotiquinPage = lazyWithRetry(() =>
  import('./modules/botiquin/BotiquinPage').then((m) => ({ default: m.BotiquinPage }))
);
const TrabajadoresPage = lazyWithRetry(() =>
  import('./modules/trabajadores/TrabajadoresPage').then((m) => ({ default: m.TrabajadoresPage }))
);
const HorasHombrePage = lazyWithRetry(() =>
  import('./modules/horas-hombre/HorasHombrePage').then((m) => ({ default: m.HorasHombrePage }))
);
const ProgramaAnualPage = lazyWithRetry(() =>
  import('./modules/programa-anual/ProgramaAnualPage').then((m) => ({ default: m.ProgramaAnualPage }))
);
const EstadisticasPage = lazyWithRetry(() =>
  import('./modules/estadisticas/EstadisticasPage').then((m) => ({ default: m.EstadisticasPage }))
);
const SimulacionCostosPage = lazyWithRetry(() =>
  import('./modules/simulacion-costos/SimulacionCostosPage').then((m) => ({
    default: m.SimulacionCostosPage
  }))
);
const InvestigacionPage = lazyWithRetry(() =>
  import('./modules/investigacion/InvestigacionPage').then((m) => ({ default: m.InvestigacionPage }))
);
const SettingsPage = lazyWithRetry(() =>
  import('./modules/settings/SettingsPage').then((m) => ({ default: m.SettingsPage }))
);

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            {/* Rutas diferidas bajo Suspense con fallback estandarizado */}
            <Route
              index
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Panel General..." />}>
                  <DashboardPage />
                </Suspense>
              }
            />

            {/* Módulo 01: Accidentes de Trabajo */}
            <Route
              path="accidentes"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Módulo de Accidentes..." />}>
                  <AccidentesPage />
                </Suspense>
              }
            />

            {/* Módulo 02: Atenciones Médicas */}
            <Route
              path="atenciones-medicas"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Atenciones Médicas..." />}>
                  <AtencionesMedicasPage />
                </Suspense>
              }
            />

            {/* Módulo 03: Inspecciones SST */}
            <Route
              path="inspecciones"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Inspecciones SST..." />}>
                  <InspeccionesPage />
                </Suspense>
              }
            />

            {/* Módulo 04: Actos y Condiciones */}
            <Route
              path="actos-condiciones"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Actos y Condiciones..." />}>
                  <ActosCondicionesPage />
                </Suspense>
              }
            />

            {/* Módulo 05: Consumo de Botiquín */}
            <Route
              path="botiquin"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Registro de Botiquín..." />}>
                  <BotiquinPage />
                </Suspense>
              }
            />

            {/* Módulo 06: Base de Trabajadores */}
            <Route
              path="trabajadores"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Padrón de Trabajadores..." />}>
                  <TrabajadoresPage />
                </Suspense>
              }
            />

            {/* Módulo 07: Horas-Hombre (HH) */}
            <Route
              path="horas-hombre"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Horas-Hombre..." />}>
                  <HorasHombrePage />
                </Suspense>
              }
            />

            {/* Módulo 08: Programa Anual SST */}
            <Route
              path="programa-anual"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Programa Anual SST..." />}>
                  <ProgramaAnualPage />
                </Suspense>
              }
            />

            {/* Módulo 09: Estadísticas SST */}
            <Route
              path="estadisticas"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Estadísticas SSOMA..." />}>
                  <EstadisticasPage />
                </Suspense>
              }
            />

            {/* Módulo 10: Simulación de Costos */}
            <Route
              path="simulacion-costos"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Simulador de Costos..." />}>
                  <SimulacionCostosPage />
                </Suspense>
              }
            />

            {/* Módulo 11: Investigación de Accidentes */}
            <Route
              path="investigacion"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Investigación Oficial..." />}>
                  <InvestigacionPage />
                </Suspense>
              }
            />

            {/* Configuración */}
            <Route
              path="configuracion"
              element={
                <Suspense fallback={<LoadingScreen message="Cargando Configuración del Sistema..." />}>
                  <SettingsPage />
                </Suspense>
              }
            />

            {/* Redirección */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </HashRouter>
    </QueryClientProvider>
  );
}
