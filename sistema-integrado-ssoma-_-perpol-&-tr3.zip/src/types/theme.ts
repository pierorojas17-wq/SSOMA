export type ThemeColor = 'corporate' | 'emerald' | 'blue' | 'indigo' | 'amber' | 'teal' | 'cyan' | 'rose' | 'purple' | 'custom';
export type ThemeBackground = 'slate' | 'midnight' | 'navy' | 'light';

export interface ThemeOption {
  id: ThemeColor;
  nombre: string;
  descripcion: string;
  hex: string;
  badge: string;
  // Clases Tailwind para soporte nativo directo
  bgClass: string;
  bgHoverClass: string;
  textClass: string;
  borderClass: string;
  bgLightClass: string;
  borderLightClass: string;
}

export const THEME_OPTIONS: Record<Exclude<ThemeColor, 'custom'>, ThemeOption> = {
  corporate: {
    id: 'corporate',
    nombre: 'Azul Profundo Ejecutivo (Oficial)',
    descripcion: 'Nueva identidad corporativa SSOMA (#263B5E)',
    hex: '#263B5E',
    badge: 'Oficial SSOMA',
    bgClass: 'bg-[#263B5E]',
    bgHoverClass: 'hover:bg-[#3F72AF]',
    textClass: 'text-[#263B5E]',
    borderClass: 'border-[#263B5E]',
    bgLightClass: 'bg-[#F4F6F8]',
    borderLightClass: 'border-[#E5E9EF]'
  },
  emerald: {
    id: 'emerald',
    nombre: 'Verde Turquesa SSOMA',
    descripcion: 'Acento ambiental y salud ocupacional (#5AB9A8)',
    hex: '#5AB9A8',
    badge: 'Turquesa SSOMA',
    bgClass: 'bg-[#5AB9A8]',
    bgHoverClass: 'hover:bg-[#489E90]',
    textClass: 'text-[#489E90]',
    borderClass: 'border-[#5AB9A8]',
    bgLightClass: 'bg-emerald-50',
    borderLightClass: 'border-emerald-200'
  },
  blue: {
    id: 'blue',
    nombre: 'Azul Corporativo',
    descripcion: 'Enfoque técnico, confiabilidad y rigor normativo',
    hex: '#2563eb',
    badge: 'Corporativo',
    bgClass: 'bg-blue-600',
    bgHoverClass: 'hover:bg-blue-500',
    textClass: 'text-blue-700',
    borderClass: 'border-blue-600',
    bgLightClass: 'bg-blue-50',
    borderLightClass: 'border-blue-200'
  },
  indigo: {
    id: 'indigo',
    nombre: 'Índigo Moderno',
    descripcion: 'Diseño sobrio de alta gama y gestión ejecutiva',
    hex: '#4f46e5',
    badge: 'Moderno',
    bgClass: 'bg-indigo-600',
    bgHoverClass: 'hover:bg-indigo-500',
    textClass: 'text-indigo-700',
    borderClass: 'border-indigo-600',
    bgLightClass: 'bg-indigo-50',
    borderLightClass: 'border-indigo-200'
  },
  amber: {
    id: 'amber',
    nombre: 'Ámbar de Seguridad',
    descripcion: 'Inspirado en la señalética industrial de prevención y precaución',
    hex: '#d97706',
    badge: 'Industrial',
    bgClass: 'bg-amber-600',
    bgHoverClass: 'hover:bg-amber-500',
    textClass: 'text-amber-700',
    borderClass: 'border-amber-600',
    bgLightClass: 'bg-amber-50',
    borderLightClass: 'border-amber-200'
  },
  teal: {
    id: 'teal',
    nombre: 'Turquesa Salud Ocupacional',
    descripcion: 'Asociado a higiene industrial, salud y ergonomía',
    hex: '#0d9488',
    badge: 'Salud Ocupacional',
    bgClass: 'bg-teal-600',
    bgHoverClass: 'hover:bg-teal-500',
    textClass: 'text-teal-700',
    borderClass: 'border-teal-600',
    bgLightClass: 'bg-teal-50',
    borderLightClass: 'border-teal-200'
  },
  cyan: {
    id: 'cyan',
    nombre: 'Cian Alta Visibilidad',
    descripcion: 'Estilo tecnológico, dinámico y de alto contraste',
    hex: '#0891b2',
    badge: 'Alta Visibilidad',
    bgClass: 'bg-cyan-600',
    bgHoverClass: 'hover:bg-cyan-500',
    textClass: 'text-cyan-700',
    borderClass: 'border-cyan-600',
    bgLightClass: 'bg-cyan-50',
    borderLightClass: 'border-cyan-200'
  },
  rose: {
    id: 'rose',
    nombre: 'Rojo Alerta SST',
    descripcion: 'Enfoque en respuesta a emergencias y control de riesgos críticos',
    hex: '#e11d48',
    badge: 'Emergencias',
    bgClass: 'bg-rose-600',
    bgHoverClass: 'hover:bg-rose-500',
    textClass: 'text-rose-700',
    borderClass: 'border-rose-600',
    bgLightClass: 'bg-rose-50',
    borderLightClass: 'border-rose-200'
  },
  purple: {
    id: 'purple',
    nombre: 'Violeta Estratégico',
    descripcion: 'Para auditorías, comités paritarios y seguimiento estratégico',
    hex: '#7c3aed',
    badge: 'Estratégico',
    bgClass: 'bg-purple-600',
    bgHoverClass: 'hover:bg-purple-500',
    textClass: 'text-purple-700',
    borderClass: 'border-purple-600',
    bgLightClass: 'bg-purple-50',
    borderLightClass: 'border-purple-200'
  }
};
