/**
 * Sistema Integrado SSOMA - Tipos y Definiciones Centrales
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 */

// Exportaciones base
export * from './common';
export * from './api';
export * from './theme';
export * from './modules';

declare global {
  interface Window {
    google?: {
      script?: {
        run: {
          withSuccessHandler: (callback: (response: any) => void) => {
            withFailureHandler: (callback: (error: any) => void) => {
              obtenerDatos: () => void;
              [key: string]: any;
            };
            obtenerDatos: () => void;
            [key: string]: any;
          };
          withFailureHandler: (callback: (error: any) => void) => {
            withSuccessHandler: (callback: (response: any) => void) => {
              obtenerDatos: () => void;
              [key: string]: any;
            };
            obtenerDatos: () => void;
            [key: string]: any;
          };
          obtenerDatos: () => void;
          [key: string]: any;
        };
      };
    };
    __ssomaCargarDatosEnPantalla?: (data: any) => void;
    __ssomaDatosPendientes?: any;
  }
}
