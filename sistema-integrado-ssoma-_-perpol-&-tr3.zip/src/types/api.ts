/**
 * Tipos de comunicación API y Google Apps Script
 */
import { EmpresaId } from './common';

export interface GasRequestPayload<T = unknown> {
  action: string;
  sheetName?: string;
  empresa?: EmpresaId;
  data?: T;
  rows?: unknown[];
  mode?: 'upsert' | 'insertar' | 'actualizar';
  primaryKey?: string;
  batchIndex?: number;
  totalBatches?: number;
  id?: string;
  driveFolderId?: string;
  fileData?: {
    base64: string;
    mimeType: string;
    fileName: string;
    modulo: string;
  };
  filter?: Record<string, unknown>;
}

export interface GasApiResponse<T = unknown> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
  timestamp: string;
  affectedRows?: number;
  created?: number;
  updated?: number;
  skipped?: number;
  rejected?: number;
  errors?: string[];
  fileUrl?: string;
  fileId?: string;
}
