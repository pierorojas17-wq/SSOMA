/**
 * Tipos y constantes comunes del Sistema Integrado SSOMA
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 */

export type EmpresaId = 'PERPOL' | 'TR3' | 'CONSOLIDADO';

export interface EmpresaInfo {
  id: EmpresaId;
  razonSocial: string;
  ruc: string;
  direccion: string;
  actividadEconomica: string;
}

export const EMPRESAS: Record<'PERPOL' | 'TR3', EmpresaInfo> = {
  PERPOL: {
    id: 'PERPOL',
    razonSocial: 'PERPOL IDEAS S.A.C.',
    ruc: '20392729977',
    direccion: 'CAL.LOS BRILLANTES NRO. 096 FND. PARCELACION RUSTICA Y SEMIRUSTICA LA CAPITANA-SANTA MARIA DE HUACHIPA (SUB PARCELA 30F-2) - LIMA – LURIGANCHO',
    actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS'
  },
  TR3: {
    id: 'TR3',
    razonSocial: 'TR3 ALIMENTOS S.A.C.',
    ruc: '20550842891',
    direccion: 'LOS BRILLANTES MZA. B1 LOTE. 11B PARCELA LA CAPITANA DEL FUNDO DE HUACHIPA - LIMA - LURIGANCHO',
    actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS'
  }
};

export interface BaseEntity {
  id: string;
  empresa: 'PERPOL' | 'TR3';
  createdAt: string;
  updatedAt?: string;
  createdBy?: string;
  syncStatus?: 'synced' | 'pending' | 'error';
}

export interface ModuloDef {
  id: string;
  codigo: number;
  nombre: string;
  tituloCorto: string;
  descripcion: string;
  ruta: string;
  icono: string;
  sheetTab: string;
  color: string;
  badge?: number;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  timestamp: number;
}

export type SeveridadRiesgo = 1 | 2 | 3 | 4;
export type PrioridadSST = 'Baja' | 'Media' | 'Alta' | 'Inmediata';
