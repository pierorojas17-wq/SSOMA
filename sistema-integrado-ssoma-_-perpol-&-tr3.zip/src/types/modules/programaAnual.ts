import { BaseEntity, EmpresaId } from '../common';

export type TipoActividadPrograma = 'Regular' | 'A Demanda';
export type EstadoActividadPrograma = 'Programado' | 'En ejecución' | 'Ejecutado' | 'Reprogramado' | 'No ejecutado';

export interface ProgramaAnualRecord extends BaseEntity {
  anio: number;
  numeroItem: number;
  objetivoGeneral: string;
  objetivoEspecifico?: string;
  actividad: string;
  tipoActividad: TipoActividadPrograma;
  responsable: string;
  presupuestoEstimado: number;
  metaPorcentaje: number;
  indicadorFormula: string;
  programacionMeses: boolean[]; // 12 posiciones
  ejecucionMeses: boolean[]; // 12 posiciones
  estado: EstadoActividadPrograma;
  avanceCalculado: number;
}

export interface ProgramaResumenAnual {
  id: string;
  anio: number;
  empresa: EmpresaId;
  avanceMensual: number[];
  promedioActividades: number;
  avanceAnualPonderado: number;
  totalActividades: number;
  actividadesEjecutadas: number;
  updatedAt: string;
}
