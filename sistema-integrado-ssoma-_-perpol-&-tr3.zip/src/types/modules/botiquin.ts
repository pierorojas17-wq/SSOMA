import { BaseEntity } from '../common';

export interface ElementoBotiquinConsumido {
  item: string;
  cantidad: number;
  unidad: string;
}

export interface ConsumoBotiquinRecord extends BaseEntity {
  codigoAtencion: string;
  fecha: string;
  hora?: string;
  tipoAtencion: 'Incidente' | 'Accidente' | 'Enfermedad común';
  personaAtendida: string;
  dniPersona: string;
  puesto: string;
  area: string;
  lugarEspecifico?: string;
  turno: string;
  lesionesSintomas: string;
  procedimientoAplicado: string;
  elementosConsumidos: ElementoBotiquinConsumido[];
  inspeccionVinculadaId?: string;
  inspeccionVinculadaCodigo?: string;
  inspeccionVinculadaDetalle?: string;
  atendidoPor: string;
  fotoUrl?: string;
  fotoDriveId?: string;
  transferidoAccidentes?: boolean;
  estadoValidacion?: 'Pendiente' | 'Validado' | 'Descartado' | 'Transferido';
  casoAccidenteId?: string;
}
