import { BaseEntity } from '../common';

export type RolInvestigador =
  | 'Investigador Principal'
  | 'Responsable del área'
  | 'Representante del CSST'
  | 'Responsable SSOMA'
  | 'Representante del Empleador'
  | 'Supervisor de Área'
  | 'Representante Comité SST'
  | 'Jefe SSOMA';

export interface InvestigadorFirma {
  nombre: string;
  cargo: string;
  rol: RolInvestigador;
  firmaUrl?: string;
  firmaDriveId?: string;
  fechaFirma?: string;
}

export interface MedidaCorrectivaInvestigacion {
  id: string;
  descripcion: string;
  tipoAccion: 'Eliminación' | 'Sustitución' | 'Control de Ingeniería' | 'Control Administrativo' | 'EPP';
  responsable: string;
  plazo: string;
  estado: 'Pendiente' | 'Implementada' | 'Verificada';
  evidenciaUrl?: string;
  fechaVerificacion?: string;
  verificador?: string;
}

export interface DatosTrabajadorInvestigacion {
  nombre: string;
  dni: string;
  edad: number;
  genero: 'M' | 'F';
  puesto: string;
  area: string;
  fechaIngreso: string;
  antiguedadPuesto: string;
}

export interface InvestigacionRecord extends BaseEntity {
  codigoInvestigacion: string;
  accidenteId: string;
  empresa: 'PERPOL' | 'TR3';
  fechaInvestigacion: string;
  fechaAccidente: string;
  horaAccidente: string;
  horaInicioLaboral?: string;
  turno: string;
  area: string;
  lugarExacto: string;
  diasDescanso: number;
  numTrabajadoresAfectados?: number;
  responsableArea?: string;
  partesCuerpoAfectadas?: string[];
  datosTrabajador: DatosTrabajadorInvestigacion;
  descripcionCircunstancias: string;
  testigos?: string;
  tipoContacto: string;
  agenteCausante: string;
  causasInmediatas: {
    actosSubestandar: string[];
    condicionesSubestandar: string[];
  };
  causasBasicas: {
    factoresPersonales: string[];
    factoresTrabajo: string[];
  };
  causaRaizMetodo: '5 Porqués' | 'Ishikawa';
  analisisCausaRaiz: string;
  conclusionCausaRaiz: string;
  medidasCorrectivas: MedidaCorrectivaInvestigacion[];
  investigadores: InvestigadorFirma[];
  porcentajeAvance: number;
  estado: 'Borrador' | 'En revisión' | 'En revision' | 'Cerrada';
  closureErrors?: string[];
  fechaCierre?: string;
}
