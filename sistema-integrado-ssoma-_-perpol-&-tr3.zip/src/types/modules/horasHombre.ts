import { BaseEntity } from '../common';

export interface ResumenMensualHH extends BaseEntity {
  id: string;
  anio: number;
  mes: number; // 1 a 12
  trabajadoresPerpol: number;
  hhPerpol: number;
  trabajadoresTr3: number;
  hhTr3: number;
  totalTrabajadores: number;
  totalHH: number;
}
