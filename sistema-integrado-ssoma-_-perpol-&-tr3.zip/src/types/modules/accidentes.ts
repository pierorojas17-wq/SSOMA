import { BaseEntity } from '../common';

export type TipoEventoAccidente = 
  | 'Incidente potencial' 
  | 'Incidente' 
  | 'Accidente leve' 
  | 'Accidente incapacitante' 
  | 'Accidente mortal';

export type EstadoCasoAccidente = 
  | 'Abierto' 
  | 'En investigación' 
  | 'Con medidas correctivas' 
  | 'Cerrado';

export interface AccidenteRecord extends BaseEntity {
  codigoCaso: string;
  fecha: string;
  hora: string;
  trabajadorDni: string;
  trabajadorNombre: string;
  cargo: string;
  area: string;
  turno: string;
  lugarExacto: string;
  responsableArea: string;
  tipoEvento: TipoEventoAccidente;
  danoMaterial: 'SI' | 'NO';
  detalleDano?: string;
  necesidadAtencion: 'SI' | 'NO';
  descripcion: string;
  fotoUrl?: string;
  fotoDriveId?: string;
  causaInmediata?: string;

  // 4 Listas de selección múltiple con soporte "Otros"
  partesCuerpoAfectadas?: string[];
  partesCuerpoOtros?: string;
  mecanismoEvento?: string[];
  mecanismoEventoOtros?: string;
  agenteEvento?: string[];
  agenteEventoOtros?: string;
  lesionReferida?: string[];
  lesionReferidaOtros?: string;

  estadoCaso: EstadoCasoAccidente;
  diasDescanso?: number;
  medidasCorrectivas?: string;
  responsableSeguimiento?: string;
  fechaCompromiso?: string;
  fechaCierre?: string;
  conclusionesInvestigacion?: string;
  origenAtencionBotiquinId?: string;
}
