import { BaseEntity, SeveridadRiesgo, PrioridadSST } from '../common';

export type ClasificacionActoCondicion = 'Acto Inseguro' | 'Condición Insegura';
export type EstadoActoCondicion = 'Pendiente' | 'En proceso' | 'Cerrado';

export interface ActoCondicionRecord extends BaseEntity {
  codigoReporte: string;
  fecha: string;
  reportadoPor: string;
  clasificacion: ClasificacionActoCondicion;
  categoriaCodigo: string;
  categoriaNombre: string;
  potencialGravedad: SeveridadRiesgo;
  prioridad: PrioridadSST;
  descripcion: string;
  fotoUrl?: string;
  fotoDriveId?: string;

  // Rama Acto Inseguro
  tipoPersonal?: 'Propio' | 'Contratista';
  empresaPersonal?: string;
  trabajadorObservadoDni?: string;
  trabajadorObservadoNombre?: string;
  cargoObservado?: string;
  areaActo?: string;
  turnoActo?: 'Mañana' | 'Tarde' | 'Noche';

  // Rama Condición Insegura
  areaCondicion?: string;
  lugarEspecifico?: string;

  // Seguimiento y Cierre
  estado: EstadoActoCondicion;
  medidaCorrectiva?: string;
  responsableSeguimiento?: string;
  fechaCompromiso?: string;
  fechaCierre?: string;
  fotoCierreUrl?: string;
  fotoCierreDriveId?: string;
  observacionCierre?: string;
}
