import { EmpresaId } from '../common';

export interface MetaIndicadoresSST {
  id?: string;
  empresa: EmpresaId;
  periodoAnio: number;
  metaIF: number; // Meta máxima de Índice de Frecuencia
  metaIS: number; // Meta máxima de Índice de Severidad
  metaIA: number; // Meta máxima de Índice de Accidentabilidad
  metaCumplimientoPrograma: number; // % meta (ej: 90%)
  metaInspeccionesSubsanadas: number; // % meta (ej: 85%)
}

export interface KPIPeriodoMensual {
  mes: number; // 1..12
  nombreMes: string;
  horasHombre: number;
  accidentesIncapacitantes: number;
  accidentesLeves: number;
  incidentes: number;
  diasPerdidos: number;
  indiceFrecuencia: number;
  indiceSeveridad: number;
  indiceAccidentabilidad: number;
  metaIF: number;
  metaIS: number;
  metaIA: number;
  cumpleFrecuencia: boolean;
  cumpleSeveridad: boolean;
}

export interface EstadisticasDashboardData {
  empresa: EmpresaId;
  periodoAnio: number;
  indiceFrecuencia: number;
  indiceSeveridad: number;
  indiceAccidentabilidad: number;
  totalAccidentesIncapacitantes: number;
  totalAccidentesLeves: number;
  totalDiasPerdidos: number;
  totalHorasHombre: number;
  totalIncidentes: number;
  cumplimientoProgramaAnual: number;
  inspeccionesRealizadas: number;
  inspeccionesSubsanadas: number;
  porcentajeSubsanacion: number;
  mensual: KPIPeriodoMensual[];
  metas: MetaIndicadoresSST;
  fechaCalculoSnapshot?: string;
}
