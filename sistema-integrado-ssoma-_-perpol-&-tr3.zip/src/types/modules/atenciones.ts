import { BaseEntity } from '../common';

export type EstadoAtencionMedica = 
  | 'En seguimiento' 
  | 'Cerrado' 
  | 'Alta / reincorporado' 
  | 'Alta con restricciones' 
  | 'Derivado a especialista';

export interface AtencionMedicaRecord extends BaseEntity {
  idAtencion: string;
  idAccidente?: string;
  codigoAccidente?: string;
  trabajadorDni: string;
  trabajadorNombre: string;
  puesto?: string;
  area?: string;
  lugarEspecifico?: string;
  turno?: string;
  lugarAtencion: string;
  tipoAtencion?: string;
  fechaAtencion: string;
  horaAtencion?: string;
  diagnostico: string;
  tratamiento?: string;
  medicamentosPrescritos?: string;
  generaDescanso: 'SI' | 'NO';
  tipoCertificadoDescanso?: string;
  nroCertificadoMedico?: string;
  cie10?: string;
  fechaInicioDescanso?: string;
  fechaFinDescanso?: string;
  diasDescanso: number;
  restriccionesLaborales?: string;
  proximaCita?: string;
  estado: EstadoAtencionMedica;
  medicoTratante?: string;
  observaciones?: string;

  // Datos heredados del evento SST
  fechaAccidente?: string;
  horaAccidente?: string;
  tipoEvento?: string;
  lugarAccidente?: string;
  partesCuerpoAfectadas?: string[];
  lesionReferida?: string[];
  mecanismoEvento?: string[];
  agenteEvento?: string[];
  descripcionAccidente?: string;
  causaInmediata?: string;
}
