import { BaseEntity } from '../common';

export interface TrabajadorRecord extends BaseEntity {
  dni: string;
  apellidosNombres: string;
  empresa: 'PERPOL' | 'TR3';
  condicion: 'Activo' | 'Inactivo' | 'Cesado';
  sexo: 'M' | 'F';
  fechaIngreso: string;
  fechaNacimiento?: string;
  puesto: string;
  area?: string;
  telefono: string;
  correo: string;
}
