import { BaseEntity, SeveridadRiesgo, PrioridadSST } from '../common';

export type TipoInspeccion = 
  | 'Condición insegura' 
  | 'Acto inseguro' 
  | 'Observación' 
  | 'No conformidad' 
  | 'Buena práctica';

export type EstadoInspeccion = 
  | 'Pendiente' 
  | 'En proceso' 
  | 'Subsanado' 
  | 'Vencido';

export interface InspeccionRecord extends BaseEntity {
  codigoInspeccion: string;
  fecha: string;
  area: string;
  lugarEspecifico?: string;
  responsableInspeccion: string;
  hallazgo: string;
  potencialGravedad: SeveridadRiesgo;
  prioridad: PrioridadSST;
  tipo: TipoInspeccion;
  evidenciasIniciales: string[];
  evidenciasCorreccion: string[];
  estado: EstadoInspeccion;
  responsableLevantamiento?: string;
  accionCorrectiva?: string;
  fechaCompromiso: string;
  fechaCierre?: string;
  fechaLevantamiento?: string;
  atencionesPrimerosAuxilios?: string[];
  diasAtraso?: number;
  estaAtrasado?: boolean;
}
