import { BaseEntity } from '../common';

export interface CostosDirectosSimulacion {
  atencionEmergencia: number;
  gastosClinicos: number;
  subsidioDiasPerdidos: number;
  reparacionEquipos: number;
  medicamentos: number;
}

export interface CostosIndirectosSimulacion {
  paralizacionPlanta: number;
  horasHombreInvestigacion: number;
  reemplazoPersonal: number;
  multasSanciones: number;
  perdidaProductividad: number;
}

export interface SimulacionCostosRecord extends BaseEntity {
  codigoSimulacion: string;
  empresa: 'PERPOL' | 'TR3';
  fechaSimulacion: string;
  incidenteId?: string;
  codigoCasoIncidente?: string;
  inspeccionId?: string;
  inspeccionPuntaje?: number;
  inspeccionDetalle?: string;
  descripcionEvento: string;
  area: string;
  lugarEspecifico?: string;

  // Matriz de potencial de riesgo (1 a 5)
  probabilidadOcurrencia: number;
  consecuenciaPersonas: number;
  consecuenciaActivos: number;
  consecuenciaOperacion: number;
  nivelRiesgoCalculado: number; // max(Personas, Activos, Operacion) * probabilidad (1 a 25)
  esHiPo: boolean;

  // Modelo económico financiero
  diasSimulados: number;
  remuneracionDiaria: number;
  costoRemuneracionSimulada: number;
  trabajadoresAfectadosParalizacion: number;
  horasParalizadas: number;
  costoHoraHombre: number;
  costoMaquinariaDanos: number;
  otrosCostosParalizacion: number;
  costoParalizacionTotal: number;

  // Desglose Directo e Indirecto
  costosDirectos: CostosDirectosSimulacion;
  costosIndirectos: CostosIndirectosSimulacion;
  costoTotalDirecto: number;
  costoTotalIndirecto: number;
  costoTotalEstimado: number;
  costoRealIncurrido: number;
  brechaCosto: number;
}
