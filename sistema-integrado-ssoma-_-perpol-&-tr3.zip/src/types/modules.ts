/**
 * Re-exportación centralizada de todos los tipos de módulos SSOMA
 */
export * from './modules/accidentes';
export * from './modules/atenciones';
export * from './modules/inspecciones';
export * from './modules/actosCondiciones';
export * from './modules/botiquin';
export * from './modules/trabajadores';
export * from './modules/horasHombre';
export * from './modules/programaAnual';
export * from './modules/estadisticas';
export * from './modules/simulacionCostos';
export * from './modules/investigacion';
