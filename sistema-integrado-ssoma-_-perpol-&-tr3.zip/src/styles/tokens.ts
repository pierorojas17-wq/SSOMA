/**
 * Sistema Unificado de Design Tokens — SSOMA PERPOL & TR3
 * Define valores estandarizados para colores, espaciados, bordes, sombras,
 * tipografías y escalas de elevación para garantizar coherencia visual.
 */

export const TOKENS = {
  // Paleta de Colores de Marca y Estados Operativos
  colors: {
    brand: {
      navy: '#263B5E',
      navyDark: '#1B2A43',
      navyLight: '#324C77',
      blue: '#3F72AF',
      blueLight: '#DBE2EF',
      teal: '#5AB9A8',
      tealDark: '#489E90',
      tealLight: '#E8F7F5',
      amber: '#F2B84B',
      amberDark: '#D49D34',
      amberLight: '#FEF9EE'
    },
    neutral: {
      appBg: '#F4F6F8',
      surface: '#FFFFFF',
      surfaceSoft: '#F8FAFC',
      surfaceMuted: '#F1F5F9',
      border: '#E5E9EF',
      borderSoft: '#EEF1F5',
      borderDark: '#CBD5E1',
      textPrimary: '#263B5E',
      textBody: '#374151',
      textSecondary: '#6B7280',
      textMuted: '#9CA3AF',
      textInverse: '#FFFFFF'
    },
    status: {
      success: {
        bg: '#ECFDF5',
        text: '#065F46',
        border: '#A7F3D0',
        dot: '#10B981',
        icon: '#059669'
      },
      warning: {
        bg: '#FFFBEB',
        text: '#92400E',
        border: '#FDE68A',
        dot: '#F59E0B',
        icon: '#D97706'
      },
      danger: {
        bg: '#FEF2F2',
        text: '#991B1B',
        border: '#FECACA',
        dot: '#EF4444',
        icon: '#DC2626'
      },
      info: {
        bg: '#EFF6FF',
        text: '#1E40AF',
        border: '#BFDBFE',
        dot: '#3B82F6',
        icon: '#2563EB'
      },
      purple: {
        bg: '#FAF5FF',
        text: '#6B21A8',
        border: '#E9D5FF',
        dot: '#A855F7',
        icon: '#9333EA'
      }
    },
    empresa: {
      PERPOL: {
        primary: '#2563EB',
        bg: '#EFF6FF',
        border: '#BFDBFE',
        text: '#1E40AF'
      },
      TR3: {
        primary: '#D97706',
        bg: '#FFFBEB',
        border: '#FDE68A',
        text: '#92400E'
      },
      CONSOLIDADO: {
        primary: '#0D9488',
        bg: '#F0FDFA',
        border: '#99F6E4',
        text: '#115E59'
      }
    }
  },

  // Espaciados Estandarizados
  spacing: {
    none: '0',
    xxs: '2px',
    xs: '4px',
    sm: '8px',
    md: '12px',
    lg: '16px',
    xl: '20px',
    '2xl': '24px',
    '3xl': '32px',
    '4xl': '40px',
    '5xl': '48px'
  },

  // Radios de Borde
  borderRadius: {
    none: '0px',
    xs: '4px',
    sm: '6px',
    md: '8px',
    lg: '12px',
    xl: '16px',
    '2xl': '20px',
    full: '9999px'
  },

  // Sombras
  shadows: {
    none: 'none',
    xs: '0 1px 2px 0 rgba(0, 0, 0, 0.04)',
    sm: '0 2px 4px 0 rgba(0, 0, 0, 0.05)',
    soft: '0 4px 14px rgba(38, 59, 94, 0.07)',
    medium: '0 8px 24px rgba(38, 59, 94, 0.10)',
    large: '0 16px 36px rgba(38, 59, 94, 0.14)',
    card: '0 2px 8px -2px rgba(38, 59, 94, 0.08), 0 4px 16px -2px rgba(38, 59, 94, 0.04)',
    modal: '0 20px 45px -10px rgba(15, 23, 42, 0.35)'
  },

  // Escala Tipográfica
  typography: {
    fonts: {
      sans: 'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace'
    },
    sizes: {
      '2xs': '10px',
      xs: '11px',
      sm: '12px',
      base: '14px',
      md: '16px',
      lg: '18px',
      xl: '20px',
      '2xl': '24px',
      '3xl': '30px'
    },
    weights: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
      extrabold: '800'
    }
  },

  // Escala de Z-Index
  zIndex: {
    base: 0,
    dropdown: 20,
    sticky: 30,
    sidebar: 40,
    header: 45,
    backdrop: 50,
    modal: 60,
    toast: 70,
    lightbox: 80,
    tooltip: 90
  },

  // Transiciones
  transitions: {
    fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
    normal: '200ms cubic-bezier(0.4, 0, 0.2, 1)',
    slow: '300ms cubic-bezier(0.4, 0, 0.2, 1)'
  }
} as const;

export type DesignTokens = typeof TOKENS;
