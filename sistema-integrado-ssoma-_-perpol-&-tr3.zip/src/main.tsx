import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { useAppStore, limpiarAlmacenamientoLocalOculto } from './store/appStore';
import { applyTheme } from './utils/themeUtils';
import { inicializarCargaAutomatica } from './services/dataLoader';
import './index.css';

// Limpieza de cualquier almacenamiento local oculto previo
limpiarAlmacenamientoLocalOculto();

// Requerimiento 1: Carga automática directa desde Google Sheets al iniciar
inicializarCargaAutomatica();

// Inicializar el tema guardado al cargar la aplicación (Blanco Corporativo obligatorio)
const currentTheme = useAppStore.getState();
if (currentTheme.themeBackground !== 'light') {
  useAppStore.setState({ themeBackground: 'light' });
}
const activeColor = (!currentTheme.themeColor || currentTheme.themeColor === 'emerald') ? 'corporate' : currentTheme.themeColor;
const activeHex = (!currentTheme.customBrandHex || currentTheme.customBrandHex === '#059669') ? '#263B5E' : currentTheme.customBrandHex;
applyTheme(
  activeColor,
  activeHex,
  'light'
);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
