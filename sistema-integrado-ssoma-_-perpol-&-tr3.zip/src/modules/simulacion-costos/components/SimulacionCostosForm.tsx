import React from 'react';
import { SimulacionCostosRecord, ScoredInspection } from '../types/simulacionCostos';
import { AccidenteRecord } from '../../../types/modules';
import { AREAS_EMPRESA, LUGARES_ESPECIFICOS } from '../../../utils/ssomaCatalogs';
import {
  Calculator,
  DollarSign,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Link as LinkIcon,
  TrendingUp,
  Save
} from 'lucide-react';

interface SimulacionCostosFormProps {
  formData: Partial<SimulacionCostosRecord>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<SimulacionCostosRecord>>>;
  editingId: string | null;
  accidentes: AccidenteRecord[];
  bestInspection: ScoredInspection | undefined;
  potentialMetrics: {
    maxConsecuencia: number;
    nivelRiesgo: number;
    esHiPo: boolean;
  };
  calculatedFinancials: {
    costoRemuneracion: number;
    costoParalizacion: number;
    totalDirecto: number;
    totalIndirecto: number;
    totalEstimado: number;
    brecha: number;
  };
  formError: string | null;
  isSubmitting: boolean;
  handleSelectIncidenteParaSimulacion: (casoCodigo: string) => void;
  handleVincularInspeccionSugerida: (scored: ScoredInspection) => void;
  handleSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
}

export const SimulacionCostosForm: React.FC<SimulacionCostosFormProps> = ({
  formData,
  setFormData,
  editingId,
  accidentes,
  bestInspection,
  potentialMetrics,
  calculatedFinancials,
  formError,
  isSubmitting,
  handleSelectIncidenteParaSimulacion,
  handleVincularInspeccionSugerida,
  handleSubmit,
  onCancel
}) => {
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {formError && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
          <span className="font-medium">{formError}</span>
        </div>
      )}

      {/* 1. Contexto del Incidente y Sugerencia Heurística */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
            <span className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#047857]" />
              1. Definición del Escenario Potencial
            </span>
            <span className="text-xs text-[#475569] font-mono font-bold">
              {editingId ? `Edición: ${editingId}` : 'Nuevo Escenario'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Empresa</label>
              <select
                value={formData.empresa}
                onChange={(e) => setFormData((prev) => ({ ...prev, empresa: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
              >
                <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Fecha Simulación</label>
              <input
                type="date"
                value={formData.fechaSimulacion}
                onChange={(e) => setFormData((prev) => ({ ...prev, fechaSimulacion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Área Involucrada <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <select
                required
                value={formData.area}
                onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                <option value="">Seleccione área...</option>
                {AREAS_EMPRESA.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <input
                type="text"
                required
                list="lista-lugares-simulacion"
                placeholder="Escribe o selecciona lugar..."
                value={formData.lugarEspecifico || ''}
                onChange={(e) => setFormData((prev) => ({ ...prev, lugarEspecifico: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
              <datalist id="lista-lugares-simulacion">
                {LUGARES_ESPECIFICOS.map((lug, idx) => (
                  <option key={`lug-sim-${idx}`} value={lug} />
                ))}
              </datalist>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Vincular Caso Real de Accidente / Incidente (Módulo 1)
            </label>
            <select
              value={formData.codigoCasoIncidente || ''}
              onChange={(e) => handleSelectIncidenteParaSimulacion(e.target.value)}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value="">Seleccione incidente de referencia...</option>
              {accidentes.map((acc, aIdx) => (
                <option key={`${acc.id || acc.codigoCaso || 'acc'}-${aIdx}`} value={acc.codigoCaso}>
                  {acc.codigoCaso} - {acc.fecha} - {acc.trabajadorNombre} ({acc.tipoEvento})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Descripción del Supuesto o Escenario Simulado *
            </label>
            <textarea
              required
              rows={3}
              value={formData.descripcionEvento}
              onChange={(e) => setFormData((prev) => ({ ...prev, descripcionEvento: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              placeholder="Detalle el escenario si el incidente hubiese escalado a una falla catastrófica..."
            />
          </div>
        </div>

        {/* Panel del Algoritmo Heurístico de Inspecciones */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
            <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#047857]" />
              Algoritmo findBestInspection
            </span>
            <span className="text-[10px] text-[#475569] font-mono font-bold">Puntuación SSOMA</span>
          </div>

          <p className="text-[11px] text-[#475569]">
            Puntúa inspecciones candidatas del Módulo 2 con <span className="text-[#047857] font-bold">+1000</span> si coincide el área, <span className="text-[#0284C7] font-bold">+120</span> si la inspección es anterior o igual al evento, menos la distancia absoluta en días.
          </p>

          {bestInspection ? (
            <div className="p-3.5 rounded-lg bg-[#F8FAFC] border border-[#CBD5E1] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-[#0F172A]">
                  {bestInspection.inspeccion.codigoInspeccion}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-[#047857] border border-emerald-300">
                  Top Score: {bestInspection.score} pts
                </span>
              </div>
              <div className="text-[11px] text-[#0F172A] line-clamp-2 font-medium">
                {bestInspection.inspeccion.hallazgo}
              </div>
              <div className="text-[10px] text-[#475569]">
                Área: {bestInspection.inspeccion.area} • Fecha: {bestInspection.inspeccion.fecha}
              </div>
              <div className="text-[10px] text-[#475569] italic">{bestInspection.razon}</div>

              <button
                type="button"
                onClick={() => handleVincularInspeccionSugerida(bestInspection)}
                className="w-full mt-1 py-1.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                <LinkIcon className="w-3.5 h-3.5" />
                <span>Vincular Inspección Sugerida</span>
              </button>
            </div>
          ) : (
            <div className="p-4 text-center text-xs text-[#475569] border border-dashed border-[#CBD5E1] rounded-lg bg-[#F8FAFC]">
              No se encontraron inspecciones candidatas para esta área.
            </div>
          )}

          {formData.inspeccionId && (
            <div className="pt-2 border-t border-[#E2E8F0] text-[11px] text-[#047857] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>Inspección vinculada: {formData.inspeccionId}</span>
            </div>
          )}
        </div>
      </div>

      {/* 2. Matriz de Riesgo y Clasificación HiPo */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#E2E8F0] gap-2">
          <span className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-600" />
            2. Matriz de Potencial y Clasificación de Alto Potencial (HiPo)
          </span>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#475569]">Riesgo Calculado:</span>
            <span className="text-base font-extrabold text-[#0F172A] font-mono">
              {potentialMetrics.nivelRiesgo} / 25
            </span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                potentialMetrics.esHiPo
                  ? 'bg-rose-100 text-rose-800 border border-rose-300'
                  : 'bg-emerald-100 text-[#047857] border border-emerald-300'
              }`}
            >
              {potentialMetrics.esHiPo ? 'HIPO (Alto Potencial)' : 'Riesgo Estándar'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Probabilidad de Ocurrencia (1 - 5)
            </label>
            <select
              value={formData.probabilidadOcurrencia}
              onChange={(e) => setFormData((prev) => ({ ...prev, probabilidadOcurrencia: Number(e.target.value) }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value={1}>1 - Muy Rara / Improbable</option>
              <option value={2}>2 - Rara (Anual)</option>
              <option value={3}>3 - Posible (Semestral)</option>
              <option value={4}>4 - Probable (Mensual)</option>
              <option value={5}>5 - Frecuente / Inminente</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Consecuencia Personas (1 - 5)
            </label>
            <select
              value={formData.consecuenciaPersonas}
              onChange={(e) => setFormData((prev) => ({ ...prev, consecuenciaPersonas: Number(e.target.value) }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value={1}>1 - Primeros Auxilios leves</option>
              <option value={2}>2 - Lesión leve (&le; 3 días descanso)</option>
              <option value={3}>3 - Lesión incapacitante temporal</option>
              <option value={4}>4 - Lesión incapacitante permanente</option>
              <option value={5}>5 - Accidente Mortal / Múltiple</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Consecuencia Activos (1 - 5)
            </label>
            <select
              value={formData.consecuenciaActivos}
              onChange={(e) => setFormData((prev) => ({ ...prev, consecuenciaActivos: Number(e.target.value) }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value={1}>1 - Sin daño material (&lt; S/ 500)</option>
              <option value={2}>2 - Daño menor (&lt; S/ 5,000)</option>
              <option value={3}>3 - Daño moderado (&lt; S/ 20,000)</option>
              <option value={4}>4 - Daño mayor (&lt; S/ 100,000)</option>
              <option value={5}>5 - Pérdida total (&gt; S/ 100,000)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Consecuencia Operación (1 - 5)
            </label>
            <select
              value={formData.consecuenciaOperacion}
              onChange={(e) => setFormData((prev) => ({ ...prev, consecuenciaOperacion: Number(e.target.value) }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value={1}>1 - Sin paralización</option>
              <option value={2}>2 - Paralización &lt; 2 horas</option>
              <option value={3}>3 - Paralización 2 a 8 horas</option>
              <option value={4}>4 - Paralización 1 a 3 días</option>
              <option value={5}>5 - Paralización prolongada &gt; 3 días</option>
            </select>
          </div>
        </div>
      </div>

      {/* 3. Modelo Económico y Fórmulas Financieras */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Costos Directos */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
            <span className="text-xs font-bold text-[#047857] flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              Costos Directos (Médicos, Subsidio y Reparación)
            </span>
            <span className="text-xs font-mono font-bold text-[#0F172A]">
              S/ {calculatedFinancials.totalDirecto.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Días Simulados</label>
              <input
                type="number"
                min={0}
                value={formData.diasSimulados}
                onChange={(e) => setFormData((prev) => ({ ...prev, diasSimulados: Number(e.target.value) }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Remuneración Diaria (S/)</label>
              <input
                type="number"
                min={0}
                value={formData.remuneracionDiaria}
                onChange={(e) => setFormData((prev) => ({ ...prev, remuneracionDiaria: Number(e.target.value) }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div className="col-span-2 text-[11px] text-[#475569] pt-1 border-t border-[#E2E8F0] flex justify-between">
              <span>Subsidio Laboral (Días × Remuneración):</span>
              <span className="font-mono font-bold text-[#047857]">
                S/ {calculatedFinancials.costoRemuneracion.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Atención Emergencia (S/)</label>
              <input
                type="number"
                value={formData.costosDirectos?.atencionEmergencia}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosDirectos: { ...prev.costosDirectos!, atencionEmergencia: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Gastos Clínicos (S/)</label>
              <input
                type="number"
                value={formData.costosDirectos?.gastosClinicos}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosDirectos: { ...prev.costosDirectos!, gastosClinicos: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Reparación de Equipos (S/)</label>
              <input
                type="number"
                value={formData.costosDirectos?.reparacionEquipos}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosDirectos: { ...prev.costosDirectos!, reparacionEquipos: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Medicamentos / Tópico (S/)</label>
              <input
                type="number"
                value={formData.costosDirectos?.medicamentos}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosDirectos: { ...prev.costosDirectos!, medicamentos: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
          </div>
        </div>

        {/* Costos Indirectos */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
            <span className="text-xs font-bold text-[#B45309] flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              Costos Indirectos (Paralización, Multas y Productividad)
            </span>
            <span className="text-xs font-mono font-bold text-[#0F172A]">
              S/ {calculatedFinancials.totalIndirecto.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg grid grid-cols-3 gap-2 text-xs">
            <div>
              <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">Trabajadores Afect.</label>
              <input
                type="number"
                min={0}
                value={formData.trabajadoresAfectadosParalizacion}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    trabajadoresAfectadosParalizacion: Number(e.target.value)
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">Horas Paralizadas</label>
              <input
                type="number"
                min={0}
                value={formData.horasParalizadas}
                onChange={(e) => setFormData((prev) => ({ ...prev, horasParalizadas: Number(e.target.value) }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">Costo HH (S/)</label>
              <input
                type="number"
                min={0}
                value={formData.costoHoraHombre}
                onChange={(e) => setFormData((prev) => ({ ...prev, costoHoraHombre: Number(e.target.value) }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div className="col-span-3 text-[11px] text-[#475569] pt-1 border-t border-[#E2E8F0] flex justify-between">
              <span>Paralización = (Trab. × Horas × Costo/h) + Maquinaria + Otros:</span>
              <span className="font-mono font-bold text-[#B45309]">
                S/ {calculatedFinancials.costoParalizacion.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Horas Investigación SSOMA (S/)</label>
              <input
                type="number"
                value={formData.costosIndirectos?.horasHombreInvestigacion}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosIndirectos: { ...prev.costosIndirectos!, horasHombreInvestigacion: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Reemplazo / Horas Extra (S/)</label>
              <input
                type="number"
                value={formData.costosIndirectos?.reemplazoPersonal}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosIndirectos: { ...prev.costosIndirectos!, reemplazoPersonal: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Multas / Sanciones Probables (S/)</label>
              <input
                type="number"
                value={formData.costosIndirectos?.multasSanciones}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosIndirectos: { ...prev.costosIndirectos!, multasSanciones: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Pérdida Productividad (S/)</label>
              <input
                type="number"
                value={formData.costosIndirectos?.perdidaProductividad}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    costosIndirectos: { ...prev.costosIndirectos!, perdidaProductividad: Number(e.target.value) }
                  }))
                }
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 4. Resumen Consolidado y Cálculo de la Brecha Preventiva */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#E2E8F0] gap-2">
          <span className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#047857]" />
            Cálculo de la Brecha Preventiva (Ahorro Potencial Evitado)
          </span>
          <span className="text-xs text-[#475569]">
            Brecha = Costo Neto Estimado - Costo Real Incurrido
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg">
            <span className="text-xs text-[#475569] block mb-1 font-semibold">Costo Real Incurrido</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[#475569] text-xs font-bold">S/</span>
              <input
                type="number"
                min={0}
                value={formData.costoRealIncurrido}
                onChange={(e) => setFormData((prev) => ({ ...prev, costoRealIncurrido: Number(e.target.value) }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-sm text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <span className="text-[10px] text-[#475569] mt-1 block">Gasto médico/reparación real</span>
          </div>

          <div className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg">
            <span className="text-xs text-[#475569] block mb-1 font-semibold">Total Directos Simulado</span>
            <div className="text-lg font-bold text-[#047857] font-mono">
              S/ {calculatedFinancials.totalDirecto.toFixed(2)}
            </div>
            <span className="text-[10px] text-[#475569] mt-1 block">Subsidios y atención</span>
          </div>

          <div className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg">
            <span className="text-xs text-[#475569] block mb-1 font-semibold">Total Indirectos Simulado</span>
            <div className="text-lg font-bold text-[#B45309] font-mono">
              S/ {calculatedFinancials.totalIndirecto.toFixed(2)}
            </div>
            <span className="text-[10px] text-[#475569] mt-1 block">Paralización y multas</span>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
            <span className="text-xs text-[#047857] font-bold block mb-1">Brecha Económica Neta</span>
            <div className="text-xl font-black text-[#047857] font-mono">
              S/ {calculatedFinancials.brecha.toFixed(2)}
            </div>
            <span className="text-[10px] text-[#047857] mt-1 block font-medium">Retorno preventivo ante Gerencia</span>
          </div>
        </div>
      </div>

      {/* Botones de acción */}
      <div className="flex items-center justify-end gap-3 pt-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-[#475569] border border-[#CBD5E1] transition-colors cursor-pointer"
        >
          Cancelar
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white text-xs font-bold transition-colors shadow-sm cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
        >
          <Save className="w-4 h-4" />
          <span>Guardar Escenario en Base Aislada</span>
        </button>
      </div>
    </form>
  );
};
