import React from 'react';
import { Calculator, DollarSign, TrendingUp } from 'lucide-react';
import { SimulacionCostosMetricas } from '../types/simulacionCostos';

interface SimulacionCostosStatsProps {
  metricas: SimulacionCostosMetricas;
}

export const SimulacionCostosStats: React.FC<SimulacionCostosStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Escenarios</span>
          <Calculator className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-2xl font-bold text-[#0F172A] mt-2">{metricas.total}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Simulaciones evaluadas</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Casos HiPo</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626] animate-pulse"></span>
        </div>
        <div className="text-2xl font-bold text-[#DC2626] mt-2">{metricas.countHiPo}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Alto Potencial de Pérdida</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Costos Directos</span>
          <DollarSign className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-xl font-bold text-[#047857] mt-2">
          S/ {metricas.totalDirectos.toLocaleString('es-PE', { minimumFractionDigits: 2 })}
        </div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Médico, subsidios y equipos</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Costos Indirectos</span>
          <DollarSign className="w-4 h-4 text-[#B45309]" />
        </div>
        <div className="text-xl font-bold text-[#B45309] mt-2">
          S/ {metricas.totalIndirectos.toLocaleString('es-PE', { minimumFractionDigits: 2 })}
        </div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Paralización, multas, reemplazo</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Brecha (Ahorro)</span>
          <TrendingUp className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-xl font-bold text-[#047857] mt-2">
          S/ {metricas.totalAhorroPotencial.toLocaleString('es-PE', { minimumFractionDigits: 2 })}
        </div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Justificación preventiva</div>
      </div>
    </div>
  );
};
