import React, { useMemo } from 'react';
import { SimulacionCostosRecord } from '../types/simulacionCostos';
import { DataTable, ColumnDef } from '../../../components/common/DataTable';
import { Eye, Edit2, Trash2 } from 'lucide-react';

interface SimulacionCostosTableProps {
  items: SimulacionCostosRecord[];
  searchTerm: string;
  filterHiPo: string;
  currentPage: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  onView: (item: SimulacionCostosRecord) => void;
  onEdit: (item: SimulacionCostosRecord) => void;
  onDelete: (item: SimulacionCostosRecord) => void;
  onClearFilters: () => void;
  onNewRecord: () => void;
  isLoading?: boolean;
}

export const SimulacionCostosTable: React.FC<SimulacionCostosTableProps> = ({
  items,
  searchTerm,
  filterHiPo,
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  onView,
  onEdit,
  onDelete,
  onClearFilters,
  onNewRecord,
  isLoading = false
}) => {
  const columns: ColumnDef<SimulacionCostosRecord>[] = useMemo(
    () => [
      {
        key: 'codigoSimulacion',
        header: 'Código',
        width: 'w-28',
        accessor: (sim) => (
          <div className="font-semibold text-emerald-700 whitespace-nowrap">
            {sim.codigoSimulacion}
            {sim.codigoCasoIncidente && (
              <div className="text-[10px] text-rose-600 font-mono">
                Ref: {sim.codigoCasoIncidente}
              </div>
            )}
          </div>
        )
      },
      {
        key: 'fechaSimulacion',
        header: 'Fecha',
        width: 'w-28',
        accessor: (sim) => (
          <span className="whitespace-nowrap text-slate-800 font-medium">
            {sim.fechaSimulacion}
          </span>
        )
      },
      {
        key: 'empresa',
        header: 'Empresa',
        width: 'w-28',
        accessor: (sim) => (
          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              sim.empresa === 'PERPOL'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'bg-amber-50 text-amber-700 border border-amber-200'
            }`}
          >
            {sim.empresa}
          </span>
        )
      },
      {
        key: 'descripcionEvento',
        header: 'Área / Escenario',
        className: 'max-w-xs',
        accessor: (sim) => (
          <div>
            <div className="text-slate-800 font-medium truncate" title={`${sim.area}${sim.lugarEspecifico ? ` • ${sim.lugarEspecifico}` : ''}`}>
              {sim.area}{sim.lugarEspecifico ? ` • ${sim.lugarEspecifico}` : ''}
            </div>
            <div className="text-[11px] text-slate-500 truncate">{sim.descripcionEvento}</div>
          </div>
        )
      },
      {
        key: 'inspeccionId',
        header: 'Inspección Asociada',
        width: 'min-w-[160px]',
        accessor: (sim) =>
          sim.inspeccionId ? (
            <div>
              <span className="font-mono text-indigo-700 font-bold text-[11px]">
                {sim.inspeccionId}
              </span>
              <div className="text-[10px] text-emerald-700 font-semibold">
                Score: {sim.inspeccionPuntaje} pts
              </div>
            </div>
          ) : (
            <span className="text-slate-500 font-medium text-[11px]">Sin vincular</span>
          )
      },
      {
        key: 'esHiPo',
        header: 'Riesgo / HiPo',
        width: 'w-32',
        accessor: (sim) => (
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                sim.esHiPo
                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              }`}
            >
              {sim.esHiPo ? 'HiPo' : 'Estándar'}
            </span>
            <span className="text-[11px] font-mono text-slate-600 font-medium">
              (Nivel {sim.nivelRiesgoCalculado})
            </span>
          </div>
        )
      },
      {
        key: 'costoTotalDirecto',
        header: 'Costo Directo',
        width: 'w-28',
        align: 'right',
        accessor: (sim) => (
          <span className="whitespace-nowrap font-mono text-emerald-700 font-bold">
            S/ {sim.costoTotalDirecto.toFixed(2)}
          </span>
        )
      },
      {
        key: 'costoTotalIndirecto',
        header: 'Costo Indirecto',
        width: 'w-28',
        align: 'right',
        accessor: (sim) => (
          <span className="whitespace-nowrap font-mono text-amber-700 font-bold">
            S/ {sim.costoTotalIndirecto.toFixed(2)}
          </span>
        )
      },
      {
        key: 'costoTotalEstimado',
        header: 'Total Estimado',
        width: 'w-32',
        align: 'right',
        accessor: (sim) => (
          <span className="whitespace-nowrap font-mono text-slate-900 font-bold">
            S/ {sim.costoTotalEstimado.toFixed(2)}
          </span>
        )
      },
      {
        key: 'brechaCosto',
        header: 'Brecha (Ahorro)',
        width: 'w-32',
        align: 'right',
        accessor: (sim) => (
          <span className="whitespace-nowrap font-mono text-teal-700 font-bold">
            S/ {sim.brechaCosto.toFixed(2)}
          </span>
        )
      }
    ],
    []
  );

  return (
    <DataTable
      columns={columns}
      data={items}
      isLoading={isLoading}
      rowKey={(sim, idx) => `${sim.id || sim.codigoSimulacion}-${idx}`}
      pagination={true}
      currentPage={currentPage}
      pageSize={pageSize}
      totalItems={totalItems}
      onPageChange={onPageChange}
      onPageSizeChange={onPageSizeChange}
      emptyTitle="No se encontraron escenarios económicos simulados"
      emptyDescription={
        searchTerm
          ? `No hay simulaciones que coincidan con "${searchTerm}".`
          : 'No se encontraron escenarios de costos registrados con los filtros actuales.'
      }
      emptyActionLabel={searchTerm || filterHiPo !== 'TODOS' ? 'Limpiar filtros' : 'Nuevo Escenario'}
      emptyActionIcon={searchTerm || filterHiPo !== 'TODOS' ? 'clear' : 'plus'}
      onEmptyAction={() => {
        if (searchTerm || filterHiPo !== 'TODOS') {
          onClearFilters();
        } else {
          onNewRecord();
        }
      }}
      actions={(sim) => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            type="button"
            onClick={() => onView(sim)}
            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            title="Ver Ficha Económica"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onEdit(sim)}
            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer"
            title="Editar Escenario"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onDelete(sim)}
            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
            title="Eliminar Escenario"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )}
    />
  );
};
