import React from 'react';
import { Calculator, X } from 'lucide-react';
import { SimulacionCostosRecord } from '../types/simulacionCostos';

interface SimulacionCostosDetailModalProps {
  viewModal: SimulacionCostosRecord | null;
  onClose: () => void;
}

export const SimulacionCostosDetailModal: React.FC<SimulacionCostosDetailModalProps> = ({
  viewModal,
  onClose
}) => {
  if (!viewModal) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 pr-2">
            <div className="w-9 h-9 rounded-lg bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center shrink-0">
              <Calculator className="w-5 h-5 text-teal-600" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-[#0F172A] flex items-center gap-2 truncate">
                <span>Ficha de Simulación Económica</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-teal-50 text-teal-800 border border-teal-200">
                  {viewModal.codigoSimulacion}
                </span>
              </h3>
              <p className="text-xs text-[#475569] font-medium truncate">
                Escenario económico de pérdida potencial y valor preventivo
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200 active:bg-slate-300 transition-colors cursor-pointer shrink-0"
            title="Cerrar ficha (Esc)"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Contenido con scroll */}
        <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <span className="text-[#475569] block text-[10px] uppercase font-bold">Empresa</span>
              <span className="font-bold text-[#0F172A]">{viewModal.empresa === 'PERPOL' ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}</span>
            </div>
            <div>
              <span className="text-[#475569] block text-[10px] uppercase font-bold">Fecha</span>
              <span className="font-semibold text-[#0F172A] font-mono">{viewModal.fechaSimulacion}</span>
            </div>
            <div>
              <span className="text-[#475569] block text-[10px] uppercase font-bold">Área / Lugar Específico</span>
              <span className="font-bold text-[#0F172A] block truncate">{viewModal.area}</span>
              <span className="text-[10px] text-slate-500">{viewModal.lugarEspecifico || 'General'}</span>
            </div>
            <div>
              <span className="text-[#475569] block text-[10px] uppercase font-bold">Nivel Riesgo / HiPo</span>
              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                viewModal.esHiPo
                  ? 'bg-rose-50 text-rose-800 border-rose-200'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-200'
              }`}>
                {viewModal.nivelRiesgoCalculado}/25 • {viewModal.esHiPo ? 'HiPo' : 'Moderado'}
              </span>
            </div>
          </div>

          <div>
            <span className="font-bold text-[#0F172A] block mb-1 text-[11px] uppercase tracking-wider">
              Escenario Simulado:
            </span>
            <p className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-slate-800 font-medium leading-relaxed">
              {viewModal.descripcionEvento}
            </p>
          </div>

          {viewModal.inspeccionId && (
            <div className="p-3.5 bg-indigo-50/60 border border-indigo-200 rounded-xl space-y-1">
              <span className="font-bold text-indigo-900 block text-[11px]">Inspección Vinculada (Heurística):</span>
              <div className="text-indigo-800 font-medium">{viewModal.inspeccionId} — {viewModal.inspeccionDetalle}</div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-teal-800 block text-xs uppercase tracking-wider">Costos Directos:</span>
              <div className="flex justify-between text-slate-600"><span>Atención Médica:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosDirectos.atencionEmergencia.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Gastos Clínicos:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosDirectos.gastosClinicos.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Subsidio Laboral:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costoRemuneracionSimulada.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Reparación Equipos:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosDirectos.reparacionEquipos.toFixed(2)}</span></div>
              <div className="flex justify-between font-bold text-teal-900 pt-2 border-t border-slate-200">
                <span>Total Directos:</span><span className="font-mono">S/ {viewModal.costoTotalDirecto.toFixed(2)}</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-amber-800 block text-xs uppercase tracking-wider">Costos Indirectos:</span>
              <div className="flex justify-between text-slate-600"><span>Paralización Planta:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costoParalizacionTotal.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Investigación SSOMA:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosIndirectos.horasHombreInvestigacion.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Reemplazo Personal:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosIndirectos.reemplazoPersonal.toFixed(2)}</span></div>
              <div className="flex justify-between text-slate-600"><span>Multas / Sanciones:</span><span className="font-mono text-slate-900 font-semibold">S/ {viewModal.costosIndirectos.multasSanciones.toFixed(2)}</span></div>
              <div className="flex justify-between font-bold text-amber-900 pt-2 border-t border-slate-200">
                <span>Total Indirectos:</span><span className="font-mono">S/ {viewModal.costoTotalIndirecto.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl flex items-center justify-between font-bold text-sm text-teal-900">
            <span>Brecha Neta de Ahorro Preventivo:</span>
            <span className="font-mono text-lg text-teal-700">S/ {viewModal.brechaCosto.toFixed(2)}</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono">Simulación: {viewModal.codigoSimulacion}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 active:bg-slate-400 border border-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer shadow-xs"
          >
            Cerrar Ficha
          </button>
        </div>
      </div>
    </div>
  );
};
