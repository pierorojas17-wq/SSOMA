import { SimulacionCostosRecord } from '../../../types/modules';
import { GasApiClient } from '../../../services/api';
import { ExportUtils } from '../../../utils/exportUtils';

export class SimulacionCostosService {
  /**
   * Guarda o actualiza un escenario de simulación en Google Apps Script
   */
  static async saveSimulacion(record: SimulacionCostosRecord) {
    return await GasApiClient.sendRequest({
      action: 'saveSimulacionCostos',
      sheetName: 'sst_simulacion_costos_incidentes',
      data: record
    });
  }

  /**
   * Elimina un escenario en Google Apps Script
   */
  static async deleteSimulacion(id: string) {
    return await GasApiClient.sendRequest({
      action: 'deleteSimulacionCostos',
      sheetName: 'sst_simulacion_costos_incidentes',
      data: { id }
    });
  }

  /**
   * Exporta a Excel
   */
  static exportExcel(records: SimulacionCostosRecord[], empresa: string) {
    const data = records.map((sim) => ({
      'Código Simulación': sim.codigoSimulacion,
      Empresa: sim.empresa,
      Fecha: sim.fechaSimulacion,
      'Caso Base (M1)': sim.codigoCasoIncidente || 'N/A',
      'Inspección Vinculada (M2)': sim.inspeccionId || 'N/A',
      'Puntaje Algoritmo': sim.inspeccionPuntaje || 0,
      Área: sim.area,
      'Descripción Escenario': sim.descripcionEvento,
      'Nivel de Riesgo': sim.nivelRiesgoCalculado,
      '¿Es HiPo?': sim.esHiPo ? 'SÍ (Alto Potencial)' : 'NO',
      'Días Simulados': sim.diasSimulados,
      'Costo Total Directo': `S/ ${sim.costoTotalDirecto.toFixed(2)}`,
      'Costo Total Indirecto': `S/ ${sim.costoTotalIndirecto.toFixed(2)}`,
      'Costo Total Estimado': `S/ ${sim.costoTotalEstimado.toFixed(2)}`,
      'Costo Real Incurrido': `S/ ${sim.costoRealIncurrido.toFixed(2)}`,
      'Brecha (Ahorro Preventivo)': `S/ ${sim.brechaCosto.toFixed(2)}`
    }));

    ExportUtils.exportToExcel(
      data,
      `SSOMA_Simulacion_Costos_${empresa}_${new Date().toISOString().slice(0, 10)}`,
      'Simulación Costos'
    );
  }

  /**
   * Exporta a PDF
   */
  static exportPDF(records: SimulacionCostosRecord[], empresa: string) {
    ExportUtils.exportToPdf({
      title: 'SIMULACIÓN Y MODELAMIENTO DE COSTOS DE ACCIDENTES',
      subtitle: `Empresa: ${empresa} | Escenarios: ${records.length}`,
      empresa: empresa as any,
      fileName: `Simulacion_Costos_${empresa}`,
      headers: ['Código', 'Fecha', 'Empresa', 'Evento Modelado', 'Tipo HiPo', 'Costos Directos', 'Costos Indirectos', 'Brecha Ahorro'],
      rows: records.map((sim) => [
        sim.codigoSimulacion,
        sim.fechaSimulacion,
        sim.empresa,
        sim.descripcionEvento,
        sim.esHiPo ? 'HiPo' : 'Estándar',
        `S/ ${sim.costoTotalDirecto.toFixed(2)}`,
        `S/ ${sim.costoTotalIndirecto.toFixed(2)}`,
        `S/ ${sim.brechaCosto.toFixed(2)}`
      ]),
      orientation: 'landscape'
    });
  }
}
