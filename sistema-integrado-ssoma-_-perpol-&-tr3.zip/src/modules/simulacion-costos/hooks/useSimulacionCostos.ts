import { useState, useMemo } from 'react';
import { useAppStore } from '../../../store/appStore';
import { SimulacionCostosRecord } from '../../../types/modules';
import {
  SimulacionCostosTab,
  ScoredInspection,
  SimulacionCostosMetricas
} from '../types/simulacionCostos';
import { SimulacionCostosService } from '../services/simulacionCostosService';
import { FilterChipOption } from '../../../components/common/ModuleToolbar';
import { AREAS_EMPRESA } from '../../../utils/ssomaCatalogs';

export function useSimulacionCostos() {
  const {
    empresaActiva,
    accidentes,
    inspecciones,
    simulacionesCostos,
    upsertSimulacionCostos,
    batchUpsertSimulacionesCostos,
    removeSimulacionCostos,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterHiPo, setFilterHiPo] = useState<'TODOS' | 'HIPO' | 'NORMAL'>('TODOS');
  const [activeTab, setActiveTab] = useState<SimulacionCostosTab>('lista');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Modales
  const [viewModal, setViewModal] = useState<SimulacionCostosRecord | null>(null);
  const [deleteModalSimulacion, setDeleteModalSimulacion] = useState<SimulacionCostosRecord | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Paginación
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Formulario de Simulación
  const [formData, setFormData] = useState<Partial<SimulacionCostosRecord>>({
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    fechaSimulacion: new Date().toISOString().slice(0, 10),
    descripcionEvento: '',
    area: AREAS_EMPRESA[0],
    lugarEspecifico: '',
    incidenteId: '',
    codigoCasoIncidente: '',
    inspeccionId: '',
    inspeccionPuntaje: 0,
    inspeccionDetalle: '',
    probabilidadOcurrencia: 3,
    consecuenciaPersonas: 4,
    consecuenciaActivos: 2,
    consecuenciaOperacion: 3,
    nivelRiesgoCalculado: 12,
    esHiPo: true,
    diasSimulados: 30,
    remuneracionDiaria: 80,
    costoRemuneracionSimulada: 2400,
    trabajadoresAfectadosParalizacion: 8,
    horasParalizadas: 4,
    costoHoraHombre: 20,
    costoMaquinariaDanos: 2000,
    otrosCostosParalizacion: 500,
    costoParalizacionTotal: 3140,
    costosDirectos: {
      atencionEmergencia: 350,
      gastosClinicos: 3500,
      subsidioDiasPerdidos: 2400,
      reparacionEquipos: 2000,
      medicamentos: 600
    },
    costosIndirectos: {
      paralizacionPlanta: 3140,
      horasHombreInvestigacion: 1500,
      reemplazoPersonal: 2800,
      multasSanciones: 9000,
      perdidaProductividad: 4000
    },
    costoTotalDirecto: 8850,
    costoTotalIndirecto: 20440,
    costoTotalEstimado: 29290,
    costoRealIncurrido: 250,
    brechaCosto: 29040
  });

  // ALGORITMO HEURÍSTICO EXACTO: findBestInspection
  const candidateInspections = useMemo<ScoredInspection[]>(() => {
    const areaEvaluada = formData.area || '';
    const fechaEvento = formData.fechaSimulacion || new Date().toISOString().slice(0, 10);
    const dEvento = new Date(fechaEvento).getTime();

    return inspecciones
      .filter((insp) => {
        if (formData.empresa && insp.empresa !== formData.empresa) return false;
        return true;
      })
      .map((insp) => {
        let score = 0;
        const razones: string[] = [];

        if (String(insp.area || '').toLowerCase() === String(areaEvaluada || '').toLowerCase()) {
          score += 1000;
          razones.push('+1000 Coincidencia de área');
        }

        const dInsp = new Date(insp.fecha).getTime();
        const diasDiff = Math.round((dEvento - dInsp) / (1000 * 3600 * 24));

        if (diasDiff >= 0) {
          score += 120;
          razones.push('+120 Inspección previa o simultánea');
        }

        const absDist = Math.abs(diasDiff);
        score -= absDist;
        razones.push(`-${absDist} días de separación`);

        return {
          inspeccion: insp,
          score,
          razon: razones.join(' | ')
        };
      })
      .sort((a, b) => b.score - a.score);
  }, [inspecciones, formData.empresa, formData.area, formData.fechaSimulacion]);

  const bestInspection = candidateInspections[0];

  // Matriz de Riesgo y cálculo de HiPo
  const potentialMetrics = useMemo(() => {
    const prob = Number(formData.probabilidadOcurrencia) || 1;
    const pPersonas = Number(formData.consecuenciaPersonas) || 1;
    const pActivos = Number(formData.consecuenciaActivos) || 1;
    const pOperacion = Number(formData.consecuenciaOperacion) || 1;

    const maxConsecuencia = Math.max(pPersonas, pActivos, pOperacion);
    const nivelRiesgo = maxConsecuencia * prob;
    const esHiPo = maxConsecuencia >= 4 || nivelRiesgo >= 16;

    return {
      maxConsecuencia,
      nivelRiesgo,
      esHiPo
    };
  }, [
    formData.probabilidadOcurrencia,
    formData.consecuenciaPersonas,
    formData.consecuenciaActivos,
    formData.consecuenciaOperacion
  ]);

  // Fórmulas Financieras Dinámicas
  const calculatedFinancials = useMemo(() => {
    const dias = Number(formData.diasSimulados) || 0;
    const remDiaria = Number(formData.remuneracionDiaria) || 0;
    const costoRemuneracion = dias * remDiaria;

    const trabAfectados = Number(formData.trabajadoresAfectadosParalizacion) || 0;
    const horas = Number(formData.horasParalizadas) || 0;
    const costoHH = Number(formData.costoHoraHombre) || 0;
    const maq = Number(formData.costoMaquinariaDanos) || 0;
    const otros = Number(formData.otrosCostosParalizacion) || 0;

    const costoParalizacion = trabAfectados * horas * costoHH + maq + otros;

    const dir = formData.costosDirectos || {
      atencionEmergencia: 0,
      gastosClinicos: 0,
      subsidioDiasPerdidos: 0,
      reparacionEquipos: 0,
      medicamentos: 0
    };

    const indir = formData.costosIndirectos || {
      paralizacionPlanta: 0,
      horasHombreInvestigacion: 0,
      reemplazoPersonal: 0,
      multasSanciones: 0,
      perdidaProductividad: 0
    };

    const totalDirecto =
      Number(dir.atencionEmergencia) +
      Number(dir.gastosClinicos) +
      costoRemuneracion +
      Number(dir.reparacionEquipos) +
      Number(dir.medicamentos);

    const totalIndirecto =
      costoParalizacion +
      Number(indir.horasHombreInvestigacion) +
      Number(indir.reemplazoPersonal) +
      Number(indir.multasSanciones) +
      Number(indir.perdidaProductividad);

    const totalEstimado = totalDirecto + totalIndirecto;
    const realIncurrido = Number(formData.costoRealIncurrido) || 0;
    const brecha = Math.max(0, totalEstimado - realIncurrido);

    return {
      costoRemuneracion,
      costoParalizacion,
      totalDirecto,
      totalIndirecto,
      totalEstimado,
      brecha
    };
  }, [
    formData.diasSimulados,
    formData.remuneracionDiaria,
    formData.trabajadoresAfectadosParalizacion,
    formData.horasParalizadas,
    formData.costoHoraHombre,
    formData.costoMaquinariaDanos,
    formData.otrosCostosParalizacion,
    formData.costosDirectos,
    formData.costosIndirectos,
    formData.costoRealIncurrido
  ]);

  // Lista filtrada
  const filteredSimulaciones = useMemo(() => {
    return simulacionesCostos.filter((sim) => {
      if (empresaActiva !== 'CONSOLIDADO' && sim.empresa !== empresaActiva) return false;
      if (filterHiPo === 'HIPO' && !sim.esHiPo) return false;
      if (filterHiPo === 'NORMAL' && sim.esHiPo) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchCode = String(sim.codigoSimulacion || '').toLowerCase().includes(q);
        const matchDesc = String(sim.descripcionEvento || '').toLowerCase().includes(q);
        const matchArea = String(sim.area || '').toLowerCase().includes(q);
        if (!matchCode && !matchDesc && !matchArea) return false;
      }
      return true;
    });
  }, [simulacionesCostos, empresaActiva, filterHiPo, searchTerm]);

  const statusOptions: FilterChipOption[] = useMemo(() => {
    const list = simulacionesCostos.filter((s) => empresaActiva === 'CONSOLIDADO' || s.empresa === empresaActiva);
    return [
      { id: 'TODOS', label: 'Todos', count: list.length },
      { id: 'HIPO', label: 'Solo HiPo', count: list.filter((s) => s.esHiPo).length },
      { id: 'NORMAL', label: 'Riesgo Moderado', count: list.filter((s) => !s.esHiPo).length }
    ];
  }, [simulacionesCostos, empresaActiva]);

  const paginatedSimulaciones = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredSimulaciones.slice(start, start + pageSize);
  }, [filteredSimulaciones, currentPage, pageSize]);

  // Métricas
  const metricas: SimulacionCostosMetricas = useMemo(() => {
    const list = simulacionesCostos.filter(
      (s) => empresaActiva === 'CONSOLIDADO' || s.empresa === empresaActiva
    );
    const total = list.length;
    const countHiPo = list.filter((s) => s.esHiPo).length;
    const totalDirectos = list.reduce((acc, s) => acc + (s.costoTotalDirecto || 0), 0);
    const totalIndirectos = list.reduce((acc, s) => acc + (s.costoTotalIndirecto || 0), 0);
    const totalAhorroPotencial = list.reduce((acc, s) => acc + (s.brechaCosto || 0), 0);

    return {
      total,
      countHiPo,
      totalDirectos,
      totalIndirectos,
      totalAhorroPotencial
    };
  }, [simulacionesCostos, empresaActiva]);

  const handleSelectIncidenteParaSimulacion = (casoCodigo: string) => {
    const acc = accidentes.find((a) => a.codigoCaso === casoCodigo || a.id === casoCodigo);
    if (!acc) return;

    setFormData((prev) => ({
      ...prev,
      incidenteId: acc.codigoCaso,
      codigoCasoIncidente: acc.codigoCaso,
      empresa: acc.empresa,
      area: acc.area,
      lugarEspecifico: acc.lugarExacto,
      descripcionEvento: `[Simulación de potencial basada en ${acc.codigoCaso}]: ${acc.descripcion}`
    }));

    addToast({
      type: 'info',
      title: 'Incidente Vinculado',
      message: `Datos del evento ${acc.codigoCaso} cargados para simulación económica.`
    });
  };

  const handleVincularInspeccionSugerida = (scored: ScoredInspection) => {
    setFormData((prev) => ({
      ...prev,
      inspeccionId: scored.inspeccion.codigoInspeccion,
      inspeccionPuntaje: scored.score,
      inspeccionDetalle: `${scored.inspeccion.hallazgo} (Score: ${scored.score} pts)`
    }));

    addToast({
      type: 'success',
      title: 'Inspección Vinculada',
      message: `Inspección ${scored.inspeccion.codigoInspeccion} asociada con puntaje ${scored.score} pts.`
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!String(formData.area || '').trim()) {
      setFormError('Debe seleccionar el área involucrada.');
      return;
    }
    if (!String(formData.lugarEspecifico || '').trim()) {
      setFormError('Debe especificar el lugar físico específico.');
      return;
    }
    if (!String(formData.descripcionEvento || '').trim()) {
      setFormError('Debe ingresar la descripción del escenario simulado.');
      return;
    }

    setIsSubmitting(true);
    incrementSync();

    try {
      const anio = new Date().getFullYear();
      const totalAnio = simulacionesCostos.filter((s) => {
        const f = s.fechaSimulacion || '';
        return f.startsWith(String(anio)) || (s.codigoSimulacion && s.codigoSimulacion.includes(`-${anio}-`));
      }).length;
      const existingSim = editingId ? simulacionesCostos.find((s) => s.id === editingId || s.codigoSimulacion === editingId) : null;
      const correlativoCodigo =
        formData.codigoSimulacion ||
        existingSim?.codigoSimulacion ||
        (editingId && !editingId.includes('-17') && !editingId.includes('-16') ? editingId : undefined) ||
        `SIM-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;

      const fullRecord: SimulacionCostosRecord = {
        id: editingId || correlativoCodigo,
        codigoSimulacion: correlativoCodigo,
        empresa: formData.empresa as 'PERPOL' | 'TR3',
        fechaSimulacion: formData.fechaSimulacion || new Date().toISOString().slice(0, 10),
        incidenteId: formData.incidenteId,
        codigoCasoIncidente: formData.codigoCasoIncidente,
        inspeccionId: formData.inspeccionId,
        inspeccionPuntaje: formData.inspeccionPuntaje,
        inspeccionDetalle: formData.inspeccionDetalle,
        descripcionEvento: formData.descripcionEvento!,
        area: formData.area || AREAS_EMPRESA[0],
        lugarEspecifico: String(formData.lugarEspecifico || '').trim() || undefined,
        probabilidadOcurrencia: Number(formData.probabilidadOcurrencia) || 3,
        consecuenciaPersonas: Number(formData.consecuenciaPersonas) || 3,
        consecuenciaActivos: Number(formData.consecuenciaActivos) || 2,
        consecuenciaOperacion: Number(formData.consecuenciaOperacion) || 3,
        nivelRiesgoCalculado: potentialMetrics.nivelRiesgo,
        esHiPo: potentialMetrics.esHiPo,
        diasSimulados: Number(formData.diasSimulados) || 0,
        remuneracionDiaria: Number(formData.remuneracionDiaria) || 0,
        costoRemuneracionSimulada: calculatedFinancials.costoRemuneracion,
        trabajadoresAfectadosParalizacion: Number(formData.trabajadoresAfectadosParalizacion) || 0,
        horasParalizadas: Number(formData.horasParalizadas) || 0,
        costoHoraHombre: Number(formData.costoHoraHombre) || 0,
        costoMaquinariaDanos: Number(formData.costoMaquinariaDanos) || 0,
        otrosCostosParalizacion: Number(formData.otrosCostosParalizacion) || 0,
        costoParalizacionTotal: calculatedFinancials.costoParalizacion,
        costosDirectos: {
          atencionEmergencia: Number(formData.costosDirectos?.atencionEmergencia) || 0,
          gastosClinicos: Number(formData.costosDirectos?.gastosClinicos) || 0,
          subsidioDiasPerdidos: calculatedFinancials.costoRemuneracion,
          reparacionEquipos: Number(formData.costosDirectos?.reparacionEquipos) || 0,
          medicamentos: Number(formData.costosDirectos?.medicamentos) || 0
        },
        costosIndirectos: {
          paralizacionPlanta: calculatedFinancials.costoParalizacion,
          horasHombreInvestigacion: Number(formData.costosIndirectos?.horasHombreInvestigacion) || 0,
          reemplazoPersonal: Number(formData.costosIndirectos?.reemplazoPersonal) || 0,
          multasSanciones: Number(formData.costosIndirectos?.multasSanciones) || 0,
          perdidaProductividad: Number(formData.costosIndirectos?.perdidaProductividad) || 0
        },
        costoTotalDirecto: calculatedFinancials.totalDirecto,
        costoTotalIndirecto: calculatedFinancials.totalIndirecto,
        costoTotalEstimado: calculatedFinancials.totalEstimado,
        costoRealIncurrido: Number(formData.costoRealIncurrido) || 0,
        brechaCosto: calculatedFinancials.brecha,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      upsertSimulacionCostos(fullRecord);

      const apiRes = await SimulacionCostosService.saveSimulacion(fullRecord);

      if (apiRes.success) {
        addToast({
          type: 'success',
          title: 'Escenario Guardado',
          message: `${correlativoCodigo} registrado en sst_simulacion_costos_incidentes (Aislado de estadísticas).`
        });
      } else {
        addToast({
          type: 'warning',
          title: 'Almacenado Local',
          message: 'Escenario simulado guardado en caché local.'
        });
      }

      setActiveTab('lista');
      setEditingId(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar simulación';
      setFormError(msg);
      addToast({ type: 'error', title: 'Error', message: msg });
    } finally {
      setIsSubmitting(false);
      decrementSync();
    }
  };

  const handleExportarExcel = () => {
    SimulacionCostosService.exportExcel(filteredSimulaciones, empresaActiva);
    addToast({ type: 'success', title: 'Exportación', message: 'Simulaciones de costos descargadas en Excel.' });
  };

  const handleExportarPDF = () => {
    SimulacionCostosService.exportPDF(filteredSimulaciones, empresaActiva);
    addToast({ type: 'success', title: 'PDF Generado', message: 'Reporte de simulación de costos descargado.' });
  };

  const confirmDeleteSimulacion = () => {
    if (!deleteModalSimulacion) return;
    removeSimulacionCostos(deleteModalSimulacion.id);
    addToast({ type: 'info', title: 'Eliminado', message: `Simulación ${deleteModalSimulacion.codigoSimulacion} borrada.` });
    setDeleteModalSimulacion(null);
  };

  const handleNuevo = () => {
    setEditingId(null);
    setFormData({
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
      fechaSimulacion: new Date().toISOString().slice(0, 10),
      descripcionEvento: '',
      area: AREAS_EMPRESA[0],
      incidenteId: '',
      codigoCasoIncidente: '',
      inspeccionId: '',
      inspeccionPuntaje: 0,
      inspeccionDetalle: '',
      probabilidadOcurrencia: 3,
      consecuenciaPersonas: 4,
      consecuenciaActivos: 2,
      consecuenciaOperacion: 3,
      nivelRiesgoCalculado: 12,
      esHiPo: true,
      diasSimulados: 30,
      remuneracionDiaria: 80,
      costoRemuneracionSimulada: 2400,
      trabajadoresAfectadosParalizacion: 8,
      horasParalizadas: 4,
      costoHoraHombre: 20,
      costoMaquinariaDanos: 2000,
      otrosCostosParalizacion: 500,
      costoParalizacionTotal: 3140,
      costosDirectos: {
        atencionEmergencia: 350,
        gastosClinicos: 3500,
        subsidioDiasPerdidos: 2400,
        reparacionEquipos: 2000,
        medicamentos: 600
      },
      costosIndirectos: {
        paralizacionPlanta: 3140,
        horasHombreInvestigacion: 1500,
        reemplazoPersonal: 2800,
        multasSanciones: 9000,
        perdidaProductividad: 4000
      },
      costoTotalDirecto: 8850,
      costoTotalIndirecto: 20440,
      costoTotalEstimado: 29290,
      costoRealIncurrido: 250,
      brechaCosto: 29040
    });
    setFormError(null);
    setActiveTab('simulador');
  };

  const handleEdit = (sim: SimulacionCostosRecord) => {
    setEditingId(sim.id);
    setFormData(sim);
    setActiveTab('simulador');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return {
    empresaActiva,
    accidentes,
    simulacionesCostos,
    searchTerm,
    setSearchTerm,
    filterHiPo,
    setFilterHiPo,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    viewModal,
    setViewModal,
    deleteModalSimulacion,
    setDeleteModalSimulacion,
    editingId,
    isSubmitting,
    formError,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    formData,
    setFormData,
    bestInspection,
    potentialMetrics,
    calculatedFinancials,
    filteredSimulaciones,
    statusOptions,
    paginatedSimulaciones,
    metricas,
    handleSelectIncidenteParaSimulacion,
    handleVincularInspeccionSugerida,
    handleSubmit,
    handleExportarExcel,
    handleExportarPDF,
    confirmDeleteSimulacion,
    handleNuevo,
    handleEdit,
    batchUpsertSimulacionesCostos
  };
}
