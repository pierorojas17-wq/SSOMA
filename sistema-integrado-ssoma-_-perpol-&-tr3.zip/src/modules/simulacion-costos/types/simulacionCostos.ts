export * from '../../../types/modules/simulacionCostos';
import { InspeccionRecord } from '../../../types/modules';

export type SimulacionCostosTab = 'lista' | 'simulador';

export interface ScoredInspection {
  inspeccion: InspeccionRecord;
  score: number;
  razon: string;
}

export interface SimulacionCostosMetricas {
  total: number;
  countHiPo: number;
  totalDirectos: number;
  totalIndirectos: number;
  totalAhorroPotencial: number;
}
