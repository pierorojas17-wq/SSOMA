import React from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { ModuleToolbar } from '../../components/common/ModuleToolbar';
import { Calculator, PieChart } from 'lucide-react';

import { useSimulacionCostos } from './hooks/useSimulacionCostos';
import { SimulacionCostosStats } from './components/SimulacionCostosStats';
import { SimulacionCostosTable } from './components/SimulacionCostosTable';
import { SimulacionCostosForm } from './components/SimulacionCostosForm';
import { SimulacionCostosDetailModal } from './components/SimulacionCostosDetailModal';

export const SimulacionCostosPage: React.FC = () => {
  const {
    empresaActiva,
    accidentes,
    simulacionesCostos,
    searchTerm,
    setSearchTerm,
    filterHiPo,
    setFilterHiPo,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    viewModal,
    setViewModal,
    deleteModalSimulacion,
    setDeleteModalSimulacion,
    editingId,
    isSubmitting,
    formError,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    formData,
    setFormData,
    bestInspection,
    potentialMetrics,
    calculatedFinancials,
    filteredSimulaciones,
    statusOptions,
    paginatedSimulaciones,
    metricas,
    handleSelectIncidenteParaSimulacion,
    handleVincularInspeccionSugerida,
    handleSubmit,
    handleExportarExcel,
    handleExportarPDF,
    confirmDeleteSimulacion,
    handleNuevo,
    handleEdit,
    batchUpsertSimulacionesCostos
  } = useSimulacionCostos();

  return (
    <div className="space-y-6">
      {/* Encabezado Principal */}
      <ModuleHeader
        codigo={12}
        titulo="Simulación de Costos de Accidentes e Incidentes"
        subtitulo="Algoritmo heurístico de vinculación con inspecciones, matriz de potencial HiPo y modelo económico"
        icono={<Calculator className="w-5 h-5 text-teal-400" />}
        onNuevo={handleNuevo}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.simulacionCostos}
        onImportSuccess={(rows) => {
          batchUpsertSimulacionesCostos(rows as any);
        }}
      />

      {/* Tarjetas KPI de Resumen */}
      <SimulacionCostosStats metricas={metricas} />

      {/* Tabs */}
      <div className="flex border-b border-[#E2E8F0] bg-white px-2 rounded-t-xl gap-1">
        <button
          onClick={() => setActiveTab('lista')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'lista'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>Escenarios Simulados</span>
          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'lista' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#0F172A]'
            }`}
          >
            {filteredSimulaciones.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('simulador')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'simulador'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>
            {editingId ? `Editando ${editingId}` : 'Simulador Económico y Algoritmo Heurístico'}
          </span>
        </button>
      </div>

      {/* TAB 1: LISTA DE ESCENARIOS */}
      {activeTab === 'lista' && (
        <div className="space-y-4">
          <ModuleToolbar
            searchQuery={searchTerm}
            onSearchChange={(val) => {
              setSearchTerm(val);
              setCurrentPage(1);
            }}
            searchPlaceholder="Buscar por código (SIM-...), área o descripción del escenario..."
            statusFilter={filterHiPo}
            onStatusFilterChange={(id) => {
              setFilterHiPo(id as any);
              setCurrentPage(1);
            }}
            statusOptions={statusOptions}
            totalCount={
              simulacionesCostos.filter((s) =>
                empresaActiva === 'CONSOLIDADO' ? true : s.empresa === empresaActiva
              ).length
            }
            filteredCount={filteredSimulaciones.length}
            onExportExcel={handleExportarExcel}
            onExportPdf={handleExportarPDF}
            onNewRecord={handleNuevo}
            newRecordLabel="Nuevo Escenario"
          />

          <SimulacionCostosTable
            items={paginatedSimulaciones}
            searchTerm={searchTerm}
            filterHiPo={filterHiPo}
            currentPage={currentPage}
            pageSize={pageSize}
            totalItems={filteredSimulaciones.length}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
            onView={(sim) => setViewModal(sim)}
            onEdit={handleEdit}
            onDelete={(sim) => setDeleteModalSimulacion(sim)}
            onClearFilters={() => {
              setSearchTerm('');
              setFilterHiPo('TODOS');
              setCurrentPage(1);
            }}
            onNewRecord={handleNuevo}
          />
        </div>
      )}

      {/* TAB 2: SIMULADOR ECONÓMICO */}
      {activeTab === 'simulador' && (
        <SimulacionCostosForm
          formData={formData}
          setFormData={setFormData}
          editingId={editingId}
          accidentes={accidentes}
          bestInspection={bestInspection}
          potentialMetrics={potentialMetrics}
          calculatedFinancials={calculatedFinancials}
          formError={formError}
          isSubmitting={isSubmitting}
          handleSelectIncidenteParaSimulacion={handleSelectIncidenteParaSimulacion}
          handleVincularInspeccionSugerida={handleVincularInspeccionSugerida}
          handleSubmit={handleSubmit}
          onCancel={() => setActiveTab('lista')}
        />
      )}

      {/* Modal Ficha Completa */}
      <SimulacionCostosDetailModal
        viewModal={viewModal}
        onClose={() => setViewModal(null)}
      />

      {/* Modal de confirmación para eliminar simulación */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalSimulacion)}
        onClose={() => setDeleteModalSimulacion(null)}
        onConfirm={confirmDeleteSimulacion}
        title="Eliminar Simulación de Costos"
        message="¿Estás seguro de que deseas eliminar este modelo de simulación de costos?"
        itemIdentifier={
          deleteModalSimulacion
            ? `${deleteModalSimulacion.codigoSimulacion}: ${deleteModalSimulacion.descripcionEvento} (S/ ${(
                deleteModalSimulacion.costoTotalDirecto + deleteModalSimulacion.costoTotalIndirecto
              ).toFixed(2)})`
            : undefined
        }
        confirmButtonText="Eliminar Simulación"
      />
    </div>
  );
};
