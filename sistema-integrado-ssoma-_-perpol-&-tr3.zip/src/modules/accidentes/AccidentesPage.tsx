import React, { useState } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { AccidenteRecord } from '../../types/modules';

// Subcomponentes del módulo Accidentes
import { AccidentesStats } from './components/AccidentesStats';
import { AccidentesFilters } from './components/AccidentesFilters';
import { AccidentesTable } from './components/AccidentesTable';
import { BandejaEntradaTable } from './components/BandejaEntradaTable';
import { AccidentesForm } from './components/AccidentesForm';
import { AccidentesFormModal } from './components/AccidentesFormModal';
import { AccidentesDetailModal } from './components/AccidentesDetailModal';
import { AccidentesSeguimientoModal } from './components/AccidentesSeguimientoModal';
import { PromptAtencionModal } from './components/PromptAtencionModal';

// Hook personalizado con lógica desacoplada
import { useAccidentes } from './hooks/useAccidentes';

// Iconos
import { AlertOctagon, Inbox, Plus } from 'lucide-react';

export const AccidentesPage: React.FC = () => {
  const {
    empresaActiva,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    searchTerm,
    setSearchTerm,
    tipoEventoFilter,
    setTipoEventoFilter,
    estadoFilter,
    setEstadoFilter,
    areaFilter,
    setAreaFilter,
    fechaDesde,
    setFechaDesde,
    fechaHasta,
    setFechaHasta,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    viewDetailModal,
    setViewDetailModal,
    seguimientoModal,
    setSeguimientoModal,
    deleteModalCaso,
    setDeleteModalCaso,
    promptAtencionModal,
    setPromptAtencionModal,
    formData,
    setFormData,
    editingId,
    formError,
    isSubmitting,
    imageFile,
    imagePreview,
    workerSearchTerm,
    setWorkerSearchTerm,
    isWorkerDropdownOpen,
    setIsWorkerDropdownOpen,
    isCustomResponsable,
    setIsCustomResponsable,
    responsablesLiderazgo,
    trabajadoresFiltrados,
    metricas,
    filteredAccidentes,
    paginatedAccidentes,
    atencionesPendientes,
    statusOptions,
    atencionesMedicas,
    accidentes,
    handleSelectTrabajador,
    handleTipoEventoChange,
    handleImageChange,
    handleClearImage,
    toggleMultiSelectOption,
    handleEditCaso,
    handleValidarAtencionDesdeBandeja,
    handleDescartarAtencion,
    handleSubmit,
    handleSaveSeguimiento,
    confirmDeleteCaso,
    handleExportarExcel,
    handleExportarPDF,
    handleImportSuccess,
    handleNuevoRegistro,
    clearFilters,
    handleNavigateToAtencion,
    handleViewAtenciones,
    handleNavigateToInvestigacion
  } = useAccidentes();

  // Modal alternativo de edición rápida
  const [isQuickEditModalOpen, setIsQuickEditModalOpen] = useState(false);

  // Estado del formulario interno de seguimiento
  const [seguimientoData, setSeguimientoData] = useState<{
    estadoCaso: 'Abierto' | 'En investigación' | 'Con medidas correctivas' | 'Cerrado';
    medidasCorrectivas: string;
    responsableSeguimiento: string;
    fechaCompromiso: string;
    fechaCierre: string;
    diasDescanso: number;
    conclusionesInvestigacion: string;
  }>({
    estadoCaso: 'Abierto',
    medidasCorrectivas: '',
    responsableSeguimiento: '',
    fechaCompromiso: '',
    fechaCierre: '',
    diasDescanso: 0,
    conclusionesInvestigacion: ''
  });

  const onOpenSeguimientoModal = (item: AccidenteRecord) => {
    setSeguimientoData({
      estadoCaso: item.estadoCaso,
      medidasCorrectivas: item.medidasCorrectivas || '',
      responsableSeguimiento: item.responsableSeguimiento || '',
      fechaCompromiso: item.fechaCompromiso || '',
      fechaCierre: item.fechaCierre || (item.estadoCaso === 'Cerrado' ? new Date().toISOString().slice(0, 10) : ''),
      diasDescanso: item.diasDescanso || 0,
      conclusionesInvestigacion: item.conclusionesInvestigacion || ''
    });
    setSeguimientoModal(item);
  };

  const onSeguimientoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!seguimientoModal) return;
    const updatedRecord: AccidenteRecord = {
      ...seguimientoModal,
      estadoCaso: seguimientoData.estadoCaso,
      medidasCorrectivas: seguimientoData.medidasCorrectivas,
      responsableSeguimiento: seguimientoData.responsableSeguimiento,
      fechaCompromiso: seguimientoData.fechaCompromiso,
      fechaCierre: seguimientoData.estadoCaso === 'Cerrado' ? seguimientoData.fechaCierre : undefined,
      diasDescanso: Number(seguimientoData.diasDescanso) || 0,
      conclusionesInvestigacion: seguimientoData.conclusionesInvestigacion,
      updatedAt: new Date().toISOString()
    };
    handleSaveSeguimiento(updatedRecord);
  };

  const handleFilterChange = (updates: Partial<{
    searchTerm: string;
    estadoFilter: string;
    tipoEventoFilter: string;
    areaFilter: string;
    fechaDesde: string;
    fechaHasta: string;
  }>) => {
    if (updates.searchTerm !== undefined) setSearchTerm(updates.searchTerm);
    if (updates.estadoFilter !== undefined) setEstadoFilter(updates.estadoFilter);
    if (updates.tipoEventoFilter !== undefined) setTipoEventoFilter(updates.tipoEventoFilter);
    if (updates.areaFilter !== undefined) setAreaFilter(updates.areaFilter);
    if (updates.fechaDesde !== undefined) setFechaDesde(updates.fechaDesde);
    if (updates.fechaHasta !== undefined) setFechaHasta(updates.fechaHasta);
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header estandarizado */}
      <ModuleHeader
        codigo={1}
        titulo="Accidentes de Trabajo y Seguimiento de Incidentes"
        subtitulo="Registro normativo de eventos SST, clasificación técnica, evidencias, medidas correctivas e investigación"
        icono={<AlertOctagon className="w-5 h-5 text-rose-500" />}
        onNuevo={handleNuevoRegistro}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* 2. Tarjetas KPI */}
      <AccidentesStats metricas={metricas} />

      {/* 3. Navegación de Pestañas */}
      <div className="flex border-b border-[#E2E8F0] bg-white px-2 rounded-t-xl gap-1">
        <button
          onClick={() => setActiveTab('seguimiento')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'seguimiento'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          <span>Seguimiento y Casos Activos</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'seguimiento' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#0F172A]'
            }`}
          >
            {filteredAccidentes.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('bandejaEntrada')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all relative cursor-pointer ${
            activeTab === 'bandejaEntrada'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Inbox className="w-4 h-4" />
          <span>Bandeja de Tópico (Módulo 4)</span>
          {atencionesPendientes.length > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-[#D97706] text-white text-[10px] font-extrabold animate-pulse font-mono">
              {atencionesPendientes.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('nuevo')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'nuevo'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>{editingId ? `Editando Caso ${editingId}` : 'Registro de Evento Directo'}</span>
        </button>
      </div>

      {/* 4. Tab 1: Seguimiento & Tabla */}
      {activeTab === 'seguimiento' && (
        <div className="space-y-4">
          <AccidentesFilters
            filters={{ searchTerm, estadoFilter, tipoEventoFilter, areaFilter, fechaDesde, fechaHasta }}
            onChange={handleFilterChange}
            statusOptions={statusOptions}
            totalCount={
              accidentes.filter((a) => (empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva)).length
            }
            filteredCount={filteredAccidentes.length}
            onExportExcel={handleExportarExcel}
            onExportPdf={handleExportarPDF}
            onNewRecord={() => setActiveTab('nuevo')}
            onClearFilters={clearFilters}
          />

          <AccidentesTable
            items={paginatedAccidentes}
            atencionesMedicas={atencionesMedicas}
            searchTerm={searchTerm}
            estadoFilter={estadoFilter}
            tipoEventoFilter={tipoEventoFilter}
            fechaDesde={fechaDesde}
            fechaHasta={fechaHasta}
            currentPage={currentPage}
            pageSize={pageSize}
            totalItems={filteredAccidentes.length}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
            onView={(item) => setViewDetailModal(item)}
            onEdit={handleEditCaso}
            onOpenSeguimiento={onOpenSeguimientoModal}
            onDelete={(item) => setDeleteModalCaso(item)}
            onNavigateToAtencion={handleNavigateToAtencion}
            onViewAtenciones={handleViewAtenciones}
            onNavigateToInvestigacion={handleNavigateToInvestigacion}
            onClearFilters={clearFilters}
            onNewRecord={() => setActiveTab('nuevo')}
          />
        </div>
      )}

      {/* 5. Tab 2: Bandeja de Entrada */}
      {activeTab === 'bandejaEntrada' && (
        <BandejaEntradaTable
          atencionesPendientes={atencionesPendientes}
          onValidar={handleValidarAtencionDesdeBandeja}
          onDescartar={handleDescartarAtencion}
        />
      )}

      {/* 6. Tab 3: Formulario Inline */}
      {activeTab === 'nuevo' && (
        <AccidentesForm
          formData={formData}
          setFormData={setFormData}
          editingId={editingId}
          formError={formError}
          isSubmitting={isSubmitting}
          imageFile={imageFile}
          imagePreview={imagePreview}
          onImageChange={handleImageChange}
          onClearImage={handleClearImage}
          trabajadoresFiltrados={trabajadoresFiltrados}
          responsablesLiderazgo={responsablesLiderazgo}
          isCustomResponsable={isCustomResponsable}
          setIsCustomResponsable={setIsCustomResponsable}
          workerSearchTerm={workerSearchTerm}
          setWorkerSearchTerm={setWorkerSearchTerm}
          isWorkerDropdownOpen={isWorkerDropdownOpen}
          setIsWorkerDropdownOpen={setIsWorkerDropdownOpen}
          onSelectTrabajador={handleSelectTrabajador}
          onTipoEventoChange={handleTipoEventoChange}
          toggleMultiSelectOption={toggleMultiSelectOption}
          onSubmit={handleSubmit}
          onCancel={() => {
            handleNuevoRegistro();
            setActiveTab('seguimiento');
          }}
        />
      )}

      {/* 7. Modal de Formulario Emergente Alternativo */}
      <AccidentesFormModal
        isOpen={isQuickEditModalOpen}
        onClose={() => setIsQuickEditModalOpen(false)}
        formData={formData}
        setFormData={setFormData}
        editingId={editingId}
        formError={formError}
        isSubmitting={isSubmitting}
        imageFile={imageFile}
        imagePreview={imagePreview}
        onImageChange={handleImageChange}
        onClearImage={handleClearImage}
        trabajadoresFiltrados={trabajadoresFiltrados}
        responsablesLiderazgo={responsablesLiderazgo}
        isCustomResponsable={isCustomResponsable}
        setIsCustomResponsable={setIsCustomResponsable}
        workerSearchTerm={workerSearchTerm}
        setWorkerSearchTerm={setWorkerSearchTerm}
        isWorkerDropdownOpen={isWorkerDropdownOpen}
        setIsWorkerDropdownOpen={setIsWorkerDropdownOpen}
        onSelectTrabajador={handleSelectTrabajador}
        onTipoEventoChange={handleTipoEventoChange}
        toggleMultiSelectOption={toggleMultiSelectOption}
        onSubmit={(e) => {
          handleSubmit(e);
          setIsQuickEditModalOpen(false);
        }}
      />

      {/* 8. Modales de Apoyo y Detalle */}
      <AccidentesSeguimientoModal
        record={seguimientoModal}
        seguimientoData={seguimientoData}
        setSeguimientoData={setSeguimientoData}
        onClose={() => setSeguimientoModal(null)}
        onSubmit={onSeguimientoSubmit}
        onOpenInvestigacion={() => {
          if (seguimientoModal) {
            handleNavigateToInvestigacion(seguimientoModal);
          }
        }}
      />

      <AccidentesDetailModal
        caso={viewDetailModal}
        atencionesMedicas={atencionesMedicas}
        onClose={() => setViewDetailModal(null)}
        onNavigateToAtencion={handleNavigateToAtencion}
        onViewAtenciones={handleViewAtenciones}
      />

      <DeleteConfirmModal
        isOpen={Boolean(deleteModalCaso)}
        title="Eliminar Registro de Accidente / Incidente"
        message={`¿Está seguro de eliminar definitivamente el caso ${deleteModalCaso?.codigoCaso} correspondiente a ${deleteModalCaso?.trabajadorNombre}? Esta acción eliminará el registro en la base de datos.`}
        onConfirm={confirmDeleteCaso}
        onClose={() => setDeleteModalCaso(null)}
      />

      <PromptAtencionModal
        caso={promptAtencionModal}
        onClose={() => {
          setPromptAtencionModal(null);
          setActiveTab('seguimiento');
        }}
        onNavigateToAtencion={(caso) => {
          setPromptAtencionModal(null);
          handleNavigateToAtencion(caso);
        }}
      />

      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.accidentes}
        onImportSuccess={(rows) => handleImportSuccess(rows as unknown as AccidenteRecord[])}
      />
    </div>
  );
};
