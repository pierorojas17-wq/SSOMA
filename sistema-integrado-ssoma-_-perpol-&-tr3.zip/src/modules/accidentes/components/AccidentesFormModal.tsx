import React from 'react';
import { X, AlertOctagon } from 'lucide-react';
import { AccidentesForm } from './AccidentesForm';
import { AccidenteRecord, TrabajadorRecord } from '../../../types/modules';

interface AccidentesFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  formData: Partial<AccidenteRecord>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<AccidenteRecord>>>;
  editingId: string | null;
  formError: string | null;
  isSubmitting: boolean;
  imageFile: File | null;
  imagePreview: string | null;
  onImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onClearImage: () => void;
  trabajadoresFiltrados: TrabajadorRecord[];
  responsablesLiderazgo: TrabajadorRecord[];
  isCustomResponsable: boolean;
  setIsCustomResponsable: React.Dispatch<React.SetStateAction<boolean>>;
  workerSearchTerm: string;
  setWorkerSearchTerm: (term: string) => void;
  isWorkerDropdownOpen: boolean;
  setIsWorkerDropdownOpen: (open: boolean) => void;
  onSelectTrabajador: (trabajador: TrabajadorRecord) => void;
  onTipoEventoChange: (tipo: string) => void;
  toggleMultiSelectOption: (
    field:
      | 'partesCuerpoAfectadas'
      | 'mecanismoEvento'
      | 'agenteEvento'
      | 'lesionReferida',
    op: string
  ) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const AccidentesFormModal: React.FC<AccidentesFormModalProps> = ({
  isOpen,
  onClose,
  formData,
  setFormData,
  editingId,
  formError,
  isSubmitting,
  imageFile,
  imagePreview,
  onImageChange,
  onClearImage,
  trabajadoresFiltrados,
  responsablesLiderazgo,
  isCustomResponsable,
  setIsCustomResponsable,
  workerSearchTerm,
  setWorkerSearchTerm,
  isWorkerDropdownOpen,
  setIsWorkerDropdownOpen,
  onSelectTrabajador,
  onTipoEventoChange,
  toggleMultiSelectOption,
  onSubmit
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="accidentes-modal-title"
        className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[92vh] flex flex-col"
      >
        {/* Header Modal */}
        <div className="px-6 py-4 bg-[#263B5E] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl" aria-hidden="true">
              <AlertOctagon className="w-5 h-5 text-rose-300" />
            </div>
            <div>
              <h2 id="accidentes-modal-title" className="text-base font-bold text-white">
                {editingId ? `Editar Evento: ${editingId}` : 'Nuevo Registro de Accidente o Incidente'}
              </h2>
              <p className="text-xs text-white/70">
                Llene los campos obligatorios del formato normativo SST
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Cerrar modal de accidente (Esc)"
            aria-label="Cerrar modal de accidente"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Form Body con Scroll */}
        <div className="p-6 overflow-y-auto grow">
          <AccidentesForm
            formData={formData}
            setFormData={setFormData}
            editingId={editingId}
            formError={formError}
            isSubmitting={isSubmitting}
            imageFile={imageFile}
            imagePreview={imagePreview}
            onImageChange={onImageChange}
            onClearImage={onClearImage}
            trabajadoresFiltrados={trabajadoresFiltrados}
            responsablesLiderazgo={responsablesLiderazgo}
            isCustomResponsable={isCustomResponsable}
            setIsCustomResponsable={setIsCustomResponsable}
            workerSearchTerm={workerSearchTerm}
            setWorkerSearchTerm={setWorkerSearchTerm}
            isWorkerDropdownOpen={isWorkerDropdownOpen}
            setIsWorkerDropdownOpen={setIsWorkerDropdownOpen}
            onSelectTrabajador={onSelectTrabajador}
            onTipoEventoChange={onTipoEventoChange}
            toggleMultiSelectOption={toggleMultiSelectOption}
            onSubmit={onSubmit}
            onCancel={onClose}
          />
        </div>
      </div>
    </div>
  );
};
