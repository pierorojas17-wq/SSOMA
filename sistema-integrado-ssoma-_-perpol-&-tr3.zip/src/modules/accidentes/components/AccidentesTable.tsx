import React from 'react';
import { AccidenteRecord, AtencionMedicaRecord } from '../../../types/modules';
import { TablePagination } from '../../../components/common/TablePagination';
import { TableEmptyState } from '../../../components/common/TableEmptyState';
import { StatusBadge } from '../../../components/common/StatusBadge';
import {
  HeartPulse,
  Activity,
  FileSearch,
  CheckSquare,
  Edit2,
  Eye,
  Trash2,
  AlertTriangle
} from 'lucide-react';

interface AccidentesTableProps {
  items: AccidenteRecord[];
  atencionesMedicas: AtencionMedicaRecord[];
  searchTerm: string;
  estadoFilter: string;
  tipoEventoFilter: string;
  fechaDesde: string;
  fechaHasta: string;
  currentPage: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  onView: (item: AccidenteRecord) => void;
  onEdit: (item: AccidenteRecord) => void;
  onOpenSeguimiento: (item: AccidenteRecord) => void;
  onDelete: (item: AccidenteRecord) => void;
  onNavigateToAtencion: (item: AccidenteRecord) => void;
  onViewAtenciones: (item: AccidenteRecord) => void;
  onNavigateToInvestigacion: (item: AccidenteRecord) => void;
  onClearFilters: () => void;
  onNewRecord: () => void;
}

export const AccidentesTable: React.FC<AccidentesTableProps> = ({
  items,
  atencionesMedicas,
  searchTerm,
  estadoFilter,
  tipoEventoFilter,
  fechaDesde,
  fechaHasta,
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  onView,
  onEdit,
  onOpenSeguimiento,
  onDelete,
  onNavigateToAtencion,
  onViewAtenciones,
  onNavigateToInvestigacion,
  onClearFilters,
  onNewRecord
}) => {
  const hasActiveFilters = Boolean(
    searchTerm || estadoFilter !== 'TODOS' || tipoEventoFilter !== 'TODOS' || fechaDesde || fechaHasta
  );

  return (
    <div id="tabla-accidentes-seguimiento" className="bg-white border border-[#E2E8F0] rounded-xl overflow-hidden shadow-xs">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1120px] text-left text-xs text-[#1E293B]">
          <thead className="bg-[#F8FAFC] text-[#475569] uppercase text-[10px] font-semibold border-b border-[#CBD5E1] tracking-wider">
            <tr>
              <th className="px-4 py-3 w-28 whitespace-nowrap">Código</th>
              <th className="px-4 py-3 w-32 whitespace-nowrap">Fecha / Hora</th>
              <th className="px-4 py-3 w-28 whitespace-nowrap">Empresa</th>
              <th className="px-4 py-3 min-w-[180px]">Trabajador</th>
              <th className="px-4 py-3 w-36 whitespace-nowrap">Tipo Evento</th>
              <th className="px-4 py-3 min-w-[160px]">Área / Lugar</th>
              <th className="px-4 py-3 w-24 text-center whitespace-nowrap">Daño Mat.</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Req. Atención</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Estado Caso</th>
              <th className="px-4 py-3 w-32 whitespace-nowrap">Plan de Acción</th>
              <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2E8F0]">
            {items.length === 0 ? (
              <TableEmptyState
                isTableRow
                colSpan={11}
                title="No se encontraron casos SST"
                description={
                  searchTerm
                    ? `No hay coincidencias para "${searchTerm}". Prueba con otro término.`
                    : 'No se encontraron eventos o accidentes con los filtros aplicados.'
                }
                actionLabel={hasActiveFilters ? 'Limpiar filtros' : 'Nuevo Caso'}
                actionIcon={hasActiveFilters ? 'clear' : 'plus'}
                onAction={hasActiveFilters ? onClearFilters : onNewRecord}
              />
            ) : (
              items.map((item, idx) => {
                const atencionesCaso = atencionesMedicas.filter(
                  (a) => a.idAccidente === item.id || a.codigoAccidente === item.codigoCaso
                );
                const totalDiasDescanso = atencionesCaso.reduce(
                  (sum, a) => sum + (Number(a.diasDescanso) || 0),
                  0
                );

                return (
                  <tr key={`${item.id || item.codigoCaso}-${idx}`} className="hover:bg-[#F1F5F9] transition-colors">
                    <td className="px-4 py-3 font-semibold text-[#DC2626] whitespace-nowrap">
                      {item.codigoCaso}
                      {item.origenAtencionBotiquinId && (
                        <div className="text-[10px] text-[#0284C7] font-mono mt-0.5">
                          Ref: {item.origenAtencionBotiquinId}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="text-[#0F172A] font-medium">{item.fecha}</div>
                      <div className="text-[11px] text-[#475569]">{item.hora}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.empresa === 'PERPOL'
                            ? 'bg-sky-50 text-[#0284C7] border border-sky-200'
                            : 'bg-amber-50 text-[#B45309] border border-amber-200'
                        }`}
                      >
                        {item.empresa}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-[#0F172A] font-medium">{item.trabajadorNombre}</div>
                      <div className="text-[11px] text-[#475569]">
                        DNI: {item.trabajadorDni} • {item.cargo}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={item.tipoEvento} />
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      <div className="text-slate-800 font-medium">{item.area}</div>
                      <div className="text-[11px] text-slate-500 truncate">{item.lugarExacto}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {item.danoMaterial === 'SI' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200" title={item.detalleDano}>
                          SÍ
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-500 font-medium">NO</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {item.necesidadAtencion === 'SI' ? (
                        atencionesCaso.length > 0 ? (
                          <button
                            type="button"
                            onClick={() => onViewAtenciones(item)}
                            className="inline-flex flex-col items-start gap-0.5 group text-left cursor-pointer"
                            title="Ver atenciones médicas de este accidente"
                          >
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200 group-hover:bg-teal-100 transition-colors">
                              <HeartPulse className="w-3 h-3 text-teal-600" />
                              Atendido ({atencionesCaso.length})
                            </span>
                            {totalDiasDescanso > 0 && (
                              <span className="text-[10px] text-rose-600 font-bold font-mono pl-1">
                                {totalDiasDescanso} d. descanso
                              </span>
                            )}
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onNavigateToAtencion(item)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-colors animate-pulse cursor-pointer"
                            title="Click para registrar atención médica inmediata heredando datos SST"
                          >
                            <AlertTriangle className="w-3 h-3 text-rose-600" />
                            <span>Pendiente</span>
                          </button>
                        )
                      ) : atencionesCaso.length > 0 ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-slate-500">
                          <HeartPulse className="w-3 h-3 text-teal-600" />
                          {atencionesCaso.length} atn.
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-500 font-medium">NO</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge
                        status={item.estadoCaso}
                        onClick={() => onOpenSeguimiento(item)}
                      />
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      {item.medidasCorrectivas ? (
                        <div className="text-slate-600 text-[11px] line-clamp-1">
                          {item.medidasCorrectivas}
                        </div>
                      ) : (
                        <span className="text-slate-500 font-medium italic text-[11px]">Sin medidas registradas</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {item.necesidadAtencion === 'SI' && (
                          <button
                            type="button"
                            onClick={() => onNavigateToAtencion(item)}
                            className="min-h-[30px] px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 border border-sky-200 text-[#0284C7] text-xs font-bold flex items-center gap-1 transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                            title="Registrar Atención Médica (Módulo 2)"
                          >
                            <HeartPulse className="w-3.5 h-3.5 text-[#0284C7] shrink-0" />
                            <span>Atención</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onViewAtenciones(item)}
                          className="min-w-[30px] min-h-[30px] flex items-center justify-center p-1.5 rounded-lg hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0284C7] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title={`Ver Atenciones Médicas de ${item.codigoCaso}`}
                          aria-label={`Ver atenciones médicas del caso ${item.codigoCaso}`}
                        >
                          <Activity className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onNavigateToInvestigacion(item)}
                          className="min-w-[30px] min-h-[30px] flex items-center justify-center p-1.5 rounded-lg hover:bg-[#F1F5F9] text-[#475569] hover:text-[#1E293B] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Investigar Evento SST (Módulo 10)"
                          aria-label={`Investigar evento SST del caso ${item.codigoCaso}`}
                        >
                          <FileSearch className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenSeguimiento(item)}
                          className="min-h-[30px] px-2.5 py-1 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#1E293B] border border-[#CBD5E1] text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Seguimiento y Cierre"
                          aria-label={`Abrir seguimiento y cierre del caso ${item.codigoCaso}`}
                        >
                          <CheckSquare className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>Seguimiento</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="min-w-[30px] min-h-[30px] flex items-center justify-center p-1.5 rounded-lg hover:bg-[#F1F5F9] text-[#475569] hover:text-[#047857] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Editar Caso SST"
                          aria-label={`Editar caso SST ${item.codigoCaso}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="min-w-[30px] min-h-[30px] flex items-center justify-center p-1.5 rounded-lg hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Ver Ficha SST"
                          aria-label={`Ver ficha SST del caso ${item.codigoCaso}`}
                        >
                          <Eye className="w-4 h-4" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete(item)}
                          className="min-w-[30px] min-h-[30px] flex items-center justify-center p-1.5 rounded-lg hover:bg-rose-50 text-[#475569] hover:text-[#DC2626] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Eliminar"
                          aria-label={`Eliminar caso SST ${item.codigoCaso}`}
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
      <TablePagination
        currentPage={currentPage}
        totalItems={totalItems}
        pageSize={pageSize}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
      />
    </div>
  );
};
