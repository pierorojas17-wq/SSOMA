import React from 'react';
import { AccidenteRecord, TrabajadorRecord } from '../../../types/modules';
import {
  CAUSAS_INMEDIATAS_ACTOS,
  CAUSAS_INMEDIATAS_CONDICIONES,
  AREAS_EMPRESA,
  LUGARES_ESPECIFICOS,
  TURNOS_TRABAJO,
  PARTES_CUERPO_AFECTADAS,
  MECANISMOS_EVENTO,
  FUENTES_AGENTES_EVENTO,
  LESIONES_REFERIDAS
} from '../../../utils/ssomaCatalogs';
import {
  AlertOctagon,
  AlertTriangle,
  Camera,
  HeartPulse,
  Save,
  ShieldAlert,
  Tag,
  User,
  X
} from 'lucide-react';

interface AccidentesFormProps {
  formData: Partial<AccidenteRecord>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<AccidenteRecord>>>;
  editingId: string | null;
  formError: string | null;
  isSubmitting: boolean;
  imageFile: File | null;
  imagePreview: string | null;
  onImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onClearImage: () => void;
  trabajadoresFiltrados: TrabajadorRecord[];
  responsablesLiderazgo: TrabajadorRecord[];
  isCustomResponsable: boolean;
  setIsCustomResponsable: React.Dispatch<React.SetStateAction<boolean>>;
  workerSearchTerm: string;
  setWorkerSearchTerm: (term: string) => void;
  isWorkerDropdownOpen: boolean;
  setIsWorkerDropdownOpen: (open: boolean) => void;
  onSelectTrabajador: (trabajador: TrabajadorRecord) => void;
  onTipoEventoChange: (tipo: string) => void;
  toggleMultiSelectOption: (
    field:
      | 'partesCuerpoAfectadas'
      | 'mecanismoEvento'
      | 'agenteEvento'
      | 'lesionReferida',
    op: string
  ) => void;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
}

export const AccidentesForm: React.FC<AccidentesFormProps> = ({
  formData,
  setFormData,
  editingId,
  formError,
  isSubmitting,
  imageFile,
  imagePreview,
  onImageChange,
  onClearImage,
  trabajadoresFiltrados,
  responsablesLiderazgo,
  isCustomResponsable,
  setIsCustomResponsable,
  workerSearchTerm,
  setWorkerSearchTerm,
  isWorkerDropdownOpen,
  setIsWorkerDropdownOpen,
  onSelectTrabajador,
  onTipoEventoChange,
  toggleMultiSelectOption,
  onSubmit,
  onCancel
}) => {
  return (
    <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-sm text-[#0F172A]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E2E8F0] mb-5 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-700">
            <AlertOctagon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#0F172A]">
              {editingId ? `Edición de Caso ${editingId}` : 'Formato Oficial de Registro de Accidente / Incidente'}
            </h3>
            <p className="text-xs text-[#475569]">
              Normativa Ley 29783 / D.S. 005-2012-TR — Notificación, causas y descanso médico
            </p>
          </div>
        </div>
        {formData.origenAtencionBotiquinId && (
          <span className="px-3 py-1 rounded bg-teal-50 border border-teal-200 text-teal-800 text-xs font-mono font-semibold self-start sm:self-auto">
            Vinculado a Tópico: {formData.origenAtencionBotiquinId}
          </span>
        )}
      </div>

      <form onSubmit={onSubmit} className="space-y-5">
        {formError && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
            <span className="font-medium">{formError}</span>
          </div>
        )}

        {/* Fila 1: Empresa, Fecha, Hora, Tipo de Evento */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Empresa</label>
            <select
              value={formData.empresa}
              onChange={(e) => setFormData((prev) => ({ ...prev, empresa: e.target.value as any }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
            >
              <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
              <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Fecha del Evento *</label>
            <input
              type="date"
              required
              value={formData.fecha}
              onChange={(e) => setFormData((prev) => ({ ...prev, fecha: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Hora Exacta *</label>
            <input
              type="time"
              required
              value={formData.hora}
              onChange={(e) => setFormData((prev) => ({ ...prev, hora: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Tipo de Evento *</label>
            <select
              value={formData.tipoEvento}
              onChange={(e) => onTipoEventoChange(e.target.value)}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-bold"
            >
              <option value="Incidente potencial">Incidente potencial (Casi accidente - sin lesión/daño)</option>
              <option value="Incidente">Incidente (Sin lesión a personas)</option>
              <option value="Accidente leve">Accidente leve</option>
              <option value="Accidente incapacitante">Accidente incapacitante</option>
              <option value="Accidente mortal">Accidente mortal (Fatal)</option>
            </select>
          </div>
        </div>

        {/* Aviso informativo si es Incidente Potencial */}
        {formData.tipoEvento === 'Incidente potencial' && (
          <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold text-amber-950">Regla Normativa de Incidente Potencial (Casi Accidente):</strong>
              <span className="font-medium">
                Evento sin daño material ni lesión física en personas, pero con potencial de causarlo. No requiere atención médica ni genera afectación de equipos.
              </span>
            </div>
          </div>
        )}

        {/* Fila 2: Autocompletado del Colaborador */}
        <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
              <User className="w-4 h-4 text-[#047857]" />
              Colaborador Involucrado / Accidentado (Autocompletado Base de Trabajadores) *
            </span>
            {formData.trabajadorNombre && (
              <span className="text-[11px] text-[#047857] font-mono font-bold">DNI / C.E.: {formData.trabajadorDni}</span>
            )}
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Escriba el nombre o DNI del trabajador..."
              value={workerSearchTerm}
              onChange={(e) => {
                setWorkerSearchTerm(e.target.value);
                setIsWorkerDropdownOpen(true);
              }}
              onFocus={() => setIsWorkerDropdownOpen(true)}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
            />
            {isWorkerDropdownOpen && (
              <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-[#CBD5E1] rounded-lg shadow-xl z-20 divide-y divide-[#E2E8F0]">
                {trabajadoresFiltrados.length === 0 ? (
                  <div className="p-2.5 text-xs text-[#475569] text-center">
                    No se encontraron trabajadores en {formData.empresa}
                  </div>
                ) : (
                  trabajadoresFiltrados.map((t, idx) => (
                    <button
                      key={`${t.id || t.dni}-${t.empresa || ''}-${idx}`}
                      type="button"
                      onClick={() => onSelectTrabajador(t)}
                      className="w-full p-2.5 text-left text-xs hover:bg-[#F1F5F9] transition-colors flex items-center justify-between cursor-pointer"
                    >
                      <div>
                        <div className="font-semibold text-[#0F172A]">{t.apellidosNombres}</div>
                        <div className="text-[11px] text-[#475569]">
                          DNI: {t.dni} • {t.puesto} • {t.area}
                        </div>
                      </div>
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] font-semibold">
                        {t.empresa}
                      </span>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">
                Puesto / Cargo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.cargo}
                onChange={(e) => setFormData((prev) => ({ ...prev, cargo: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">
                Área de Ocurrencia <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <select
                required
                value={formData.area}
                onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                <option value="">Seleccione área...</option>
                {AREAS_EMPRESA.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">
                Turno <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <select
                required
                value={formData.turno}
                onChange={(e) => setFormData((prev) => ({ ...prev, turno: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                {TURNOS_TRABAJO.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Fila 3: Ubicación Exacta y Responsable del Área */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <input
              type="text"
              required
              list="lista-lugares-exactos-accidente"
              placeholder="Escribe o selecciona lugar (ej: Caldero, Sala de compresores...)"
              value={formData.lugarExacto}
              onChange={(e) => setFormData((prev) => ({ ...prev, lugarExacto: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
            <datalist id="lista-lugares-exactos-accidente">
              {LUGARES_ESPECIFICOS.map((lug, idx) => (
                <option key={`lug-acc-${idx}`} value={lug} />
              ))}
            </datalist>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-[#475569]">
                Jefe de Área / Responsable Inmediato <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <button
                type="button"
                onClick={() => setIsCustomResponsable(!isCustomResponsable)}
                className="text-[10px] text-[#047857] hover:underline font-bold cursor-pointer"
              >
                {isCustomResponsable ? 'Elegir de lista de líderes' : 'Escribir manualmente'}
              </button>
            </div>
            {isCustomResponsable ? (
              <input
                type="text"
                required
                placeholder="Nombre del jefe, supervisor, gestor o encargado de turno..."
                value={formData.responsableArea}
                onChange={(e) => setFormData((prev) => ({ ...prev, responsableArea: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            ) : (
              <select
                required
                value={formData.responsableArea}
                onChange={(e) => {
                  if (e.target.value === '__OTRO__') {
                    setIsCustomResponsable(true);
                    setFormData((prev) => ({ ...prev, responsableArea: '' }));
                  } else {
                    setFormData((prev) => ({ ...prev, responsableArea: e.target.value }));
                  }
                }}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
              >
                <option value="">Seleccione supervisor, coordinador, jefe, gestor o gerencia...</option>
                {responsablesLiderazgo.map((resp, rIdx) => {
                  const val = `${resp.apellidosNombres} (${resp.puesto})`;
                  return (
                    <option key={`${resp.id || resp.dni || 'resp'}-${resp.empresa || ''}-${rIdx}`} value={val}>
                      {resp.apellidosNombres} — {resp.puesto} ({resp.empresa})
                    </option>
                  );
                })}
                {formData.responsableArea &&
                  !responsablesLiderazgo.some(
                    (r) => `${r.apellidosNombres} (${r.puesto})` === formData.responsableArea
                  ) && (
                    <option value={formData.responsableArea}>
                      {formData.responsableArea} (Actual)
                    </option>
                  )}
                <option value="__OTRO__">➕ Otro (Ingresar texto libre)...</option>
              </select>
            )}
            <span className="text-[10px] text-[#475569] block mt-1">
              Líderes activos unificados de PERPOL y TR3 (Supervisión, Coordinación, Jefatura, Gestión/Gestor y Gerencia)
            </span>
          </div>
        </div>

        {/* Fila 4: Daño Material y Requerimiento de Atención Médica */}
        <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                ¿Generó Daño Material o Afectación al Proceso?
              </label>
              <select
                disabled={formData.tipoEvento === 'Incidente potencial'}
                value={formData.danoMaterial}
                onChange={(e) => setFormData((prev) => ({ ...prev, danoMaterial: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
              >
                <option value="NO">NO</option>
                <option value="SI">SÍ</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                ¿Requirió Primeros Auxilios o Atención Médica?
              </label>
              <select
                disabled={formData.tipoEvento === 'Incidente potencial'}
                value={formData.necesidadAtencion}
                onChange={(e) => setFormData((prev) => ({ ...prev, necesidadAtencion: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] disabled:opacity-50 font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                <option value="SI">SÍ (Tópico interno o Clínica externa)</option>
                <option value="NO">NO (No requirió atención médica)</option>
              </select>
            </div>
          </div>
          {formData.danoMaterial === 'SI' && (
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Detalle del Daño Material *</label>
              <input
                type="text"
                required
                placeholder="Equipos, estructuras o producto dañado y costo estimado..."
                value={formData.detalleDano}
                onChange={(e) => setFormData((prev) => ({ ...prev, detalleDano: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
          )}
          {formData.necesidadAtencion === 'SI' && (
            <div className="p-2.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-900 text-[11px] flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-teal-700 shrink-0" />
              <span>
                <strong>Gestión Independiente de Salud:</strong> Este indicador señala que el evento requirió atención. Todos los datos médicos (diagnóstico, lugar de atención, descanso médico y citas) se registran de forma independiente en el <strong>Módulo 2: Atenciones Médicas</strong>.
              </span>
            </div>
          )}
        </div>

        {/* SECCIÓN OBLIGATORIA: 4 LISTAS DE SELECCIÓN MÚLTIPLE CON CAMPO 'OTROS' */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#E2E8F0]">
            <Tag className="w-4 h-4 text-[#047857]" />
            <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
              Clasificación Técnica Normativa del Evento SST (Selección Múltiple)
            </span>
          </div>

          {/* 1. Partes del cuerpo afectadas */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                <span>1. Partes del cuerpo afectadas</span>
                <span className="text-[10px] text-[#475569] font-normal">(Seleccione una o varias opciones)</span>
              </label>
              {(formData.partesCuerpoAfectadas || []).length > 0 && (
                <span className="text-[10px] font-mono text-[#047857] font-bold">
                  {(formData.partesCuerpoAfectadas || []).length} seleccionada(s)
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {PARTES_CUERPO_AFECTADAS.map((op) => {
                const isSelected = (formData.partesCuerpoAfectadas || []).includes(op);
                return (
                  <button
                    key={op}
                    type="button"
                    onClick={() => toggleMultiSelectOption('partesCuerpoAfectadas', op)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-100 border-[#047857] text-[#047857] font-bold shadow-2xs'
                        : 'bg-white border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1] hover:text-[#0F172A]'
                    }`}
                  >
                    {isSelected ? '✓ ' : ''}{op}
                  </button>
                );
              })}
            </div>
            {(formData.partesCuerpoAfectadas || []).includes('Otros') && (
              <div className="pt-1">
                <input
                  type="text"
                  required
                  placeholder="Especifique otras partes del cuerpo afectadas..."
                  value={formData.partesCuerpoOtros || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, partesCuerpoOtros: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>
            )}
          </div>

          {/* 2. Tipo / mecanismo del evento */}
          <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                <span>2. Tipo / mecanismo del evento</span>
                <span className="text-[10px] text-[#475569] font-normal">(Seleccione una o varias opciones)</span>
              </label>
              {(formData.mecanismoEvento || []).length > 0 && (
                <span className="text-[10px] font-mono text-[#047857] font-bold">
                  {(formData.mecanismoEvento || []).length} seleccionada(s)
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {MECANISMOS_EVENTO.map((op) => {
                const isSelected = (formData.mecanismoEvento || []).includes(op);
                return (
                  <button
                    key={op}
                    type="button"
                    onClick={() => toggleMultiSelectOption('mecanismoEvento', op)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-100 border-[#047857] text-[#047857] font-bold shadow-2xs'
                        : 'bg-white border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1] hover:text-[#0F172A]'
                    }`}
                  >
                    {isSelected ? '✓ ' : ''}{op}
                  </button>
                );
              })}
            </div>
            {(formData.mecanismoEvento || []).includes('Otros') && (
              <div className="pt-1">
                <input
                  type="text"
                  required
                  placeholder="Especifique otro tipo / mecanismo del evento..."
                  value={formData.mecanismoEventoOtros || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, mecanismoEventoOtros: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>
            )}
          </div>

          {/* 3. Fuente o agente del evento */}
          <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                <span>3. Fuente o agente del evento</span>
                <span className="text-[10px] text-[#475569] font-normal">(Seleccione una o varias opciones)</span>
              </label>
              {(formData.agenteEvento || []).length > 0 && (
                <span className="text-[10px] font-mono text-[#047857] font-bold">
                  {(formData.agenteEvento || []).length} seleccionada(s)
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {FUENTES_AGENTES_EVENTO.map((op) => {
                const isSelected = (formData.agenteEvento || []).includes(op);
                return (
                  <button
                    key={op}
                    type="button"
                    onClick={() => toggleMultiSelectOption('agenteEvento', op)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-100 border-[#047857] text-[#047857] font-bold shadow-2xs'
                        : 'bg-white border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1] hover:text-[#0F172A]'
                    }`}
                  >
                    {isSelected ? '✓ ' : ''}{op}
                  </button>
                );
              })}
            </div>
            {(formData.agenteEvento || []).includes('Otros') && (
              <div className="pt-1">
                <input
                  type="text"
                  required
                  placeholder="Especifique otra fuente o agente del evento..."
                  value={formData.agenteEventoOtros || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, agenteEventoOtros: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>
            )}
          </div>

          {/* 4. Lesión o afectación a la salud referida */}
          <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                <span>4. Lesión o afectación a la salud referida</span>
                <span className="text-[10px] text-[#475569] font-normal">(Seleccione una o varias opciones)</span>
              </label>
              {(formData.lesionReferida || []).length > 0 && (
                <span className="text-[10px] font-mono text-[#047857] font-bold">
                  {(formData.lesionReferida || []).length} seleccionada(s)
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {LESIONES_REFERIDAS.map((op) => {
                const isSelected = (formData.lesionReferida || []).includes(op);
                return (
                  <button
                    key={op}
                    type="button"
                    onClick={() => toggleMultiSelectOption('lesionReferida', op)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-100 border-[#047857] text-[#047857] font-bold shadow-2xs'
                        : 'bg-white border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1] hover:text-[#0F172A]'
                    }`}
                  >
                    {isSelected ? '✓ ' : ''}{op}
                  </button>
                );
              })}
            </div>
            {(formData.lesionReferida || []).includes('Otros') && (
              <div className="pt-1">
                <input
                  type="text"
                  required
                  placeholder="Especifique otra lesión o afectación a la salud referida..."
                  value={formData.lesionReferidaOtros || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, lesionReferidaOtros: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>
            )}
          </div>
        </div>

        {/* Fila 5: Descripción Minuciosa del Suceso */}
        <div>
          <label className="block text-xs font-semibold text-[#475569] mb-1">
            Descripción Detallada y Circunstanciada del Suceso *
          </label>
          <textarea
            required
            rows={4}
            placeholder="¿Qué ocurrió? ¿Cómo ocurrió? ¿Qué tarea se encontraba realizando el colaborador? Mencione circunstancias, equipos involucrados o condiciones presentes..."
            value={formData.descripcion}
            onChange={(e) => setFormData((prev) => ({ ...prev, descripcion: e.target.value }))}
            className="w-full bg-white border border-[#CBD5E1] rounded-lg p-3 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
          />
        </div>

        {/* Fila 6: Causas Inmediatas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Causa Inmediata / Subestándar (Catálogo Normativo)
            </label>
            <select
              value={formData.causaInmediata}
              onChange={(e) => setFormData((prev) => ({ ...prev, causaInmediata: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
            >
              <option value="">Seleccione causa principal...</option>
              <optgroup label="Actos Subestándar">
                {CAUSAS_INMEDIATAS_ACTOS.map((c) => (
                  <option key={c} value={`Acto: ${c}`}>
                    {c}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Condiciones Subestándar">
                {CAUSAS_INMEDIATAS_CONDICIONES.map((c) => (
                  <option key={c} value={`Condición: ${c}`}>
                    {c}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              Evidencia Fotográfica del Hecho
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center justify-center gap-2 p-2 rounded-lg border border-dashed border-[#CBD5E1] hover:border-[#047857] bg-white cursor-pointer text-xs text-[#475569] hover:text-[#0F172A] transition-colors">
                <Camera className="w-4 h-4 text-[#047857]" />
                <span className="font-medium">{imageFile ? imageFile.name : 'Subir fotografía (máx. 8 MB)'}</span>
                <input type="file" accept="image/*" className="hidden" onChange={onImageChange} />
              </label>
              {typeof imagePreview === 'string' && imagePreview.trim().length > 0 && (
                <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-[#047857] shrink-0">
                  <img src={imagePreview.trim()} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={onClearImage}
                    className="absolute inset-0 bg-black/60 text-white flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="pt-4 border-t border-[#E2E8F0] flex flex-wrap items-center justify-end gap-2.5 sm:gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[38px] px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-[#475569] border border-[#CBD5E1] cursor-pointer transition-colors focus:outline-none focus:ring-2 focus:ring-[#10B981]"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="min-h-[38px] flex items-center gap-1.5 px-6 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] disabled:opacity-60 text-xs font-bold text-white shadow-sm transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
          >
            <Save className="w-4 h-4" />
            <span>{isSubmitting ? 'Guardando...' : editingId ? 'Guardar Cambios' : 'Registrar Caso Oficial'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
