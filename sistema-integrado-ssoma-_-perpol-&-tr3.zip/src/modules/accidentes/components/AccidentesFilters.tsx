import React from 'react';
import { ModuleToolbar } from '../../../components/common/ModuleToolbar';
import { AREAS_EMPRESA } from '../../../utils/ssomaCatalogs';

export interface AccidentesFiltersState {
  searchTerm: string;
  estadoFilter: string;
  tipoEventoFilter: string;
  areaFilter: string;
  fechaDesde: string;
  fechaHasta: string;
}

interface AccidentesFiltersProps {
  filters: AccidentesFiltersState;
  onChange: (filters: Partial<AccidentesFiltersState>) => void;
  statusOptions: Array<{ id: string; label: string; count?: number }>;
  totalCount: number;
  filteredCount: number;
  onExportExcel: () => void;
  onExportPdf: () => void;
  onNewRecord: () => void;
  onClearFilters?: () => void;
}

export const AccidentesFilters: React.FC<AccidentesFiltersProps> = ({
  filters,
  onChange,
  statusOptions,
  totalCount,
  filteredCount,
  onExportExcel,
  onExportPdf,
  onNewRecord
}) => {
  return (
    <ModuleToolbar
      searchQuery={filters.searchTerm}
      onSearchChange={(val) => onChange({ searchTerm: val })}
      searchPlaceholder="Buscar por código (ACC-...), colaborador, DNI, área o descripción..."
      statusFilter={filters.estadoFilter}
      onStatusFilterChange={(id) => onChange({ estadoFilter: id })}
      statusOptions={statusOptions}
      totalCount={totalCount}
      filteredCount={filteredCount}
      onExportExcel={onExportExcel}
      onExportPdf={onExportPdf}
      onNewRecord={onNewRecord}
      newRecordLabel="Nuevo Caso"
    >
      <select
        value={filters.tipoEventoFilter}
        onChange={(e) => onChange({ tipoEventoFilter: e.target.value })}
        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
      >
        <option value="TODOS">Todos los tipos de evento</option>
        <option value="Incidente potencial">Incidente potencial (Casi accidente)</option>
        <option value="Incidente">Incidente</option>
        <option value="Accidente leve">Accidente leve</option>
        <option value="Accidente incapacitante">Accidente incapacitante</option>
        <option value="Accidente mortal">Accidente mortal</option>
      </select>

      <select
        value={filters.areaFilter}
        onChange={(e) => onChange({ areaFilter: e.target.value })}
        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
        aria-label="Filtrar por Área"
      >
        <option value="TODOS">Todas las áreas</option>
        {AREAS_EMPRESA.map((area) => (
          <option key={area} value={area}>
            {area}
          </option>
        ))}
      </select>

      <div className="flex items-center gap-1.5">
        <span className="text-[11px] text-slate-500 font-medium">Rango:</span>
        <input
          type="date"
          value={filters.fechaDesde}
          onChange={(e) => onChange({ fechaDesde: e.target.value })}
          className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 shadow-2xs"
          title="Fecha desde"
        />
        <span className="text-slate-400 text-xs">-</span>
        <input
          type="date"
          value={filters.fechaHasta}
          onChange={(e) => onChange({ fechaHasta: e.target.value })}
          className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 shadow-2xs"
          title="Fecha hasta"
        />
      </div>
    </ModuleToolbar>
  );
};
