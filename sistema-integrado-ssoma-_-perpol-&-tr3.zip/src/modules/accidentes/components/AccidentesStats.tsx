import React from 'react';
import { AlertOctagon, HeartPulse, CheckSquare } from 'lucide-react';

interface AccidentesStatsProps {
  metricas: {
    total: number;
    incidentes: number;
    accidentesLeves: number;
    incapacitantes: number;
    mortales: number;
    requirieronAtencion: number;
    conDanoMaterial: number;
    abiertos: number;
    cerrados: number;
  };
}

export const AccidentesStats: React.FC<AccidentesStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2.5 sm:gap-3">
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Total Eventos</span>
          <AlertOctagon className="w-4 h-4 text-[#64748B] shrink-0" />
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#0F172A] mt-2">{metricas.total}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">Año en curso</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Incidentes</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#D97706] shrink-0"></span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#D97706] mt-2">{metricas.incidentes}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">Sin pérdida humana</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Accidentes Leves</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#D97706] shrink-0"></span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#D97706] mt-2">{metricas.accidentesLeves}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">Eventos menores</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Incapacitantes</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626] shrink-0"></span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#DC2626] mt-2">{metricas.incapacitantes}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">Investigación SST</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Req. Atención</span>
          <HeartPulse className="w-4 h-4 text-[#0284C7] shrink-0" />
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#0284C7] mt-2">{metricas.requirieronAtencion}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">Tópico / Asistencial</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs min-w-0">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold gap-1">
          <span className="truncate">Casos Abiertos</span>
          <CheckSquare className="w-4 h-4 text-[#059669] shrink-0" />
        </div>
        <div className="text-xl sm:text-2xl font-bold text-[#059669] mt-2">{metricas.abiertos}</div>
        <div className="text-[11px] text-[#475569] mt-1 truncate">{metricas.cerrados} cerrados</div>
      </div>
    </div>
  );
};
