import React from 'react';
import { AccidenteRecord } from '../../../types/modules';
import { HeartPulse, X } from 'lucide-react';

interface PromptAtencionModalProps {
  caso: AccidenteRecord | null;
  onClose: () => void;
  onNavigateToAtencion: (caso: AccidenteRecord) => void;
}

export const PromptAtencionModal: React.FC<PromptAtencionModalProps> = ({
  caso,
  onClose,
  onNavigateToAtencion
}) => {
  if (!caso) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="prompt-atencion-title"
        className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200 cursor-default select-text text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700 border border-teal-200" aria-hidden="true">
              <HeartPulse className="w-5 h-5 text-teal-700" />
            </div>
            <h3 id="prompt-atencion-title" className="text-sm font-bold text-[#0F172A]">¿Registrar Atención Médica Inmediata?</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
            title="Cerrar (Esc)"
            aria-label="Cerrar sugerencia de atención médica"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>
        <div className="p-6 space-y-4 text-xs text-slate-700">
          <div className="p-3.5 rounded-xl bg-teal-50/60 border border-teal-200 space-y-1.5">
            <div className="flex items-center justify-between pb-1 border-b border-teal-200">
              <span className="font-bold text-teal-900 text-xs">
                Caso Registrado: {caso.codigoCaso}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] bg-rose-50 text-rose-700 border border-rose-200 font-bold">
                Requiere Atención
              </span>
            </div>
            <div className="text-[11px] pt-1 space-y-1 text-slate-700">
              <div>
                <span className="text-slate-500 font-medium">Colaborador:</span> <strong className="text-slate-900">{caso.trabajadorNombre}</strong> (DNI: {caso.trabajadorDni})
              </div>
              <div>
                <span className="text-slate-500 font-medium">Área:</span> <span className="text-slate-800">{caso.area} • {caso.cargo}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Evento SST:</span> <span className="text-slate-800">{caso.tipoEvento} ({caso.fecha} {caso.hora})</span>
              </div>
              {caso.lesionReferida && caso.lesionReferida.length > 0 && (
                <div>
                  <span className="text-slate-500 font-medium">Lesión referida:</span> <span className="text-rose-700 font-semibold">{caso.lesionReferida.join(', ')}</span>
                </div>
              )}
              {caso.partesCuerpoAfectadas && caso.partesCuerpoAfectadas.length > 0 && (
                <div>
                  <span className="text-slate-500 font-medium">Partes afectadas:</span> <span className="text-slate-800">{caso.partesCuerpoAfectadas.join(', ')}</span>
                </div>
              )}
            </div>
          </div>

          <p className="text-slate-600 leading-relaxed">
            Todos los datos registrados en este suceso SST se heredarán automáticamente al módulo de <strong className="text-teal-800">Atenciones Médicas</strong> para que puedas registrar el diagnóstico clínico, tratamiento, descansos médicos y pautas terapéuticas del colaborador accidentado.
          </p>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Permanecer en Accidentes
            </button>
            <button
              type="button"
              onClick={() => onNavigateToAtencion(caso)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-500 text-xs font-bold text-white transition-colors shadow-lg shadow-teal-950 cursor-pointer"
            >
              <HeartPulse className="w-4 h-4" />
              <span>Ir a Atenciones Médicas</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
