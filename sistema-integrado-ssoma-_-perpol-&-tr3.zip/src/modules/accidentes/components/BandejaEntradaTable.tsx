import React from 'react';
import { ConsumoBotiquinRecord } from '../../../types/modules';
import { Inbox, CheckCircle2, Plus } from 'lucide-react';

interface BandejaEntradaTableProps {
  atencionesPendientes: ConsumoBotiquinRecord[];
  onValidar: (atencion: ConsumoBotiquinRecord) => void;
  onDescartar: (atencion: ConsumoBotiquinRecord) => void;
}

export const BandejaEntradaTable: React.FC<BandejaEntradaTableProps> = ({
  atencionesPendientes,
  onValidar,
  onDescartar
}) => {
  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[#B45309]">
            <Inbox className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#0F172A]">
              Bandeja de Transferencia de Tópico (Módulo 4: Consumo de Botiquín)
            </h3>
            <p className="text-xs text-[#475569] font-medium">
              Atenciones clasificadas como "Incidente" o "Accidente" pendientes de validación oficial como caso investigable
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xl font-black text-[#B45309] font-mono">{atencionesPendientes.length}</span>
          <div className="text-[11px] text-[#475569] font-medium">Pendientes en bandeja</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {atencionesPendientes.length === 0 ? (
          <div className="col-span-2 bg-white border border-[#E2E8F0] rounded-xl p-8 text-center text-[#475569] shadow-2xs">
            <CheckCircle2 className="w-8 h-8 text-[#047857] mx-auto mb-2 opacity-90" />
            <p className="text-sm font-bold text-[#0F172A]">Bandeja al día</p>
            <p className="text-xs text-[#475569] mt-1 font-medium">
              No hay atenciones médicas de incidentes o accidentes pendientes de validación.
            </p>
          </div>
        ) : (
          atencionesPendientes.map((atn, atnIdx) => (
            <div
              key={`${atn.id || atn.codigoAtencion || 'atn'}-${atnIdx}`}
              className="bg-white border border-[#E2E8F0] hover:border-[#CBD5E1] rounded-xl p-4 flex flex-col justify-between transition-colors shadow-2xs"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#B45309] text-xs font-mono">{atn.codigoAtencion}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        atn.empresa === 'PERPOL'
                          ? 'bg-blue-50 text-[#0284C7] border-blue-200'
                          : 'bg-amber-50 text-[#B45309] border-amber-200'
                      }`}
                    >
                      {atn.empresa}
                    </span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      atn.tipoAtencion === 'Accidente'
                        ? 'bg-rose-50 text-[#DC2626] border-rose-200'
                        : 'bg-amber-50 text-[#B45309] border-amber-200'
                    }`}
                  >
                    {atn.tipoAtencion}
                  </span>
                </div>

                <div>
                  <div className="text-[#0F172A] text-sm font-bold">{atn.personaAtendida}</div>
                  <div className="text-xs text-[#475569] font-medium">
                    DNI: {atn.dniPersona} • {atn.puesto} • {atn.area}
                  </div>
                  <div className="text-[11px] text-[#475569] mt-0.5 font-medium">
                    Ocurrencia: {atn.fecha} a las {atn.hora || '10:00'} (Turno {atn.turno})
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] text-xs space-y-1">
                  <div className="text-[#0F172A] font-bold">Lesiones / Síntomas:</div>
                  <div className="text-[#475569] font-medium">{atn.lesionesSintomas}</div>
                  <div className="text-[11px] text-[#475569] pt-1 border-t border-[#E2E8F0]">
                    Tratamiento: {atn.procedimientoAplicado}
                  </div>
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-[#E2E8F0] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => onDescartar(atn)}
                  className="px-3 py-1.5 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] text-xs font-semibold text-[#1E293B] border border-[#CBD5E1] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                >
                  Descartar
                </button>
                <button
                  type="button"
                  onClick={() => onValidar(atn)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-xs font-bold text-white transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Validar y Crear Caso Oficial</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
