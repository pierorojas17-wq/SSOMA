import React from 'react';
import { AccidenteRecord, AtencionMedicaRecord } from '../../../types/modules';
import { AlertOctagon, X, HeartPulse, ExternalLink, Activity, Camera } from 'lucide-react';
import { DriveImage } from '../../../components/common/DriveImage';

interface AccidentesDetailModalProps {
  caso: AccidenteRecord | null;
  atencionesMedicas: AtencionMedicaRecord[];
  onClose: () => void;
  onNavigateToAtencion: (caso: AccidenteRecord) => void;
  onViewAtenciones: (caso: AccidenteRecord) => void;
}

export const AccidentesDetailModal: React.FC<AccidentesDetailModalProps> = ({
  caso,
  atencionesMedicas,
  onClose,
  onNavigateToAtencion,
  onViewAtenciones
}) => {
  if (!caso) return null;

  const atencionesCaso = atencionesMedicas.filter(
    (a) => a.idAccidente === caso.id || a.codigoAccidente === caso.codigoCaso
  );
  const diasTotales = atencionesCaso.reduce((sum, a) => sum + (Number(a.diasDescanso) || 0), 0);

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-ficha-title"
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 bg-white border border-[#E2E8F0] rounded-2xl w-full max-w-2xl max-h-[calc(100dvh-2rem)] flex flex-col shadow-2xl overflow-hidden my-auto text-[#0F172A] cursor-default select-text"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header del modal fijo y accesible */}
        <div className="sticky top-0 z-20 px-4 sm:px-6 py-3 sm:py-4 bg-[#F8FAFC] border-b border-[#E2E8F0] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 pr-2">
            <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-[#DC2626] shrink-0">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 id="modal-ficha-title" className="text-sm font-bold text-[#0F172A] truncate">
                Ficha Oficial de Caso — {caso.codigoCaso}
              </h3>
              <p className="text-[11px] text-[#475569] font-medium truncate">
                {caso.empresa} • {caso.tipoEvento}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[36px] min-h-[36px] p-2 rounded-lg text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9] active:bg-[#E2E8F0] border border-[#CBD5E1] transition-colors cursor-pointer shrink-0 z-30 flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            title="Cerrar ficha (Esc)"
            aria-label="Cerrar ficha"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido con scroll vertical independiente */}
        <div className="p-4 sm:p-6 space-y-3.5 sm:space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-3 border-b border-slate-200">
            <div>
              <span className="text-slate-500 font-medium">Fecha y Hora:</span>
              <div className="font-semibold text-slate-800">
                {caso.fecha} a las {caso.hora} (Turno {caso.turno})
              </div>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Empresa:</span>
              <div className="font-semibold text-slate-800">{caso.empresa}</div>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Trabajador:</span>
              <div className="font-semibold text-slate-800">{caso.trabajadorNombre}</div>
              <div className="text-[11px] text-slate-500">
                DNI: {caso.trabajadorDni} • {caso.cargo}
              </div>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Clasificación:</span>
              <div className="font-bold text-rose-600">{caso.tipoEvento}</div>
              <div className="text-[11px] text-slate-500">Estado: {caso.estadoCaso}</div>
            </div>
          </div>

          <div>
            <span className="text-[#475569] font-semibold block mb-0.5">Ubicación / Lugar Físico Específico:</span>
            <div className="text-[#0F172A] font-medium">
              {caso.area} — {caso.lugarExacto}
            </div>
          </div>

          {caso.responsableArea && (
            <div>
              <span className="text-[#475569] font-semibold block mb-0.5">Jefe de Área / Responsable Inmediato:</span>
              <div className="text-[#0F172A] font-medium">{caso.responsableArea}</div>
            </div>
          )}

          <div>
            <span className="text-slate-500 font-semibold block mb-0.5">Descripción de los Hechos:</span>
            <p className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-700 leading-relaxed">
              {caso.descripcion}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 p-2.5 rounded-lg bg-slate-50 border border-slate-200">
            <div>
              <span className="text-slate-500 font-semibold block mb-0.5">¿Daño Material?:</span>
              <div className="text-slate-800 font-medium">
                {caso.danoMaterial === 'SI' ? (
                  <span className="text-amber-700 font-bold">
                    SÍ {caso.detalleDano ? `— ${caso.detalleDano}` : ''}
                  </span>
                ) : (
                  <span className="text-slate-500">NO</span>
                )}
              </div>
            </div>
            <div>
              <span className="text-slate-500 font-semibold block mb-0.5">¿Requirió Atención Médica?:</span>
              <div className="text-slate-800 font-medium">
                {caso.necesidadAtencion === 'SI' ? (
                  <span className="inline-flex items-center gap-1 text-teal-700 font-bold">
                    <HeartPulse className="w-3.5 h-3.5 text-teal-600" />
                    SÍ (Tópico / Asistencial)
                  </span>
                ) : (
                  <span className="text-slate-500">NO</span>
                )}
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider block">
              Clasificación Técnica Normativa SST
            </span>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">Partes del cuerpo afectadas:</span>
              <div className="flex flex-wrap gap-1">
                {(caso.partesCuerpoAfectadas || []).length > 0 ? (
                  caso.partesCuerpoAfectadas!.map((p, pIdx) => (
                    <span key={`${p}-${pIdx}`} className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-semibold">
                      {p}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic text-[11px]">No especificado</span>
                )}
                {caso.partesCuerpoOtros && (
                  <span className="px-2 py-0.5 rounded bg-slate-100 text-rose-700 text-[10px] border border-slate-200">
                    Otros: {caso.partesCuerpoOtros}
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">Tipo / mecanismo del evento:</span>
              <div className="flex flex-wrap gap-1">
                {(caso.mecanismoEvento || []).length > 0 ? (
                  caso.mecanismoEvento!.map((m, mIdx) => (
                    <span key={`${m}-${mIdx}`} className="px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-semibold">
                      {m}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic text-[11px]">No especificado</span>
                )}
                {caso.mecanismoEventoOtros && (
                  <span className="px-2 py-0.5 rounded bg-slate-100 text-amber-700 text-[10px] border border-slate-200">
                    Otros: {caso.mecanismoEventoOtros}
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">Fuente o agente del evento:</span>
              <div className="flex flex-wrap gap-1">
                {(caso.agenteEvento || []).length > 0 ? (
                  caso.agenteEvento!.map((ag, agIdx) => (
                    <span key={`${ag}-${agIdx}`} className="px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200 text-[10px] font-semibold">
                      {ag}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic text-[11px]">No especificado</span>
                )}
                {caso.agenteEventoOtros && (
                  <span className="px-2 py-0.5 rounded bg-slate-100 text-sky-700 text-[10px] border border-slate-200">
                    Otros: {caso.agenteEventoOtros}
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">Lesión o afectación a la salud referida:</span>
              <div className="flex flex-wrap gap-1">
                {(caso.lesionReferida || []).length > 0 ? (
                  caso.lesionReferida!.map((l, lIdx) => (
                    <span key={`${l}-${lIdx}`} className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-semibold">
                      {l}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic text-[11px]">No especificado</span>
                )}
                {caso.lesionReferidaOtros && (
                  <span className="px-2 py-0.5 rounded bg-slate-100 text-purple-700 text-[10px] border border-slate-200">
                    Otros: {caso.lesionReferidaOtros}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div>
            <span className="text-slate-500 font-semibold block mb-0.5">Causa Inmediata / Subestándar:</span>
            <div className="text-slate-800">{caso.causaInmediata || 'En determinación'}</div>
          </div>

          {caso.medidasCorrectivas && (
            <div>
              <span className="text-slate-500 font-semibold block mb-0.5">Plan de Acción / Medidas:</span>
              <p className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-700">
                {caso.medidasCorrectivas}
              </p>
            </div>
          )}

          {caso.fotoUrl && (
            <div className="space-y-1.5">
              <span className="text-[#475569] font-semibold text-xs flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-sky-600" />
                <span>Evidencia Fotográfica del Suceso:</span>
              </span>
              <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-44 flex items-center justify-center p-1">
                <DriveImage
                  src={caso.fotoUrl}
                  driveId={caso.fotoDriveId}
                  alt={`Evidencia caso - ${caso.codigoCaso}`}
                  className="max-h-full max-w-full object-contain rounded-lg"
                  containerClassName="w-full h-full flex items-center justify-center"
                />
              </div>
            </div>
          )}

          <div className="p-3.5 rounded-xl bg-sky-50/50 border border-sky-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#0284C7] flex items-center gap-1.5">
                <HeartPulse className="w-4 h-4 text-[#0284C7]" />
                Historial Médico y Descansos del Colaborador
              </span>
              {atencionesCaso.length > 0 ? (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-[#0284C7] border border-sky-200">
                  {atencionesCaso.length} Atención(es) Registrada(s)
                </span>
              ) : (
                <span className="text-[10px] text-[#B45309] font-medium">
                  {caso.necesidadAtencion === 'SI' ? 'Atención médica pendiente' : 'Sin atenciones médicas'}
                </span>
              )}
            </div>
            {atencionesCaso.length > 0 && (
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-sky-200">
                <div>
                  <span className="text-[#475569] block">Total Días de Descanso:</span>
                  <span className="font-bold text-[#DC2626] text-xs">{diasTotales} día(s) otorgados</span>
                </div>
                <div>
                  <span className="text-[#475569] block">Última Atención / Estado:</span>
                  <span className="font-semibold text-[#0F172A]">{atencionesCaso[0]?.estado}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-[#475569] block">Diagnóstico Principal:</span>
                  <span className="text-[#0F172A] italic line-clamp-2">{atencionesCaso[0]?.diagnostico}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer fijo con botones de acción */}
        <div className="px-4 sm:px-6 py-3 bg-[#F8FAFC] border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-2.5 shrink-0">
          <span className="text-[11px] text-[#475569] font-mono">ID: {caso.id}</span>
          <div className="flex items-center gap-2 flex-wrap">
            {caso.necesidadAtencion === 'SI' && (
              <button
                type="button"
                onClick={() => onNavigateToAtencion(caso)}
                className="min-h-[36px] flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-xs font-bold text-white transition-colors shadow-xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              >
                <HeartPulse className="w-4 h-4 text-white" />
                <span>Registrar Atención</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onViewAtenciones(caso)}
              className="min-h-[36px] flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#F1F5F9] text-xs font-semibold text-[#1E293B] transition-colors border border-[#CBD5E1] cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title={`Ver atenciones médicas de ${caso.codigoCaso}`}
            >
              <Activity className="w-3.5 h-3.5 text-[#0284C7]" />
              <span>Ver Atenciones</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[36px] px-4 py-2 rounded-lg bg-white hover:bg-[#F1F5F9] active:bg-[#E2E8F0] border border-[#CBD5E1] text-xs font-semibold text-[#1E293B] transition-colors cursor-pointer shadow-xs focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              Cerrar Ficha
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
