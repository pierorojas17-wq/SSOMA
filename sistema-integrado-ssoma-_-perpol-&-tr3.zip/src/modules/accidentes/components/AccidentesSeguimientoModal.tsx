import React from 'react';
import { AccidenteRecord } from '../../../types/modules';
import { CheckSquare, X, FileSearch, Save } from 'lucide-react';

interface AccidentesSeguimientoModalProps {
  record: AccidenteRecord | null;
  seguimientoData: {
    estadoCaso: 'Abierto' | 'En investigación' | 'Con medidas correctivas' | 'Cerrado';
    medidasCorrectivas: string;
    responsableSeguimiento: string;
    fechaCompromiso: string;
    fechaCierre: string;
    diasDescanso: number;
    conclusionesInvestigacion: string;
  };
  setSeguimientoData: React.Dispatch<React.SetStateAction<{
    estadoCaso: 'Abierto' | 'En investigación' | 'Con medidas correctivas' | 'Cerrado';
    medidasCorrectivas: string;
    responsableSeguimiento: string;
    fechaCompromiso: string;
    fechaCierre: string;
    diasDescanso: number;
    conclusionesInvestigacion: string;
  }>>;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  onOpenInvestigacion: () => void;
}

export const AccidentesSeguimientoModal: React.FC<AccidentesSeguimientoModalProps> = ({
  record,
  seguimientoData,
  setSeguimientoData,
  onClose,
  onSubmit,
  onOpenInvestigacion
}) => {
  if (!record) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="seguimiento-modal-title"
        className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl my-8 cursor-default select-text text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700 border border-teal-200" aria-hidden="true">
              <CheckSquare className="w-5 h-5 text-teal-700" />
            </div>
            <div>
              <h3 id="seguimiento-modal-title" className="text-base font-bold text-[#0F172A]">
                Seguimiento y Plan de Acción — {record.codigoCaso}
              </h3>
              <p className="text-xs text-[#475569]">
                {record.tipoEvento} • {record.trabajadorNombre} ({record.empresa})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
            title="Cerrar modal (Esc)"
            aria-label="Cerrar modal de seguimiento"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={onSubmit} className="p-6 space-y-4 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-slate-600 font-semibold">Descripción del Evento:</div>
            <div className="text-slate-800">{record.descripcion}</div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Estado del Caso *</label>
              <select
                value={seguimientoData.estadoCaso}
                onChange={(e) =>
                  setSeguimientoData((prev) => ({ ...prev, estadoCaso: e.target.value as any }))
                }
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-500 font-bold"
              >
                <option value="Abierto">Abierto</option>
                <option value="En investigación">En investigación</option>
                <option value="Con medidas correctivas">Con medidas correctivas</option>
                <option value="Cerrado">Cerrado</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Días Totales de Descanso Médico
              </label>
              <input
                type="number"
                min={0}
                value={seguimientoData.diasDescanso}
                onChange={(e) =>
                  setSeguimientoData((prev) => ({ ...prev, diasDescanso: Number(e.target.value) || 0 }))
                }
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Medidas Correctivas y Plan de Acción *
            </label>
            <textarea
              rows={3}
              required
              placeholder="Acciones correctivas inmediatas, controles de ingeniería, cambios en PETS o capacitaciones..."
              value={seguimientoData.medidasCorrectivas}
              onChange={(e) =>
                setSeguimientoData((prev) => ({ ...prev, medidasCorrectivas: e.target.value }))
              }
              className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Responsable de Seguimiento
              </label>
              <input
                type="text"
                placeholder="Ingeniero / Supervisor"
                value={seguimientoData.responsableSeguimiento}
                onChange={(e) =>
                  setSeguimientoData((prev) => ({ ...prev, responsableSeguimiento: e.target.value }))
                }
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Fecha de Compromiso</label>
              <input
                type="date"
                value={seguimientoData.fechaCompromiso}
                onChange={(e) =>
                  setSeguimientoData((prev) => ({ ...prev, fechaCompromiso: e.target.value }))
                }
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Fecha de Cierre {seguimientoData.estadoCaso === 'Cerrado' && '*'}
              </label>
              <input
                type="date"
                value={seguimientoData.fechaCierre}
                onChange={(e) =>
                  setSeguimientoData((prev) => ({ ...prev, fechaCierre: e.target.value }))
                }
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Conclusiones / Lección Aprendida Difundida
            </label>
            <textarea
              rows={2}
              placeholder="Síntesis final del caso y confirmación de difusión al Comité SST..."
              value={seguimientoData.conclusionesInvestigacion}
              onChange={(e) =>
                setSeguimientoData((prev) => ({ ...prev, conclusionesInvestigacion: e.target.value }))
              }
              className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="p-3 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-between">
            <div>
              <div className="font-bold text-[#0F172A]">Investigación de Accidentes (Módulo 10)</div>
              <div className="text-[11px] text-[#475569]">
                Árbol de causas, método 5 Porqués / Ishikawa y formato normativo MTPE
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenInvestigacion}
              className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1 transition-colors cursor-pointer"
            >
              <FileSearch className="w-3.5 h-3.5" />
              <span>Abrir Investigación</span>
            </button>
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-teal-600 hover:bg-teal-500 text-xs font-bold text-white transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Guardar Seguimiento</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
