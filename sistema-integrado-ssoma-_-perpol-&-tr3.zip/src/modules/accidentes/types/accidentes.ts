export * from '../../../types/modules/accidentes';
export type { ConsumoBotiquinRecord, AtencionMedicaRecord, TrabajadorRecord } from '../../../types/modules';

export type AccidentesTab = 'seguimiento' | 'bandejaEntrada' | 'nuevo';

export interface AccidentesFiltros {
  searchTerm: string;
  tipoEventoFilter: string;
  estadoFilter: string;
  fechaDesde: string;
  fechaHasta: string;
}

export interface AccidentesMetricas {
  total: number;
  incidentes: number;
  accidentesLeves: number;
  incapacitantes: number;
  mortales: number;
  requirieronAtencion: number;
  conDanoMaterial: number;
  abiertos: number;
  cerrados: number;
}
