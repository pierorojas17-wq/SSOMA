import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAppStore } from '../../../store/appStore';
import { AccidenteRecord, ConsumoBotiquinRecord, TrabajadorRecord } from '../../../types/modules';
import { AccidentesTab, AccidentesMetricas } from '../types/accidentes';
import { AccidentesService } from '../services/accidentesService';
import { FilterChipOption } from '../../../components/common/ModuleToolbar';

export function useAccidentes() {
  const navigate = useNavigate();
  const location = useLocation();

  const {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    consumosBotiquin,
    upsertAccidente,
    batchUpsertAccidentes,
    removeAccidente,
    marcarAtencionTransferida,
    descartarAtencionTransferencia,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  // Vistas / Tabs
  const [activeTab, setActiveTab] = useState<AccidentesTab>('seguimiento');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Filtros de búsqueda
  const [searchTerm, setSearchTerm] = useState('');
  const [tipoEventoFilter, setTipoEventoFilter] = useState<string>('TODOS');
  const [estadoFilter, setEstadoFilter] = useState<string>('TODOS');
  const [areaFilter, setAreaFilter] = useState<string>('TODOS');
  const [fechaDesde, setFechaDesde] = useState('');
  const [fechaHasta, setFechaHasta] = useState('');

  // Paginación
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modales
  const [viewDetailModal, setViewDetailModal] = useState<AccidenteRecord | null>(null);
  const [seguimientoModal, setSeguimientoModal] = useState<AccidenteRecord | null>(null);
  const [deleteModalCaso, setDeleteModalCaso] = useState<AccidenteRecord | null>(null);
  const [promptAtencionModal, setPromptAtencionModal] = useState<AccidenteRecord | null>(null);

  // Formulario y estado de edición
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [workerSearchTerm, setWorkerSearchTerm] = useState('');
  const [isWorkerDropdownOpen, setIsWorkerDropdownOpen] = useState(false);
  const [isCustomResponsable, setIsCustomResponsable] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const initialFormData: Partial<AccidenteRecord> = {
    fecha: new Date().toISOString().slice(0, 10),
    hora: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    trabajadorNombre: '',
    trabajadorDni: '',
    cargo: '',
    area: '',
    turno: 'Mañana',
    lugarExacto: '',
    responsableArea: '',
    tipoEvento: 'Accidente leve',
    danoMaterial: 'NO',
    detalleDano: '',
    necesidadAtencion: 'SI',
    descripcion: '',
    causaInmediata: '',
    partesCuerpoAfectadas: [],
    partesCuerpoOtros: '',
    mecanismoEvento: [],
    mecanismoEventoOtros: '',
    agenteEvento: [],
    agenteEventoOtros: '',
    lesionReferida: [],
    lesionReferidaOtros: '',
    estadoCaso: 'Abierto',
    medidasCorrectivas: '',
    responsableSeguimiento: '',
    fechaCompromiso: '',
    fechaCierre: ''
  };

  const [formData, setFormData] = useState<Partial<AccidenteRecord>>(initialFormData);

  // Escuchar si viene redirigido desde el Módulo 2 (Atenciones Médicas) con filtro de caso
  useEffect(() => {
    if (location.state) {
      const s = location.state as any;
      if (s.filtroCodigoCaso || s.filtroIdAccidente) {
        const query = s.filtroCodigoCaso || s.filtroIdAccidente;
        setSearchTerm(query);
        setActiveTab('seguimiento');
        addToast({
          type: 'info',
          title: 'Caso SST Localizado',
          message: `Mostrando datos del evento SST correspondiente a ${query}.`
        });
      }
    }
  }, [location.state, addToast]);

  // Actualizar empresa por defecto en formulario si cambia empresa activa
  useEffect(() => {
    if (empresaActiva !== 'CONSOLIDADO') {
      setFormData((prev) => ({ ...prev, empresa: empresaActiva }));
    }
  }, [empresaActiva]);

  // Líderes y responsables de área
  const responsablesLiderazgo = useMemo(() => {
    const keywords = ['supervisor', 'supervisora', 'jefe', 'jefa', 'coordinador', 'coordinadora', 'gerente', 'gestor', 'gestora'];
    return trabajadores
      .filter((t) => {
        if (t.condicion !== 'Activo') return false;
        const p = String(t.puesto || '').toLowerCase();
        return keywords.some((k) => p.includes(k));
      })
      .sort((a, b) => String(a.apellidosNombres || '').localeCompare(String(b.apellidosNombres || '')));
  }, [trabajadores]);

  // Trabajadores filtrados por empresa y búsqueda para autocompletar
  const trabajadoresFiltrados = useMemo(() => {
    return trabajadores
      .filter((t) => {
        if (formData.empresa && t.empresa !== formData.empresa) return false;
        if (!workerSearchTerm.trim()) return true;
        const q = workerSearchTerm.toLowerCase();
        return (
          String(t.apellidosNombres || '').toLowerCase().includes(q) ||
          String(t.dni || '').includes(q)
        );
      })
      .slice(0, 15);
  }, [trabajadores, formData.empresa, workerSearchTerm]);

  // Bandeja de Entrada de Tópico (Módulo 4 -> Módulo 1)
  const atencionesPendientes = useMemo(() => {
    return consumosBotiquin.filter((atencion) => {
      if (empresaActiva !== 'CONSOLIDADO' && atencion.empresa !== empresaActiva) return false;
      const raw = atencion as any;
      const esCandidato =
        atencion.tipoAtencion === 'Accidente' ||
        atencion.tipoAtencion === 'Incidente' ||
        String(raw.requiereInvestigacion || '').toUpperCase() === 'SÍ' ||
        String(raw.requiereInvestigacion || '').toUpperCase() === 'SI' ||
        String(raw.descansoMedico || '').toUpperCase() === 'SÍ' ||
        String(raw.descansoMedico || '').toUpperCase() === 'SI';
      const noTransferido = !atencion.transferidoAccidentes;
      const noDescartado = !raw.descartadoTransferencia;
      return esCandidato && noTransferido && noDescartado;
    });
  }, [consumosBotiquin, empresaActiva]);

  // Filtrado de Casos de Accidentes
  const filteredAccidentes = useMemo(() => {
    return accidentes
      .filter((a) => {
        if (empresaActiva !== 'CONSOLIDADO' && a.empresa !== empresaActiva) return false;
        if (tipoEventoFilter !== 'TODOS' && a.tipoEvento !== tipoEventoFilter) return false;
        if (estadoFilter !== 'TODOS' && a.estadoCaso !== estadoFilter) return false;
        if (areaFilter !== 'TODOS' && a.area !== areaFilter) return false;
        if (fechaDesde && a.fecha < fechaDesde) return false;
        if (fechaHasta && a.fecha > fechaHasta) return false;
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          return (
            a.codigoCaso.toLowerCase().includes(q) ||
            a.trabajadorNombre.toLowerCase().includes(q) ||
            a.trabajadorDni.includes(q) ||
            a.area.toLowerCase().includes(q) ||
            a.descripcion.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  }, [accidentes, empresaActiva, tipoEventoFilter, estadoFilter, areaFilter, fechaDesde, fechaHasta, searchTerm]);

  // Paginación
  const paginatedAccidentes = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return filteredAccidentes.slice(startIndex, startIndex + pageSize);
  }, [filteredAccidentes, currentPage, pageSize]);

  // Métricas de KPIs
  const metricas: AccidentesMetricas = useMemo(() => {
    const lista = accidentes.filter((a) => (empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva));
    return {
      total: lista.length,
      incidentes: lista.filter((a) => a.tipoEvento === 'Incidente' || a.tipoEvento === 'Incidente potencial').length,
      accidentesLeves: lista.filter((a) => a.tipoEvento === 'Accidente leve').length,
      incapacitantes: lista.filter((a) => a.tipoEvento === 'Accidente incapacitante').length,
      mortales: lista.filter((a) => a.tipoEvento === 'Accidente mortal').length,
      requirieronAtencion: lista.filter((a) => a.necesidadAtencion === 'SI').length,
      conDanoMaterial: lista.filter((a) => a.danoMaterial === 'SI').length,
      abiertos: lista.filter((a) => a.estadoCaso === 'Abierto' || a.estadoCaso === 'En investigación').length,
      cerrados: lista.filter((a) => a.estadoCaso === 'Cerrado').length
    };
  }, [accidentes, empresaActiva]);

  // Opciones de estado para la Toolbar
  const statusOptions: FilterChipOption[] = useMemo(() => {
    const base = accidentes.filter((a) => (empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva));
    return [
      { id: 'TODOS', label: 'Todos', count: base.length },
      { id: 'Abierto', label: 'Abiertos', count: base.filter((a) => a.estadoCaso === 'Abierto').length, color: 'text-amber-400' },
      { id: 'En investigación', label: 'En investigación', count: base.filter((a) => a.estadoCaso === 'En investigación').length, color: 'text-blue-400' },
      { id: 'Con medidas correctivas', label: 'Con medidas', count: base.filter((a) => a.estadoCaso === 'Con medidas correctivas').length, color: 'text-purple-400' },
      { id: 'Cerrado', label: 'Cerrados', count: base.filter((a) => a.estadoCaso === 'Cerrado').length, color: 'text-emerald-400' }
    ];
  }, [accidentes, empresaActiva]);

  // Autocompletado al seleccionar trabajador
  const handleSelectTrabajador = (trabajador: TrabajadorRecord) => {
    setFormData((prev) => ({
      ...prev,
      trabajadorNombre: String(trabajador.apellidosNombres || ''),
      trabajadorDni: String(trabajador.dni || ''),
      cargo: String(trabajador.puesto || ''),
      area: String(trabajador.area || ''),
      empresa: trabajador.empresa
    }));
    setWorkerSearchTerm(String(trabajador.apellidosNombres || ''));
    setIsWorkerDropdownOpen(false);
  };

  // Cambio de tipo de evento con reglas normativas
  const handleTipoEventoChange = (tipo: string) => {
    setFormData((prev) => {
      const next: Partial<AccidenteRecord> = { ...prev, tipoEvento: tipo as any };
      if (tipo === 'Incidente potencial') {
        next.danoMaterial = 'NO';
        next.detalleDano = '';
        next.necesidadAtencion = 'NO';
      }
      return next;
    });
  };

  // Manejo de imagen
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      addToast({ type: 'warning', title: 'Archivo muy pesado', message: 'La fotografía no debe superar los 8 MB.' });
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleClearImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  // Selección múltiple para etiquetas
  const toggleMultiSelectOption = (
    field: 'partesCuerpoAfectadas' | 'mecanismoEvento' | 'agenteEvento' | 'lesionReferida',
    op: string
  ) => {
    setFormData((prev) => {
      const current = (prev[field] as string[]) || [];
      const exists = current.includes(op);
      const next = exists ? current.filter((x) => x !== op) : [...current, op];
      const result: Partial<AccidenteRecord> = { ...prev, [field]: next };
      if (exists && op === 'Otros') {
        if (field === 'partesCuerpoAfectadas') result.partesCuerpoOtros = '';
        if (field === 'mecanismoEvento') result.mecanismoEventoOtros = '';
        if (field === 'agenteEvento') result.agenteEventoOtros = '';
        if (field === 'lesionReferida') result.lesionReferidaOtros = '';
      }
      return result;
    });
  };

  // Cargar registro para edición
  const handleEditCaso = (caso: AccidenteRecord) => {
    setEditingId(caso.id || caso.codigoCaso);
    setFormData({
      ...caso,
      partesCuerpoAfectadas: Array.isArray(caso.partesCuerpoAfectadas) ? caso.partesCuerpoAfectadas : [],
      partesCuerpoOtros: caso.partesCuerpoOtros || '',
      mecanismoEvento: Array.isArray(caso.mecanismoEvento) ? caso.mecanismoEvento : [],
      mecanismoEventoOtros: caso.mecanismoEventoOtros || '',
      agenteEvento: Array.isArray(caso.agenteEvento) ? caso.agenteEvento : [],
      agenteEventoOtros: caso.agenteEventoOtros || '',
      lesionReferida: Array.isArray(caso.lesionReferida) ? caso.lesionReferida : [],
      lesionReferidaOtros: caso.lesionReferidaOtros || ''
    });
    setWorkerSearchTerm(caso.trabajadorNombre);
    setImagePreview(caso.fotoUrl || null);
    setImageFile(null);
    setIsCustomResponsable(
      Boolean(
        caso.responsableArea &&
        !responsablesLiderazgo.some((r) => `${r.apellidosNombres} (${r.puesto})` === caso.responsableArea)
      )
    );
    setActiveTab('nuevo');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    addToast({
      type: 'info',
      title: 'Modo Edición',
      message: `Cargando datos del evento SST ${caso.codigoCaso} para su edición.`
    });
  };

  // Convertir atención de tópico de la bandeja en caso de accidente oficial
  const handleValidarAtencionDesdeBandeja = (atencion: ConsumoBotiquinRecord) => {
    setEditingId(null);
    setFormData({
      fecha: atencion.fecha,
      hora: atencion.hora || '10:00',
      empresa: atencion.empresa,
      trabajadorNombre: atencion.personaAtendida,
      trabajadorDni: atencion.dniPersona,
      cargo: atencion.puesto,
      area: atencion.area,
      turno: (atencion.turno as any) || 'Mañana',
      lugarExacto: atencion.area,
      responsableArea: '',
      tipoEvento: atencion.tipoAtencion === 'Accidente' ? 'Accidente leve' : 'Incidente',
      danoMaterial: 'NO',
      detalleDano: '',
      necesidadAtencion: 'SI',
      partesCuerpoAfectadas: [],
      partesCuerpoOtros: '',
      mecanismoEvento: [],
      mecanismoEventoOtros: '',
      agenteEvento: [],
      agenteEventoOtros: '',
      lesionReferida: [],
      lesionReferidaOtros: '',
      descripcion: `[Generado a partir de Atención de Tópico ${atencion.codigoAtencion}]\nLesiones / Síntomas: ${atencion.lesionesSintomas}\nProcedimiento realizado: ${atencion.procedimientoAplicado}`,
      causaInmediata: '',
      estadoCaso: 'En investigación',
      origenAtencionBotiquinId: atencion.codigoAtencion
    });
    setWorkerSearchTerm(atencion.personaAtendida);
    setImagePreview(null);
    setImageFile(null);
    setIsCustomResponsable(false);
    setActiveTab('nuevo');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    addToast({
      type: 'info',
      title: 'Validando Atención de Tópico',
      message: `Cargando datos de atención ${atencion.codigoAtencion} para formalizar en Módulo 1.`
    });
  };

  // Descartar atención de la bandeja
  const handleDescartarAtencion = (atencion: ConsumoBotiquinRecord) => {
    descartarAtencionTransferencia(atencion.id || atencion.codigoAtencion);
    addToast({
      type: 'info',
      title: 'Atención Descartada',
      message: `La atención ${atencion.codigoAtencion} permanecerá como atención asistencial de botiquín sin derivación a caso oficial.`
    });
  };

  // Nuevo registro limpio
  const handleNuevoRegistro = () => {
    setEditingId(null);
    setFormData({ ...initialFormData, empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL' });
    setWorkerSearchTerm('');
    setImagePreview(null);
    setImageFile(null);
    setIsCustomResponsable(false);
    setActiveTab('nuevo');
  };

  // Limpiar filtros
  const clearFilters = () => {
    setSearchTerm('');
    setTipoEventoFilter('TODOS');
    setEstadoFilter('TODOS');
    setAreaFilter('TODOS');
    setFechaDesde('');
    setFechaHasta('');
    setCurrentPage(1);
  };

  // Guardar Accidente / Incidente (Módulo 1)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!String(formData.trabajadorNombre || '').trim() || !String(formData.trabajadorDni || '').trim()) {
      setFormError('Debe seleccionar al trabajador accidentado/involucrado.');
      return;
    }
    if (!String(formData.cargo || '').trim()) {
      setFormError('El puesto o cargo del trabajador es obligatorio.');
      return;
    }
    if (!String(formData.area || '').trim()) {
      setFormError('El área de ocurrencia es obligatoria.');
      return;
    }
    if (!String(formData.lugarExacto || '').trim()) {
      setFormError('El lugar exacto de ocurrencia es obligatorio.');
      return;
    }
    if (!String(formData.responsableArea || '').trim()) {
      setFormError('Debe indicar o seleccionar el jefe / responsable de área.');
      return;
    }
    if (!String(formData.descripcion || '').trim()) {
      setFormError('Debe ingresar la descripción detallada y circunstanciada del suceso.');
      return;
    }

    if (formData.tipoEvento === 'Incidente potencial') {
      if (formData.danoMaterial === 'SI') {
        setFormError('Normativa SST: Un Incidente Potencial (casi accidente) no genera daño material.');
        return;
      }
      if (formData.necesidadAtencion === 'SI') {
        setFormError('Normativa SST: Un Incidente Potencial no requiere atención médica ni primeros auxilios.');
        return;
      }
    }

    if (formData.danoMaterial === 'SI' && !String(formData.detalleDano || '').trim()) {
      setFormError('Especifique el detalle de los daños materiales generados.');
      return;
    }

    if (formData.partesCuerpoAfectadas?.includes('Otros') && !String(formData.partesCuerpoOtros || '').trim()) {
      setFormError('Ha seleccionado "Otros" en Partes del cuerpo afectadas: complete la especificación.');
      return;
    }
    if (formData.mecanismoEvento?.includes('Otros') && !String(formData.mecanismoEventoOtros || '').trim()) {
      setFormError('Ha seleccionado "Otros" en Tipo / mecanismo del evento: complete la especificación.');
      return;
    }
    if (formData.agenteEvento?.includes('Otros') && !String(formData.agenteEventoOtros || '').trim()) {
      setFormError('Ha seleccionado "Otros" en Fuente o agente del evento: complete la especificación.');
      return;
    }
    if (formData.lesionReferida?.includes('Otros') && !String(formData.lesionReferidaOtros || '').trim()) {
      setFormError('Ha seleccionado "Otros" en Lesión o afectación a la salud referida: complete la especificación.');
      return;
    }

    setIsSubmitting(true);
    incrementSync();

    try {
      let finalFotoUrl = formData.fotoUrl;
      let finalFotoDriveId = formData.fotoDriveId;

      if (imageFile) {
        addToast({ type: 'info', title: 'Comprimiendo Imagen', message: 'Optimizando foto para Google Drive...' });
        const uploadRes = await AccidentesService.uploadFoto(imageFile, formData.empresa || 'PERPOL');
        if (uploadRes.fileUrl) {
          finalFotoUrl = uploadRes.fileUrl;
          finalFotoDriveId = uploadRes.fileId;
        }
      }

      const existingCaso = editingId ? accidentes.find((a) => a.id === editingId || a.codigoCaso === editingId) : null;
      let correlativoCodigo = existingCaso?.codigoCaso;
      if (!correlativoCodigo) {
        const anio = new Date(formData.fecha || Date.now()).getFullYear();
        const totalAnio = accidentes.filter((a) => {
          const f = a.fecha || '';
          return f.startsWith(String(anio)) || (a.codigoCaso && a.codigoCaso.includes(`-${anio}-`));
        }).length;
        correlativoCodigo = `ACC-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;
      }

      const fullRecord: AccidenteRecord = {
        id: editingId || correlativoCodigo,
        codigoCaso: correlativoCodigo,
        empresa: formData.empresa as 'PERPOL' | 'TR3',
        fecha: formData.fecha || new Date().toISOString().slice(0, 10),
        hora: formData.hora || '10:00',
        trabajadorNombre: formData.trabajadorNombre!,
        trabajadorDni: formData.trabajadorDni!,
        cargo: formData.cargo || '',
        area: formData.area || '',
        turno: formData.turno || 'Mañana',
        lugarExacto: formData.lugarExacto || formData.area || '',
        responsableArea: formData.responsableArea || '',
        tipoEvento: formData.tipoEvento as any,
        danoMaterial: formData.danoMaterial as 'SI' | 'NO',
        detalleDano: formData.detalleDano,
        necesidadAtencion: formData.necesidadAtencion as 'SI' | 'NO',
        descripcion: formData.descripcion!,
        causaInmediata: formData.causaInmediata || '',
        partesCuerpoAfectadas: formData.partesCuerpoAfectadas || [],
        partesCuerpoOtros: formData.partesCuerpoOtros || undefined,
        mecanismoEvento: formData.mecanismoEvento || [],
        mecanismoEventoOtros: formData.mecanismoEventoOtros || undefined,
        agenteEvento: formData.agenteEvento || [],
        agenteEventoOtros: formData.agenteEventoOtros || undefined,
        lesionReferida: formData.lesionReferida || [],
        lesionReferidaOtros: formData.lesionReferidaOtros || undefined,
        estadoCaso: (formData.estadoCaso as any) || 'Abierto',
        medidasCorrectivas: formData.medidasCorrectivas,
        responsableSeguimiento: formData.responsableSeguimiento,
        fechaCompromiso: formData.fechaCompromiso,
        fechaCierre: formData.fechaCierre,
        origenAtencionBotiquinId: formData.origenAtencionBotiquinId,
        fotoUrl: finalFotoUrl,
        fotoDriveId: finalFotoDriveId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // 1. Optimistic update en Zustand
      upsertAccidente(fullRecord);

      // 2. Si vino de tópico, marcar la atención como transferida y validada
      if (formData.origenAtencionBotiquinId) {
        marcarAtencionTransferida(formData.origenAtencionBotiquinId, correlativoCodigo);
      }

      // 3. Persistir en GAS
      const apiRes = await AccidentesService.saveAccidente(fullRecord);

      if (!apiRes.success) {
        addToast({
          type: 'warning',
          title: 'Aviso de Sincronización',
          message: apiRes.error || apiRes.message || 'No se pudo registrar inmediatamente en Google Sheets. Verifique la conexión.'
        });
      } else {
        addToast({
          type: 'success',
          title: 'Caso Oficial Registrado',
          message: `Código ${correlativoCodigo} guardado en Google Sheets exitosamente.`
        });
      }

      if (fullRecord.necesidadAtencion === 'SI') {
        setPromptAtencionModal(fullRecord);
      } else {
        setActiveTab('seguimiento');
      }

      setEditingId(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar el caso de accidente';
      setFormError(msg);
      addToast({ type: 'error', title: 'Error', message: msg });
    } finally {
      setIsSubmitting(false);
      decrementSync();
    }
  };

  // Abrir modal de Seguimiento
  const handleOpenSeguimiento = (record: AccidenteRecord) => {
    setSeguimientoModal(record);
  };

  // Guardar Seguimiento
  const handleSaveSeguimiento = async (updatedRecord: AccidenteRecord) => {
    upsertAccidente(updatedRecord);
    addToast({
      type: 'success',
      title: 'Seguimiento Actualizado',
      message: `Caso ${updatedRecord.codigoCaso} actualizado con estado '${updatedRecord.estadoCaso}'.`
    });

    try {
      await AccidentesService.saveAccidente(updatedRecord);
    } catch {
      // Manejado por store
    }
    setSeguimientoModal(null);
  };

  // Confirmar eliminación
  const confirmDeleteCaso = async () => {
    if (!deleteModalCaso) return;
    const record = deleteModalCaso;
    removeAccidente(record.id);
    addToast({ type: 'info', title: 'Caso Eliminado', message: `Caso ${record.codigoCaso} eliminado.` });

    try {
      await AccidentesService.deleteAccidente(record.codigoCaso);
    } catch {
      // Ignorar fallback
    } finally {
      setDeleteModalCaso(null);
    }
  };

  // Exportar Excel
  const handleExportarExcel = () => {
    AccidentesService.exportExcel(
      filteredAccidentes,
      `SSOMA_Accidentes_Incidentes_${empresaActiva}_${new Date().toISOString().slice(0, 10)}`
    );
    addToast({ type: 'success', title: 'Exportación Excel', message: 'Reporte oficial de eventos SST exportado.' });
  };

  // Exportar PDF
  const handleExportarPDF = () => {
    AccidentesService.exportPDF(
      filteredAccidentes,
      `Registro_Accidentes_${empresaActiva}`,
      `REGISTRO OFICIAL DE ACCIDENTES DE TRABAJO E INCIDENTES - ${empresaActiva}`
    );
    addToast({ type: 'success', title: 'Reporte PDF Generado', message: 'El PDF fue generado y descargado correctamente.' });
  };

  // Importar desde Excel / CSV
  const handleImportSuccess = (importedData: AccidenteRecord[]) => {
    batchUpsertAccidentes(importedData);
    addToast({
      type: 'success',
      title: 'Importación Completada',
      message: `Se importaron ${importedData.length} registros de accidentes correctamente.`
    });
  };

  // Navegación
  const handleNavigateToAtencion = (item: AccidenteRecord) => {
    navigate('/atenciones-medicas', {
      state: {
        idAccidenteOrigen: item.id,
        codigoCasoAccidente: item.codigoCaso,
        dniTrabajador: item.trabajadorDni,
        nombreTrabajador: item.trabajadorNombre,
        empresa: item.empresa,
        fechaEvento: item.fecha
      }
    });
  };

  const handleViewAtenciones = (item: AccidenteRecord) => {
    navigate('/atenciones-medicas', {
      state: {
        filtroCodigoCaso: item.codigoCaso,
        filtroDni: item.trabajadorDni
      }
    });
  };

  const handleNavigateToInvestigacion = (item: AccidenteRecord) => {
    navigate('/investigacion', {
      state: {
        codigoCaso: item.codigoCaso,
        empresa: item.empresa,
        trabajadorNombre: item.trabajadorNombre,
        fecha: item.fecha
      }
    });
  };

  return {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    searchTerm,
    setSearchTerm,
    tipoEventoFilter,
    setTipoEventoFilter,
    estadoFilter,
    setEstadoFilter,
    areaFilter,
    setAreaFilter,
    fechaDesde,
    setFechaDesde,
    fechaHasta,
    setFechaHasta,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    viewDetailModal,
    setViewDetailModal,
    seguimientoModal,
    setSeguimientoModal,
    deleteModalCaso,
    setDeleteModalCaso,
    promptAtencionModal,
    setPromptAtencionModal,
    formData,
    setFormData,
    editingId,
    setEditingId,
    formError,
    isSubmitting,
    imageFile,
    setImageFile,
    imagePreview,
    setImagePreview,
    workerSearchTerm,
    setWorkerSearchTerm,
    isWorkerDropdownOpen,
    setIsWorkerDropdownOpen,
    isCustomResponsable,
    setIsCustomResponsable,
    responsablesLiderazgo,
    trabajadoresFiltrados,
    metricas,
    filteredAccidentes,
    paginatedAccidentes,
    atencionesPendientes,
    statusOptions,
    handleSelectTrabajador,
    handleTipoEventoChange,
    handleImageChange,
    handleClearImage,
    toggleMultiSelectOption,
    handleEditCaso,
    handleValidarAtencionDesdeBandeja,
    handleDescartarAtencion,
    handleSubmit,
    handleOpenSeguimiento,
    handleSaveSeguimiento,
    confirmDeleteCaso,
    handleExportarExcel,
    handleExportarPDF,
    handleImportSuccess,
    handleNuevoRegistro,
    clearFilters,
    handleNavigateToAtencion,
    handleViewAtenciones,
    handleNavigateToInvestigacion
  };
}
