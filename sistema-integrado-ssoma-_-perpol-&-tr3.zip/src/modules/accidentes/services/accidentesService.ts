import { AccidenteRecord } from '../../../types/modules';
import { GasApiClient } from '../../../services/api';
import { DriveStorageService } from '../../../services/driveService';
import { ExportUtils } from '../../../utils/exportUtils';
import { EmpresaId } from '../../../types';

export class AccidentesService {
  /**
   * Persiste un accidente en Google Apps Script
   */
  static async saveAccidente(record: AccidenteRecord) {
    return await GasApiClient.sendRequest({
      action: 'saveAccidente',
      sheetName: 'SSOMA_Accidentes',
      data: record
    });
  }

  /**
   * Elimina un accidente de Google Apps Script
   */
  static async deleteAccidente(codigoCaso: string) {
    return await GasApiClient.sendRequest({
      action: 'deleteAccidente',
      sheetName: 'SSOMA_Accidentes',
      data: { codigoCaso }
    });
  }

  /**
   * Sube una foto a Google Drive optimizada
   */
  static async uploadFoto(file: File, empresa: string) {
    return await DriveStorageService.uploadToDrive(file, {
      modulo: 'accidentes',
      fileName: `Accidente_${empresa}_${Date.now()}.jpg`,
      maxDimension: 1200,
      quality: 0.75
    });
  }

  /**
   * Exporta a Excel
   */
  static exportExcel(records: AccidenteRecord[], filename: string) {
    const data = records.map((a) => ({
      'Código': a.codigoCaso,
      'Fecha': a.fecha,
      'Hora': a.hora,
      'Empresa': a.empresa,
      'Trabajador': a.trabajadorNombre,
      'DNI': a.trabajadorDni,
      'Cargo': a.cargo,
      'Área': a.area,
      'Tipo de Evento': a.tipoEvento,
      'Días Descanso': a.diasDescanso,
      'Estado': a.estadoCaso,
      'Descripción': a.descripcion
    }));
    ExportUtils.exportToExcel(data, filename, 'Accidentes e Incidentes');
  }

  /**
   * Exporta a PDF
   */
  static exportPDF(records: AccidenteRecord[], filename: string, title: string, empresa: EmpresaId = 'CONSOLIDADO') {
    ExportUtils.exportToPdf({
      title,
      empresa,
      fileName: filename,
      headers: ['Código', 'Fecha', 'Empresa', 'Trabajador', 'Tipo Evento', 'Área', 'Estado'],
      rows: records.map((r) => [
        r.codigoCaso,
        r.fecha,
        r.empresa,
        `${r.trabajadorNombre} (${r.trabajadorDni})`,
        r.tipoEvento,
        r.area,
        r.estadoCaso
      ]),
      orientation: 'landscape'
    });
  }
}
