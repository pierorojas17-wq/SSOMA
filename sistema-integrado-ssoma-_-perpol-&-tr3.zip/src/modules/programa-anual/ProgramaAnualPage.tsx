import React, { useState, useMemo, useEffect } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore } from '../../store/appStore';
import { ProgramaAnualRecord, ProgramaResumenAnual } from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { ExportUtils } from '../../utils/exportUtils';
import { ModuleToolbar } from '../../components/common/ModuleToolbar';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import {
  CalendarCheck2,
  Target,
  TrendingUp,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Save,
  X,
  Edit2,
  Trash2,
  Eye,
  Sliders
} from 'lucide-react';

const MESES_CORTOS = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SET', 'OCT', 'NOV', 'DIC'];

/**
 * Algoritmo Crítico: activityProgress
 * Cumple con el requisito del Prompt Maestro:
 * - Regular: redondeo(meses programados y ejecutados hasta el corte / meses programados hasta el corte * 100)
 * - A demanda: 100% si se atendió la demanda requerida, o 100% si no hubo demanda pendiente.
 */
export function calculateActivityProgress(
  programacion: boolean[],
  ejecucion: boolean[],
  tipo: 'Regular' | 'A Demanda',
  mesCorte: number // 1 a 12
): number {
  const safeProg = Array.isArray(programacion) ? programacion : [];
  const safeEjec = Array.isArray(ejecucion) ? ejecucion : [];

  if (tipo === 'A Demanda') {
    const ejecutados = safeEjec.slice(0, mesCorte).filter(Boolean).length;
    const programados = safeProg.slice(0, mesCorte).filter(Boolean).length;
    if (programados === 0) {
      return ejecutados > 0 ? 100 : 100;
    }
    return Math.min(100, Math.round((ejecutados / programados) * 100));
  }

  // Actividad Regular
  let programadosHastaCorte = 0;
  let ejecutadosHastaCorte = 0;

  for (let i = 0; i < mesCorte; i++) {
    if (safeProg[i]) {
      programadosHastaCorte++;
      if (safeEjec[i]) {
        ejecutadosHastaCorte++;
      }
    }
  }

  if (programadosHastaCorte === 0) {
    // Si no estuvo programada en meses pasados pero se ejecutó algo
    const extraEjecutados = safeEjec.slice(0, mesCorte).filter(Boolean).length;
    return extraEjecutados > 0 ? 100 : 0;
  }

  return Math.min(100, Math.round((ejecutadosHastaCorte / programadosHastaCorte) * 100));
}

// Actividades del PASST (inicialmente vacío para iniciar correlativo desde 0001)
const SEED_ACTIVIDADES: ProgramaAnualRecord[] = [];

export const ProgramaAnualPage: React.FC = () => {
  const {
    empresaActiva,
    setProgramaResumen,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  const [actividades, setActividades] = useState<ProgramaAnualRecord[]>(SEED_ACTIVIDADES);
  const [selectedAnio, setSelectedAnio] = useState<number>(2026);
  const [mesCorte, setMesCorte] = useState<number>(new Date().getMonth() + 1); // 1 a 12
  const [searchTerm, setSearchTerm] = useState('');
  const [collapsedObjetivos, setCollapsedObjetivos] = useState<Record<string, boolean>>({});
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingActividad, setEditingActividad] = useState<ProgramaAnualRecord | null>(null);
  const [deleteModalActividad, setDeleteModalActividad] = useState<ProgramaAnualRecord | null>(null);
  const [viewDetailActividad, setViewDetailActividad] = useState<ProgramaAnualRecord | null>(null);
  const [modalFormData, setModalFormData] = useState<Partial<ProgramaAnualRecord>>({
    anio: 2026,
    numeroItem: 1,
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    objetivoGeneral: '1. Liderazgo, Compromiso e IPERC',
    actividad: '',
    tipoActividad: 'Regular',
    responsable: 'Jefatura SSOMA',
    presupuestoEstimado: 1000,
    metaPorcentaje: 100,
    indicadorFormula: '(Actividades realizadas / Programadas) × 100',
    programacionMeses: Array(12).fill(false),
    ejecucionMeses: Array(12).fill(false),
    estado: 'Programado'
  });

  // Filtrado de actividades
  const filteredActividades = useMemo(() => {
    return actividades.filter((a) => {
      const matchEmpresa =
        empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva;
      const matchAnio = a.anio === selectedAnio;
      const term = searchTerm.toLowerCase().trim();
      const matchSearch =
        !term ||
        String(a.actividad || '').toLowerCase().includes(term) ||
        String(a.objetivoGeneral || '').toLowerCase().includes(term) ||
        String(a.responsable || '').toLowerCase().includes(term);

      return matchEmpresa && matchAnio && matchSearch;
    });
  }, [actividades, empresaActiva, selectedAnio, searchTerm]);

  // Recálculo del avance de cada actividad según el mes de corte
  const actividadesConAvance = useMemo(() => {
    return filteredActividades.map((a) => {
      const avance = calculateActivityProgress(
        a.programacionMeses,
        a.ejecucionMeses,
        a.tipoActividad,
        mesCorte
      );

      // Determinar estado automático según ejecución
      let estado = a.estado;
      const totalProg = (a.programacionMeses || []).filter(Boolean).length;
      const totalEjec = (a.ejecucionMeses || []).filter(Boolean).length;

      if (totalEjec === 0 && totalProg > 0) {
        estado = 'Programado';
      } else if (totalEjec > 0 && totalEjec < totalProg) {
        estado = 'En ejecución';
      } else if (totalEjec >= totalProg && totalProg > 0) {
        estado = 'Ejecutado';
      }

      return {
        ...a,
        avanceCalculado: avance,
        estado
      };
    });
  }, [filteredActividades, mesCorte]);

  // Agrupamiento por Objetivos Generales
  const agrupadoPorObjetivo = useMemo(() => {
    const map: Record<string, typeof actividadesConAvance> = {};
    actividadesConAvance.forEach((a) => {
      if (!map[a.objetivoGeneral]) {
        map[a.objetivoGeneral] = [];
      }
      map[a.objetivoGeneral].push(a);
    });
    return map;
  }, [actividadesConAvance]);

  // Cálculo del Resumen Anual y Mensual
  const resumenAnual = useMemo<ProgramaResumenAnual>(() => {
    const avanceMensual = Array(12).fill(0);

    for (let m = 0; m < 12; m++) {
      let programadasMes = 0;
      let ejecutadasMes = 0;

      actividadesConAvance.forEach((a) => {
        if (a.programacionMeses[m]) programadasMes++;
        if (a.ejecucionMeses[m]) ejecutadasMes++;
      });

      avanceMensual[m] =
        programadasMes > 0
          ? Math.min(100, Math.round((ejecutadasMes / programadasMes) * 100))
          : ejecutadasMes > 0
          ? 100
          : 0;
    }

    const totalActividades = actividadesConAvance.length;
    const sumaAvances = actividadesConAvance.reduce((acc, a) => acc + a.avanceCalculado, 0);
    const promedioActividades =
      totalActividades > 0 ? Math.round(sumaAvances / totalActividades) : 0;

    // Avance ponderado anual
    const avanceAnualPonderado = promedioActividades;
    const actividadesEjecutadas = actividadesConAvance.filter((a) => a.estado === 'Ejecutado').length;

    return {
      id: `${selectedAnio}-${empresaActiva}`,
      anio: selectedAnio,
      empresa: empresaActiva,
      avanceMensual,
      promedioActividades,
      avanceAnualPonderado,
      totalActividades,
      actividadesEjecutadas,
      updatedAt: new Date().toISOString()
    };
  }, [actividadesConAvance, selectedAnio, empresaActiva]);

  // Publicación automática del Resumen Anual al estado global (para consumo por Módulo 8: Estadísticas)
  useEffect(() => {
    setProgramaResumen(resumenAnual);
  }, [resumenAnual, setProgramaResumen]);

  // Alternar programación o ejecución de un mes directamente en el Gantt interactivo
  const handleToggleGantt = async (
    actividadId: string,
    mesIdx: number,
    field: 'programacionMeses' | 'ejecucionMeses'
  ) => {
    const target = actividades.find((a) => a.id === actividadId);
    if (!target) return;

    const newArray = [...target[field]];
    newArray[mesIdx] = !newArray[mesIdx];

    const updatedActividad: ProgramaAnualRecord = {
      ...target,
      [field]: newArray,
      updatedAt: new Date().toISOString()
    };

    // Actualización optimista
    setActividades((prev) =>
      prev.map((a) => (a.id === actividadId ? updatedActividad : a))
    );

    incrementSync();

    try {
      await GasApiClient.post({
        action: 'saveProgramaAnual',
        sheetName: 'SSOMA_Programa_Anual',
        data: updatedActividad
      });
      // Sincronizar también el resumen consolidado en segundo plano
      await GasApiClient.post({
        action: 'saveProgramaResumen',
        sheetName: 'SSOMA_Programa_Resumen',
        data: resumenAnual
      });
    } finally {
      decrementSync();
    }
  };

  // Guardar nueva actividad o cambios en modal
  const handleSaveActividad = async (e: React.FormEvent) => {
    e.preventDefault();

    const totalAnio = actividades.filter((a) => a.anio === selectedAnio).length;
    const record: ProgramaAnualRecord = {
      id: editingActividad?.id || `PROG-${selectedAnio}-${String(totalAnio + 1).padStart(4, '0')}`,
      anio: selectedAnio,
      numeroItem: modalFormData.numeroItem || actividades.length + 1,
      empresa: modalFormData.empresa as 'PERPOL' | 'TR3',
      objetivoGeneral: modalFormData.objetivoGeneral || '1. Liderazgo e IPERC',
      actividad: String(modalFormData.actividad || '').trim(),
      tipoActividad: modalFormData.tipoActividad || 'Regular',
      responsable: String(modalFormData.responsable || 'SSOMA').trim(),
      presupuestoEstimado: Number(modalFormData.presupuestoEstimado) || 0,
      metaPorcentaje: Number(modalFormData.metaPorcentaje) || 100,
      indicadorFormula: String(modalFormData.indicadorFormula || '(Ejecutadas / Programadas) × 100').trim(),
      programacionMeses: modalFormData.programacionMeses || Array(12).fill(false),
      ejecucionMeses: modalFormData.ejecucionMeses || Array(12).fill(false),
      estado: (modalFormData.estado as any) || 'Programado',
      avanceCalculado: 0,
      createdAt: editingActividad?.createdAt || new Date().toISOString()
    };

    setActividades((prev) => {
      const idx = prev.findIndex((a) => a.id === record.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = record;
        return copy;
      }
      return [...prev, record];
    });

    setIsModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: editingActividad ? 'Actividad Actualizada' : 'Actividad Agregada',
      message: `${record.actividad} guardada en el Programa Anual.`
    });

    try {
      await GasApiClient.post({
        action: 'saveProgramaAnual',
        sheetName: 'SSOMA_Programa_Anual',
        data: record
      });
    } finally {
      decrementSync();
    }
  };

  const confirmDeleteActividad = async () => {
    if (!deleteModalActividad) return;
    const a = deleteModalActividad;

    setActividades((prev) => prev.filter((item) => item.id !== a.id));
    incrementSync();

    addToast({
      type: 'info',
      title: 'Actividad Eliminada',
      message: `Actividad '${a.actividad}' fue removida del cronograma.`
    });

    try {
      await GasApiClient.post({
        action: 'deleteProgramaAnual',
        sheetName: 'SSOMA_Programa_Anual',
        id: a.id
      });
    } finally {
      decrementSync();
      setDeleteModalActividad(null);
    }
  };

  // Exportaciones
  const handleExportExcel = () => {
    const exportData = actividadesConAvance.map((a) => {
      const row: Record<string, unknown> = {
        'N°': a.numeroItem,
        'Objetivo General': a.objetivoGeneral,
        'Actividad': a.actividad,
        'Tipo': a.tipoActividad,
        'Responsable': a.responsable,
        'Presupuesto (S/)': a.presupuestoEstimado,
        'Meta (%)': `${a.metaPorcentaje}%`,
        'Estado': a.estado,
        [`Avance al Mes ${MESES_CORTOS[mesCorte - 1]}`]: `${a.avanceCalculado}%`
      };

      MESES_CORTOS.forEach((m, idx) => {
        row[`${m} (Prog)`] = a.programacionMeses[idx] ? 'SI' : 'NO';
        row[`${m} (Ejec)`] = a.ejecucionMeses[idx] ? 'SI' : 'NO';
      });

      return row;
    });

    ExportUtils.exportToExcel(exportData, `Programa_Anual_SST_${selectedAnio}_${empresaActiva}`);
    addToast({
      type: 'success',
      title: 'Excel Generado',
      message: 'El cronograma completo Gantt fue exportado a Excel.'
    });
  };

  const handleExportPdf = () => {
    ExportUtils.exportToPdf({
      title: `PROGRAMA ANUAL DE SEGURIDAD Y SALUD EN EL TRABAJO (PASST) - ${selectedAnio}`,
      subtitle: `Empresa: ${empresaActiva} | Corte a: ${MESES_CORTOS[mesCorte - 1]} | Cumplimiento Ponderado: ${resumenAnual.avanceAnualPonderado}%`,
      empresa: empresaActiva,
      fileName: `Programa_Anual_SST_${selectedAnio}`,
      headers: ['N°', 'Objetivo', 'Actividad', 'Tipo', 'Responsable', 'Estado', 'Cumplimiento'],
      rows: actividadesConAvance.map((a) => [
        a.numeroItem,
        a.objetivoGeneral,
        a.actividad,
        a.tipoActividad,
        a.responsable,
        a.estado,
        `${a.avanceCalculado}%`
      ]),
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'PDF Generado',
      message: 'Reporte oficial del Programa Anual SST listo.'
    });
  };

  return (
    <div className="space-y-6">
      <ModuleHeader
        codigo={8}
        titulo="Programa Anual de Seguridad y Salud en el Trabajo (PASST)"
        subtitulo="Diagrama de Gantt interactivo (Programado vs Ejecutado), cálculo de avance crítico y publicación directa a Estadísticas SST"
        icono={<CalendarCheck2 className="w-5 h-5" />}
        onNuevo={() => {
          setEditingActividad(null);
          setModalFormData({
            anio: selectedAnio,
            numeroItem: actividades.length + 1,
            empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
            objetivoGeneral: '1. Liderazgo, Compromiso e IPERC',
            actividad: '',
            tipoActividad: 'Regular',
            responsable: 'Jefatura SSOMA',
            presupuestoEstimado: 1500,
            metaPorcentaje: 100,
            indicadorFormula: '(Ejecutadas / Programadas) × 100',
            programacionMeses: Array(12).fill(false),
            ejecucionMeses: Array(12).fill(false),
            estado: 'Programado'
          });
          setIsModalOpen(true);
        }}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS['programa-anual']}
        onImportSuccess={(rows) => {
          setActividades((prev) => {
            const list = [...prev];
            rows.forEach((r: any) => {
              const idx = list.findIndex((a) => a.id === r.id || a.numeroItem === Number(r.numeroItem));
              const itemToUpsert: ProgramaAnualRecord = {
                id: r.id || `PROG-${Date.now()}-${r.numeroItem}`,
                anio: Number(r.anio) || selectedAnio,
                numeroItem: Number(r.numeroItem) || (list.length + 1),
                empresa: (r.empresa as any) || empresaActiva,
                objetivoGeneral: r.objetivoGeneral || '1. Liderazgo, Compromiso e IPERC',
                actividad: r.actividad || 'Actividad Anual',
                tipoActividad: (r.tipoActividad as any) || 'Regular',
                responsable: r.responsable || 'Jefatura SSOMA',
                presupuestoEstimado: Number(r.presupuestoEstimado) || 0,
                metaPorcentaje: Number(r.metaPorcentaje) || 100,
                indicadorFormula: r.indicadorFormula || '(Ejecutadas / Programadas) × 100',
                programacionMeses: Array(12).fill(true),
                ejecucionMeses: Array(12).fill(false),
                estado: 'Programado',
                avanceCalculado: 0,
                createdAt: new Date().toISOString()
              };
              if (idx >= 0) list[idx] = { ...list[idx], ...itemToUpsert };
              else list.push(itemToUpsert);
            });
            return list;
          });
        }}
      />

      {/* Tarjetas de Avance Anual Ponderado */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <TrendingUp className="w-4 h-4 text-[#047857]" />
            <span className="font-semibold">Cumplimiento Ponderado</span>
          </div>
          <div className="text-2xl font-black text-[#047857]">
            {resumenAnual.avanceAnualPonderado}%
          </div>
          <div className="text-[10px] text-[#475569] mt-1">
            Corte evaluado: {MESES_CORTOS[mesCorte - 1]} {selectedAnio}
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <Target className="w-4 h-4 text-[#0284C7]" />
            <span className="font-semibold">Total de Actividades</span>
          </div>
          <div className="text-2xl font-black text-[#0F172A]">{resumenAnual.totalActividades}</div>
          <div className="text-[10px] text-[#475569] mt-1">Agrupadas por 4 objetivos clave</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <CheckCircle2 className="w-4 h-4 text-[#047857]" />
            <span className="font-semibold">Actividades Ejecutadas</span>
          </div>
          <div className="text-2xl font-black text-[#0F172A]">
            {resumenAnual.actividadesEjecutadas}
          </div>
          <div className="text-[10px] text-[#475569] mt-1">Con cumplimiento al 100%</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <Sliders className="w-4 h-4 text-[#B45309]" />
            <span className="font-semibold">Ajuste de Mes de Corte</span>
          </div>
          <select
            value={mesCorte}
            onChange={(e) => setMesCorte(Number(e.target.value))}
            aria-label="Ajuste de Mes de Corte"
            className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 text-xs text-[#0F172A] font-semibold mt-1 focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
          >
            {MESES_CORTOS.map((m, idx) => (
              <option key={m} value={idx + 1}>
                Hasta {m} ({idx + 1})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Barra de herramientas y filtros estandarizada */}
      <ModuleToolbar
        searchQuery={searchTerm}
        onSearchChange={(val) => setSearchTerm(val)}
        searchPlaceholder="Buscar actividad o responsable..."
        totalCount={actividades.filter((a) => empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva).length}
        filteredCount={filteredActividades.length}
        onExportExcel={handleExportExcel}
        onExportPdf={handleExportPdf}
        onNewRecord={() => {
          setEditingActividad(null);
          setIsModalOpen(true);
        }}
        newRecordLabel="Nueva Actividad"
      >
        <div className="flex items-center gap-1.5 text-xs text-[#475569] bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 shadow-2xs font-medium">
          <span>Año:</span>
          <select
            value={selectedAnio}
            onChange={(e) => setSelectedAnio(Number(e.target.value))}
            aria-label="Seleccionar Año para Programa Anual"
            className="bg-transparent text-[#0F172A] font-bold focus:outline-hidden cursor-pointer"
          >
            {[2025, 2026, 2027].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </ModuleToolbar>

      {/* LEYENDA DEL GANTT */}
      <div className="flex flex-wrap items-center justify-between p-3.5 rounded-xl bg-white border border-[#E2E8F0] text-[11px] text-[#475569] shadow-2xs">
        <div className="flex items-center gap-4">
          <span className="font-semibold text-[#0F172A]">Leyenda del Gantt:</span>
          <span className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-[#1E293B] border border-[#0F172A] flex items-center justify-center text-[10px] font-bold text-white">
              P
            </span>
            <span className="text-[#0F172A] font-medium">Programado</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-[#047857] border border-[#065F46] flex items-center justify-center text-[10px] font-bold text-white">
              E
            </span>
            <span className="text-[#0F172A] font-medium">Ejecutado</span>
          </span>
        </div>
        <div className="text-[#475569] text-[10px]">
          Haz clic sobre las casillas <strong>P</strong> o <strong>E</strong> para marcar o desmarcar en tiempo real
        </div>
      </div>

      {/* DIAGRAMA DE GANTT AGRUPADO POR OBJETIVOS */}
      <div className="space-y-4">
        {Object.entries(agrupadoPorObjetivo).length === 0 ? (
          <TableEmptyState
            title="No hay actividades en el Programa Anual"
            description={
              searchTerm
                ? `No hay actividades que coincidan con "${searchTerm}" para el año ${selectedAnio}.`
                : `No hay actividades programadas para el año ${selectedAnio} y empresa seleccionada.`
            }
            actionLabel={searchTerm ? 'Limpiar búsqueda' : 'Nueva Actividad'}
            actionIcon={searchTerm ? 'clear' : 'plus'}
            onAction={() => {
              if (searchTerm) {
                setSearchTerm('');
              } else {
                setEditingActividad(null);
                setIsModalOpen(true);
              }
            }}
          />
        ) : (
          Object.entries(agrupadoPorObjetivo).map(([objetivo, items]) => {
            const isCollapsed = collapsedObjetivos[objetivo];
            const avgObjetivo = Math.round(
              items.reduce((acc, curr) => acc + curr.avanceCalculado, 0) / items.length
            );

            return (
              <div
                key={objetivo}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs"
              >
                {/* Cabecera del Objetivo */}
                <div
                  onClick={() =>
                    setCollapsedObjetivos((prev) => ({ ...prev, [objetivo]: !prev[objetivo] }))
                  }
                  className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between cursor-pointer hover:bg-slate-100/70 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    {isCollapsed ? (
                      <ChevronRight className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-emerald-600" />
                    )}
                    <h3 className="font-bold text-slate-800 text-sm tracking-tight">{objetivo}</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600 font-mono">
                      {items.length} actividades
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-500">Avance Objetivo:</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-slate-200 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-emerald-500 h-2 rounded-full transition-all"
                          style={{ width: `${avgObjetivo}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-emerald-700 font-mono w-9 text-right">
                        {avgObjetivo}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Tabla Gantt */}
                {!isCollapsed && (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[1000px] text-left text-xs text-slate-700">
                      <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
                        <tr>
                          <th className="px-3 py-2.5 w-10 text-center whitespace-nowrap">N°</th>
                          <th className="px-3 py-2.5 min-w-[240px]">Actividad y Responsable</th>
                          <th className="px-2 py-2.5 w-24 text-center whitespace-nowrap">Tipo</th>
                          <th className="px-2 py-2.5 w-24 text-center whitespace-nowrap">Avance</th>
                          {MESES_CORTOS.map((m, idx) => (
                            <th
                              key={m}
                              className={`px-1 py-2 text-center min-w-[42px] ${
                                idx + 1 === mesCorte ? 'bg-emerald-50 text-emerald-700 font-bold' : ''
                              }`}
                            >
                              {m}
                            </th>
                          ))}
                          <th className="px-3 py-2.5 text-right w-16">Acción</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {items.map((a, aIdx) => (
                          <tr key={`${a.id || a.actividad || ''}-${aIdx}`} className="hover:bg-slate-50/80 transition-colors">
                            <td className="px-3 py-2 text-center font-mono font-semibold text-slate-500">
                              0{a.numeroItem}
                            </td>
                            <td className="px-3 py-2">
                              <div className="font-semibold text-slate-800 leading-tight">{a.actividad}</div>
                              <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-2">
                                <span>Resp: {a.responsable}</span>
                                <span>•</span>
                                <span className="font-mono">Ppto: S/ {a.presupuestoEstimado}</span>
                              </div>
                            </td>
                            <td className="px-2 py-2 text-center">
                              <span
                                className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                                  a.tipoActividad === 'A Demanda'
                                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                    : 'bg-slate-100 text-slate-700 border border-slate-200'
                                }`}
                              >
                                {a.tipoActividad}
                              </span>
                            </td>
                            <td className="px-2 py-2 text-center">
                              <div className="flex flex-col items-center">
                                <span className="font-mono font-bold text-emerald-700 text-xs">
                                  {a.avanceCalculado}%
                                </span>
                                <div className="w-14 bg-slate-200 rounded-full h-1 mt-1 overflow-hidden">
                                  <div
                                    className="bg-emerald-500 h-1 rounded-full"
                                    style={{ width: `${a.avanceCalculado}%` }}
                                  />
                                </div>
                              </div>
                            </td>

                            {/* 12 Meses del Gantt Interactivo */}
                            {MESES_CORTOS.map((_, mIdx) => {
                              const isProg = a.programacionMeses[mIdx];
                              const isEjec = a.ejecucionMeses[mIdx];
                              const isCurrentCutoff = mIdx + 1 === mesCorte;

                              return (
                                <td
                                  key={mIdx}
                                  className={`px-1 py-1.5 text-center ${
                                    isCurrentCutoff ? 'bg-emerald-50/60' : ''
                                  }`}
                                >
                                  <div className="inline-flex flex-col gap-1 items-center justify-center">
                                    {/* Botón P (Programado) */}
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleToggleGantt(a.id, mIdx, 'programacionMeses')
                                      }
                                      className={`w-5 h-4 rounded text-[9px] font-bold flex items-center justify-center transition-all ${
                                        isProg
                                          ? 'bg-blue-600 text-white shadow-xs hover:bg-blue-500'
                                          : 'bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200'
                                      }`}
                                      title={isProg ? 'Programado (clic para quitar)' : 'Marcar Programado'}
                                    >
                                      P
                                    </button>

                                    {/* Botón E (Ejecutado) */}
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleToggleGantt(a.id, mIdx, 'ejecucionMeses')
                                      }
                                      className={`w-5 h-4 rounded text-[9px] font-bold flex items-center justify-center transition-all ${
                                        isEjec
                                          ? 'bg-emerald-500 text-white shadow-xs hover:bg-emerald-400'
                                          : 'bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200'
                                      }`}
                                      title={isEjec ? 'Ejecutado (clic para quitar)' : 'Marcar Ejecutado'}
                                    >
                                      E
                                    </button>
                                  </div>
                                </td>
                              );
                            })}

                            <td className="px-3 py-2 text-right">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => setViewDetailActividad(a)}
                                  className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
                                  title="Ver detalle de actividad"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingActividad(a);
                                    setModalFormData({ ...a });
                                    setIsModalOpen(true);
                                  }}
                                  className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-indigo-600 transition-colors"
                                  title="Editar actividad"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeleteModalActividad(a)}
                                  className="p-1 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors"
                                  title="Eliminar actividad"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* TABLA RESUMEN DE CUMPLIMIENTO MENSUAL (CONSUMIBLE POR ESTADÍSTICAS) */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#047857]" />
            <h3 className="font-bold text-[#0F172A] text-sm">
              Curva de Cumplimiento Mensual del Programa ({selectedAnio})
            </h3>
          </div>
          <span className="text-[10px] text-[#475569] bg-[#F1F5F9] px-2 py-0.5 rounded border border-[#E2E8F0] font-medium">
            Exportado automáticamente a Estadísticas SST
          </span>
        </div>

        <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 text-center">
          {MESES_CORTOS.map((mes, idx) => {
            const pct = resumenAnual.avanceMensual[idx];
            return (
              <div
                key={mes}
                className={`p-2 rounded-lg border ${
                  idx + 1 === mesCorte
                    ? 'bg-emerald-50 border-[#047857] shadow-2xs'
                    : 'bg-[#F8FAFC] border-[#E2E8F0]'
                }`}
              >
                <div className="text-[10px] font-semibold text-[#475569]">{mes}</div>
                <div
                  className={`text-sm font-black mt-0.5 font-mono ${
                    pct >= 100
                      ? 'text-[#047857]'
                      : pct >= 50
                      ? 'text-[#B45309]'
                      : pct > 0
                      ? 'text-[#0284C7]'
                      : 'text-[#475569]'
                  }`}
                >
                  {pct}%
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODAL DE CREACIÓN / EDICIÓN DE ACTIVIDAD */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-teal-50 border border-teal-200 text-teal-700">
                  <CalendarCheck2 className="w-5 h-5 text-teal-600" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0F172A] text-base">
                    {editingActividad ? 'Editar Actividad del Programa' : 'Nueva Actividad del PASST'}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">
                    Planificación anual de actividades y metas SST
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveActividad} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Empresa</label>
                  <select
                    value={modalFormData.empresa}
                    onChange={(e) => setModalFormData({ ...modalFormData, empresa: e.target.value as any })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                    <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tipo de Actividad</label>
                  <select
                    value={modalFormData.tipoActividad}
                    onChange={(e) => setModalFormData({ ...modalFormData, tipoActividad: e.target.value as any })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="Regular">Regular (Cronograma fijo)</option>
                    <option value="A Demanda">A Demanda (Atención según necesidad)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Objetivo General</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: 1. Liderazgo, Compromiso e IPERC"
                  value={modalFormData.objetivoGeneral}
                  onChange={(e) => setModalFormData({ ...modalFormData, objetivoGeneral: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nombre de la Actividad *</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Ej: Simulacro nacional de sismo y evacuación con participación de brigadas"
                  value={modalFormData.actividad}
                  onChange={(e) => setModalFormData({ ...modalFormData, actividad: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Responsable *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Supervisor SSOMA"
                    value={modalFormData.responsable}
                    onChange={(e) => setModalFormData({ ...modalFormData, responsable: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Presupuesto Estimado (S/)</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0.00"
                    value={modalFormData.presupuestoEstimado}
                    onChange={(e) =>
                      setModalFormData({ ...modalFormData, presupuestoEstimado: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingActividad ? 'Guardar Cambios' : 'Registrar Actividad'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DETALLE DE ACTIVIDAD DEL PROGRAMA ANUAL */}
      {viewDetailActividad && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewDetailActividad(null);
          }}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="fixed inset-0 -z-10 cursor-pointer"
            onClick={() => setViewDetailActividad(null)}
            aria-hidden="true"
          />

          <div
            className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className="w-9 h-9 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center shrink-0">
                  <CalendarCheck2 className="w-5 h-5 text-indigo-600" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-[#0F172A] flex items-center gap-2 truncate">
                    <span>Actividad N° {viewDetailActividad.numeroItem}</span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-indigo-50 text-indigo-800 border border-indigo-200">
                      PASST {viewDetailActividad.anio}
                    </span>
                  </h3>
                  <p className="text-xs text-[#475569] font-medium truncate">
                    {viewDetailActividad.objetivoGeneral}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewDetailActividad(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200 active:bg-slate-300 transition-colors cursor-pointer shrink-0"
                title="Cerrar ficha (Esc)"
              >
                <X className="w-5 h-5 text-slate-600" />
              </button>
            </div>

            {/* Contenido con scroll */}
            <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-indigo-700 block mb-1">Actividad</span>
                <p className="text-[#0F172A] text-sm font-bold leading-relaxed">
                  {viewDetailActividad.actividad}
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Empresa</span>
                  <span className="text-[#0F172A] font-bold">{viewDetailActividad.empresa === 'PERPOL' ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Tipo Actividad</span>
                  <span className="text-slate-800 font-semibold">{viewDetailActividad.tipoActividad}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Responsable</span>
                  <span className="text-[#0F172A] font-semibold">{viewDetailActividad.responsable}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Presupuesto</span>
                  <span className="text-[#047857] font-mono font-bold text-sm">
                    S/ {viewDetailActividad.presupuestoEstimado?.toLocaleString() || '0.00'}
                  </span>
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[#0F172A] font-bold uppercase text-[10px] tracking-wider">Cronograma de Cumplimiento Mensual</span>
                  <span className="text-[11px] font-mono text-[#047857] font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Meta: {viewDetailActividad.metaPorcentaje}%
                  </span>
                </div>
                <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5 text-center font-mono text-[10px] pt-1">
                  {MESES_CORTOS.map((mes, idx) => {
                    const prog = viewDetailActividad.programacionMeses?.[idx];
                    const ejec = viewDetailActividad.ejecucionMeses?.[idx];
                    return (
                      <div
                        key={mes}
                        className={`p-1.5 rounded-lg border flex flex-col items-center gap-1 ${
                          ejec
                            ? 'bg-emerald-100 border-emerald-300 text-emerald-900 font-bold'
                            : prog
                            ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                            : 'bg-white border-slate-200 text-slate-400'
                        }`}
                      >
                        <span className="font-bold text-[9px]">{mes}</span>
                        <span className="text-[8px]">
                          {ejec ? '✓ Ejec' : prog ? '○ Prog' : '-'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {viewDetailActividad.indicadorFormula && (
                <div className="text-[11px] text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="font-bold text-[#0F172A] block mb-0.5">Fórmula de Indicador:</span>
                  {viewDetailActividad.indicadorFormula}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const a = viewDetailActividad;
                  setViewDetailActividad(null);
                  setEditingActividad(a);
                  setModalFormData({ ...a });
                  setIsModalOpen(true);
                }}
                className="px-4 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5 text-teal-600" />
                <span>Editar Actividad</span>
              </button>
              <button
                type="button"
                onClick={() => setViewDetailActividad(null)}
                className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 active:bg-slate-400 border border-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer shadow-xs"
              >
                Cerrar Ficha
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de confirmación para eliminar actividad */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalActividad)}
        onClose={() => setDeleteModalActividad(null)}
        onConfirm={confirmDeleteActividad}
        title="Eliminar Actividad del Programa Anual"
        message="¿Estás seguro de que deseas eliminar esta actividad del Programa Anual SST?"
        itemIdentifier={
          deleteModalActividad
            ? `Ítem ${deleteModalActividad.numeroItem}: ${deleteModalActividad.actividad} (${deleteModalActividad.responsable})`
            : undefined
        }
        confirmButtonText="Eliminar Actividad"
      />
    </div>
  );
};
