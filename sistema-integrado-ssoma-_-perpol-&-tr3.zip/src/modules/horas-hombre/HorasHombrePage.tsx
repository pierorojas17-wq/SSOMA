import React, { useState, useMemo } from 'react';
import { useAppStore } from '../../store/appStore';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { GasApiClient } from '../../services/api';
import { ExportUtils } from '../../utils/exportUtils';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import { ResumenMensualHH } from '../../types/modules';
import {
  Clock,
  Building2,
  Save,
  Trash2,
  Edit2,
  FileSpreadsheet,
  FileText,
  TrendingUp,
  Users,
  Calendar,
  Layers,
  Wand2,
  CheckCircle2
} from 'lucide-react';

const MESES = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre'
];

export const HorasHombrePage: React.FC = () => {
  const {
    horasHombre,
    upsertHorasHombre,
    batchUpsertHorasHombre,
    removeHorasHombre,
    trabajadores,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  const [selectedAnio, setSelectedAnio] = useState<number>(new Date().getFullYear());
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [deleteModalHH, setDeleteModalHH] = useState<ResumenMensualHH | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Formulario de Registro Mensual HH
  const [hhFormData, setHhFormData] = useState({
    mes: new Date().getMonth() + 1,
    trabajadoresPerpol: 85,
    hhPerpol: 15300,
    trabajadoresTr3: 65,
    hhTr3: 11700
  });

  // Lista de registros correspondientes al año seleccionado
  const resumenHHList = useMemo(() => {
    return horasHombre
      .filter((h) => h.anio === selectedAnio)
      .sort((a, b) => a.mes - b.mes);
  }, [horasHombre, selectedAnio]);

  // Totales acumulados anuales
  const totalAnualHH = useMemo(() => {
    return resumenHHList.reduce((acc, curr) => acc + (Number(curr.totalHH) || 0), 0);
  }, [resumenHHList]);

  const totalAnualHHPerpol = useMemo(() => {
    return resumenHHList.reduce((acc, curr) => acc + (Number(curr.hhPerpol) || 0), 0);
  }, [resumenHHList]);

  const totalAnualHHTr3 = useMemo(() => {
    return resumenHHList.reduce((acc, curr) => acc + (Number(curr.hhTr3) || 0), 0);
  }, [resumenHHList]);

  const promedioTrabajadores = useMemo(() => {
    if (resumenHHList.length === 0) return 0;
    const sum = resumenHHList.reduce((acc, curr) => acc + (Number(curr.totalTrabajadores) || 0), 0);
    return Math.round(sum / resumenHHList.length);
  }, [resumenHHList]);

  const promedioMensualHH = useMemo(() => {
    if (resumenHHList.length === 0) return 0;
    return Math.round(totalAnualHH / resumenHHList.length);
  }, [totalAnualHH, resumenHHList.length]);

  // Autocompletar dotación activa desde el padrón de trabajadores
  const handleAutocompletarDesdePadron = () => {
    const activosPerpol = trabajadores.filter(
      (t) => t.empresa === 'PERPOL' && t.condicion === 'Activo'
    ).length;
    const activosTr3 = trabajadores.filter(
      (t) => t.empresa === 'TR3' && t.condicion === 'Activo'
    ).length;

    const horasEstandar = 192; // 8 horas x 24 días laborables
    const calcPerpol = activosPerpol > 0 ? activosPerpol : 85;
    const calcTr3 = activosTr3 > 0 ? activosTr3 : 65;

    setHhFormData((prev) => ({
      ...prev,
      trabajadoresPerpol: calcPerpol,
      hhPerpol: calcPerpol * horasEstandar,
      trabajadoresTr3: calcTr3,
      hhTr3: calcTr3 * horasEstandar
    }));

    addToast({
      type: 'info',
      title: 'Datos Calculados desde Padrón',
      message: `PERPOL: ${calcPerpol} trab. (${(calcPerpol * horasEstandar).toLocaleString()} HH) | TR3: ${calcTr3} trab. (${(calcTr3 * horasEstandar).toLocaleString()} HH)`
    });
  };

  // Cargar registro para edición
  const handleEdit = (record: ResumenMensualHH) => {
    setEditingId(record.id);
    setSelectedAnio(record.anio);
    setHhFormData({
      mes: record.mes,
      trabajadoresPerpol: record.trabajadoresPerpol,
      hhPerpol: record.hhPerpol,
      trabajadoresTr3: record.trabajadoresTr3,
      hhTr3: record.hhTr3
    });

    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  const handleCancelarEdicion = () => {
    setEditingId(null);
    setHhFormData({
      mes: new Date().getMonth() + 1,
      trabajadoresPerpol: 85,
      hhPerpol: 15300,
      trabajadoresTr3: 65,
      hhTr3: 11700
    });
  };

  // Guardar o Actualizar Horas-Hombre del Mes
  const handleSaveResumenHH = async (e: React.FormEvent) => {
    e.preventDefault();

    const anio = selectedAnio;
    const mes = Number(hhFormData.mes);
    const key = `${anio}-${mes < 10 ? '0' + mes : mes}`;

    const totalTrabajadores = Number(hhFormData.trabajadoresPerpol) + Number(hhFormData.trabajadoresTr3);
    const totalHH = Number(hhFormData.hhPerpol) + Number(hhFormData.hhTr3);

    const record: ResumenMensualHH = {
      id: key,
      empresa: 'PERPOL',
      anio,
      mes,
      trabajadoresPerpol: Number(hhFormData.trabajadoresPerpol),
      hhPerpol: Number(hhFormData.hhPerpol),
      trabajadoresTr3: Number(hhFormData.trabajadoresTr3),
      hhTr3: Number(hhFormData.hhTr3),
      totalTrabajadores,
      totalHH,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    upsertHorasHombre(record);
    setEditingId(null);
    incrementSync();

    addToast({
      type: 'success',
      title: 'Horas-Hombre Registradas',
      message: `Mes ${MESES[mes - 1]} ${anio} guardado exitosamente.`
    });

    try {
      await GasApiClient.post({
        action: 'saveResumenHH',
        sheetName: 'SSOMA_HorasHombre',
        data: record
      });
    } catch {
      // Manejado por store
    } finally {
      decrementSync();
    }
  };

  // Confirmar eliminación
  const handleConfirmDelete = async () => {
    if (!deleteModalHH) return;
    const targetId = deleteModalHH.id;
    removeHorasHombre(targetId);
    setDeleteModalHH(null);
    incrementSync();

    addToast({
      type: 'info',
      title: 'Registro Eliminado',
      message: `El registro de ${MESES[deleteModalHH.mes - 1]} ${deleteModalHH.anio} fue retirado.`
    });

    try {
      await GasApiClient.post({
        action: 'deleteRow',
        sheetName: 'SSOMA_HorasHombre',
        data: { id: targetId }
      });
    } catch {
      // Ignorar fallback
    } finally {
      decrementSync();
    }
  };

  // Exportación a Excel en Cliente
  const handleExportExcel = () => {
    const exportData = resumenHHList.map((r) => ({
      'Año': r.anio,
      'Mes': MESES[r.mes - 1],
      'Trabajadores PERPOL': r.trabajadoresPerpol,
      'HH PERPOL': r.hhPerpol,
      'Trabajadores TR3': r.trabajadoresTr3,
      'HH TR3': r.hhTr3,
      'Total Personal': r.totalTrabajadores,
      'Total Horas-Hombre': r.totalHH,
      'Promedio HH/Trabajador': r.totalTrabajadores > 0 ? Math.round(r.totalHH / r.totalTrabajadores) : 0
    }));

    ExportUtils.exportToExcel(exportData, `Consolidado_Horas_Hombre_${selectedAnio}`);

    addToast({
      type: 'success',
      title: 'Exportación a Excel Completa',
      message: `Consolidado HH del año ${selectedAnio} descargado en formato .xlsx.`
    });
  };

  // Exportación a PDF en Cliente
  const handleExportPdf = () => {
    ExportUtils.exportToPdf({
      title: `CONSOLIDADO MENSUAL DE PERSONAL Y HORAS-HOMBRE (HH) - ${selectedAnio}`,
      subtitle: 'PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C. | Sistema Integrado SSOMA',
      empresa: 'CONSOLIDADO',
      fileName: `Consolidado_Horas_Hombre_${selectedAnio}`,
      headers: [
        'Mes',
        'Trab. PERPOL',
        'HH PERPOL',
        'Trab. TR3',
        'HH TR3',
        'Total Personal',
        'Total Horas-Hombre',
        'Prom. h/colaborador'
      ],
      rows: resumenHHList.map((r) => [
        MESES[r.mes - 1],
        r.trabajadoresPerpol,
        `${r.hhPerpol.toLocaleString()} hrs`,
        r.trabajadoresTr3,
        `${r.hhTr3.toLocaleString()} hrs`,
        r.totalTrabajadores,
        `${r.totalHH.toLocaleString()} hrs`,
        r.totalTrabajadores > 0 ? `${Math.round(r.totalHH / r.totalTrabajadores)} h` : '-'
      ]),
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'Exportación a PDF Completa',
      message: 'Documento PDF de Horas-Hombre generado profesionalmente.'
    });
  };

  return (
    <div className="space-y-6">
      <ModuleHeader
        codigo={7}
        titulo="Resumen Mensual y Horas-Hombre (HH)"
        subtitulo="Consolidación mensual de horas trabajadas y dotación de personal para el cálculo de tasas de accidentabilidad e indicadores de SST (PERPOL & TR3)"
        icono={<Clock className="w-5 h-5 text-cyan-400" />}
        onImportar={() => setIsImportModalOpen(true)}
      >
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
            title="Descargar reporte en Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Excel</span>
          </button>
          <button
            onClick={handleExportPdf}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
            title="Descargar reporte en PDF corporativo"
          >
            <FileText className="w-4 h-4 text-rose-600" />
            <span className="hidden sm:inline">PDF</span>
          </button>
        </div>
      </ModuleHeader>

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.horasHombre}
        onImportSuccess={(rows) => {
          batchUpsertHorasHombre(rows as any);
          addToast({
            type: 'success',
            title: 'Importación Exitosa',
            message: `${rows.length} registros de Horas-Hombre incorporados al consolidado.`
          });
        }}
      />

      {/* Tarjetas de Indicadores Anuales (KPIs) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#475569]">Total HH Anual ({selectedAnio})</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-200">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#0F172A]">
              {totalAnualHH.toLocaleString()}
            </span>
            <span className="text-xs text-[#475569] font-mono">HH</span>
          </div>
          <div className="mt-2 text-[11px] text-[#475569] flex items-center justify-between border-t border-[#E2E8F0] pt-2 font-mono">
            <span className="text-[#047857] font-semibold">PERPOL: {totalAnualHHPerpol.toLocaleString()}</span>
            <span className="text-[#0284C7] font-semibold">TR3: {totalAnualHHTr3.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#475569]">Dotación Promedio Mensual</span>
            <div className="p-2 rounded-lg bg-blue-50 text-[#0284C7] border border-blue-200">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#0F172A]">
              {promedioTrabajadores}
            </span>
            <span className="text-xs text-[#475569]">colaboradores</span>
          </div>
          <div className="mt-2 text-[11px] text-[#475569] border-t border-[#E2E8F0] pt-2 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-[#047857]" />
            <span className="font-medium">Base consolidada en planta</span>
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#475569]">Promedio Mensual HH</span>
            <div className="p-2 rounded-lg bg-slate-100 text-[#1E293B] border border-[#CBD5E1]">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#0F172A]">
              {promedioMensualHH.toLocaleString()}
            </span>
            <span className="text-xs text-[#475569] font-mono">HH / mes</span>
          </div>
          <div className="mt-2 text-[11px] text-[#475569] border-t border-[#E2E8F0] pt-2">
            <span>Para cálculo de Índices IF / IS</span>
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#475569]">Meses Registrados</span>
            <div className="p-2 rounded-lg bg-amber-50 text-[#B45309] border border-amber-200">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#0F172A]">
              {resumenHHList.length} / 12
            </span>
            <span className="text-xs text-[#475569]">periodos</span>
          </div>
          <div className="mt-2 text-[11px] text-[#475569] border-t border-[#E2E8F0] pt-2 flex items-center justify-between">
            <span>Avance anual:</span>
            <span className="font-bold text-[#047857]">
              {Math.round((resumenHHList.length / 12) * 100)}%
            </span>
          </div>
        </div>
      </div>

      {/* Contenido Principal: Formulario de Registro + Tabla Consolidada */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Columna Izquierda: Formulario de Registro Mensual HH */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#047857]" />
              <h3 className="font-bold text-[#0F172A] text-sm">
                {editingId ? 'Editar Horas-Hombre del Mes' : 'Registrar Horas-Hombre del Mes'}
              </h3>
            </div>
            {editingId && (
              <button
                type="button"
                onClick={handleCancelarEdicion}
                className="text-[11px] text-[#DC2626] hover:underline font-semibold cursor-pointer"
              >
                Cancelar
              </button>
            )}
          </div>

          <form onSubmit={handleSaveResumenHH} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#0F172A] mb-1 font-semibold">Año</label>
                <select
                  value={selectedAnio}
                  onChange={(e) => setSelectedAnio(Number(e.target.value))}
                  aria-label="Seleccionar Año para Registro Mensual"
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 text-[#0F172A] font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                >
                  {[2024, 2025, 2026, 2027].map((y) => (
                    <option key={y} value={y}>
                      Año {y}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[#0F172A] mb-1 font-semibold">Mes</label>
                <select
                  value={hhFormData.mes}
                  onChange={(e) => setHhFormData({ ...hhFormData, mes: Number(e.target.value) })}
                  aria-label="Seleccionar Mes para Registro Mensual"
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 text-[#0F172A] font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                >
                  {MESES.map((m, idx) => (
                    <option key={m} value={idx + 1}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Botón para pre-llenar con base de datos del módulo de trabajadores */}
            <button
              type="button"
              onClick={handleAutocompletarDesdePadron}
              className="w-full py-2 px-3 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#1E293B] border border-[#CBD5E1] flex items-center justify-center gap-1.5 transition-colors text-xs font-semibold shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              title="Obtener conteo de colaboradores activos desde el padrón y calcular 192 hrs/mes"
            >
              <Wand2 className="w-3.5 h-3.5 text-[#047857]" />
              <span>Calcular desde Padrón Activo (192 h/trabajador)</span>
            </button>

            {/* Sección PERPOL */}
            <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
              <div className="font-semibold text-[#047857] text-[11px] flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5" />
                  <span>PERPOL IDEAS S.A.C.</span>
                </div>
                <span className="text-[10px] text-[#475569] font-mono">Sede Principal</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">N° Trabajadores</label>
                  <input
                    type="number"
                    min="0"
                    value={hhFormData.trabajadoresPerpol}
                    onChange={(e) =>
                      setHhFormData({ ...hhFormData, trabajadoresPerpol: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">Horas-Hombre (HH)</label>
                  <input
                    type="number"
                    min="0"
                    value={hhFormData.hhPerpol}
                    onChange={(e) =>
                      setHhFormData({ ...hhFormData, hhPerpol: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Sección TR3 */}
            <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
              <div className="font-semibold text-[#0284C7] text-[11px] flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5" />
                  <span>TR3 ALIMENTOS S.A.C.</span>
                </div>
                <span className="text-[10px] text-[#475569] font-mono">Planta Láctea</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">N° Trabajadores</label>
                  <input
                    type="number"
                    min="0"
                    value={hhFormData.trabajadoresTr3}
                    onChange={(e) =>
                      setHhFormData({ ...hhFormData, trabajadoresTr3: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">Horas-Hombre (HH)</label>
                  <input
                    type="number"
                    min="0"
                    value={hhFormData.hhTr3}
                    onChange={(e) =>
                      setHhFormData({ ...hhFormData, hhTr3: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Totales consolidados del mes en vivo */}
            <div className="p-3.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] space-y-1.5 shadow-2xs">
              <div className="flex items-center justify-between text-xs text-[#475569] font-medium">
                <span>Total Personal Mes:</span>
                <span className="font-bold font-mono text-[#0F172A]">
                  {Number(hhFormData.trabajadoresPerpol) + Number(hhFormData.trabajadoresTr3)} trabajadores
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-[#475569] font-medium">
                <span>Total Horas-Hombre:</span>
                <span className="font-bold font-mono text-[#047857] text-sm">
                  {(Number(hhFormData.hhPerpol) + Number(hhFormData.hhTr3)).toLocaleString()} HH
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-bold text-xs transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <Save className="w-4 h-4" />
              <span>
                {editingId
                  ? `Actualizar ${MESES[hhFormData.mes - 1]} ${selectedAnio}`
                  : `Guardar ${MESES[hhFormData.mes - 1]} ${selectedAnio}`}
              </span>
            </button>
          </form>
        </div>

        {/* Columna Derecha: Tabla de Consolidado Anual */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-[#E2E8F0] p-4 rounded-xl shadow-2xs">
            <div>
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#047857]" />
                <h3 className="font-bold text-[#0F172A] text-sm">
                  Consolidado de Horas-Hombre — Año {selectedAnio}
                </h3>
              </div>
              <p className="text-xs text-[#475569] mt-0.5">
                Total acumulado del periodo:{' '}
                <strong className="text-[#047857] font-mono font-bold">
                  {totalAnualHH.toLocaleString()} Horas-Hombre
                </strong>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#475569] font-medium">Año:</span>
              <select
                value={selectedAnio}
                onChange={(e) => setSelectedAnio(Number(e.target.value))}
                aria-label="Seleccionar Año para Consolidado de Horas-Hombre"
                className="bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1 text-xs text-[#0F172A] font-bold shadow-2xs cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
              >
                {[2024, 2025, 2026, 2027].map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="bg-white border border-[#E2E8F0] rounded-xl overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[940px] text-left text-xs text-[#0F172A]">
                <thead className="bg-[#F8FAFC] text-[#475569] uppercase text-[10px] font-semibold border-b border-[#E2E8F0] tracking-wider">
                  <tr>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">Mes</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">Trab. PERPOL</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">HH PERPOL</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">Trab. TR3</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">HH TR3</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">Total Personal</th>
                    <th className="px-4 py-3 w-36 whitespace-nowrap">Total HH</th>
                    <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1F5F9]">
                  {resumenHHList.length === 0 ? (
                    <TableEmptyState
                      isTableRow
                      colSpan={8}
                      title={`No hay registros de Horas-Hombre para el año ${selectedAnio}`}
                      description="Utilice el formulario lateral para ingresar los meses o importe un archivo Excel."
                    />
                  ) : (
                    resumenHHList.map((r, rIdx) => {
                      return (
                        <tr key={`${r.id || r.mes || ''}-${rIdx}`} className="hover:bg-[#F8FAFC] transition-colors">
                          <td className="px-4 py-3 font-semibold text-[#0F172A] flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-[#047857]"></span>
                            <span>{MESES[r.mes - 1]}</span>
                          </td>
                          <td className="px-4 py-3 text-[#0F172A] font-mono">{r.trabajadoresPerpol}</td>
                          <td className="px-4 py-3 font-mono font-semibold text-[#047857]">{r.hhPerpol.toLocaleString()}</td>
                          <td className="px-4 py-3 text-[#0F172A] font-mono">{r.trabajadoresTr3}</td>
                          <td className="px-4 py-3 font-mono font-semibold text-[#0284C7]">{r.hhTr3.toLocaleString()}</td>
                          <td className="px-4 py-3 text-[#0F172A] font-mono">{r.totalTrabajadores}</td>
                          <td className="px-4 py-3 font-bold text-[#0F172A] font-mono">
                            {r.totalHH.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => handleEdit(r)}
                                className="p-1.5 rounded-md hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                                title="Editar horas del mes"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteModalHH(r)}
                                className="p-1.5 rounded-md hover:bg-rose-50 text-[#475569] hover:text-[#DC2626] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                                title="Eliminar registro del mes"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                {resumenHHList.length > 0 && (
                  <tfoot className="bg-[#F8FAFC] border-t-2 border-[#CBD5E1] font-semibold text-xs text-[#0F172A]">
                    <tr>
                      <td className="px-4 py-3 text-[#0F172A] uppercase tracking-wider font-bold">
                        Total Anual {selectedAnio}
                      </td>
                      <td className="px-4 py-3 text-[#0F172A] font-mono">
                        {promedioTrabajadores} <span className="text-[10px] text-[#475569]">(prom)</span>
                      </td>
                      <td className="px-4 py-3 text-[#047857] font-mono font-bold">
                        {totalAnualHHPerpol.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-[#0F172A] font-mono">
                        {promedioTrabajadores} <span className="text-[10px] text-[#475569]">(prom)</span>
                      </td>
                      <td className="px-4 py-3 text-[#0284C7] font-mono font-bold">
                        {totalAnualHHTr3.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-[#0F172A] font-mono font-bold">
                        {promedioTrabajadores} <span className="text-[10px] text-[#475569]">prom.</span>
                      </td>
                      <td className="px-4 py-3 text-[#047857] font-mono font-bold text-sm">
                        {totalAnualHH.toLocaleString()} HH
                      </td>
                      <td className="px-4 py-3 text-right text-[#475569] font-mono text-[10px] font-semibold">
                        {resumenHHList.length} meses
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL DE CONFIRMACIÓN DE ELIMINACIÓN */}
      {deleteModalHH && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setDeleteModalHH(null);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-600">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-[#0F172A] text-base">Eliminar Registro Mensual</h3>
                <p className="text-xs text-[#475569] font-medium">Esta acción retirará las horas del periodo.</p>
              </div>
            </div>

            <p className="text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200 leading-relaxed">
              ¿Está seguro de que desea eliminar el registro de Horas-Hombre del mes de{' '}
              <strong className="text-slate-900 font-bold">
                {MESES[deleteModalHH.mes - 1]} {deleteModalHH.anio}
              </strong>{' '}
              ({deleteModalHH.totalHH.toLocaleString()} HH acumuladas)?
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModalHH(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-colors shadow-sm cursor-pointer"
              >
                Eliminar Registro
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
