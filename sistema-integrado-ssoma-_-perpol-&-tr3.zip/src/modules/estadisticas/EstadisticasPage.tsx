import React, { useState, useMemo, useEffect } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore } from '../../store/appStore';
import {
  MetaIndicadoresSST,
  KPIPeriodoMensual
} from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { ExportUtils } from '../../utils/exportUtils';
import {
  BarChart3,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  FileSpreadsheet,
  FileText,
  Target,
  Activity,
  UserCheck,
  Clock,
  Building2,
  Info,
  X,
  Save,
  Sliders,
  Upload
} from 'lucide-react';

const NOMBRES_MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export const EstadisticasPage: React.FC = () => {
  const {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    inspecciones,
    programaResumen,
    metasIndicadores,
    setMetasIndicadores,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  // Filtros de periodo
  const [selectedAnio, setSelectedAnio] = useState<number>(2026);
  const [selectedMes, setSelectedMes] = useState<number | 'TODOS'>('TODOS');
  const [vistaGrafico, setVistaGrafico] = useState<'IF' | 'IS' | 'IA'>('IF');
  const [selectedTurnoFilter, setSelectedTurnoFilter] = useState<string | null>(null);

  // Horas por jornada base (estándar 8h x 24 días laborables al mes = 192 horas/trabajador)
  const horasPorJornadaMes = 192;

  // Estados de modales
  const [isMetasModalOpen, setIsMetasModalOpen] = useState(false);
  const [isSavingMetas, setIsSavingMetas] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Edición temporal de Metas
  const [metasForm, setMetasForm] = useState<MetaIndicadoresSST>({
    empresa: empresaActiva,
    periodoAnio: selectedAnio,
    metaIF: metasIndicadores.metaIF || 5.0,
    metaIS: metasIndicadores.metaIS || 50.0,
    metaIA: metasIndicadores.metaIA || 0.25,
    metaCumplimientoPrograma: metasIndicadores.metaCumplimientoPrograma || 90,
    metaInspeccionesSubsanadas: metasIndicadores.metaInspeccionesSubsanadas || 85
  });

  // Sincronizar metas con la empresa activa
  useEffect(() => {
    setMetasForm({
      empresa: empresaActiva,
      periodoAnio: selectedAnio,
      metaIF: metasIndicadores.metaIF || 5.0,
      metaIS: metasIndicadores.metaIS || 50.0,
      metaIA: metasIndicadores.metaIA || 0.25,
      metaCumplimientoPrograma: metasIndicadores.metaCumplimientoPrograma || 90,
      metaInspeccionesSubsanadas: metasIndicadores.metaInspeccionesSubsanadas || 85
    });
  }, [empresaActiva, selectedAnio, metasIndicadores]);

  // Cargar metas fijadas desde GAS al montar
  useEffect(() => {
    const fetchMetas = async () => {
      try {
        const res = await GasApiClient.sendRequest<MetaIndicadoresSST[]>({
          action: 'getIndicatorTargets',
          sheetName: 'SSOMA_MetasSST',
          empresa: empresaActiva
        });
        if (res.success && Array.isArray(res.data) && res.data.length > 0) {
          const match = res.data.find(
            (m) =>
              (m.empresa === empresaActiva || empresaActiva === 'CONSOLIDADO') &&
              Number(m.periodoAnio) === selectedAnio
          );
          if (match) {
            setMetasIndicadores(match);
          }
        }
      } catch (e) {
        // En modo local o fallback ya se cuenta con las metas en Zustand
      }
    };
    fetchMetas();
  }, [empresaActiva, selectedAnio, setMetasIndicadores]);

  // =========================================================================
  // 1. CONSOLIDACIÓN AUTOMÁTICA DE SERIES GLOBALES
  // =========================================================================

  // A) Serie de Trabajadores Activos y HHT (Módulo 6: Base de Trabajadores)
  const trabajadoresFiltrados = useMemo(() => {
    return trabajadores.filter((t) => {
      if (empresaActiva !== 'CONSOLIDADO' && t.empresa !== empresaActiva) return false;
      return t.condicion === 'Activo';
    });
  }, [trabajadores, empresaActiva]);

  const totalTrabajadoresActivos = trabajadoresFiltrados.length || 1;

  // B) Serie de Eventos Médicos y Días Perdidos (Módulo 1: Accidentes / Incidentes)
  // Regla estricta: Los días de descanso médico acumulados se atribuyen
  // al mes exacto en que ocurrió el evento (fecha de ocurrencia).
  const accidentesPeriodo = useMemo(() => {
    return accidentes.filter((acc) => {
      if (empresaActiva !== 'CONSOLIDADO' && acc.empresa !== empresaActiva) return false;
      if (!acc.fecha) return false;
      const anioEvento = new Date(acc.fecha).getFullYear();
      return anioEvento === selectedAnio;
    });
  }, [accidentes, empresaActiva, selectedAnio]);

  // C) Serie de Inspecciones SST (Módulo 2: Inspecciones SST)
  const inspeccionesPeriodo = useMemo(() => {
    return inspecciones.filter((insp) => {
      if (empresaActiva !== 'CONSOLIDADO' && insp.empresa !== empresaActiva) return false;
      if (!insp.fecha) return false;
      const anioInsp = new Date(insp.fecha).getFullYear();
      return anioInsp === selectedAnio;
    });
  }, [inspecciones, empresaActiva, selectedAnio]);

  // D) Matriz Mensualizada (1 a 12 meses) con Cálculo Normativo
  const matrizMensual = useMemo<KPIPeriodoMensual[]>(() => {
    return Array.from({ length: 12 }, (_, idx) => {
      const mesNum = idx + 1;
      const nombreMes = NOMBRES_MESES[idx];

      // HHT: trabajadores activos * horas promedio
      const horasHombre = totalTrabajadoresActivos * horasPorJornadaMes;

      // Eventos del mes (por fecha de ocurrencia del evento - 1 accidente = 1 evento SST)
      const eventosMes = accidentesPeriodo.filter((acc) => {
        const d = new Date(acc.fecha);
        return d.getMonth() + 1 === mesNum;
      });

      // Función auxiliar para obtener días de descanso acumulados de un accidente
      const getDiasDescanso = (a: typeof eventosMes[0]) => {
        const atnsVinculadas = atencionesMedicas.filter(
          (m) =>
            (m.idAccidente && (m.idAccidente === a.id || m.idAccidente === a.codigoCaso)) ||
            (m.codigoAccidente && (m.codigoAccidente === a.codigoCaso || m.codigoAccidente === a.id))
        );
        if (atnsVinculadas.length > 0) {
          return atnsVinculadas.reduce((s, m) => s + (Number(m.diasDescanso) || 0), 0);
        }
        return Number(a.diasDescanso) || 0;
      };

      // Accidentes Incapacitantes: 1 accidente = 1 evento SST (clasificado como Incapacitante o con descanso médico > 0)
      const incapacitantes = eventosMes.filter(
        (a) =>
          a.tipoEvento === 'Accidente incapacitante' ||
          (a.tipoEvento !== 'Incidente' && a.tipoEvento !== 'Incidente potencial' && getDiasDescanso(a) > 0)
      ).length;

      // Accidentes Leves: 1 accidente = 1 evento SST (accidentes sin días perdidos)
      const leves = eventosMes.filter(
        (a) =>
          a.tipoEvento === 'Accidente leve' ||
          (a.tipoEvento !== 'Incidente' &&
            a.tipoEvento !== 'Incidente potencial' &&
            a.tipoEvento !== 'Accidente mortal' &&
            getDiasDescanso(a) === 0)
      ).length;

      // Incidentes: sin daño a personas
      const incidentesCount = eventosMes.filter(
        (a) => a.tipoEvento === 'Incidente' || a.tipoEvento === 'Incidente potencial'
      ).length;

      // Días de descanso médico atribuidos a este mes (sumando descansos de las atenciones médicas del evento)
      const diasPerdidos = eventosMes.reduce((sum, a) => sum + getDiasDescanso(a), 0);

      // FÓRMULAS NORMATIVAS SST (D.S. 005-2012-TR / RM 050-2013-TR):
      // IF = (Incapacitantes * 1,000,000) / HHT
      const indiceFrecuencia = horasHombre > 0 ? (incapacitantes * 1000000) / horasHombre : 0;

      // IS = (Días Perdidos * 1,000,000) / HHT
      const indiceSeveridad = horasHombre > 0 ? (diasPerdidos * 1000000) / horasHombre : 0;

      // IA = (IF * IS) / 1,000
      const indiceAccidentabilidad = (indiceFrecuencia * indiceSeveridad) / 1000;

      const metaIF = metasIndicadores.metaIF || 5.0;
      const metaIS = metasIndicadores.metaIS || 50.0;
      const metaIA = metasIndicadores.metaIA || 0.25;

      return {
        mes: mesNum,
        nombreMes,
        horasHombre,
        accidentesIncapacitantes: incapacitantes,
        accidentesLeves: leves,
        incidentes: incidentesCount,
        diasPerdidos,
        indiceFrecuencia: Number(indiceFrecuencia.toFixed(2)),
        indiceSeveridad: Number(indiceSeveridad.toFixed(2)),
        indiceAccidentabilidad: Number(indiceAccidentabilidad.toFixed(4)),
        metaIF,
        metaIS,
        metaIA,
        cumpleFrecuencia: indiceFrecuencia <= metaIF,
        cumpleSeveridad: indiceSeveridad <= metaIS
      };
    });
  }, [
    totalTrabajadoresActivos,
    horasPorJornadaMes,
    accidentesPeriodo,
    atencionesMedicas,
    metasIndicadores
  ]);

  // E) Acumulado Anual / Periodo Seleccionado
  const resumenKPI = useMemo(() => {
    let fuente = matrizMensual;
    if (selectedMes !== 'TODOS') {
      fuente = matrizMensual.filter((m) => m.mes === selectedMes);
    }

    const totalHH = fuente.reduce((acc, m) => acc + m.horasHombre, 0);
    const totalIncap = fuente.reduce((acc, m) => acc + m.accidentesIncapacitantes, 0);
    const totalLeves = fuente.reduce((acc, m) => acc + m.accidentesLeves, 0);
    const totalIncid = fuente.reduce((acc, m) => acc + m.incidentes, 0);
    const totalDias = fuente.reduce((acc, m) => acc + m.diasPerdidos, 0);

    const ifAcumulado = totalHH > 0 ? (totalIncap * 1000000) / totalHH : 0;
    const isAcumulado = totalHH > 0 ? (totalDias * 1000000) / totalHH : 0;
    const iaAcumulado = (ifAcumulado * isAcumulado) / 1000;

    // Cumplimiento del Programa Anual (Módulo 7)
    let cumplimientoPrograma = 92;
    if (programaResumen && programaResumen.anio === selectedAnio) {
      cumplimientoPrograma = programaResumen.avanceAnualPonderado || 92;
    }

    // Inspecciones SST Subsanadas (Módulo 2)
    const totalInsp = inspeccionesPeriodo.length;
    const inspSubsanadas = inspeccionesPeriodo.filter((i) => i.estado === 'Subsanado').length;
    const porcentajeSubsanacion = totalInsp > 0 ? Math.round((inspSubsanadas / totalInsp) * 100) : 100;

    return {
      totalHH,
      totalIncap,
      totalLeves,
      totalIncid,
      totalDias,
      ifAcumulado: Number(ifAcumulado.toFixed(2)),
      isAcumulado: Number(isAcumulado.toFixed(2)),
      iaAcumulado: Number(iaAcumulado.toFixed(4)),
      cumplimientoPrograma,
      totalInsp,
      inspSubsanadas,
      porcentajeSubsanacion
    };
  }, [matrizMensual, selectedMes, programaResumen, selectedAnio, inspeccionesPeriodo]);

  // F) Desgloses Estadísticos
  const desgloseArea = useMemo(() => {
    const mapa: Record<string, number> = {};
    accidentesPeriodo.forEach((a) => {
      const ar = a.area || 'Sin Área';
      mapa[ar] = (mapa[ar] || 0) + 1;
    });
    return Object.entries(mapa).sort((a, b) => b[1] - a[1]);
  }, [accidentesPeriodo]);

  const desgloseTurno = useMemo(() => {
    const mapa: Record<string, number> = { Mañana: 0, Tarde: 0, Noche: 0 };
    accidentesPeriodo.forEach((a) => {
      const t = a.turno || 'Mañana';
      mapa[t] = (mapa[t] || 0) + 1;
    });
    return Object.entries(mapa);
  }, [accidentesPeriodo]);

  // Conteo de Eventos por Supervisor
  const desgloseSupervisor = useMemo(() => {
    const mapa: Record<
      string,
      {
        supervisor: string;
        total: number;
        turnos: Record<string, number>;
        tipos: { incapacitantes: number; leves: number; incidentes: number };
      }
    > = {};

    accidentesPeriodo.forEach((a) => {
      const sup = String(a.responsableArea || '').trim() || 'Sin Supervisor Registrado';
      if (!mapa[sup]) {
        mapa[sup] = {
          supervisor: sup,
          total: 0,
          turnos: {},
          tipos: { incapacitantes: 0, leves: 0, incidentes: 0 }
        };
      }
      mapa[sup].total += 1;
      const t = a.turno || 'Sin Turno';
      mapa[sup].turnos[t] = (mapa[sup].turnos[t] || 0) + 1;

      if (a.tipoEvento === 'Accidente incapacitante' || a.tipoEvento === 'Accidente mortal') {
        mapa[sup].tipos.incapacitantes += 1;
      } else if (a.tipoEvento === 'Accidente leve') {
        mapa[sup].tipos.leves += 1;
      } else {
        mapa[sup].tipos.incidentes += 1;
      }
    });

    return Object.values(mapa).sort((a, b) => b.total - a.total);
  }, [accidentesPeriodo]);

  const desgloseSupervisorFiltrado = useMemo(() => {
    if (!selectedTurnoFilter) return desgloseSupervisor;
    return desgloseSupervisor
      .filter((s) => s.turnos[selectedTurnoFilter] && s.turnos[selectedTurnoFilter] > 0)
      .map((s) => ({
        ...s,
        totalFiltrado: s.turnos[selectedTurnoFilter]
      }))
      .sort((a, b) => b.totalFiltrado - a.totalFiltrado);
  }, [desgloseSupervisor, selectedTurnoFilter]);

  // =========================================================================
  // 2. SEMÁFORO DE METAS Y ALERTAS
  // =========================================================================
  const getSemaforoStatus = (actual: number, meta: number) => {
    if (actual === 0) return { color: 'text-[#047857] bg-emerald-50 border-emerald-200', label: 'Meta Cumplida (0 eventos)', estado: 'optimo' };
    if (actual <= meta * 0.85) return { color: 'text-[#047857] bg-emerald-50 border-emerald-200', label: 'Cumple Meta', estado: 'optimo' };
    if (actual <= meta) return { color: 'text-[#B45309] bg-amber-50 border-amber-200', label: 'En Límite Prudencial', estado: 'alerta' };
    return { color: 'text-[#DC2626] bg-rose-50 border-rose-200', label: 'Excede Meta Límite', estado: 'critico' };
  };

  const statusIF = getSemaforoStatus(resumenKPI.ifAcumulado, metasIndicadores.metaIF);
  const statusIS = getSemaforoStatus(resumenKPI.isAcumulado, metasIndicadores.metaIS);
  const statusIA = getSemaforoStatus(resumenKPI.iaAcumulado, metasIndicadores.metaIA);

  // =========================================================================
  // 3. ACCIONES Y PERSISTENCIA (BACKEND / LOCAL)
  // =========================================================================

  // Guardar Metas Anuales (saveIndicatorTargets)
  const handleSaveMetas = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingMetas(true);
    incrementSync();

    try {
      setMetasIndicadores(metasForm);

      const res = await GasApiClient.sendRequest({
        action: 'saveIndicatorTargets',
        sheetName: 'SSOMA_MetasSST',
        empresa: empresaActiva,
        data: metasForm
      });

      if (res.success) {
        addToast({
          type: 'success',
          title: 'Metas Actualizadas',
          message: `Metas de indicadores fijadas para el periodo ${selectedAnio}.`
        });
      } else {
        addToast({
          type: 'warning',
          title: 'Aviso de Sincronización',
          message: res.error || res.message || 'No se pudieron guardar las metas en Google Sheets. Verifique la conexión.'
        });
      }
      setIsMetasModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar metas';
      addToast({ type: 'error', title: 'Error', message: msg });
    } finally {
      setIsSavingMetas(false);
      decrementSync();
    }
  };

  // Exportar Matriz a Excel
  const handleExportarExcel = () => {
    const dataExcel = matrizMensual.map((m) => ({
      Año: selectedAnio,
      Mes: m.nombreMes,
      Empresa: empresaActiva,
      'Trabajadores Activos': totalTrabajadoresActivos,
      'Horas Hombre Trabajadas (HHT)': m.horasHombre,
      'Accidentes Incapacitantes': m.accidentesIncapacitantes,
      'Accidentes Leves': m.accidentesLeves,
      'Incidentes Peligrosos / Potenciales': m.incidentes,
      'Días Perdidos (Cargados)': m.diasPerdidos,
      'Índice de Frecuencia (IF)': m.indiceFrecuencia,
      'Meta IF': m.metaIF,
      '¿Cumple IF?': m.cumpleFrecuencia ? 'SÍ' : 'NO',
      'Índice de Severidad (IS)': m.indiceSeveridad,
      'Meta IS': m.metaIS,
      '¿Cumple IS?': m.cumpleSeveridad ? 'SÍ' : 'NO',
      'Índice de Accidentabilidad (IA)': m.indiceAccidentabilidad,
      'Meta IA': m.metaIA
    }));

    ExportUtils.exportToExcel(
      dataExcel,
      `SSOMA_Matriz_Estadisticas_${empresaActiva}_${selectedAnio}`,
      `Estadisticas_${selectedAnio}`
    );

    addToast({
      type: 'success',
      title: 'Exportación Exitosa',
      message: `Matriz mensualizada de estadísticas ${selectedAnio} descargada en Excel.`
    });
  };

  // Exportar Reporte Ejecutivo en PDF
  const handleExportarPDF = () => {
    const headers = [
      'Mes',
      'HHT',
      'Incap.',
      'Leves',
      'Incid.',
      'Días Perd.',
      'IF',
      'IS',
      'IA',
      'Estado'
    ];

    const rows = matrizMensual.map((m) => [
      m.nombreMes,
      m.horasHombre.toLocaleString(),
      m.accidentesIncapacitantes,
      m.accidentesLeves,
      m.incidentes,
      m.diasPerdidos,
      m.indiceFrecuencia.toFixed(2),
      m.indiceSeveridad.toFixed(2),
      m.indiceAccidentabilidad.toFixed(4),
      m.cumpleFrecuencia && m.cumpleSeveridad ? 'Cumple' : 'Alerta'
    ]);

    // Fila totalizadora
    rows.push([
      'TOTAL ACUMULADO',
      resumenKPI.totalHH.toLocaleString(),
      resumenKPI.totalIncap,
      resumenKPI.totalLeves,
      resumenKPI.totalIncid,
      resumenKPI.totalDias,
      resumenKPI.ifAcumulado.toFixed(2),
      resumenKPI.isAcumulado.toFixed(2),
      resumenKPI.iaAcumulado.toFixed(4),
      statusIF.estado === 'optimo' && statusIS.estado === 'optimo' ? 'CUMPLE' : 'ALERTA'
    ]);

    ExportUtils.exportToPdf({
      title: `CUADRO DE MANDO GERENCIAL SST - AÑO ${selectedAnio}`,
      subtitle: `Empresa: ${empresaActiva} | HHT Totales: ${resumenKPI.totalHH.toLocaleString()} | Colaboradores: ${totalTrabajadoresActivos}`,
      empresa: empresaActiva,
      fileName: `Reporte_Estadisticas_SST_${empresaActiva}_${selectedAnio}`,
      headers,
      rows,
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'Reporte PDF',
      message: 'Cuadro de mando gerencial generado en formato PDF.'
    });
  };

  // =========================================================================
  // RENDERIZADO VISUAL
  // =========================================================================
  return (
    <div className="space-y-6">
      {/* Encabezado Principal */}
      <ModuleHeader
        codigo={9}
        titulo="Estadísticas e Índices de Seguridad y Salud (SST)"
        subtitulo="Consolidación gerencial automática: HHT, accidentes, severidad normativa D.S. 005-2012-TR y semáforo de metas"
        icono={<BarChart3 className="w-5 h-5 text-emerald-400" />}
      >
        <div className="flex flex-wrap items-center gap-2">
          {/* Selector de Año */}
          <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-[#CBD5E1] text-xs shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-[#475569]" />
            <span className="text-[#475569] font-medium">Año:</span>
            <select
              value={selectedAnio}
              onChange={(e) => setSelectedAnio(Number(e.target.value))}
              aria-label="Seleccionar Año para Estadísticas"
              className="bg-transparent text-[#0F172A] font-bold focus:outline-hidden cursor-pointer"
            >
              <option value={2026}>2026</option>
              <option value={2025}>2025</option>
              <option value={2024}>2024</option>
            </select>
          </div>

          {/* Selector de Mes */}
          <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-[#CBD5E1] text-xs shadow-2xs">
            <span className="text-[#475569] font-medium">Periodo:</span>
            <select
              value={selectedMes}
              onChange={(e) =>
                setSelectedMes(e.target.value === 'TODOS' ? 'TODOS' : Number(e.target.value))
              }
              aria-label="Seleccionar Mes o Periodo para Estadísticas"
              className="bg-transparent text-[#0F172A] font-bold focus:outline-hidden cursor-pointer"
            >
              <option value="TODOS">Acumulado Anual</option>
              {NOMBRES_MESES.map((m, i) => (
                <option key={i + 1} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Botón Configurar Metas */}
          <button
            type="button"
            onClick={() => setIsMetasModalOpen(true)}
            title="Fijar metas anuales de IF, IS, IA y cumplimiento"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] rounded-lg text-xs font-semibold text-[#1E293B] transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          >
            <Sliders className="w-3.5 h-3.5 text-[#D97706]" />
            <span>Fijar Metas</span>
          </button>

          {/* Botón Importar Metas Masivas */}
          <button
            type="button"
            onClick={() => setIsImportModalOpen(true)}
            title="Carga masiva de metas desde archivo"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] rounded-lg text-xs font-semibold text-[#1E293B] transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          >
            <Upload className="w-3.5 h-3.5 text-[#047857]" />
            <span>Importar</span>
          </button>

          {/* Botón Exportar Excel */}
          <button
            type="button"
            onClick={handleExportarExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#047857] hover:bg-[#065F46] text-white rounded-lg text-xs font-bold transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Excel</span>
          </button>

          {/* Botón Exportar PDF */}
          <button
            type="button"
            onClick={handleExportarPDF}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] rounded-lg text-xs font-bold transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          >
            <FileText className="w-3.5 h-3.5 text-[#DC2626]" />
            <span>PDF</span>
          </button>
        </div>
      </ModuleHeader>

      {/* Tarjetas Semáforo de Indicadores Normativos Principales */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* IF: Índice de Frecuencia */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 relative overflow-hidden flex flex-col justify-between shadow-2xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#475569]">
                Índice de Frecuencia (IF)
              </span>
              <div className="text-3xl font-black text-[#0F172A] mt-1">
                {resumenKPI.ifAcumulado}
              </div>
            </div>
            <div
              className={`px-2 py-1 rounded-md text-[10px] font-bold border flex items-center gap-1 ${statusIF.color}`}
            >
              {statusIF.estado === 'optimo' ? (
                <CheckCircle2 className="w-3 h-3" />
              ) : (
                <AlertTriangle className="w-3 h-3" />
              )}
              {statusIF.label}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#E2E8F0] space-y-1.5 text-xs">
            <div className="flex justify-between text-[#475569]">
              <span>Meta Fijada:</span>
              <span className="font-semibold text-[#0F172A]">≤ {metasIndicadores.metaIF}</span>
            </div>
            <div className="flex justify-between text-[#475569]">
              <span>Accidentes Incap.:</span>
              <span className="font-bold text-[#B45309]">{resumenKPI.totalIncap}</span>
            </div>
            <div className="text-[10px] text-[#475569] font-mono">
              Fórmula: (N° Incap. × 10⁶) / HHT
            </div>
          </div>
        </div>

        {/* IS: Índice de Severidad */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 relative overflow-hidden flex flex-col justify-between shadow-2xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#475569]">
                Índice de Severidad (IS)
              </span>
              <div className="text-3xl font-black text-[#0F172A] mt-1">
                {resumenKPI.isAcumulado}
              </div>
            </div>
            <div
              className={`px-2 py-1 rounded-md text-[10px] font-bold border flex items-center gap-1 ${statusIS.color}`}
            >
              {statusIS.estado === 'optimo' ? (
                <CheckCircle2 className="w-3 h-3" />
              ) : (
                <AlertTriangle className="w-3 h-3" />
              )}
              {statusIS.label}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#E2E8F0] space-y-1.5 text-xs">
            <div className="flex justify-between text-[#475569]">
              <span>Meta Fijada:</span>
              <span className="font-semibold text-[#0F172A]">≤ {metasIndicadores.metaIS}</span>
            </div>
            <div className="flex justify-between text-[#475569]">
              <span>Días Perdidos Acum.:</span>
              <span className="font-bold text-[#DC2626]">{resumenKPI.totalDias}</span>
            </div>
            <div className="text-[10px] text-[#475569] font-mono">
              Fórmula: (Días Perd. × 10⁶) / HHT
            </div>
          </div>
        </div>

        {/* IA: Índice de Accidentabilidad */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 relative overflow-hidden flex flex-col justify-between shadow-2xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#475569]">
                Accidentabilidad (IA)
              </span>
              <div className="text-3xl font-black text-[#0F172A] mt-1">
                {resumenKPI.iaAcumulado}
              </div>
            </div>
            <div
              className={`px-2 py-1 rounded-md text-[10px] font-bold border flex items-center gap-1 ${statusIA.color}`}
            >
              {statusIA.estado === 'optimo' ? (
                <CheckCircle2 className="w-3 h-3" />
              ) : (
                <AlertTriangle className="w-3 h-3" />
              )}
              {statusIA.label}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#E2E8F0] space-y-1.5 text-xs">
            <div className="flex justify-between text-[#475569]">
              <span>Meta Fijada:</span>
              <span className="font-semibold text-[#0F172A]">≤ {metasIndicadores.metaIA}</span>
            </div>
            <div className="flex justify-between text-[#475569]">
              <span>HHT Acumuladas:</span>
              <span className="font-semibold text-[#047857]">
                {resumenKPI.totalHH.toLocaleString()}
              </span>
            </div>
            <div className="text-[10px] text-[#475569] font-mono">
              Fórmula: (IF × IS) / 1,000
            </div>
          </div>
        </div>

        {/* Cumplimiento de Programa & Subsanación */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 relative overflow-hidden flex flex-col justify-between shadow-2xs">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#475569]">
                Programa Anual (M7)
              </span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded border ${
                  resumenKPI.cumplimientoPrograma >= metasIndicadores.metaCumplimientoPrograma
                    ? 'text-[#047857] bg-emerald-50 border-emerald-200'
                    : 'text-[#B45309] bg-amber-50 border-amber-200'
                }`}
              >
                {resumenKPI.cumplimientoPrograma}%
              </span>
            </div>

            {/* Barra de progreso de cumplimiento */}
            <div className="w-full bg-[#F1F5F9] border border-[#E2E8F0] h-2 rounded-full overflow-hidden mt-2">
              <div
                className="bg-[#047857] h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, resumenKPI.cumplimientoPrograma)}%` }}
              />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#E2E8F0] space-y-1.5 text-xs">
            <div className="flex justify-between text-[#475569]">
              <span>Inspecciones Cerradas:</span>
              <span className="font-bold text-[#0F172A]">
                {resumenKPI.inspSubsanadas} / {resumenKPI.totalInsp} ({resumenKPI.porcentajeSubsanacion}%)
              </span>
            </div>
            <div className="flex justify-between text-[#475569]">
              <span>Meta Subsanación:</span>
              <span className="font-semibold text-[#0F172A]">
                ≥ {metasIndicadores.metaInspeccionesSubsanadas}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Selector de Gráficos y Panel de Visualización */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 space-y-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-[#0F172A] flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#047857]" />
              <span>Evolución Mensualizada de Índices SST ({selectedAnio})</span>
            </h3>
            <p className="text-xs text-[#475569] mt-0.5">
              Comparativa de desempeño respecto a las metas normativas fijadas
            </p>
          </div>

          {/* Botones de Selección de Vista de Gráfico */}
          <div className="flex items-center gap-1 bg-[#F1F5F9] p-1 rounded-lg border border-[#E2E8F0] self-start sm:self-auto shadow-2xs">
            <button
              type="button"
              onClick={() => setVistaGrafico('IF')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                vistaGrafico === 'IF'
                  ? 'bg-[#1E293B] !text-white shadow-2xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-white'
              }`}
              style={vistaGrafico === 'IF' ? { color: '#ffffff' } : undefined}
            >
              <span className={vistaGrafico === 'IF' ? '!text-white' : ''} style={vistaGrafico === 'IF' ? { color: '#ffffff' } : undefined}>
                Frecuencia (IF)
              </span>
            </button>
            <button
              type="button"
              onClick={() => setVistaGrafico('IS')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                vistaGrafico === 'IS'
                  ? 'bg-[#1E293B] !text-white shadow-2xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-white'
              }`}
              style={vistaGrafico === 'IS' ? { color: '#ffffff' } : undefined}
            >
              <span className={vistaGrafico === 'IS' ? '!text-white' : ''} style={vistaGrafico === 'IS' ? { color: '#ffffff' } : undefined}>
                Severidad (IS)
              </span>
            </button>
            <button
              type="button"
              onClick={() => setVistaGrafico('IA')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden ${
                vistaGrafico === 'IA'
                  ? 'bg-[#1E293B] !text-white shadow-2xs active'
                  : 'text-[#475569] hover:text-[#0F172A] hover:bg-white'
              }`}
              style={vistaGrafico === 'IA' ? { color: '#ffffff' } : undefined}
            >
              <span className={vistaGrafico === 'IA' ? '!text-white' : ''} style={vistaGrafico === 'IA' ? { color: '#ffffff' } : undefined}>
                Accidentab. (IA)
              </span>
            </button>
          </div>
        </div>

        {/* Gráfico Interactivo SVG */}
        <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-4">
          <div className="h-64 w-full flex items-end gap-2 pt-6 pb-2 px-2 relative">
            {/* Línea de meta de referencia */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-amber-400 z-10 flex items-center justify-end px-3 text-[10px] text-[#B45309] font-bold"
              style={{
                bottom: `${Math.min(
                  90,
                  Math.max(
                    15,
                    vistaGrafico === 'IF'
                      ? (metasIndicadores.metaIF / Math.max(15, ...matrizMensual.map((m) => m.indiceFrecuencia))) * 180
                      : vistaGrafico === 'IS'
                      ? (metasIndicadores.metaIS / Math.max(100, ...matrizMensual.map((m) => m.indiceSeveridad))) * 180
                      : (metasIndicadores.metaIA / Math.max(1, ...matrizMensual.map((m) => m.indiceAccidentabilidad))) * 180
                  )
                )}px`
              }}
            >
              <span>
                Meta {vistaGrafico}:{' '}
                {vistaGrafico === 'IF'
                  ? metasIndicadores.metaIF
                  : vistaGrafico === 'IS'
                  ? metasIndicadores.metaIS
                  : metasIndicadores.metaIA}
              </span>
            </div>

            {/* Barras de los 12 Meses */}
            {matrizMensual.map((m) => {
              let val = 0;
              let maxVal = 1;
              let barColor = 'bg-[#047857]';

              if (vistaGrafico === 'IF') {
                val = m.indiceFrecuencia;
                maxVal = Math.max(15, metasIndicadores.metaIF * 1.5, ...matrizMensual.map((x) => x.indiceFrecuencia));
                barColor = val > m.metaIF ? 'bg-[#DC2626]' : 'bg-[#047857]';
              } else if (vistaGrafico === 'IS') {
                val = m.indiceSeveridad;
                maxVal = Math.max(100, metasIndicadores.metaIS * 1.5, ...matrizMensual.map((x) => x.indiceSeveridad));
                barColor = val > m.metaIS ? 'bg-[#DC2626]' : 'bg-[#0284C7]';
              } else {
                // vistaGrafico === 'IA'
                val = m.indiceAccidentabilidad;
                maxVal = Math.max(1, metasIndicadores.metaIA * 1.5, ...matrizMensual.map((x) => x.indiceAccidentabilidad));
                barColor = val > m.metaIA ? 'bg-[#DC2626]' : 'bg-[#1E293B]';
              }

              const heightPercent = maxVal > 0 ? Math.min(100, (val / maxVal) * 100) : 0;

              return (
                <div
                  key={m.mes}
                  className="flex-1 flex flex-col items-center justify-end h-full group relative"
                >
                  {/* Tooltip flotante con detalles al pasar el cursor */}
                  <div className="absolute bottom-full mb-2 hidden group-hover:flex flex-col items-center z-30 pointer-events-none">
                    <div className="bg-[#1E293B] text-white border border-[#0F172A] px-2.5 py-1.5 rounded-lg shadow-xl text-[11px] whitespace-nowrap">
                      <div className="font-bold text-white">
                        {m.nombreMes} {selectedAnio}
                      </div>
                      <div className="text-emerald-400 font-semibold mt-0.5">
                        {vistaGrafico}: {vistaGrafico === 'IA' ? val.toFixed(3) : val.toFixed(1)}
                      </div>
                      <div className="text-slate-300 text-[10px]">
                        HHT: {m.horasHombre.toLocaleString()} h
                      </div>
                      <div className="text-amber-300 text-[10px]">
                        Incap: {m.accidentesIncapacitantes} | Días: {m.diasPerdidos}
                      </div>
                    </div>
                    <div className="w-2 h-2 bg-[#1E293B] rotate-45 -mt-1 border-r border-b border-[#0F172A]" />
                  </div>

                  {/* Valor en la cima de la barra */}
                  <span className="text-[10px] text-[#475569] font-mono mb-1 group-hover:text-[#0F172A] transition-colors font-semibold">
                    {val > 0 ? (vistaGrafico === 'IA' ? val.toFixed(3) : val.toFixed(1)) : '-'}
                  </span>

                  {/* Barra SVG/CSS */}
                  <div className="w-full max-w-[32px] bg-[#E2E8F0] rounded-t-md h-full flex items-end overflow-hidden p-0.5">
                    <div
                      className={`w-full rounded-t-sm transition-all duration-500 ${barColor}`}
                      style={{ height: `${Math.max(4, heightPercent)}%` }}
                    />
                  </div>

                  {/* Nombre abreviado del Mes */}
                  <span className="text-[10px] text-[#475569] font-medium mt-2">
                    {m.nombreMes.slice(0, 3)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Distribuciones Secundarias: Por Área y Por Turno */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Distribución por Área */}
          <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#0F172A] flex items-center gap-1.5 mb-3">
              <Building2 className="w-3.5 h-3.5 text-[#0284C7]" />
              <span>Eventos por Área Operativa ({selectedAnio})</span>
            </h4>
            {desgloseArea.length === 0 ? (
              <div className="py-6 text-center text-xs text-[#475569]">
                No hay accidentes registrados en el periodo seleccionado.
              </div>
            ) : (
              <div className="space-y-2">
                {desgloseArea.slice(0, 6).map(([area, cant]) => (
                  <div key={area} className="space-y-1">
                    <div className="flex justify-between text-xs text-[#0F172A]">
                      <span className="truncate">{area}</span>
                      <span className="font-semibold text-[#475569]">
                        {cant} ({Math.round((cant / accidentesPeriodo.length) * 100)}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-[#0284C7] h-full rounded-full"
                        style={{ width: `${(cant / accidentesPeriodo.length) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Distribución por Turno de Trabajo y Conteo por Supervisor */}
          <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#0F172A] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#B45309]" />
                  <span>Incidencia por Turno Laboral</span>
                </h4>
                <span className="text-[11px] text-[#475569] font-medium">
                  {accidentesPeriodo.length} {accidentesPeriodo.length === 1 ? 'evento' : 'eventos'}
                </span>
              </div>

              {/* Botones / Tarjetas de Turnos */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {desgloseTurno.map(([turno, cant]) => {
                  const isSelected = selectedTurnoFilter === turno;
                  return (
                    <button
                      key={turno}
                      type="button"
                      onClick={() => setSelectedTurnoFilter((prev) => (prev === turno ? null : turno))}
                      className={`rounded-lg p-2.5 text-left transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-[#1E293B] border-[#1E293B] text-white shadow-xs active'
                          : 'bg-white border-[#E2E8F0] hover:border-[#CBD5E1] hover:bg-slate-50 text-[#0F172A]'
                      }`}
                      title={isSelected ? 'Clic para quitar filtro' : `Filtrar conteo por ${turno}`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[11px] font-bold ${isSelected ? 'text-white' : 'text-[#0F172A]'}`}>
                          {turno}
                        </span>
                        {isSelected && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/20 text-white font-bold">
                            Activo
                          </span>
                        )}
                      </div>
                      <div className={`text-xl font-bold mt-0.5 ${isSelected ? 'text-white' : 'text-[#0F172A]'}`}>
                        {cant}
                      </div>
                      <div className={`text-[10px] font-medium mt-0.5 ${isSelected ? 'text-white/80' : 'text-[#475569]'}`}>
                        {accidentesPeriodo.length > 0
                          ? `${Math.round((cant / accidentesPeriodo.length) * 100)}% del total`
                          : '0%'}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Conteo de Eventos por Supervisor */}
              <div className="pt-3 border-t border-[#E2E8F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#0F172A]">
                    <UserCheck className="w-3.5 h-3.5 text-[#047857]" />
                    <span>Conteo de Eventos por Supervisor</span>
                    {selectedTurnoFilter && (
                      <span className="text-[10px] font-semibold text-[#B45309] bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        Turno {selectedTurnoFilter}
                      </span>
                    )}
                  </div>
                  {selectedTurnoFilter && (
                    <button
                      type="button"
                      onClick={() => setSelectedTurnoFilter(null)}
                      className="text-[10px] text-[#475569] hover:text-[#0F172A] underline transition-colors"
                    >
                      Mostrar todos
                    </button>
                  )}
                </div>

                {desgloseSupervisorFiltrado.length === 0 ? (
                  <div className="py-4 text-center text-xs text-[#475569] bg-white rounded-lg border border-[#E2E8F0]">
                    {selectedTurnoFilter
                      ? `No hay eventos registrados en el turno ${selectedTurnoFilter}.`
                      : 'No hay eventos asociados a supervisores en este periodo.'}
                  </div>
                ) : (
                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {desgloseSupervisorFiltrado.map((item) => {
                      const cantidad = 'totalFiltrado' in item ? (item as any).totalFiltrado : item.total;
                      const baseTotal = selectedTurnoFilter
                        ? (desgloseTurno.find(([t]) => t === selectedTurnoFilter)?.[1] || 1)
                        : accidentesPeriodo.length;
                      const porcentaje = baseTotal > 0 ? Math.round((cantidad / baseTotal) * 100) : 0;

                      return (
                        <div
                          key={item.supervisor}
                          className="bg-white border border-[#E2E8F0] rounded-lg p-2.5 space-y-1.5 hover:border-[#CBD5E1] transition-colors shadow-2xs"
                        >
                          <div className="flex items-start justify-between gap-2 text-xs">
                            <div className="font-semibold text-[#0F172A] truncate flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#B45309] shrink-0" />
                              <span className="truncate" title={item.supervisor}>
                                {item.supervisor}
                              </span>
                            </div>
                            <span className="font-mono font-bold text-[#B45309] text-xs shrink-0 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              {cantidad} {cantidad === 1 ? 'evento' : 'eventos'} ({porcentaje}%)
                            </span>
                          </div>

                          {/* Barra de proporción */}
                          <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full overflow-hidden">
                            <div
                              className="bg-[#047857] h-full rounded-full transition-all duration-300"
                              style={{ width: `${Math.min(100, Math.max(5, porcentaje))}%` }}
                            />
                          </div>

                          {/* Detalle de turnos y tipo de severidad */}
                          <div className="flex items-center justify-between text-[10px] text-[#475569] pt-0.5">
                            <div className="flex items-center gap-1 flex-wrap">
                              {Object.entries(item.turnos).map(([t, c]) => (
                                <span
                                  key={t}
                                  className={`px-1.5 py-0.5 rounded font-mono text-[9px] ${
                                    selectedTurnoFilter === t
                                      ? 'bg-[#1E293B] text-white border border-[#1E293B]'
                                      : 'bg-[#F1F5F9] text-[#475569] border border-[#E2E8F0]'
                                  }`}
                                >
                                  {t}: {c}
                                </span>
                              ))}
                            </div>
                            <div className="flex items-center gap-1 shrink-0 font-medium">
                              {item.tipos.incapacitantes > 0 && (
                                <span className="text-[#DC2626] bg-red-50 border border-red-200 px-1 py-0.5 rounded">
                                  {item.tipos.incapacitantes} Incap.
                                </span>
                              )}
                              {item.tipos.leves > 0 && (
                                <span className="text-[#B45309] bg-amber-50 border border-amber-200 px-1 py-0.5 rounded">
                                  {item.tipos.leves} Leve
                                </span>
                              )}
                              {item.tipos.incidentes > 0 && (
                                <span className="text-[#475569] bg-[#F1F5F9] border border-[#CBD5E1] px-1 py-0.5 rounded">
                                  {item.tipos.incidentes} Incid.
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Matriz Mensualizada Detallada (Ene - Dic) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#E2E8F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
          <div>
            <h3 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#047857]" />
              <span>Matriz Mensualizada de Estadísticas SST — {selectedAnio}</span>
            </h3>
            <p className="text-xs text-[#475569]">
              Datos auditables consolidados de HHT, accidentes, descansos médicos y cálculo normativo
            </p>
          </div>

          <button
            onClick={handleExportarExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[#047857] rounded-lg text-xs font-semibold transition-colors self-start sm:self-auto shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Descargar Matriz Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] text-left text-xs text-[#0F172A]">
            <thead className="bg-[#F8FAFC] text-[#475569] border-b border-[#E2E8F0] uppercase tracking-wider font-semibold text-[10px]">
              <tr>
                <th className="px-4 py-3 w-28 whitespace-nowrap">Mes</th>
                <th className="px-4 py-3 w-28 text-right whitespace-nowrap">HHT</th>
                <th className="px-4 py-3 w-20 text-center whitespace-nowrap">Incap.</th>
                <th className="px-4 py-3 w-20 text-center whitespace-nowrap">Leves</th>
                <th className="px-4 py-3 w-20 text-center whitespace-nowrap">Incid.</th>
                <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Días Perd.</th>
                <th className="px-4 py-3 w-28 text-right whitespace-nowrap">Índice IF</th>
                <th className="px-4 py-3 w-28 text-right whitespace-nowrap">Índice IS</th>
                <th className="px-4 py-3 w-28 text-right whitespace-nowrap">Índice IA</th>
                <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Semáforo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1F5F9] font-mono">
              {matrizMensual.map((m) => {
                const cumple = m.cumpleFrecuencia && m.cumpleSeveridad;
                return (
                  <tr key={m.mes} className="hover:bg-[#F8FAFC] transition-colors font-sans">
                    <td className="px-4 py-2.5 font-semibold text-[#0F172A]">
                      {m.nombreMes}
                    </td>
                    <td className="px-4 py-2.5 text-right text-[#0F172A] font-mono">
                      {m.horasHombre.toLocaleString()}
                    </td>
                    <td className="px-4 py-2.5 text-center font-mono">
                      {m.accidentesIncapacitantes > 0 ? (
                        <span className="px-2 py-0.5 rounded-full bg-rose-50 text-[#DC2626] border border-rose-200 font-bold">
                          {m.accidentesIncapacitantes}
                        </span>
                      ) : (
                        <span className="text-[#475569]">0</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-center text-[#475569] font-mono">
                      {m.accidentesLeves}
                    </td>
                    <td className="px-4 py-2.5 text-center text-[#475569] font-mono">
                      {m.incidentes}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono">
                      {m.diasPerdidos > 0 ? (
                        <span className="font-bold text-[#DC2626]">{m.diasPerdidos}</span>
                      ) : (
                        <span className="text-[#475569]">0</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono font-semibold">
                      <span className={m.indiceFrecuencia > m.metaIF ? 'text-[#DC2626]' : 'text-[#0F172A]'}>
                        {m.indiceFrecuencia.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono font-semibold">
                      <span className={m.indiceSeveridad > m.metaIS ? 'text-[#DC2626]' : 'text-[#0F172A]'}>
                        {m.indiceSeveridad.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-[#0F172A]">
                      {m.indiceAccidentabilidad.toFixed(4)}
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          cumple
                            ? 'bg-emerald-50 text-[#047857] border border-emerald-200'
                            : 'bg-rose-50 text-[#DC2626] border border-rose-200'
                        }`}
                      >
                        {cumple ? (
                          <>
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            Cumple
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-2.5 h-2.5" />
                            Alerta
                          </>
                        )}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {/* Pie de Tabla con Totales Acumulados */}
            <tfoot className="bg-[#F8FAFC] font-semibold border-t-2 border-[#CBD5E1] text-xs text-[#0F172A]">
              <tr>
                <td className="py-3 px-3 uppercase tracking-wider font-bold text-[#0F172A]">TOTAL ACUMULADO</td>
                <td className="py-3 px-3 text-right font-mono font-bold text-[#047857]">
                  {resumenKPI.totalHH.toLocaleString()}
                </td>
                <td className="py-3 px-3 text-center font-mono font-bold text-[#B45309]">
                  {resumenKPI.totalIncap}
                </td>
                <td className="py-3 px-3 text-center font-mono text-[#0F172A] font-semibold">
                  {resumenKPI.totalLeves}
                </td>
                <td className="py-3 px-3 text-center font-mono text-[#0F172A] font-semibold">
                  {resumenKPI.totalIncid}
                </td>
                <td className="py-3 px-3 text-right font-mono font-bold text-[#DC2626]">
                  {resumenKPI.totalDias}
                </td>
                <td className="py-3 px-3 text-right font-mono font-extrabold text-[#0F172A]">
                  {resumenKPI.ifAcumulado.toFixed(2)}
                </td>
                <td className="py-3 px-3 text-right font-mono font-extrabold text-[#0F172A]">
                  {resumenKPI.isAcumulado.toFixed(2)}
                </td>
                <td className="py-3 px-3 text-right font-mono font-extrabold text-[#0F172A]">
                  {resumenKPI.iaAcumulado.toFixed(4)}
                </td>
                <td className="py-3 px-3 text-center">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                      statusIF.estado === 'optimo' && statusIS.estado === 'optimo'
                        ? 'bg-emerald-50 text-[#047857] border-emerald-200'
                        : 'bg-rose-50 text-[#DC2626] border-rose-200'
                    }`}
                  >
                    {statusIF.estado === 'optimo' && statusIS.estado === 'optimo'
                      ? 'CONFORME'
                      : 'OBSERVADO'}
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL PARA FIJAR METAS ANUALES DE INDICADORES (saveIndicatorTargets)     */}
      {/* ========================================================================= */}
      {isMetasModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsMetasModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-[#E2E8F0] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl text-[#0F172A] cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-5 border-b border-[#E2E8F0] flex items-center justify-between bg-[#F8FAFC]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-[#D97706]">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0F172A]">
                    Fijar Metas Anuales de Indicadores SST
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">
                    Parámetros de evaluación del Comité de Seguridad y Salud en el Trabajo
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsMetasModalOpen(false)}
                className="text-[#475569] hover:text-[#0F172A] p-1.5 rounded-lg hover:bg-[#F1F5F9] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMetas} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-[#0F172A] font-semibold mb-1">Empresa</label>
                  <input
                    type="text"
                    disabled
                    value={empresaActiva}
                    className="w-full bg-[#F1F5F9] border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[#0F172A] font-semibold mb-1">Año de Gestión</label>
                  <input
                    type="number"
                    value={metasForm.periodoAnio}
                    onChange={(e) =>
                      setMetasForm({ ...metasForm, periodoAnio: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-[#E2E8F0] text-xs">
                <div>
                  <div className="flex justify-between mb-1">
                    <label className="text-[#0F172A] font-semibold">
                      Meta Máxima Índice de Frecuencia (IF)
                    </label>
                    <span className="text-[#475569] font-mono text-[11px]">(Límite permisible)</span>
                  </div>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required
                    value={metasForm.metaIF}
                    onChange={(e) =>
                      setMetasForm({ ...metasForm, metaIF: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <label className="text-[#0F172A] font-semibold">
                      Meta Máxima Índice de Severidad (IS)
                    </label>
                    <span className="text-[#475569] font-mono text-[11px]">(Límite de días perdidos)</span>
                  </div>
                  <input
                    type="number"
                    step="1"
                    min="0"
                    required
                    value={metasForm.metaIS}
                    onChange={(e) =>
                      setMetasForm({ ...metasForm, metaIS: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <label className="text-[#0F172A] font-semibold">
                      Meta Máxima Accidentabilidad (IA)
                    </label>
                    <span className="text-[#475569] font-mono text-[11px]">(IF × IS / 1000)</span>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={metasForm.metaIA}
                    onChange={(e) =>
                      setMetasForm({ ...metasForm, metaIA: Number(e.target.value) })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#0F172A] font-semibold mb-1">
                      Meta Prog. Anual (%)
                    </label>
                    <input
                      type="number"
                      min="50"
                      max="100"
                      value={metasForm.metaCumplimientoPrograma}
                      onChange={(e) =>
                        setMetasForm({
                          ...metasForm,
                          metaCumplimientoPrograma: Number(e.target.value)
                        })
                      }
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#0F172A] font-semibold mb-1">
                      Meta Subsanación (%)
                    </label>
                    <input
                      type="number"
                      min="50"
                      max="100"
                      value={metasForm.metaInspeccionesSubsanadas}
                      onChange={(e) =>
                        setMetasForm({
                          ...metasForm,
                          metaInspeccionesSubsanadas: Number(e.target.value)
                        })
                      }
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-[#B45309] flex items-start gap-2 leading-relaxed">
                <Info className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
                <p>
                  Las metas quedan registradas en la hoja <strong>SSOMA_MetasSST</strong> de Google Sheets y gobiernan el semáforo automático mensual para el CSST.
                </p>
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-[#E2E8F0]">
                <button
                  type="button"
                  onClick={() => setIsMetasModalOpen(false)}
                  className="px-4 py-2 bg-white hover:bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] rounded-lg text-xs font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSavingMetas}
                  className="flex items-center gap-1.5 px-4 py-2 bg-[#047857] hover:bg-[#065F46] text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isSavingMetas ? 'Guardando...' : 'Confirmar Metas'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.estadisticas}
        onImportSuccess={(rows) => {
          if (rows.length > 0) {
            const first = rows[0] as any;
            setMetasIndicadores({
              empresa: first.empresa || empresaActiva,
              periodoAnio: Number(first.periodoAnio) || selectedAnio,
              metaIF: Number(first.metaIF) || 5.0,
              metaIS: Number(first.metaIS) || 50.0,
              metaIA: Number(first.metaIA) || 0.25,
              metaCumplimientoPrograma: Number(first.metaCumplimientoPrograma) || 90,
              metaInspeccionesSubsanadas: Number(first.metaInspeccionesSubsanadas) || 85
            });
          }
        }}
      />
    </div>
  );
};
