import React, { useState, useMemo } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore, sanitizeInspeccion } from '../../store/appStore';
import { InspeccionRecord } from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { DriveStorageService } from '../../services/driveService';
import { ExportUtils } from '../../utils/exportUtils';
import { ModuleToolbar, FilterChipOption } from '../../components/common/ModuleToolbar';
import { TablePagination } from '../../components/common/TablePagination';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import { StatusBadge } from '../../components/common/StatusBadge';
import { ImageLightboxModal } from '../../components/common/ImageLightboxModal';
import { DriveImage } from '../../components/common/DriveImage';
import {
  AREAS_EMPRESA,
  LUGARES_ESPECIFICOS,
  pgToPrioridad,
  pgToDiasPlazo,
  getDelayInfo
} from '../../utils/ssomaCatalogs';
import {
  ClipboardCheck,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Eye,
  Camera,
  Upload,
  Edit2,
  Trash2,
  X,
  Save,
  CheckSquare,
  Layers,
  AlertOctagon,
  HeartPulse
} from 'lucide-react';

const TIPOS_HALLAZGO = [
  'Condición insegura',
  'Acto inseguro',
  'Observación',
  'No conformidad',
  'Buena práctica'
] as const;

export const InspeccionesPage: React.FC = () => {
  const {
    empresaActiva,
    getTrabajadoresActivos,
    inspecciones: rawInspecciones,
    upsertInspeccion,
    batchUpsertInspecciones,
    removeInspeccion,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  const [activeTab, setActiveTab] = useState<'base' | 'matriz'>('base');

  // Asegurar que cada inspección tenga sus arreglos definidos (evitar TypeError: length de undefined)
  const inspecciones = useMemo(() => {
    const list = Array.isArray(rawInspecciones) ? rawInspecciones : [];
    return list.map((insp) => ({
      ...insp,
      evidenciasIniciales: Array.isArray(insp.evidenciasIniciales) ? insp.evidenciasIniciales : [],
      evidenciasCorreccion: Array.isArray(insp.evidenciasCorreccion) ? insp.evidenciasCorreccion : [],
      atencionesPrimerosAuxilios: Array.isArray(insp.atencionesPrimerosAuxilios) ? insp.atencionesPrimerosAuxilios : []
    }));
  }, [rawInspecciones]);

  const [searchTerm, setSearchTerm] = useState('');
  const [tipoFilter, setTipoFilter] = useState<string>('TODOS');
  const [pgFilter, setPgFilter] = useState<string>('TODOS');
  const [areaFilter, setAreaFilter] = useState<string>('TODOS');
  const [estadoFilter, setEstadoFilter] = useState<string>('TODOS');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Modal Registro Nuevo / Editar
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<InspeccionRecord | null>(null);
  const [deleteModalInspeccion, setDeleteModalInspeccion] = useState<InspeccionRecord | null>(null);
  const [viewDetailModal, setViewDetailModal] = useState<InspeccionRecord | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<InspeccionRecord>>({
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: new Date().toISOString().slice(0, 10),
    area: 'Procesos',
    lugarEspecifico: '',
    responsableInspeccion: '',
    hallazgo: '',
    potencialGravedad: 2,
    prioridad: 'Media',
    tipo: 'Condición insegura',
    evidenciasIniciales: [],
    evidenciasCorreccion: [],
    estado: 'Pendiente',
    fechaCompromiso: new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10)
  });

  // Múltiples Imágenes Iniciales (máx 5)
  const [initialFiles, setInitialFiles] = useState<File[]>([]);
  const [initialPreviews, setInitialPreviews] = useState<string[]>([]);
  const [isCompressingInit, setIsCompressingInit] = useState(false);

  // Modal Seguimiento / Levantamiento
  const [isSeguimientoModalOpen, setIsSeguimientoModalOpen] = useState(false);
  const [seguimientoRecord, setSeguimientoRecord] = useState<InspeccionRecord | null>(null);
  const [seguimientoForm, setSeguimientoForm] = useState({
    responsableLevantamiento: '',
    accionCorrectiva: '',
    fechaCompromiso: '',
    fechaCierre: new Date().toISOString().slice(0, 10),
    estado: 'Pendiente' as 'Pendiente' | 'En proceso' | 'Subsanado' | 'Vencido'
  });
  const [correccionFiles, setCorreccionFiles] = useState<File[]>([]);
  const [correccionPreviews, setCorreccionPreviews] = useState<string[]>([]);
  const [isCompressingCorr, setIsCompressingCorr] = useState(false);
  const [seguimientoError, setSeguimientoError] = useState<string | null>(null);

  const trabajadoresActivos = useMemo(() => {
    return getTrabajadoresActivos(empresaActiva);
  }, [getTrabajadoresActivos, empresaActiva]);

  // Filtrado de la lista con cálculo dinámico de retraso
  const filteredInspecciones = useMemo(() => {
    return (inspecciones || [])
      .filter((insp) => {
        const matchEmpresa =
          empresaActiva === 'CONSOLIDADO' ? true : insp.empresa === empresaActiva;
        const matchTipo = tipoFilter === 'TODOS' ? true : insp.tipo === tipoFilter;
        const matchPg = pgFilter === 'TODOS' ? true : String(insp.potencialGravedad) === pgFilter;
        const matchArea = areaFilter === 'TODOS' ? true : insp.area === areaFilter;
        const matchEstado = estadoFilter === 'TODOS' ? true : insp.estado === estadoFilter;

        const term = searchTerm.toLowerCase().trim();
        const matchSearch =
          !term ||
          String(insp.codigoInspeccion || '').toLowerCase().includes(term) ||
          String(insp.hallazgo || '').toLowerCase().includes(term) ||
          String(insp.area || '').toLowerCase().includes(term) ||
          String(insp.responsableInspeccion || '').toLowerCase().includes(term);

        return matchEmpresa && matchTipo && matchPg && matchArea && matchEstado && matchSearch;
      })
      .map((insp) => {
        const delay = getDelayInfo(insp.fechaCompromiso, insp.fechaCierre);
        let calculatedEstado = insp.estado;
        if (insp.estado !== 'Subsanado' && delay.overdue) {
          calculatedEstado = 'Vencido';
        }
        return {
          ...insp,
          estado: calculatedEstado,
          diasAtraso: delay.days,
          estaAtrasado: delay.overdue,
          evidenciasIniciales: Array.isArray(insp.evidenciasIniciales) ? insp.evidenciasIniciales : [],
          evidenciasCorreccion: Array.isArray(insp.evidenciasCorreccion) ? insp.evidenciasCorreccion : [],
          atencionesPrimerosAuxilios: Array.isArray(insp.atencionesPrimerosAuxilios) ? insp.atencionesPrimerosAuxilios : []
        };
      });
  }, [inspecciones, empresaActiva, tipoFilter, pgFilter, areaFilter, estadoFilter, searchTerm]);

  // Paginación y opciones de filtros
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);

  const statusOptions: FilterChipOption[] = useMemo(() => {
    const listEmpresa = (inspecciones || []).filter((i) =>
      empresaActiva === 'CONSOLIDADO' ? true : i.empresa === empresaActiva
    );
    const pendientes = listEmpresa.filter((i) => i.estado === 'Pendiente').length;
    const enProceso = listEmpresa.filter((i) => i.estado === 'En proceso').length;
    const subsanados = listEmpresa.filter((i) => i.estado === 'Subsanado').length;
    const vencidos = listEmpresa.filter((i) => {
      const d = getDelayInfo(i.fechaCompromiso, i.fechaCierre);
      return i.estado !== 'Subsanado' && (i.estado === 'Vencido' || d.overdue);
    }).length;

    return [
      { id: 'TODOS', label: 'Todos', count: listEmpresa.length },
      { id: 'Pendiente', label: 'Pendientes', count: pendientes },
      { id: 'En proceso', label: 'En Proceso', count: enProceso },
      { id: 'Subsanado', label: 'Subsanados', count: subsanados },
      { id: 'Vencido', label: 'Vencidos', count: vencidos }
    ];
  }, [inspecciones, empresaActiva]);

  const paginatedInspecciones = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredInspecciones.slice(start, start + pageSize);
  }, [filteredInspecciones, currentPage, pageSize]);

  // Manejo de cambio de Potencial de Gravedad (1 al 4) y actualización de prioridad/plazo
  const handlePgChange = (pg: 1 | 2 | 3 | 4) => {
    const prio = pgToPrioridad(pg);
    const dias = pgToDiasPlazo(pg);
    const compDate = new Date(Date.now() + dias * 86400000).toISOString().slice(0, 10);

    setFormData((prev) => ({
      ...prev,
      potencialGravedad: pg,
      prioridad: prio,
      fechaCompromiso: prev.fechaCompromiso || compDate
    }));
  };

  // Manejo de Fotos Iniciales Múltiples (Máx 5)
  const handleInitialFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const currentCount = (formData.evidenciasIniciales || []).length + initialPreviews.length;
    const availableSlots = 5 - currentCount;

    if (availableSlots <= 0) {
      setFormError('Límite alcanzado: Ya tienes 5 fotos iniciales adjuntas.');
      return;
    }

    const filesToProcess = files.slice(0, availableSlots);
    setIsCompressingInit(true);

    try {
      const newPreviews: string[] = [];
      const newFiles: File[] = [];

      for (const file of filesToProcess) {
        if (file.size > 8 * 1024 * 1024) {
          continue; // Omitir archivos > 8MB
        }
        const compressed = await DriveStorageService.compressImage(file, {
          maxDimension: 1200,
          quality: 0.82
        });
        newPreviews.push(`data:image/jpeg;base64,${compressed.base64}`);
        newFiles.push(file);
      }

      setInitialFiles((prev) => [...prev, ...newFiles]);
      setInitialPreviews((prev) => [...prev, ...newPreviews]);
      setFormError(null);
    } catch {
      setFormError('Error al procesar imágenes iniciales en canvas.');
    } finally {
      setIsCompressingInit(false);
    }
  };

  const handleRemoveInitialPhoto = (idx: number, isExisting: boolean) => {
    if (isExisting) {
      setFormData((prev) => ({
        ...prev,
        evidenciasIniciales: (prev.evidenciasIniciales || []).filter((_, i) => i !== idx)
      }));
    } else {
      setInitialFiles((prev) => prev.filter((_, i) => i !== idx));
      setInitialPreviews((prev) => prev.filter((_, i) => i !== idx));
    }
  };

  // Manejo de Fotos de Corrección Múltiples (Máx 5)
  const handleCorreccionFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const currentCount =
      (seguimientoRecord?.evidenciasCorreccion || []).length + correccionPreviews.length;
    const availableSlots = 5 - currentCount;

    if (availableSlots <= 0) {
      setSeguimientoError('Límite alcanzado: Ya tienes 5 fotos de corrección adjuntas.');
      return;
    }

    const filesToProcess = files.slice(0, availableSlots);
    setIsCompressingCorr(true);

    try {
      const newPreviews: string[] = [];
      const newFiles: File[] = [];

      for (const file of filesToProcess) {
        if (file.size > 8 * 1024 * 1024) continue;
        const compressed = await DriveStorageService.compressImage(file, {
          maxDimension: 1200,
          quality: 0.82
        });
        newPreviews.push(`data:image/jpeg;base64,${compressed.base64}`);
        newFiles.push(file);
      }

      setCorreccionFiles((prev) => [...prev, ...newFiles]);
      setCorreccionPreviews((prev) => [...prev, ...newPreviews]);
      setSeguimientoError(null);
    } catch {
      setSeguimientoError('Error al procesar imágenes de corrección.');
    } finally {
      setIsCompressingCorr(false);
    }
  };

  const handleRemoveCorreccionPhoto = (idx: number, isExisting: boolean) => {
    if (isExisting && seguimientoRecord) {
      setSeguimientoRecord({
        ...seguimientoRecord,
        evidenciasCorreccion: seguimientoRecord.evidenciasCorreccion.filter((_, i) => i !== idx)
      });
    } else {
      setCorreccionFiles((prev) => prev.filter((_, i) => i !== idx));
      setCorreccionPreviews((prev) => prev.filter((_, i) => i !== idx));
    }
  };

  // Abrir Modal de Nueva Inspección
  const handleOpenNuevoModal = () => {
    setEditingRecord(null);
    setFormError(null);
    setInitialFiles([]);
    setInitialPreviews([]);

    setFormData({
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      area: 'Procesos',
      lugarEspecifico: '',
      responsableInspeccion: '',
      hallazgo: '',
      potencialGravedad: 2,
      prioridad: 'Media',
      tipo: 'Condición insegura',
      evidenciasIniciales: [],
      evidenciasCorreccion: [],
      estado: 'Pendiente',
      fechaCompromiso: new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10),
      atencionesPrimerosAuxilios: []
    });
    setIsModalOpen(true);
  };

  // Guardar Registro de Inspección (con subida por lotes a Drive)
  const handleSaveInspeccion = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!String(formData.hallazgo || '').trim()) {
      setFormError('La descripción detallada del hallazgo es obligatoria.');
      return;
    }
    if (!String(formData.responsableInspeccion || '').trim()) {
      setFormError('El responsable de la inspección es obligatorio.');
      return;
    }
    if (!String(formData.area || '').trim()) {
      setFormError('El área inspeccionada es obligatoria.');
      return;
    }
    if (!String(formData.lugarEspecifico || '').trim()) {
      setFormError('El lugar físico específico es obligatorio.');
      return;
    }

    let finalUrls: string[] = [...(formData.evidenciasIniciales || [])];

    // Subida batch de fotos iniciales a Google Drive si las hay
    if (initialFiles.length > 0) {
      try {
        incrementSync();
        addToast({
          type: 'info',
          title: 'Subiendo Evidencias a Drive',
          message: `Almacenando ${initialFiles.length} foto(s) en Google Drive...`
        });

        for (let i = 0; i < initialFiles.length; i++) {
          const res = await DriveStorageService.uploadToDrive(initialFiles[i], {
            modulo: 'INSPECCIONES_INICIAL',
            fileName: `insp_${Date.now()}_${i + 1}.jpg`,
            maxDimension: 1200
          });
          if (res.fileUrl) {
            finalUrls.push(res.fileUrl);
          }
        }
      } catch {
        finalUrls = [...finalUrls, ...initialPreviews];
      } finally {
        decrementSync();
      }
    }

    // Generar correlativo secuencial anual incremental basado en cantidad de casos registrados si es nuevo
    let cod = editingRecord?.codigoInspeccion;
    if (!cod) {
      const anio = new Date().getFullYear();
      const totalAnio = inspecciones.filter((i) => {
        const f = i.fecha || '';
        return f.startsWith(String(anio)) || (i.codigoInspeccion && i.codigoInspeccion.includes(`-${anio}-`));
      }).length;
      cod = `INSP-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;
    }

    const newRecord: InspeccionRecord = {
      id: editingRecord?.id || cod,
      codigoInspeccion: cod,
      empresa: formData.empresa as 'PERPOL' | 'TR3',
      fecha: formData.fecha || new Date().toISOString().slice(0, 10),
      area: formData.area || 'Procesos',
      lugarEspecifico: String(formData.lugarEspecifico || '').trim() || undefined,
      responsableInspeccion: String(formData.responsableInspeccion || '').trim() || 'Inspector SST',
      hallazgo: String(formData.hallazgo || '').trim(),
      potencialGravedad: formData.potencialGravedad || 2,
      prioridad: pgToPrioridad(formData.potencialGravedad || 2),
      tipo: formData.tipo as any,
      evidenciasIniciales: finalUrls.slice(0, 5),
      evidenciasCorreccion: formData.evidenciasCorreccion || [],
      estado: (formData.estado as any) || 'Pendiente',
      fechaCompromiso: formData.fechaCompromiso || new Date().toISOString().slice(0, 10),
      responsableLevantamiento: formData.responsableLevantamiento || '',
      accionCorrectiva: formData.accionCorrectiva || '',
      atencionesPrimerosAuxilios: formData.atencionesPrimerosAuxilios || [],
      createdAt: editingRecord?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    upsertInspeccion(newRecord);

    setIsModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: editingRecord ? 'Inspección Actualizada' : 'Inspección Registrada',
      message: `${newRecord.codigoInspeccion} guardada exitosamente.`
    });

    try {
      await GasApiClient.post({
        action: 'saveInspeccion',
        sheetName: 'SSOMA_Inspecciones',
        data: newRecord
      });
    } finally {
      decrementSync();
    }
  };

  // Abrir Modal de Seguimiento / Levantamiento
  const handleOpenSeguimiento = (record: InspeccionRecord) => {
    setSeguimientoRecord(record);
    setSeguimientoError(null);
    setCorreccionFiles([]);
    setCorreccionPreviews([]);

    setSeguimientoForm({
      responsableLevantamiento: record.responsableLevantamiento || '',
      accionCorrectiva: record.accionCorrectiva || '',
      fechaCompromiso: record.fechaCompromiso || new Date().toISOString().slice(0, 10),
      fechaCierre: record.fechaCierre || new Date().toISOString().slice(0, 10),
      estado: record.estado
    });

    setIsSeguimientoModalOpen(true);
  };

  // Guardar Seguimiento sin sobrescribir hallazgos originales
  const handleSaveSeguimiento = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!seguimientoRecord) return;
    setSeguimientoError(null);

    if (!String(seguimientoForm.accionCorrectiva || '').trim()) {
      setSeguimientoError('Es obligatorio detallar la acción correctiva ejecutada.');
      return;
    }
    if (!String(seguimientoForm.responsableLevantamiento || '').trim()) {
      setSeguimientoError('Es obligatorio asignar el responsable del levantamiento.');
      return;
    }

    let finalCorrUrls = [...(seguimientoRecord.evidenciasCorreccion || [])];

    if (correccionFiles.length > 0) {
      try {
        incrementSync();
        addToast({
          type: 'info',
          title: 'Subiendo Fotos de Corrección',
          message: `Guardando ${correccionFiles.length} foto(s) en Google Drive...`
        });

        for (let j = 0; j < correccionFiles.length; j++) {
          const res = await DriveStorageService.uploadToDrive(correccionFiles[j], {
            modulo: 'INSPECCIONES_CORRECCION',
            fileName: `corr_${seguimientoRecord.codigoInspeccion}_${Date.now()}_${j + 1}.jpg`,
            maxDimension: 1200
          });
          if (res.fileUrl) {
            finalCorrUrls.push(res.fileUrl);
          }
        }
      } catch {
        finalCorrUrls = [...finalCorrUrls, ...correccionPreviews];
      } finally {
        decrementSync();
      }
    }

    const isSubsanado = seguimientoForm.estado === 'Subsanado';

    const updatedRecord: InspeccionRecord = {
      ...seguimientoRecord,
      responsableLevantamiento: String(seguimientoForm.responsableLevantamiento || '').trim(),
      accionCorrectiva: String(seguimientoForm.accionCorrectiva || '').trim(),
      fechaCompromiso: seguimientoForm.fechaCompromiso,
      fechaCierre: isSubsanado ? seguimientoForm.fechaCierre : undefined,
      fechaLevantamiento: isSubsanado ? seguimientoForm.fechaCierre : undefined,
      estado: seguimientoForm.estado,
      evidenciasCorreccion: finalCorrUrls.slice(0, 5),
      updatedAt: new Date().toISOString()
    };

    upsertInspeccion(updatedRecord);

    setIsSeguimientoModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: 'Seguimiento Actualizado',
      message: `${updatedRecord.codigoInspeccion} actualizado.`
    });

    try {
      await GasApiClient.post({
        action: 'updateSeguimientoInspeccion',
        sheetName: 'SSOMA_Inspecciones',
        id: updatedRecord.id,
        data: {
          responsableLevantamiento: updatedRecord.responsableLevantamiento,
          accionCorrectiva: updatedRecord.accionCorrectiva,
          fechaCompromiso: updatedRecord.fechaCompromiso,
          fechaCierre: updatedRecord.fechaCierre,
          fechaLevantamiento: updatedRecord.fechaLevantamiento,
          estado: updatedRecord.estado,
          evidenciasCorreccion: updatedRecord.evidenciasCorreccion
        }
      });
    } finally {
      decrementSync();
    }
  };

  const confirmDeleteInspeccion = async () => {
    if (!deleteModalInspeccion) return;
    const record = deleteModalInspeccion;

    removeInspeccion(record.id);
    incrementSync();

    addToast({
      type: 'info',
      title: 'Inspección Eliminada',
      message: `${record.codigoInspeccion} fue removida.`
    });

    try {
      await GasApiClient.post({
        action: 'deleteInspeccion',
        sheetName: 'SSOMA_Inspecciones',
        id: record.id
      });
    } catch {
      // Fallback silencioso
    } finally {
      decrementSync();
      setDeleteModalInspeccion(null);
    }
  };

  // Exportaciones
  const handleExportExcel = () => {
    const exportData = filteredInspecciones.map((i) => ({
      'Código': i.codigoInspeccion,
      'Empresa': i.empresa,
      'Fecha': i.fecha,
      'Área': i.area,
      'Lugar Físico Específico': i.lugarEspecifico || 'General',
      'Responsable Inspección': i.responsableInspeccion,
      'Tipo de Hallazgo': i.tipo,
      'P.G.': `P.G. ${i.potencialGravedad}`,
      'Prioridad': i.prioridad,
      'Hallazgo': i.hallazgo,
      'Estado': i.estado,
      'Compromiso': i.fechaCompromiso,
      'Fecha Cierre': i.fechaCierre || 'Abierto',
      'Días Retraso (Algoritmo UTC)': i.diasAtraso || 0,
      'Acción Correctiva': i.accionCorrectiva || 'Sin acción',
      'Responsable Levantamiento': i.responsableLevantamiento || 'Sin asignar',
      'Evidencias Iniciales Drive': i.evidenciasIniciales.join(', '),
      'Evidencias Corrección Drive': i.evidenciasCorreccion.join(', '),
      'Atenciones Botiquín Vinculadas': i.atencionesPrimerosAuxilios?.join(', ') || 'Ninguna'
    }));

    ExportUtils.exportToExcel(exportData, `Inspecciones_SST_${empresaActiva}`);
    addToast({
      type: 'success',
      title: 'Excel Exportado',
      message: 'Base de datos de inspecciones descargada con éxito.'
    });
  };

  const handleExportPdf = () => {
    ExportUtils.exportToPdf({
      title: 'REGISTRO DE INSPECCIONES DE SEGURIDAD Y SALUD EN EL TRABAJO',
      subtitle: `Empresa: ${empresaActiva} | Registros: ${filteredInspecciones.length}`,
      empresa: empresaActiva,
      fileName: `Inspecciones_SST_${empresaActiva}`,
      headers: ['Código', 'Fecha', 'Área', 'Tipo', 'P.G.', 'Hallazgo', 'Compromiso', 'Retraso', 'Estado'],
      rows: filteredInspecciones.map((i) => [
        i.codigoInspeccion,
        i.fecha,
        i.area,
        i.tipo,
        `P.G. ${i.potencialGravedad}`,
        i.hallazgo,
        i.fechaCompromiso,
        i.estaAtrasado ? `${i.diasAtraso}d atraso` : 'A tiempo',
        i.estado
      ]),
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'PDF Exportado',
      message: 'Reporte oficial de inspecciones generado.'
    });
  };

  // KPIs
  const totalSubsanadas = useMemo(
    () => filteredInspecciones.filter((i) => i.estado === 'Subsanado').length,
    [filteredInspecciones]
  );
  const totalVencidas = useMemo(
    () => filteredInspecciones.filter((i) => i.estaAtrasado && i.estado !== 'Subsanado').length,
    [filteredInspecciones]
  );
  const totalProceso = useMemo(
    () => filteredInspecciones.filter((i) => i.estado === 'En proceso' || i.estado === 'Pendiente').length,
    [filteredInspecciones]
  );

  return (
    <div className="space-y-6">
      <ModuleHeader
        codigo={3}
        titulo="Inspecciones de Seguridad y Salud en el Trabajo"
        subtitulo="Registro de hallazgos, matriz de potencial de gravedad (P.G. 1 al 4), control estricto de retraso en UTC y hasta 5 fotos en Google Drive"
        icono={<ClipboardCheck className="w-5 h-5" />}
        onNuevo={handleOpenNuevoModal}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.inspecciones}
        onImportSuccess={(rows) => {
          const cleanRows = (rows as any[]).map(sanitizeInspeccion);
          batchUpsertInspecciones(cleanRows);
        }}
      />

      {/* Tabs */}
      <div role="tablist" aria-label="Secciones de Inspecciones SST" className="flex border-b border-[#E2E8F0] bg-white px-2 rounded-t-xl gap-1">
        <button
          type="button"
          role="tab"
          id="tab-inspecciones-base"
          aria-selected={activeTab === 'base'}
          aria-controls="panel-inspecciones-base"
          onClick={() => setActiveTab('base')}
          className={`px-4 py-2.5 text-xs font-bold rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'base'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <ClipboardCheck className="w-4 h-4" aria-hidden="true" />
          <span>Base de Inspecciones y Seguimiento</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
            activeTab === 'base' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#0F172A]'
          }`}>
            {inspecciones.length}
          </span>
        </button>
        <button
          type="button"
          role="tab"
          id="tab-inspecciones-matriz"
          aria-selected={activeTab === 'matriz'}
          aria-controls="panel-inspecciones-matriz"
          onClick={() => setActiveTab('matriz')}
          className={`px-4 py-2.5 text-xs font-bold rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'matriz'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Layers className="w-4 h-4" aria-hidden="true" />
          <span>Matriz de Potencial de Gravedad (P.G. 1 a 4)</span>
        </button>
      </div>

      {activeTab === 'base' ? (
        <div id="panel-inspecciones-base" role="tabpanel" aria-labelledby="tab-inspecciones-base" className="space-y-4">
          {/* Tarjetas de Indicadores */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
                <ClipboardCheck className="w-4 h-4 text-[#047857]" />
                <span className="font-semibold">Total Inspecciones</span>
              </div>
              <div className="text-2xl font-black text-[#0F172A]">{filteredInspecciones.length}</div>
            </div>

            <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
                <CheckCircle2 className="w-4 h-4 text-[#047857]" />
                <span className="font-semibold">Subsanadas</span>
              </div>
              <div className="text-2xl font-black text-[#047857]">{totalSubsanadas}</div>
            </div>

            <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
                <Clock className="w-4 h-4 text-[#0284C7]" />
                <span className="font-semibold">En Proceso / Pendientes</span>
              </div>
              <div className="text-2xl font-black text-[#0284C7]">{totalProceso}</div>
            </div>

            <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
                <AlertOctagon className="w-4 h-4 text-[#DC2626]" />
                <span className="font-semibold">Vencidas (&gt;1 día retraso)</span>
              </div>
              <div className="text-2xl font-black text-[#DC2626]">{totalVencidas}</div>
            </div>
          </div>

          {/* Filtros y Herramientas Estandarizada */}
          <ModuleToolbar
            searchQuery={searchTerm}
            onSearchChange={(val) => {
              setSearchTerm(val);
              setCurrentPage(1);
            }}
            searchPlaceholder="Buscar código, hallazgo, área o responsable..."
            statusFilter={estadoFilter}
            onStatusFilterChange={(id) => {
              setEstadoFilter(id);
              setCurrentPage(1);
            }}
            statusOptions={statusOptions}
            totalCount={(inspecciones || []).filter((i) => empresaActiva === 'CONSOLIDADO' ? true : i.empresa === empresaActiva).length}
            filteredCount={filteredInspecciones.length}
            onExportExcel={handleExportExcel}
            onExportPdf={handleExportPdf}
            onNewRecord={handleOpenNuevoModal}
            newRecordLabel="Nueva Inspección"
          >
            <select
              value={tipoFilter}
              onChange={(e) => {
                setTipoFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todos los tipos</option>
              {TIPOS_HALLAZGO.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>

            <select
              value={pgFilter}
              onChange={(e) => {
                setPgFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todos los P.G.</option>
              <option value="1">P.G. 1 (Bajo)</option>
              <option value="2">P.G. 2 (Medio)</option>
              <option value="3">P.G. 3 (Alto)</option>
              <option value="4">P.G. 4 (Crítico)</option>
            </select>

            <select
              value={areaFilter}
              onChange={(e) => {
                setAreaFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todas las áreas</option>
              {AREAS_EMPRESA.map((area) => (
                <option key={area} value={area}>
                  {area}
                </option>
              ))}
            </select>
          </ModuleToolbar>

          {/* Tabla de Inspecciones */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1080px] text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
                  <tr>
                    <th className="px-4 py-3 w-28 whitespace-nowrap">Código</th>
                    <th className="px-4 py-3 w-36 whitespace-nowrap">Fecha & Área</th>
                    <th className="px-4 py-3 w-32 whitespace-nowrap">Tipo / P.G.</th>
                    <th className="px-4 py-3 min-w-[200px]">Hallazgo</th>
                    <th className="px-4 py-3 w-36 whitespace-nowrap">Compromiso / Retraso</th>
                    <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Fotos Drive</th>
                    <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Botiquín</th>
                    <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Estado</th>
                    <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paginatedInspecciones.length === 0 ? (
                    <TableEmptyState
                      isTableRow
                      colSpan={9}
                      title="No se encontraron inspecciones"
                      description={
                        searchTerm
                          ? `No hay coincidencias para "${searchTerm}". Prueba con otro término.`
                          : 'No hay inspecciones que coincidan con los filtros seleccionados.'
                      }
                      actionLabel={
                        searchTerm || estadoFilter !== 'TODOS' || tipoFilter !== 'TODOS' || pgFilter !== 'TODOS' || areaFilter !== 'TODOS'
                          ? 'Limpiar filtros'
                          : 'Nueva Inspección'
                      }
                      actionIcon={
                        searchTerm || estadoFilter !== 'TODOS' || tipoFilter !== 'TODOS' || pgFilter !== 'TODOS' || areaFilter !== 'TODOS'
                          ? 'clear'
                          : 'plus'
                      }
                      onAction={() => {
                        if (searchTerm || estadoFilter !== 'TODOS' || tipoFilter !== 'TODOS' || pgFilter !== 'TODOS' || areaFilter !== 'TODOS') {
                          setSearchTerm('');
                          setEstadoFilter('TODOS');
                          setTipoFilter('TODOS');
                          setPgFilter('TODOS');
                          setAreaFilter('TODOS');
                          setCurrentPage(1);
                        } else {
                          handleOpenNuevoModal();
                        }
                      }}
                    />
                  ) : (
                    paginatedInspecciones.map((insp, iIdx) => {
                      const delay = getDelayInfo(insp.fechaCompromiso, insp.fechaCierre);

                      return (
                        <tr key={`${insp.id || insp.codigoInspeccion || ''}-${iIdx}`} className="hover:bg-slate-50/80 transition-colors">
                          <td className="px-4 py-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                            {insp.codigoInspeccion}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-slate-800 font-medium">{insp.fecha}</div>
                            <div className="text-[10px] text-slate-500 truncate max-w-[160px]" title={`${insp.area}${insp.lugarEspecifico ? ` • ${insp.lugarEspecifico}` : ''}`}>
                              {insp.area}{insp.lugarEspecifico ? ` • ${insp.lugarEspecifico}` : ''}
                            </div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-slate-800 font-semibold">{insp.tipo}</div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono text-[10px] text-slate-500">
                                P.G. {insp.potencialGravedad}
                              </span>
                              <span
                                className={`text-[9px] px-1.5 py-0.2 rounded font-semibold ${
                                  insp.prioridad === 'Inmediata'
                                    ? 'bg-red-50 text-red-700 border border-red-200'
                                    : insp.prioridad === 'Alta'
                                    ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                    : insp.prioridad === 'Media'
                                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                    : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                }`}
                              >
                                {insp.prioridad}
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-3 max-w-xs">
                            <p className="line-clamp-2 text-slate-600">{insp.hallazgo}</p>
                            <span className="text-[10px] text-slate-400">
                              Resp: {insp.responsableInspeccion}
                            </span>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="font-mono text-slate-600">{insp.fechaCompromiso}</div>
                            {/* Algoritmo crítico: solo overdue si diffDays > 1 */}
                            {insp.estado !== 'Subsanado' && (
                              <div
                                className={`text-[10px] font-semibold mt-0.5 ${
                                  delay.overdue ? 'text-rose-600 font-bold' : 'text-slate-500'
                                }`}
                              >
                                {delay.text}
                              </div>
                            )}
                            {insp.estado === 'Subsanado' && insp.fechaCierre && (
                              <div className="text-[10px] text-emerald-600 font-medium">
                                Cerrado: {insp.fechaCierre}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex flex-col gap-1">
                              {insp.evidenciasIniciales && insp.evidenciasIniciales.length > 0 ? (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setLightboxImage({
                                      url: insp.evidenciasIniciales[0],
                                      title: `Evidencia Inicial (1/${insp.evidenciasIniciales.length}) - ${insp.codigoInspeccion}`,
                                      subtitle: insp.hallazgo
                                    })
                                  }
                                  className="text-[10px] text-sky-700 hover:text-sky-900 flex items-center gap-1 cursor-pointer font-medium"
                                  title="Ver foto inicial en pantalla completa"
                                  aria-label={`Ver fotos iniciales (${insp.evidenciasIniciales.length}) de la inspección ${insp.codigoInspeccion}`}
                                >
                                  <Camera className="w-3 h-3 text-sky-500" aria-hidden="true" />
                                  <span>Iniciales: {insp.evidenciasIniciales.length}/5</span>
                                </button>
                              ) : (
                                <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                                  <Camera className="w-3 h-3 text-slate-400" aria-hidden="true" />
                                  <span>0 iniciales</span>
                                </span>
                              )}

                              {insp.evidenciasCorreccion && insp.evidenciasCorreccion.length > 0 ? (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setLightboxImage({
                                      url: insp.evidenciasCorreccion[0],
                                      title: `Evidencia Cierre (1/${insp.evidenciasCorreccion.length}) - ${insp.codigoInspeccion}`,
                                      subtitle: insp.accionCorrectiva || insp.hallazgo
                                    })
                                  }
                                  className="text-[10px] text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer font-medium"
                                  title="Ver foto de cierre en pantalla completa"
                                  aria-label={`Ver fotos de cierre (${insp.evidenciasCorreccion.length}) de la inspección ${insp.codigoInspeccion}`}
                                >
                                  <CheckCircle2 className="w-3 h-3 text-emerald-500" aria-hidden="true" />
                                  <span>Cierre: {insp.evidenciasCorreccion.length}/5</span>
                                </button>
                              ) : (
                                <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-slate-400" aria-hidden="true" />
                                  <span>0 cierre</span>
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {Array.isArray(insp.atencionesPrimerosAuxilios) &&
                            insp.atencionesPrimerosAuxilios.length > 0 ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200 text-[10px] font-mono">
                                <HeartPulse className="w-3 h-3" aria-hidden="true" />
                                <span>{insp.atencionesPrimerosAuxilios.length} casos</span>
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-500 font-medium">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <StatusBadge
                              status={insp.estaAtrasado && insp.estado !== 'Subsanado' ? 'Vencido' : insp.estado}
                              onClick={() => handleOpenSeguimiento(insp)}
                            />
                          </td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setViewDetailModal(insp)}
                                className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                                title="Ver Ficha de Inspección"
                                aria-label={`Ver ficha de la inspección ${insp.codigoInspeccion}`}
                              >
                                <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenSeguimiento(insp)}
                                className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                                title="Levantar / Seguimiento"
                                aria-label={`Levantar observaciones de la inspección ${insp.codigoInspeccion}`}
                              >
                                <CheckSquare className="w-3.5 h-3.5" aria-hidden="true" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingRecord(insp);
                                  setFormData({ ...insp });
                                  setInitialPreviews(insp.evidenciasIniciales);
                                  setIsModalOpen(true);
                                }}
                                className="p-1.5 rounded hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                                title="Editar Inspección"
                                aria-label={`Editar inspección ${insp.codigoInspeccion}`}
                              >
                                <Edit2 className="w-3.5 h-3.5" aria-hidden="true" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteModalInspeccion(insp)}
                                className="p-1.5 rounded hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
                                title="Eliminar"
                                aria-label={`Eliminar inspección ${insp.codigoInspeccion}`}
                              >
                                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Paginación */}
            <TablePagination
              currentPage={currentPage}
              totalItems={filteredInspecciones.length}
              pageSize={pageSize}
              onPageChange={setCurrentPage}
              onPageSizeChange={(newSize) => {
                setPageSize(newSize);
                setCurrentPage(1);
              }}
            />
          </div>
        </div>
      ) : (
        /* PESTAÑA: TABLA MATRIZ DE POTENCIAL DE GRAVEDAD (P.G.) */
        <div id="panel-inspecciones-matriz" role="tabpanel" aria-labelledby="tab-inspecciones-matriz" className="space-y-4">
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-3">
            <h3 className="font-bold text-[#0F172A] text-sm flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#047857]" />
              <span>Matriz Oficial de Potencial de Gravedad (P.G.) y Conversión a Prioridad</span>
            </h3>
            <p className="text-xs text-[#475569]">
              Regla técnica de priorización establecida para PERPOL IDEAS S.A.C. y TR3 ALIMENTOS S.A.C.
              según la severidad de las consecuencias posibles sobre las personas y las operaciones.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
              {/* P.G. 1 */}
              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-[#047857] bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                    P.G. 1 (Bajo)
                  </span>
                  <span className="text-xs font-bold text-[#047857]">Prioridad Baja</span>
                </div>
                <h4 className="font-bold text-[#0F172A] text-xs">Consecuencia Menor</h4>
                <p className="text-[11px] text-[#475569] leading-relaxed">
                  Primeros auxilios simples sin descanso médico, daño material menor o desvíos leves
                  de orden y limpieza.
                </p>
                <div className="pt-2 border-t border-emerald-200 text-[10px] text-[#1E293B] font-medium">
                  Plazo estándar: <strong className="font-bold">30 días</strong>
                </div>
              </div>

              {/* P.G. 2 */}
              <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-[#B45309] bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                    P.G. 2 (Medio)
                  </span>
                  <span className="text-xs font-bold text-[#B45309]">Prioridad Media</span>
                </div>
                <h4 className="font-bold text-[#0F172A] text-xs">Consecuencia Moderada</h4>
                <p className="text-[11px] text-[#475569] leading-relaxed">
                  Tratamiento médico ambulatorio, descanso médico &lt; 3 días, daño a equipos reparable sin
                  parada de línea.
                </p>
                <div className="pt-2 border-t border-amber-200 text-[10px] text-[#1E293B] font-medium">
                  Plazo estándar: <strong className="font-bold">15 días</strong>
                </div>
              </div>

              {/* P.G. 3 */}
              <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded border border-rose-300">
                    P.G. 3 (Alto)
                  </span>
                  <span className="text-xs font-bold text-rose-700">Prioridad Alta</span>
                </div>
                <h4 className="font-bold text-[#0F172A] text-xs">Consecuencia Grave</h4>
                <p className="text-[11px] text-[#475569] leading-relaxed">
                  Accidente incapacitante con fractura, quemadura, internamiento clínico o paralización
                  parcial de planta.
                </p>
                <div className="pt-2 border-t border-rose-200 text-[10px] text-[#1E293B] font-medium">
                  Plazo estándar: <strong className="font-bold">72 horas (3 días)</strong>
                </div>
              </div>

              {/* P.G. 4 */}
              <div className="p-4 rounded-xl bg-red-50/50 border border-red-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-red-800 bg-red-100 px-2 py-0.5 rounded border border-red-300">
                    P.G. 4 (Crítico)
                  </span>
                  <span className="text-xs font-bold text-red-700">Prioridad Inmediata</span>
                </div>
                <h4 className="font-bold text-[#0F172A] text-xs">Consecuencia Fatal o Catastrófica</h4>
                <p className="text-[11px] text-[#475569] leading-relaxed">
                  Peligro inminente de fatalidad, amputación, incendio mayor, atrapamiento o explosión.
                  Paralización preventiva inmediata.
                </p>
                <div className="pt-2 border-t border-red-200 text-[10px] text-[#1E293B] font-medium">
                  Plazo estándar: <strong className="font-bold">24 horas / Inmediato</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: NUEVA INSPECCIÓN CON HASTA 5 FOTOS INICIALES */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-200">
                  <ClipboardCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0F172A] text-base">
                    {editingRecord ? `Editar ${editingRecord.codigoInspeccion}` : 'Registrar Inspección SST'}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">
                    Formato de hallazgo con hasta 5 fotos y plazos normativos
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span className="font-medium">{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveInspeccion} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Razón Social</label>
                  <select
                    value={formData.empresa}
                    onChange={(e) => setFormData({ ...formData, empresa: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                    <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Fecha Inspección <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.fecha}
                    onChange={(e) => setFormData({ ...formData, fecha: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Área Inspeccionada <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    required
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="">Seleccione área...</option>
                    {AREAS_EMPRESA.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="lista-lugares-inspeccion"
                    placeholder="Escribe o selecciona lugar..."
                    value={formData.lugarEspecifico}
                    onChange={(e) => setFormData({ ...formData, lugarEspecifico: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-lugares-inspeccion">
                    {LUGARES_ESPECIFICOS.map((lug, idx) => (
                      <option key={`lug-insp-${idx}`} value={lug} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Responsable de la Inspección <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="lista-responsables-insp"
                    placeholder="Inspector / Supervisor SST"
                    value={formData.responsableInspeccion}
                    onChange={(e) => setFormData({ ...formData, responsableInspeccion: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-responsables-insp">
                    {trabajadoresActivos.map((t, idx) => (
                      <option key={`${t.id || t.dni}-${idx}`} value={t.apellidosNombres} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Tipo de Hallazgo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.tipo}
                    onChange={(e) => setFormData({ ...formData, tipo: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    {TIPOS_HALLAZGO.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Potencial de Gravedad y Prioridad */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-[#475569] font-semibold mb-1">
                      Potencial de Gravedad (P.G.) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <select
                      value={formData.potencialGravedad}
                      onChange={(e) => handlePgChange(Number(e.target.value) as 1 | 2 | 3 | 4)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    >
                      <option value={1}>P.G. 1 (Bajo - 30 días)</option>
                      <option value={2}>P.G. 2 (Medio - 15 días)</option>
                      <option value={3}>P.G. 3 (Alto - 72 hrs)</option>
                      <option value={4}>P.G. 4 (Crítico - 24 hrs)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#475569] font-semibold mb-1">
                      Fecha Límite de Compromiso <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.fechaCompromiso}
                      onChange={(e) => setFormData({ ...formData, fechaCompromiso: e.target.value })}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                  </div>
                </div>

                <div className="text-[11px] text-[#475569] flex items-center justify-between">
                  <span>
                    Prioridad Automática: <strong className="text-[#047857]">{formData.prioridad}</strong>
                  </span>
                  <span>
                    Plazo sugerido: {pgToDiasPlazo(formData.potencialGravedad || 2)} días calendario
                  </span>
                </div>
              </div>

              {/* Descripción del Hallazgo */}
              <div>
                <label className="block text-[#475569] font-semibold mb-1">
                  Descripción Detallada del Hallazgo / Desvío <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Detalla qué se observó, máquina afectada, condición o acto detectado..."
                  value={formData.hallazgo}
                  onChange={(e) => setFormData({ ...formData, hallazgo: e.target.value })}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:border-[#047857] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>

              {/* Múltiples Fotos Iniciales (Hasta 5) */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-[#0F172A] font-semibold text-xs flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#047857]" />
                    <span>Fotos Iniciales de Evidencia (Máximo 5 fotos en Google Drive)</span>
                  </label>
                  <span className="text-[10px] text-[#475569] font-mono font-bold">
                    {(formData.evidenciasIniciales?.length || 0) + initialPreviews.length} / 5 adjuntas
                  </span>
                </div>

                {/* Previsualización en cuadrícula */}
                <div className="grid grid-cols-5 gap-2">
                  {/* Existentes en Drive */}
                  {(formData.evidenciasIniciales || [])
                    .filter((url): url is string => Boolean(url && typeof url === 'string' && url.trim().length > 0))
                    .map((url, idx) => (
                      <div key={`exist-${idx}`} className="relative group rounded-lg overflow-hidden border border-[#CBD5E1] aspect-square">
                        <img src={url.trim()} alt="Evidencia" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveInitialPhoto(idx, true)}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          title="Eliminar foto"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}

                  {/* Nuevas previews locales */}
                  {initialPreviews
                    .filter((preview): preview is string => Boolean(preview && typeof preview === 'string' && preview.trim().length > 0))
                    .map((preview, idx) => (
                      <div key={`new-${idx}`} className="relative group rounded-lg overflow-hidden border border-[#047857] aspect-square">
                        <img src={preview.trim()} alt="Nueva" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveInitialPhoto(idx, false)}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          title="Eliminar foto"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}

                  {/* Botón de carga si hay cupo */}
                  {(formData.evidenciasIniciales?.length || 0) + initialPreviews.length < 5 && (
                    <label className="border border-dashed border-[#CBD5E1] hover:border-[#047857] rounded-lg aspect-square flex flex-col items-center justify-center cursor-pointer bg-white transition-colors text-[#475569] hover:text-[#0F172A]">
                      <Upload className="w-4 h-4 mb-1 text-[#047857]" />
                      <span className="text-[9px] text-center px-1 font-semibold">Agregar Foto</span>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        capture="environment"
                        onChange={handleInitialFilesSelected}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>

                {isCompressingInit && (
                  <span className="text-[11px] text-[#B45309] font-semibold animate-pulse block">
                    Comprimiendo imágenes a 1200px para Google Drive...
                  </span>
                )}
              </div>

              {/* Botones de acción */}
              <div className="pt-3 border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-[#475569] font-semibold text-xs border border-[#CBD5E1] cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-bold text-xs transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingRecord ? 'Guardar Cambios' : 'Registrar Inspección'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: SEGUIMIENTO Y LEVANTAMIENTO (HASTA 5 FOTOS DE CORRECCIÓN) */}
      {isSeguimientoModalOpen && seguimientoRecord && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsSeguimientoModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-[#CBD5E1] rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-[#0F172A] cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-200">
                  <CheckSquare className="w-5 h-5 text-[#047857]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0F172A] text-base">
                    Levantamiento: {seguimientoRecord.codigoInspeccion}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium line-clamp-1">{seguimientoRecord.hallazgo}</p>
                </div>
              </div>
              <button
                onClick={() => setIsSeguimientoModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {seguimientoError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{seguimientoError}</span>
              </div>
            )}

            <form onSubmit={handleSaveSeguimiento} className="space-y-4 text-xs">
              <div>
                <label className="block text-[#475569] font-semibold mb-1">
                  Acción Correctiva Ejecutada <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Detalla cómo se subsanó la condición o el plan aplicado..."
                  value={seguimientoForm.accionCorrectiva}
                  onChange={(e) => setSeguimientoForm({ ...seguimientoForm, accionCorrectiva: e.target.value })}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Responsable del Levantamiento <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="lista-responsables-lev"
                    placeholder="Encargado de subsanar"
                    value={seguimientoForm.responsableLevantamiento}
                    onChange={(e) =>
                      setSeguimientoForm({ ...seguimientoForm, responsableLevantamiento: e.target.value })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-responsables-lev">
                    {trabajadoresActivos.map((t, idx) => (
                      <option key={`${t.id || t.dni}-${idx}`} value={t.apellidosNombres} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Fecha Compromiso <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={seguimientoForm.fechaCompromiso}
                    onChange={(e) =>
                      setSeguimientoForm({ ...seguimientoForm, fechaCompromiso: e.target.value })
                    }
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Estado de la Inspección <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={seguimientoForm.estado}
                    onChange={(e) => setSeguimientoForm({ ...seguimientoForm, estado: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="Pendiente">Pendiente</option>
                    <option value="En proceso">En proceso</option>
                    <option value="Subsanado">Subsanado (Levantado)</option>
                    <option value="Vencido">Vencido</option>
                  </select>
                </div>

                {seguimientoForm.estado === 'Subsanado' && (
                  <div>
                    <label className="block text-[#475569] font-semibold mb-1">
                      Fecha de Levantamiento / Cierre <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <input
                      type="date"
                      required
                      value={seguimientoForm.fechaCierre}
                      onChange={(e) => setSeguimientoForm({ ...seguimientoForm, fechaCierre: e.target.value })}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#047857] font-mono font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                  </div>
                )}
              </div>

              {/* Múltiples Fotos de Corrección (Hasta 5) */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-[#0F172A] font-semibold text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#047857]" />
                    <span>Fotos de Evidencia de Levantamiento (Máx 5 en Drive)</span>
                  </label>
                  <span className="text-[10px] text-[#475569] font-mono font-bold">
                    {(seguimientoRecord.evidenciasCorreccion?.length || 0) + correccionPreviews.length} / 5
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {(seguimientoRecord.evidenciasCorreccion || [])
                    .filter((url): url is string => Boolean(url && typeof url === 'string' && url.trim().length > 0))
                    .map((url, idx) => (
                      <div key={`exist-corr-${idx}`} className="relative group rounded-lg overflow-hidden border border-[#CBD5E1] aspect-square">
                        <img src={url.trim()} alt="Corrección" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveCorreccionPhoto(idx, true)}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          title="Eliminar foto"
                        >
                          <X className="w-3 h-3 text-white" />
                        </button>
                      </div>
                    ))}

                  {correccionPreviews
                    .filter((preview): preview is string => Boolean(preview && typeof preview === 'string' && preview.trim().length > 0))
                    .map((preview, idx) => (
                      <div key={`new-corr-${idx}`} className="relative group rounded-lg overflow-hidden border border-[#047857] aspect-square">
                        <img src={preview.trim()} alt="Nueva" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveCorreccionPhoto(idx, false)}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          title="Eliminar foto"
                        >
                          <X className="w-3 h-3 text-white" />
                        </button>
                      </div>
                    ))}

                  {(seguimientoRecord.evidenciasCorreccion?.length || 0) + correccionPreviews.length < 5 && (
                    <label className="border border-dashed border-[#CBD5E1] hover:border-[#047857] rounded-lg aspect-square flex flex-col items-center justify-center cursor-pointer bg-white hover:bg-slate-50 transition-colors text-[#475569] hover:text-[#0F172A]">
                      <Upload className="w-4 h-4 mb-1 text-[#047857]" />
                      <span className="text-[9px] text-center px-1 font-semibold">Agregar</span>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        capture="environment"
                        onChange={handleCorreccionFilesSelected}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>

                {isCompressingCorr && (
                  <span className="text-[11px] text-[#B45309] font-semibold animate-pulse block">
                    Comprimiendo fotos de corrección para Google Drive...
                  </span>
                )}
              </div>

              <div className="pt-3 border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsSeguimientoModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-[#475569] font-semibold text-xs border border-[#CBD5E1] cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-bold text-xs transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                >
                  <Save className="w-4 h-4 text-white" />
                  <span>Guardar Levantamiento</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL FICHA DETALLADA DE INSPECCIÓN */}
      {viewDetailModal && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewDetailModal(null);
          }}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="fixed inset-0 -z-10 cursor-pointer"
            onClick={() => setViewDetailModal(null)}
            aria-hidden="true"
          />

          <div
            className="relative z-10 bg-white border border-[#CBD5E1] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-[#0F172A] cursor-default select-text"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header del modal fijo */}
            <div className="sticky top-0 z-20 px-6 py-4 bg-[#F8FAFC] border-b border-[#E2E8F0] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-200 shrink-0">
                  <ClipboardCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-base font-bold text-[#0F172A] truncate">
                    Ficha de Inspección SST — {viewDetailModal.codigoInspeccion}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium truncate">
                    {viewDetailModal.empresa} • {viewDetailModal.area}{viewDetailModal.lugarEspecifico ? ` • ${viewDetailModal.lugarEspecifico}` : ''} • Fecha: {viewDetailModal.fecha}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewDetailModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
                title="Cerrar ficha (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Contenido con scroll independiente */}
            <div className="p-6 space-y-4 text-xs text-[#475569] overflow-y-auto flex-1">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0]">
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Tipo Hallazgo</span>
                  <span className="text-[#0F172A] font-bold">{viewDetailModal.tipo}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Potencial Gravedad</span>
                  <span className="text-amber-800 font-bold font-mono">P.G. {viewDetailModal.potencialGravedad} ({viewDetailModal.prioridad})</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Fecha Compromiso</span>
                  <span className="text-sky-800 font-mono font-medium">{viewDetailModal.fechaCompromiso}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Estado</span>
                  <span className={`font-bold ${viewDetailModal.estado === 'Subsanado' ? 'text-[#047857]' : 'text-amber-700'}`}>
                    {viewDetailModal.estado}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[#0F172A] font-bold block mb-1">Descripción del Hallazgo / Desvío:</span>
                <p className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] text-[#0F172A] leading-relaxed text-sm">
                  {viewDetailModal.hallazgo}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] space-y-1.5">
                  <span className="text-[#475569] text-[10px] uppercase font-bold block mb-1">Responsables</span>
                  <div className="text-[#0F172A]">
                    <span className="text-[#475569]">Inspector: </span>
                    <span className="text-[#0F172A] font-bold">{viewDetailModal.responsableInspeccion}</span>
                  </div>
                  {viewDetailModal.responsableLevantamiento && (
                    <div className="text-[#0F172A] mt-1">
                      <span className="text-[#475569]">Resp. Levantamiento: </span>
                      <span className="text-[#047857] font-bold">{viewDetailModal.responsableLevantamiento}</span>
                    </div>
                  )}
                </div>

                <div className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] space-y-1.5">
                  <span className="text-[#475569] text-[10px] uppercase font-bold block mb-1">Plan de Acción / Cierre</span>
                  <div className="text-[#0F172A]">
                    <span className="text-[#475569]">Acción Correctiva: </span>
                    <span className="text-[#0F172A] font-medium">{viewDetailModal.accionCorrectiva || 'Pendiente de registrar'}</span>
                  </div>
                  {viewDetailModal.fechaCierre && (
                    <div className="text-[#0F172A] mt-1">
                      <span className="text-[#475569]">Fecha Cierre: </span>
                      <span className="text-[#047857] font-mono font-bold">{viewDetailModal.fechaCierre}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Fotografías Iniciales */}
              {Array.isArray(viewDetailModal.evidenciasIniciales) && viewDetailModal.evidenciasIniciales.filter((u) => Boolean(u && typeof u === 'string' && u.trim().length > 0)).length > 0 && (
                <div>
                  <span className="text-slate-700 font-semibold block mb-1.5 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-sky-600" />
                    <span>Evidencias Fotográficas Iniciales:</span>
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(viewDetailModal.evidenciasIniciales || [])
                      .filter((url): url is string => Boolean(url && typeof url === 'string' && url.trim().length > 0))
                      .map((url, idx) => (
                        <div key={idx} className="rounded-lg overflow-hidden border border-slate-200 bg-slate-100 h-28 flex items-center justify-center p-1">
                          <DriveImage
                            src={url}
                            alt={`Evidencia inicial ${idx + 1}`}
                            className="max-h-full max-w-full object-contain rounded"
                            onClick={() =>
                              setLightboxImage({
                                url,
                                title: `Evidencia Inicial #${idx + 1} - ${viewDetailModal.codigoInspeccion}`,
                                subtitle: viewDetailModal.hallazgo
                              })
                            }
                          />
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Fotografías de Corrección */}
              {Array.isArray(viewDetailModal.evidenciasCorreccion) && viewDetailModal.evidenciasCorreccion.filter((u) => Boolean(u && typeof u === 'string' && u.trim().length > 0)).length > 0 && (
                <div>
                  <span className="text-slate-700 font-semibold block mb-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Evidencias Fotográficas de Subsanación / Cierre:</span>
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(viewDetailModal.evidenciasCorreccion || [])
                      .filter((url): url is string => Boolean(url && typeof url === 'string' && url.trim().length > 0))
                      .map((url, idx) => (
                        <div key={idx} className="rounded-lg overflow-hidden border border-slate-200 bg-slate-100 h-28 flex items-center justify-center p-1">
                          <DriveImage
                            src={url}
                            alt={`Evidencia cierre ${idx + 1}`}
                            className="max-h-full max-w-full object-contain rounded"
                            onClick={() =>
                              setLightboxImage({
                                url,
                                title: `Evidencia Cierre #${idx + 1} - ${viewDetailModal.codigoInspeccion}`,
                                subtitle: viewDetailModal.accionCorrectiva || viewDetailModal.hallazgo
                              })
                            }
                          />
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-slate-500 font-mono">ID: {viewDetailModal.id}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const r = viewDetailModal;
                    setViewDetailModal(null);
                    handleOpenSeguimiento(r);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-emerald-700 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 cursor-pointer"
                >
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Gestionar Levantamiento</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewDetailModal(null)}
                  className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de confirmación para eliminar inspección */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalInspeccion)}
        onClose={() => setDeleteModalInspeccion(null)}
        onConfirm={confirmDeleteInspeccion}
        title="Eliminar Inspección SST"
        message="¿Estás seguro de que deseas eliminar este registro de inspección y hallazgo?"
        itemIdentifier={
          deleteModalInspeccion
            ? `${deleteModalInspeccion.codigoInspeccion}: ${deleteModalInspeccion.area} (${deleteModalInspeccion.hallazgo})`
            : undefined
        }
        confirmButtonText="Eliminar Inspección"
      />

      {/* Visor de fotos Lightbox */}
      <ImageLightboxModal
        isOpen={Boolean(lightboxImage)}
        onClose={() => setLightboxImage(null)}
        imageUrl={lightboxImage?.url}
        title={lightboxImage?.title}
        subtitle={lightboxImage?.subtitle}
      />
    </div>
  );
};
