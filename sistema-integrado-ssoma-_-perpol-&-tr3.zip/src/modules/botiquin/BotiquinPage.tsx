import React, { useState, useMemo } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore } from '../../store/appStore';
import { ConsumoBotiquinRecord } from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { DriveStorageService } from '../../services/driveService';
import { ExportUtils } from '../../utils/exportUtils';
import { ModuleToolbar, FilterChipOption } from '../../components/common/ModuleToolbar';
import { TablePagination } from '../../components/common/TablePagination';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import { CATALOGO_INSUMOS_BOTIQUIN, TURNOS_TRABAJO, AREAS_EMPRESA, LUGARES_ESPECIFICOS } from '../../utils/ssomaCatalogs';
import { useNavigate } from 'react-router-dom';
import { DriveImage } from '../../components/common/DriveImage';
import {
  Cross,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Eye,
  Camera,
  Edit2,
  Trash2,
  X,
  Save,
  Activity,
  Pill,
  Link as LinkIcon,
  Send,
  User,
  ShieldAlert,
  HelpCircle,
  ExternalLink,
  RefreshCw,
  Check
} from 'lucide-react';

interface ElementoFormRow {
  item: string;
  cantidad: number;
  unidad: string;
}

export const BotiquinPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    empresaActiva,
    trabajadores,
    inspecciones,
    consumosBotiquin,
    upsertConsumoBotiquin,
    batchUpsertConsumosBotiquin,
    removeConsumoBotiquin,
    marcarAtencionTransferida,
    vincularAtencionAInspeccion,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  // Estados de vista y filtrado
  const [searchTerm, setSearchTerm] = useState('');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [tipoFilter, setTipoFilter] = useState<'TODOS' | 'Incidente' | 'Accidente' | 'Enfermedad común'>('TODOS');
  const [transferenciaFilter, setTransferenciaFilter] = useState<'TODOS' | 'Pendiente' | 'Validado' | 'Descartado'>('TODOS');
  const [areaFilter, setAreaFilter] = useState<string>('TODOS');
  const [fechaDesde, setFechaDesde] = useState('');
  const [fechaHasta, setFechaHasta] = useState('');

  // Modales
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewDetailModal, setViewDetailModal] = useState<ConsumoBotiquinRecord | null>(null);
  const [deleteModalAtencion, setDeleteModalAtencion] = useState<ConsumoBotiquinRecord | null>(null);
  const [editingRecord, setEditingRecord] = useState<ConsumoBotiquinRecord | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Selector reactivo de autocompletado de trabajadores
  const [workerSearchTerm, setWorkerSearchTerm] = useState('');
  const [isWorkerDropdownOpen, setIsWorkerDropdownOpen] = useState(false);

  // Selector reactivo de autocompletado de brigadista / responsable de atención
  const [atendidoSearchTerm, setAtendidoSearchTerm] = useState('');
  const [isAtendidoDropdownOpen, setIsAtendidoDropdownOpen] = useState(false);

  // Formulario principal
  const [formData, setFormData] = useState<Partial<ConsumoBotiquinRecord>>({
    fecha: new Date().toISOString().slice(0, 10),
    hora: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    tipoAtencion: 'Incidente',
    personaAtendida: '',
    dniPersona: '',
    puesto: '',
    area: '',
    lugarEspecifico: '',
    turno: 'Mañana',
    lesionesSintomas: '',
    procedimientoAplicado: '',
    atendidoPor: '',
    inspeccionVinculadaId: '',
    inspeccionVinculadaCodigo: '',
    inspeccionVinculadaDetalle: ''
  });

  // Lista dinámica de insumos consumidos
  const [elementosList, setElementosList] = useState<ElementoFormRow[]>([
    { item: 'Gasa estéril fraccionada (10x10 cm)', cantidad: 1, unidad: 'Sobres' }
  ]);

  // Manejo de imagen de evidencia
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Filtrado de lista por empresa activa y filtros de búsqueda
  const filteredConsumos = useMemo(() => {
    return consumosBotiquin.filter((item) => {
      // Filtro por empresa
      if (empresaActiva !== 'CONSOLIDADO' && item.empresa !== empresaActiva) {
        return false;
      }
      // Filtro por tipo de atención
      if (tipoFilter !== 'TODOS' && item.tipoAtencion !== tipoFilter) {
        return false;
      }
      // Filtro por estado de transferencia
      if (transferenciaFilter !== 'TODOS') {
        const estado = item.estadoValidacion || 'Pendiente';
        if (estado !== transferenciaFilter) return false;
      }
      // Filtro por área
      if (areaFilter !== 'TODOS' && item.area !== areaFilter) {
        return false;
      }
      // Filtro por fecha
      if (fechaDesde && item.fecha < fechaDesde) return false;
      if (fechaHasta && item.fecha > fechaHasta) return false;

      // Filtro por texto
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchCode = String(item.codigoAtencion || '').toLowerCase().includes(q);
        const matchWorker = String(item.personaAtendida || '').toLowerCase().includes(q);
        const matchDni = String(item.dniPersona || '').toLowerCase().includes(q);
        const matchArea = String(item.area || '').toLowerCase().includes(q);
        const matchSintoma = String(item.lesionesSintomas || '').toLowerCase().includes(q);
        if (!matchCode && !matchWorker && !matchDni && !matchArea && !matchSintoma) {
          return false;
        }
      }

      return true;
    });
  }, [consumosBotiquin, empresaActiva, tipoFilter, transferenciaFilter, areaFilter, fechaDesde, fechaHasta, searchTerm]);

  // Métricas para tarjetas de resumen
  const metricas = useMemo(() => {
    const list = consumosBotiquin.filter(
      (c) => empresaActiva === 'CONSOLIDADO' || c.empresa === empresaActiva
    );
    const total = list.length;
    const incidentes = list.filter((c) => c.tipoAtencion === 'Incidente').length;
    const accidentes = list.filter((c) => c.tipoAtencion === 'Accidente').length;
    const enfermedadComun = list.filter((c) => c.tipoAtencion === 'Enfermedad común').length;
    const pendientesTransferencia = list.filter(
      (c) => (c.tipoAtencion === 'Incidente' || c.tipoAtencion === 'Accidente') && !c.transferidoAccidentes
    ).length;
    const vinculadosInspeccion = list.filter((c) => !!c.inspeccionVinculadaId).length;

    const totalInsumos = list.reduce((acc, c) => {
      if (Array.isArray(c.elementosConsumidos)) {
        return acc + c.elementosConsumidos.reduce((sub, el) => sub + (Number(el.cantidad) || 0), 0);
      }
      return acc;
    }, 0);

    return {
      total,
      incidentes,
      accidentes,
      enfermedadComun,
      pendientesTransferencia,
      vinculadosInspeccion,
      totalInsumos
    };
  }, [consumosBotiquin, empresaActiva]);

  // Paginación y chips de tipo de atención
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const statusOptions: FilterChipOption[] = useMemo(() => {
    const list = consumosBotiquin.filter((c) => empresaActiva === 'CONSOLIDADO' || c.empresa === empresaActiva);
    return [
      { id: 'TODOS', label: 'Todos', count: list.length },
      { id: 'Incidente', label: 'Incidentes', count: list.filter((c) => c.tipoAtencion === 'Incidente').length },
      { id: 'Accidente', label: 'Accidentes', count: list.filter((c) => c.tipoAtencion === 'Accidente').length },
      { id: 'Enfermedad común', label: 'Enf. Común', count: list.filter((c) => c.tipoAtencion === 'Enfermedad común').length }
    ];
  }, [consumosBotiquin, empresaActiva]);

  const paginatedConsumos = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredConsumos.slice(start, start + pageSize);
  }, [filteredConsumos, currentPage, pageSize]);

  // Lista de trabajadores activos para autocompletado reactivo
  const trabajadoresFiltrados = useMemo(() => {
    return trabajadores
      .filter((t) => {
        if (t.condicion !== 'Activo') return false;
        if (formData.empresa && t.empresa !== formData.empresa) return false;
        if (!workerSearchTerm.trim()) return true;
        const q = workerSearchTerm.toLowerCase();
        return (
          String(t.apellidosNombres || '').toLowerCase().includes(q) ||
          String(t.dni || '').includes(q) ||
          String(t.puesto || '').toLowerCase().includes(q)
        );
      })
      .slice(0, 15);
  }, [trabajadores, formData.empresa, workerSearchTerm]);

  // Lista de brigadistas / responsables de atención para autocompletado reactivo
  const brigadistasFiltrados = useMemo(() => {
    return trabajadores
      .filter((t) => {
        if (t.condicion !== 'Activo') return false;
        if (!atendidoSearchTerm.trim()) return true;
        const q = atendidoSearchTerm.toLowerCase();
        return (
          String(t.apellidosNombres || '').toLowerCase().includes(q) ||
          String(t.dni || '').includes(q) ||
          String(t.puesto || '').toLowerCase().includes(q) ||
          String(t.area || '').toLowerCase().includes(q)
        );
      })
      .slice(0, 20);
  }, [trabajadores, atendidoSearchTerm]);

  // Lista de inspecciones sincronizadas desde Zustand
  const effectiveInspecciones = useMemo(() => {
    return Array.isArray(inspecciones) ? inspecciones : [];
  }, [inspecciones]);

  // Opciones de inspecciones disponibles para vinculación (Módulo 2)
  const inspectionAssociationOptions = useMemo(() => {
    return [...effectiveInspecciones].sort((a, b) => {
      // Priorizar las de la empresa actualmente seleccionada en el formulario
      if (formData.empresa) {
        if (a.empresa === formData.empresa && b.empresa !== formData.empresa) return -1;
        if (a.empresa !== formData.empresa && b.empresa === formData.empresa) return 1;
      }
      return (b.fecha || '').localeCompare(a.fecha || '');
    });
  }, [effectiveInspecciones, formData.empresa]);

  // Inspección actualmente vinculada en el formulario
  const selectedLinkedInspection = useMemo(() => {
    if (!formData.inspeccionVinculadaId) return null;
    return (
      effectiveInspecciones.find(
        (i) =>
          String(i.id || '') === String(formData.inspeccionVinculadaId) ||
          String(i.codigoInspeccion || '') === String(formData.inspeccionVinculadaId) ||
          (formData.inspeccionVinculadaCodigo && String(i.codigoInspeccion || '') === String(formData.inspeccionVinculadaCodigo))
      ) || null
    );
  }, [formData.inspeccionVinculadaId, formData.inspeccionVinculadaCodigo, effectiveInspecciones]);

  // Manejador para abrir modal en modo nuevo
  const handleNuevo = () => {
    setEditingRecord(null);
    setFormData({
      fecha: new Date().toISOString().slice(0, 10),
      hora: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
      tipoAtencion: 'Incidente',
      personaAtendida: '',
      dniPersona: '',
      puesto: '',
      area: '',
      lugarEspecifico: '',
      turno: 'Mañana',
      lesionesSintomas: '',
      procedimientoAplicado: '',
      atendidoPor: '',
      inspeccionVinculadaId: '',
      inspeccionVinculadaCodigo: '',
      inspeccionVinculadaDetalle: ''
    });
    setElementosList([{ item: 'Gasa estéril fraccionada (10x10 cm)', cantidad: 1, unidad: 'Sobres' }]);
    setImageFile(null);
    setImagePreview(null);
    setFormError(null);
    setWorkerSearchTerm('');
    setIsWorkerDropdownOpen(false);
    setAtendidoSearchTerm('');
    setIsAtendidoDropdownOpen(false);
    setIsModalOpen(true);
  };

  // Manejador para abrir modal en modo edición
  const handleEditar = (record: ConsumoBotiquinRecord) => {
    setEditingRecord(record);
    setFormData({
      ...record
    });
    if (Array.isArray(record.elementosConsumidos) && record.elementosConsumidos.length > 0) {
      setElementosList(record.elementosConsumidos);
    } else {
      setElementosList([{ item: 'Gasa estéril fraccionada (10x10 cm)', cantidad: 1, unidad: 'Sobres' }]);
    }
    setImageFile(null);
    setImagePreview(record.fotoUrl || null);
    setFormError(null);
    setWorkerSearchTerm(record.personaAtendida);
    setIsWorkerDropdownOpen(false);
    setAtendidoSearchTerm(record.atendidoPor || '');
    setIsAtendidoDropdownOpen(false);
    setIsModalOpen(true);
  };

  // Selección de trabajador desde el menú de autocompletado
  const handleSelectTrabajador = (trabajador: (typeof trabajadores)[0]) => {
    setFormData((prev) => ({
      ...prev,
      personaAtendida: String(trabajador.apellidosNombres || ''),
      dniPersona: String(trabajador.dni || ''),
      puesto: String(trabajador.puesto || ''),
      area: String(trabajador.area || ''),
      empresa: trabajador.empresa
    }));
    setWorkerSearchTerm(String(trabajador.apellidosNombres || ''));
    setIsWorkerDropdownOpen(false);
  };

  // Selección e HERENCIA INTEGRAL de datos desde Inspección SST (Módulo 2)
  const handleSelectInspeccion = (selId: string) => {
    if (!selId) {
      setFormData((prev) => ({
        ...prev,
        inspeccionVinculadaId: '',
        inspeccionVinculadaCodigo: '',
        inspeccionVinculadaDetalle: ''
      }));
      return;
    }

    const insp =
      inspectionAssociationOptions.find(
        (i) => String(i.id || '') === selId || String(i.codigoInspeccion || '') === selId
      ) ||
      effectiveInspecciones.find(
        (i) => String(i.id || '') === selId || String(i.codigoInspeccion || '') === selId
      );

    if (insp) {
      const code = insp.codigoInspeccion || String(insp.id || '');
      const detail = insp.hallazgo || '';

      setFormData((prev) => {
        const next: Partial<ConsumoBotiquinRecord> = {
          ...prev,
          inspeccionVinculadaId: insp.id || insp.codigoInspeccion,
          inspeccionVinculadaCodigo: code,
          inspeccionVinculadaDetalle: detail
        };

        // 1. Heredar Empresa de la inspección
        if (insp.empresa) {
          next.empresa = insp.empresa;
        }

        // 2. Heredar Fecha de la inspección
        if (insp.fecha) {
          next.fecha = insp.fecha;
        }

        // 3. Heredar Área de trabajo y Lugar Específico de la inspección
        if (insp.area) {
          next.area = insp.area;
        }
        if (insp.lugarEspecifico) {
          next.lugarEspecifico = insp.lugarEspecifico;
        }

        // 4. Heredar Tipo de Atención según la naturaleza del evento
        if (insp.tipo === 'Acto inseguro' || insp.tipo === 'Condición insegura' || insp.tipo === 'No conformidad') {
          if (prev.tipoAtencion === 'Enfermedad común' || !prev.tipoAtencion) {
            next.tipoAtencion = 'Incidente';
          }
        }

        // 5. Heredar Lesiones / Síntomas o descripción del hallazgo
        if (!prev.lesionesSintomas || prev.lesionesSintomas.trim() === '') {
          next.lesionesSintomas = detail;
        }

        // 6. Heredar Procedimiento Médico / Medida preventiva según acción correctiva
        if (!prev.procedimientoAplicado || prev.procedimientoAplicado.trim() === '') {
          if (insp.accionCorrectiva && insp.accionCorrectiva.trim() !== '') {
            next.procedimientoAplicado = `Atención preventiva según SST: ${insp.accionCorrectiva}`;
          }
        }

        // 7. Heredar Fotografía de evidencia si la inspección cuenta con foto y no se subió una
        if (Array.isArray(insp.evidenciasIniciales) && insp.evidenciasIniciales.length > 0) {
          if (!prev.fotoUrl && !imageFile) {
            next.fotoUrl = insp.evidenciasIniciales[0];
          }
        }

        return next;
      });

      // Si la inspección tiene evidencia y no se ha cargado archivo manual, actualizar preview
      if (Array.isArray(insp.evidenciasIniciales) && insp.evidenciasIniciales.length > 0 && !imageFile && !imagePreview) {
        setImagePreview(insp.evidenciasIniciales[0]);
      }

      addToast({
        type: 'success',
        title: 'Inspección Vinculada',
        message: `Se heredaron los datos de ${code}: Empresa (${insp.empresa || 'N/A'}), Fecha (${insp.fecha || 'N/A'}), Área (${insp.area || 'N/A'})${detail ? ' y Hallazgo.' : '.'}`
      });
    }
  };

  // Re-aplicar forzosamente todos los datos de la inspección vinculada al formulario
  const handleReaplicarDatosInspeccion = () => {
    if (!selectedLinkedInspection) return;
    const insp = selectedLinkedInspection;
    setFormData((prev) => ({
      ...prev,
      empresa: insp.empresa || prev.empresa,
      fecha: insp.fecha || prev.fecha,
      area: insp.area || prev.area,
      lesionesSintomas: insp.hallazgo || prev.lesionesSintomas,
      procedimientoAplicado: insp.accionCorrectiva
        ? `Atención preventiva según SST: ${insp.accionCorrectiva}`
        : prev.procedimientoAplicado,
      inspeccionVinculadaId: insp.id || insp.codigoInspeccion,
      inspeccionVinculadaCodigo: insp.codigoInspeccion,
      inspeccionVinculadaDetalle: insp.hallazgo || '',
      tipoAtencion:
        insp.tipo === 'Condición insegura' || insp.tipo === 'Acto inseguro'
          ? (prev.tipoAtencion === 'Enfermedad común' ? 'Incidente' : prev.tipoAtencion || 'Incidente')
          : prev.tipoAtencion || 'Incidente'
    }));

    if (Array.isArray(insp.evidenciasIniciales) && insp.evidenciasIniciales.length > 0 && !imageFile) {
      setImagePreview(insp.evidenciasIniciales[0]);
    }

    addToast({
      type: 'info',
      title: 'Datos Re-aplicados',
      message: 'Se han re-sincronizado los campos del formulario con la inspección vinculada.'
    });
  };

  const handleCopiarHallazgoSintomas = (detail: string) => {
    setFormData((prev) => ({ ...prev, lesionesSintomas: detail }));
    addToast({
      type: 'info',
      title: 'Hallazgo Copiado',
      message: 'El hallazgo de la inspección se copió al campo de Lesiones o Síntomas.'
    });
  };

  const handleCopiarAccionProcedimiento = (accion: string) => {
    setFormData((prev) => ({ ...prev, procedimientoAplicado: `Atención preventiva según SST: ${accion}` }));
    addToast({
      type: 'info',
      title: 'Acción Copiada',
      message: 'La acción correctiva se copió al campo de Procedimiento Médico.'
    });
  };

  // Gestión de filas de insumos consumidos
  const handleAddElemento = () => {
    setElementosList((prev) => [
      ...prev,
      { item: 'Apósitos / Curitas adhesivas estándar', cantidad: 1, unidad: 'Unidades' }
    ]);
  };

  const handleRemoveElemento = (index: number) => {
    if (elementosList.length <= 1) {
      addToast({
        type: 'warning',
        title: 'Requisito de Insumos',
        message: 'Debe registrar al menos un elemento o medicamento suministrado en la atención.'
      });
      return;
    }
    setElementosList((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleUpdateElemento = (index: number, field: keyof ElementoFormRow, value: string | number) => {
    setElementosList((prev) => {
      const updated = [...prev];
      if (field === 'cantidad') {
        updated[index] = { ...updated[index], cantidad: Math.max(1, Number(value) || 1) };
      } else if (field === 'item') {
        const itemCatalog = CATALOGO_INSUMOS_BOTIQUIN.find((c) => c.nombre === value);
        updated[index] = {
          ...updated[index],
          item: String(value),
          unidad: itemCatalog ? itemCatalog.unidad : updated[index].unidad
        };
      } else if (field === 'unidad') {
        updated[index] = { ...updated[index], unidad: String(value) };
      }
      return updated;
    });
  };

  // Manejo de carga de imagen fotográfica
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      addToast({ type: 'error', title: 'Archivo Inválido', message: 'Debe seleccionar un archivo de imagen (JPG, PNG, WebP).' });
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      addToast({ type: 'error', title: 'Archivo Muy Pesado', message: 'La imagen excede el límite de 8 MB.' });
      return;
    }

    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Guardado de la atención médica (Frontend + Google Apps Script + Google Drive)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validaciones estrictas
    if (!String(formData.personaAtendida || '').trim() || !String(formData.dniPersona || '').trim()) {
      setFormError('Debe seleccionar al trabajador atendido utilizando el buscador.');
      return;
    }
    if (!String(formData.area || '').trim()) {
      setFormError('El área de ocurrencia es obligatoria.');
      return;
    }
    if (!String(formData.lugarEspecifico || '').trim()) {
      setFormError('El lugar físico específico es obligatorio.');
      return;
    }
    if (!String(formData.lesionesSintomas || '').trim()) {
      setFormError('Especifique las lesiones o sintomatología atendida.');
      return;
    }
    if (!String(formData.procedimientoAplicado || '').trim()) {
      setFormError('Detalle el procedimiento médico, curación o indicación brindada.');
      return;
    }

    // Validar insumos
    const validElementos = elementosList.filter((el) => String(el.item || '').trim() && el.cantidad >= 1);
    if (validElementos.length === 0) {
      setFormError('Debe incluir al menos un insumo médico o material de curación consumido.');
      return;
    }

    setIsSubmitting(true);
    incrementSync();

    try {
      let finalFotoUrl = formData.fotoUrl;
      let finalFotoDriveId = formData.fotoDriveId;

      // Subida de imagen comprimida a Google Drive si se adjuntó archivo nuevo
      if (imageFile) {
        addToast({ type: 'info', title: 'Optimizando Imagen', message: 'Comprimiendo fotografía para Google Drive...' });
        const uploadRes = await DriveStorageService.uploadToDrive(imageFile, {
          modulo: 'botiquin',
          fileName: `Botiquin_${formData.empresa}_${Date.now()}.jpg`,
          maxDimension: 1200,
          quality: 0.75
        });

        if (uploadRes.fileUrl) {
          finalFotoUrl = uploadRes.fileUrl;
          finalFotoDriveId = uploadRes.fileId;
        }
      }

      // Generar código y datos completos
      const anio = new Date().getFullYear();
      const totalAnio = consumosBotiquin.filter((b) => {
        const f = b.fecha || '';
        return f.startsWith(String(anio)) || (b.codigoAtencion && b.codigoAtencion.includes(`-${anio}-`));
      }).length;
      const correlativoCodigo =
        editingRecord?.codigoAtencion ||
        `BOT-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;

      // Regla de negocio: "Enfermedad común" no genera eventos estadísticos SST
      const esEnfermedadComun = formData.tipoAtencion === 'Enfermedad común';
      const estadoValidacion = esEnfermedadComun
        ? 'Descartado'
        : editingRecord?.estadoValidacion || 'Pendiente';
      const transferidoAccidentes = esEnfermedadComun
        ? false
        : editingRecord?.transferidoAccidentes || false;

      const fullRecord: ConsumoBotiquinRecord = {
        id: editingRecord?.id || correlativoCodigo,
        codigoAtencion: correlativoCodigo,
        empresa: formData.empresa as 'PERPOL' | 'TR3',
        fecha: formData.fecha || new Date().toISOString().slice(0, 10),
        hora: formData.hora || '10:00',
        tipoAtencion: formData.tipoAtencion as 'Incidente' | 'Accidente' | 'Enfermedad común',
        personaAtendida: formData.personaAtendida!,
        dniPersona: formData.dniPersona!,
        puesto: formData.puesto || '',
        area: formData.area || '',
        lugarEspecifico: String(formData.lugarEspecifico || '').trim() || undefined,
        turno: formData.turno || 'Mañana',
        lesionesSintomas: formData.lesionesSintomas!,
        procedimientoAplicado: formData.procedimientoAplicado!,
        elementosConsumidos: validElementos,
        atendidoPor: formData.atendidoPor || 'Tópico SSOMA',
        inspeccionVinculadaId: formData.inspeccionVinculadaId || undefined,
        inspeccionVinculadaCodigo: formData.inspeccionVinculadaCodigo || undefined,
        inspeccionVinculadaDetalle: formData.inspeccionVinculadaDetalle || undefined,
        fotoUrl: finalFotoUrl,
        fotoDriveId: finalFotoDriveId,
        transferidoAccidentes,
        estadoValidacion,
        casoAccidenteId: editingRecord?.casoAccidenteId,
        createdAt: editingRecord?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // 1. Optimistic update en Zustand
      upsertConsumoBotiquin(fullRecord);

      // 2. Si se vinculó una inspección, actualizar en Módulo 2
      if (fullRecord.inspeccionVinculadaId) {
        const atnResumen = `${fullRecord.codigoAtencion}: ${fullRecord.tipoAtencion} - ${fullRecord.personaAtendida} (${fullRecord.lesionesSintomas})`;
        vincularAtencionAInspeccion(fullRecord.inspeccionVinculadaId, atnResumen);
      }

      // 3. Persistir en Google Apps Script
      const apiRes = await GasApiClient.sendRequest({
        action: 'saveConsumoBotiquin',
        sheetName: 'SSOMA_Botiquin',
        data: fullRecord
      });

      if (!apiRes.success) {
        addToast({
          type: 'warning',
          title: 'Almacenado Local',
          message: 'Atención guardada en caché local. Pendiente de sincronización con Sheets.'
        });
      } else {
        addToast({
          type: 'success',
          title: 'Atención Registrada',
          message: `Código ${correlativoCodigo} guardado en Google Sheets exitosamente.`
        });
      }

      setIsModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error inesperado al registrar atención';
      setFormError(msg);
      addToast({ type: 'error', title: 'Error de Guardado', message: msg });
    } finally {
      setIsSubmitting(false);
      decrementSync();
    }
  };

  // Eliminación con confirmación modal
  const confirmDeleteAtencion = async () => {
    if (!deleteModalAtencion) return;
    const record = deleteModalAtencion;

    removeConsumoBotiquin(record.id);
    addToast({ type: 'info', title: 'Registro Eliminado', message: `Atención ${record.codigoAtencion} eliminada.` });

    try {
      await GasApiClient.sendRequest({
        action: 'deleteConsumoBotiquin',
        sheetName: 'SSOMA_Botiquin',
        id: record.id
      });
    } catch {
      // Ignorar fallback
    } finally {
      setDeleteModalAtencion(null);
    }
  };

  // Transferencia rápida al Módulo 1 (Accidentes / Incidentes)
  const handleTransferirAModulo1 = (record: ConsumoBotiquinRecord) => {
    if (record.tipoAtencion === 'Enfermedad común') {
      addToast({
        type: 'warning',
        title: 'Regla de Negocio',
        message: 'Las atenciones por Enfermedad común no generan eventos estadísticos ni investigación de accidentes.'
      });
      return;
    }

    marcarAtencionTransferida(record.id);
    addToast({
      type: 'success',
      title: 'Transferido a Módulo 1',
      message: `Atención ${record.codigoAtencion} disponible en la bandeja de entrada de Accidentes/Incidentes.`
    });
    // Navegar automáticamente a Accidentes
    navigate('/accidentes');
  };

  // Exportaciones
  const handleExportarExcel = () => {
    const dataToExport = filteredConsumos.map((c) => ({
      'Código Atención': c.codigoAtencion,
      Empresa: c.empresa,
      Fecha: c.fecha,
      Hora: c.hora || '',
      'Tipo de Atención': c.tipoAtencion,
      'Trabajador Atendido': c.personaAtendida,
      DNI: c.dniPersona,
      Puesto: c.puesto,
      Área: c.area,
      Turno: c.turno,
      'Lesiones / Síntomas': c.lesionesSintomas,
      'Procedimiento Aplicado': c.procedimientoAplicado,
      'Insumos Dispensados': (c.elementosConsumidos || []).map((el) => `${el.item} (${el.cantidad} ${el.unidad})`).join('; '),
      'Inspección Vinculada': c.inspeccionVinculadaCodigo || 'Ninguna',
      'Atendido Por': c.atendidoPor,
      'Transferido a Accidentes': c.transferidoAccidentes ? 'SÍ' : 'NO',
      'Estado Validación': c.estadoValidacion || 'Pendiente'
    }));

    ExportUtils.exportToExcel(dataToExport, `SSOMA_Consumo_Botiquin_${empresaActiva}_${new Date().toISOString().slice(0, 10)}`);
    addToast({ type: 'success', title: 'Exportación Excel', message: 'Reporte de atenciones de botiquín generado.' });
  };

  const handleExportarPDF = () => {
    ExportUtils.exportToPdf({
      title: 'REGISTRO DE ATENCIONES DE PRIMEROS AUXILIOS Y CONSUMO DE BOTIQUÍN',
      subtitle: `Empresa: ${empresaActiva} | Atenciones: ${filteredConsumos.length}`,
      empresa: empresaActiva,
      fileName: `Consumo_Botiquin_${empresaActiva}`,
      headers: ['Código', 'Fecha/Hora', 'Empresa', 'Tipo', 'Colaborador (DNI)', 'Área', 'Lesiones / Síntomas', 'Atendido Por'],
      rows: filteredConsumos.map((c) => [
        c.codigoAtencion,
        `${c.fecha} ${c.hora || ''}`.trim(),
        c.empresa,
        c.tipoAtencion,
        `${c.personaAtendida} (${c.dniPersona})`,
        c.area,
        c.lesionesSintomas,
        c.atendidoPor
      ]),
      orientation: 'landscape'
    });
    addToast({ type: 'success', title: 'Reporte PDF Generado', message: 'El PDF fue generado y descargado correctamente.' });
  };

  return (
    <div className="space-y-6">
      {/* Encabezado estandarizado */}
      <ModuleHeader
        codigo={5}
        titulo="Consumo de Botiquín y Primeros Auxilios"
        subtitulo="Control de atenciones de tópica, lesiones atendidas, insumos suministrados y vinculación con inspecciones SST"
        icono={<Cross className="w-5 h-5 text-teal-400" />}
        onNuevo={handleNuevo}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.botiquin}
        onImportSuccess={(rows) => {
          batchUpsertConsumosBotiquin(rows as any);
        }}
      />

      {/* Tarjetas KPI */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Total Atenciones</span>
            <Activity className="w-4 h-4 text-[#047857]" />
          </div>
          <div className="text-2xl font-bold text-[#0F172A] mt-2">{metricas.total}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">Registradas en tópico</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Incidentes</span>
            <span className="w-2.5 h-2.5 rounded-full bg-[#D97706]"></span>
          </div>
          <div className="text-2xl font-bold text-[#B45309] mt-2">{metricas.incidentes}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">Eventos leves sin daño</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Accidentes</span>
            <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626]"></span>
          </div>
          <div className="text-2xl font-bold text-[#DC2626] mt-2">{metricas.accidentes}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">Lesiones laborales</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Enf. Común</span>
            <span className="w-2.5 h-2.5 rounded-full bg-[#0284C7]"></span>
          </div>
          <div className="text-2xl font-bold text-[#0284C7] mt-2">{metricas.enfermedadComun}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">No genera evento SST</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Insumos Totales</span>
            <Pill className="w-4 h-4 text-[#047857]" />
          </div>
          <div className="text-2xl font-bold text-[#047857] mt-2">{metricas.totalInsumos}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">Items dispensados</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
          <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
            <span>Pend. Módulo 1</span>
            <Send className="w-4 h-4 text-[#B45309]" />
          </div>
          <div className="text-2xl font-bold text-[#B45309] mt-2">{metricas.pendientesTransferencia}</div>
          <div className="text-[11px] text-[#475569] mt-1 font-medium">Para validar caso</div>
        </div>
      </div>

      {/* Barra de Filtros y Búsqueda Estandarizada */}
      <ModuleToolbar
        searchQuery={searchTerm}
        onSearchChange={(val) => {
          setSearchTerm(val);
          setCurrentPage(1);
        }}
        searchPlaceholder="Buscar por trabajador, DNI, código de atención (BOT-...), área o lesión..."
        statusFilter={tipoFilter}
        onStatusFilterChange={(id) => {
          setTipoFilter(id as any);
          setCurrentPage(1);
        }}
        statusOptions={statusOptions}
        totalCount={consumosBotiquin.filter((c) => empresaActiva === 'CONSOLIDADO' ? true : c.empresa === empresaActiva).length}
        filteredCount={filteredConsumos.length}
        onExportExcel={handleExportarExcel}
        onExportPdf={handleExportarPDF}
        onNewRecord={() => handleNuevo()}
        newRecordLabel="Nueva Atención"
      >
        {/* Filtro Transferencia a M1 */}
        <select
          value={transferenciaFilter}
          onChange={(e) => {
            setTransferenciaFilter(e.target.value as any);
            setCurrentPage(1);
          }}
          className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
        >
          <option value="TODOS">Todos los estados M1</option>
          <option value="Pendiente">Pendiente en Módulo 1</option>
          <option value="Validado">Validado / Transferido</option>
          <option value="Descartado">Descartado / Enf. Común</option>
        </select>

        {/* Filtro por Área */}
        <select
          value={areaFilter}
          onChange={(e) => {
            setAreaFilter(e.target.value);
            setCurrentPage(1);
          }}
          className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
        >
          <option value="TODOS">Todas las áreas</option>
          {AREAS_EMPRESA.map((area) => (
            <option key={area} value={area}>
              {area}
            </option>
          ))}
        </select>

        {/* Fechas */}
        <div className="flex items-center gap-1">
          <input
            type="date"
            value={fechaDesde}
            onChange={(e) => {
              setFechaDesde(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 shadow-2xs"
            title="Fecha desde"
          />
          <span className="text-slate-400 text-xs">-</span>
          <input
            type="date"
            value={fechaHasta}
            onChange={(e) => {
              setFechaHasta(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 shadow-2xs"
            title="Fecha hasta"
          />
        </div>
      </ModuleToolbar>

      {/* Tabla Principal */}
      <div id="tabla-consumo-botiquin" className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1100px] text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
              <tr>
                <th className="px-4 py-3 w-28 whitespace-nowrap">Código</th>
                <th className="px-4 py-3 w-32 whitespace-nowrap">Fecha / Hora</th>
                <th className="px-4 py-3 w-28 whitespace-nowrap">Empresa</th>
                <th className="px-4 py-3 w-32 whitespace-nowrap">Tipo Atención</th>
                <th className="px-4 py-3 min-w-[180px]">Trabajador Atendido</th>
                <th className="px-4 py-3 min-w-[150px]">Área / Turno</th>
                <th className="px-4 py-3 min-w-[180px]">Lesiones / Insumos</th>
                <th className="px-4 py-3 w-32 whitespace-nowrap">Inspección Vinculada</th>
                <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Bandeja M1</th>
                <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedConsumos.length === 0 ? (
                <TableEmptyState
                  isTableRow
                  colSpan={10}
                  title="No se encontraron atenciones médicas"
                  description={
                    searchTerm
                      ? `No hay registros que coincidan con "${searchTerm}".`
                      : 'No se encontraron registros de atenciones médicas con los filtros actuales.'
                  }
                  actionLabel={
                    searchTerm || tipoFilter !== 'TODOS' || transferenciaFilter !== 'TODOS' || areaFilter !== 'TODOS' || fechaDesde || fechaHasta
                      ? 'Limpiar filtros'
                      : 'Nueva Atención'
                  }
                  actionIcon={
                    searchTerm || tipoFilter !== 'TODOS' || transferenciaFilter !== 'TODOS' || areaFilter !== 'TODOS' || fechaDesde || fechaHasta
                      ? 'clear'
                      : 'plus'
                  }
                  onAction={() => {
                    if (searchTerm || tipoFilter !== 'TODOS' || transferenciaFilter !== 'TODOS' || areaFilter !== 'TODOS' || fechaDesde || fechaHasta) {
                      setSearchTerm('');
                      setTipoFilter('TODOS');
                      setTransferenciaFilter('TODOS');
                      setAreaFilter('TODOS');
                      setFechaDesde('');
                      setFechaHasta('');
                      setCurrentPage(1);
                    } else {
                      handleNuevo();
                    }
                  }}
                />
              ) : (
                paginatedConsumos.map((item, idx) => {
                  const isIncidente = item.tipoAtencion === 'Incidente';
                  const isAccidente = item.tipoAtencion === 'Accidente';
                  const isEnfermedad = item.tipoAtencion === 'Enfermedad común';

                  return (
                    <tr key={`${item.id || item.codigoAtencion}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-semibold text-teal-700 whitespace-nowrap">
                        {item.codigoAtencion}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="text-slate-800 font-medium">{item.fecha}</div>
                        <div className="text-[11px] text-slate-500">{item.hora || '10:00'}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.empresa === 'PERPOL'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {item.empresa}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            isIncidente
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : isAccidente
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-sky-50 text-sky-700 border border-sky-200'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              isIncidente ? 'bg-amber-500' : isAccidente ? 'bg-rose-500' : 'bg-sky-500'
                            }`}
                          />
                          {item.tipoAtencion}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-slate-800 font-medium">{item.personaAtendida}</div>
                        <div className="text-[11px] text-slate-500">
                          DNI: {item.dniPersona} • {item.puesto}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-slate-800 font-medium">{item.area}</div>
                        <div className="text-[11px] text-slate-500">{item.lugarEspecifico ? `${item.lugarEspecifico} • ` : ''}Turno: {item.turno}</div>
                      </td>
                      <td className="px-4 py-3 max-w-xs">
                        <div className="text-slate-700 line-clamp-1 font-medium">{item.lesionesSintomas}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Pill className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>
                            {(item.elementosConsumidos || []).length} insumo(s) dispensados
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {item.inspeccionVinculadaId ? (
                          <div className="flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-mono flex items-center gap-1">
                              <LinkIcon className="w-3 h-3" />
                              {item.inspeccionVinculadaCodigo || item.inspeccionVinculadaId}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-500 font-medium text-[11px]">Sin vínculo</span>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {isEnfermedad ? (
                          <span className="text-[11px] text-slate-500 italic">No aplica (Enf. Común)</span>
                        ) : item.transferidoAccidentes ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {item.casoAccidenteId ? `Validado (${item.casoAccidenteId})` : 'En Módulo 1'}
                          </span>
                        ) : (
                          <button
                            onClick={() => handleTransferirAModulo1(item)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 text-[11px] font-semibold transition-colors cursor-pointer"
                            title="Validar y abrir caso oficial en Módulo 1"
                          >
                            <Send className="w-3 h-3" />
                            <span>Transferir a M1</span>
                          </button>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setViewDetailModal(item)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                            title="Ver Ficha de Atención"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEditar(item)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-teal-600 transition-colors cursor-pointer"
                            title="Editar"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteModalAtencion(item)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Eliminar"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        {/* Paginación estandarizada */}
        <TablePagination
          currentPage={currentPage}
          totalItems={filteredConsumos.length}
          pageSize={pageSize}
          onPageChange={(page) => setCurrentPage(page)}
          onPageSizeChange={(newSize) => {
            setPageSize(newSize);
            setCurrentPage(1);
          }}
          pageSizeOptions={[10, 25, 50, 100]}
        />
      </div>

      {/* MODAL DE REGISTRO / EDICIÓN */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl my-8 text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-[#E2E8F0] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-teal-50 border border-teal-200 text-[#047857]">
                  <Cross className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0F172A]">
                    {editingRecord ? `Editar Atención ${editingRecord.codigoAtencion}` : 'Nueva Atención Médica y Consumo de Botiquín'}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">
                    Registro de primeros auxilios, insumos suministrados y vinculación con incidentes
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Fila 1: Empresa, Fecha, Hora, Tipo de Atención */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Empresa <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.empresa}
                    onChange={(e) => setFormData((prev) => ({ ...prev, empresa: e.target.value as any }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                    <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Fecha Atención <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.fecha}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fecha: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Hora <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.hora}
                    onChange={(e) => setFormData((prev) => ({ ...prev, hora: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Tipo de Atención <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.tipoAtencion}
                    onChange={(e) => setFormData((prev) => ({ ...prev, tipoAtencion: e.target.value as any }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-semibold"
                  >
                    <option value="Incidente">Incidente</option>
                    <option value="Accidente">Accidente</option>
                    <option value="Enfermedad común">Enfermedad común</option>
                  </select>
                </div>
              </div>

              {/* Mensaje de regla de negocio según clasificación */}
              {formData.tipoAtencion === 'Enfermedad común' ? (
                <div className="p-2.5 rounded-lg bg-sky-50 border border-sky-200 text-[11px] text-sky-900 flex items-start gap-2">
                  <HelpCircle className="w-4 h-4 shrink-0 mt-0.5 text-sky-600" />
                  <div>
                    <span className="font-bold">Regla Normativa SSOMA:</span> Las consultas por Enfermedad Común no configuran eventos de seguridad industrial ni son transferidas al Módulo 1 ni afectarán los índices de accidentabilidad.
                  </div>
                </div>
              ) : (
                <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                  <div>
                    <span className="font-bold">Transferencia Automática:</span> Al clasificarse como {formData.tipoAtencion}, este registro quedará disponible como evento pendiente en la Bandeja de Entrada del Módulo 1 (Accidentes e Incidentes) para validación oficial.
                  </div>
                </div>
              )}

              {/* Fila 2: Autocompletado del Colaborador (Módulo 6) */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                    <User className="w-4 h-4 text-[#047857]" />
                    Colaborador Atendido (Autocompletado Base de Trabajadores) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </span>
                  {formData.personaAtendida && (
                    <span className="text-[11px] text-[#047857] font-mono font-bold">DNI: {formData.dniPersona}</span>
                  )}
                </div>

                <div className="relative">
                  <input
                    type="text"
                    placeholder="Escriba el nombre o DNI del trabajador..."
                    value={workerSearchTerm}
                    onChange={(e) => {
                      setWorkerSearchTerm(e.target.value);
                      setIsWorkerDropdownOpen(true);
                    }}
                    onFocus={() => setIsWorkerDropdownOpen(true)}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                  {isWorkerDropdownOpen && (
                    <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-[#CBD5E1] rounded-lg shadow-xl z-20 divide-y divide-[#E2E8F0]">
                      {trabajadoresFiltrados.length === 0 ? (
                        <div className="p-2.5 text-xs text-[#475569] text-center">
                          No se encontraron trabajadores activos en {formData.empresa}
                        </div>
                      ) : (
                        trabajadoresFiltrados.map((t, idx) => (
                          <button
                            key={`${t.id || t.dni}-${t.empresa || ''}-${idx}`}
                            type="button"
                            onClick={() => handleSelectTrabajador(t)}
                            className="w-full p-2.5 text-left text-xs hover:bg-[#F1F5F9] transition-colors flex items-center justify-between cursor-pointer"
                          >
                            <div>
                              <div className="font-semibold text-[#0F172A]">{t.apellidosNombres}</div>
                              <div className="text-[11px] text-[#475569]">
                                DNI: {t.dni} • {t.puesto} • {t.area}
                              </div>
                            </div>
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] font-semibold">
                              {t.empresa}
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  )}
                </div>

                {/* Datos derivados del colaborador */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
                  <div>
                    <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Puesto / Cargo</label>
                    <input
                      type="text"
                      value={formData.puesto}
                      onChange={(e) => setFormData((prev) => ({ ...prev, puesto: e.target.value }))}
                      className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                      placeholder="Puesto de trabajo"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">
                      Área de Ocurrencia <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <select
                      required
                      value={formData.area}
                      onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
                      className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    >
                      <option value="">Seleccione área...</option>
                      {formData.area && !AREAS_EMPRESA.includes(formData.area) && (
                        <option value={formData.area}>{formData.area}</option>
                      )}
                      {AREAS_EMPRESA.map((area) => (
                        <option key={area} value={area}>
                          {area}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">
                      Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      list="lista-lugares-botiquin"
                      placeholder="Escribe o selecciona lugar..."
                      value={formData.lugarEspecifico}
                      onChange={(e) => setFormData((prev) => ({ ...prev, lugarEspecifico: e.target.value }))}
                      className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <datalist id="lista-lugares-botiquin">
                      {LUGARES_ESPECIFICOS.map((lug, idx) => (
                        <option key={`lug-bot-${idx}`} value={lug} />
                      ))}
                    </datalist>
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#475569] mb-0.5 font-semibold">Turno</label>
                    <select
                      value={formData.turno}
                      onChange={(e) => setFormData((prev) => ({ ...prev, turno: e.target.value as any }))}
                      className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    >
                      {TURNOS_TRABAJO.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Fila 3: Lesiones y Procedimiento Aplicado */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Lesiones o Síntomas Manifestados <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Describa el corte, contusión, quemadura, dolor o malestar..."
                    value={formData.lesionesSintomas}
                    onChange={(e) => setFormData((prev) => ({ ...prev, lesionesSintomas: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Procedimiento Médico / Curación Aplicada <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Lavado antiséptico, inmovilización, curación, reposo, toma de signos vitales..."
                    value={formData.procedimientoAplicado}
                    onChange={(e) => setFormData((prev) => ({ ...prev, procedimientoAplicado: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
              </div>

              {/* Fila 4: Control Dinámico de Insumos Médicos Dispensados */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-[#047857]" />
                    Insumos y Medicamentos Dispensados (Mínimo 1) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleAddElemento}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-[#1E293B] text-xs font-bold transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-[#047857]" />
                    <span>Agregar Insumo</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {elementosList.map((row, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-white p-2 rounded-lg border border-[#E2E8F0] shadow-2xs">
                      <div className="flex-1">
                        <select
                          value={row.item}
                          onChange={(e) => handleUpdateElemento(idx, 'item', e.target.value)}
                          className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                        >
                          <option value="">Seleccione o escriba insumo...</option>
                          {CATALOGO_INSUMOS_BOTIQUIN.map((catItem) => (
                            <option key={catItem.nombre} value={catItem.nombre}>
                              {catItem.nombre} ({catItem.categoria})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="w-24">
                        <input
                          type="number"
                          min={1}
                          value={row.cantidad}
                          onChange={(e) => handleUpdateElemento(idx, 'cantidad', e.target.value)}
                          className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] text-center font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                          title="Cantidad consumida"
                        />
                      </div>

                      <div className="w-24">
                        <input
                          type="text"
                          value={row.unidad}
                          onChange={(e) => handleUpdateElemento(idx, 'unidad', e.target.value)}
                          className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#475569] text-center"
                          placeholder="Unidad"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveElemento(idx)}
                        className="p-1.5 text-[#475569] hover:text-rose-600 rounded hover:bg-rose-50 cursor-pointer transition-colors"
                        title="Eliminar insumo"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Fila 5: Vinculación con Inspecciones SST (Módulo 2) */}
              <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                    <LinkIcon className="w-4 h-4 text-[#047857]" />
                    Vincular con Inspección SST (Módulo 2 - Opcional)
                  </label>
                  {selectedLinkedInspection && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#047857] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                      <Check className="w-3 h-3 text-[#047857]" />
                      Datos Heredados Automáticamente
                    </span>
                  )}
                </div>

                <div className="space-y-1.5">
                  <select
                    value={formData.inspeccionVinculadaId || ''}
                    onChange={(e) => handleSelectInspeccion(e.target.value)}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium cursor-pointer"
                  >
                    <option value="">(Ninguna inspección asociada)</option>
                    {inspectionAssociationOptions.map((insp, iIdx) => {
                      const idVal = insp.id || insp.codigoInspeccion;
                      return (
                        <option key={`${idVal}-${iIdx}`} value={idVal}>
                          [{insp.empresa || 'SST'}] {insp.codigoInspeccion} — {insp.fecha} — {insp.area || 'Sin área'} ({String(insp.hallazgo || '').slice(0, 45)}...)
                        </option>
                      );
                    })}
                  </select>
                  <p className="text-[11px] text-[#475569]">
                    Al seleccionar una inspección, se heredarán automáticamente la empresa, fecha, área, descripción del evento/síntomas y medidas correctivas al formulario.
                  </p>
                </div>

                {/* Tarjeta detallada de inspección vinculada y controles de herencia */}
                {selectedLinkedInspection && (
                  <div className="rounded-xl border border-indigo-200 bg-indigo-50/50 p-3.5 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-indigo-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-indigo-100 text-indigo-900 border border-indigo-300">
                          {selectedLinkedInspection.codigoInspeccion}
                        </span>
                        <span className="text-[11px] font-medium text-[#0F172A]">
                          {selectedLinkedInspection.tipo}
                        </span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-white text-[#1E293B] border border-indigo-200 font-bold">
                          {selectedLinkedInspection.empresa}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={handleReaplicarDatosInspeccion}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#047857] hover:bg-[#065F46] text-white text-[11px] font-semibold transition-colors cursor-pointer"
                          title="Volver a rellenar empresa, fecha, área y síntomas con los datos de esta inspección"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Re-aplicar a Formulario</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectInspeccion('')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-100 text-[#475569] border border-[#CBD5E1] text-[11px] font-medium transition-colors cursor-pointer"
                          title="Quitar vínculo con esta inspección"
                        >
                          Desvincular
                        </button>
                      </div>
                    </div>

                    {/* Fichas informativas de datos heredados */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                      <div className="bg-white p-2 rounded border border-indigo-100">
                        <span className="text-[#475569] block text-[10px] font-semibold">Área Heredada</span>
                        <span className="font-semibold text-[#0F172A]">{selectedLinkedInspection.area || 'No especificada'}</span>
                      </div>
                      <div className="bg-white p-2 rounded border border-indigo-100">
                        <span className="text-[#475569] block text-[10px] font-semibold">Fecha Inspección</span>
                        <span className="font-semibold text-[#0F172A]">{selectedLinkedInspection.fecha || 'N/A'}</span>
                      </div>
                      <div className="bg-white p-2 rounded border border-indigo-100">
                        <span className="text-[#475569] block text-[10px] font-semibold">Responsable SST</span>
                        <span className="font-semibold text-[#0F172A]">{selectedLinkedInspection.responsableInspeccion || 'N/A'}</span>
                      </div>
                      <div className="bg-white p-2 rounded border border-indigo-100">
                        <span className="text-[#475569] block text-[10px] font-semibold">Estado Inspección</span>
                        <span className="font-bold text-[#B45309]">{selectedLinkedInspection.estado || 'Pendiente'}</span>
                      </div>
                    </div>

                    {/* Hallazgo y acciones */}
                    {selectedLinkedInspection.hallazgo && (
                      <div className="text-[11px] bg-white p-2.5 rounded border border-indigo-100 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-indigo-900">Hallazgo de Inspección:</span>
                          <button
                            type="button"
                            onClick={() => handleCopiarHallazgoSintomas(selectedLinkedInspection.hallazgo)}
                            className="text-[10px] text-[#047857] hover:underline font-bold cursor-pointer"
                          >
                            Copiar a Síntomas
                          </button>
                        </div>
                        <p className="text-[#0F172A] font-medium">{selectedLinkedInspection.hallazgo}</p>
                      </div>
                    )}

                    {selectedLinkedInspection.accionCorrectiva && (
                      <div className="text-[11px] bg-white p-2.5 rounded border border-indigo-100 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[#047857]">Acción Correctiva Sugerida:</span>
                          <button
                            type="button"
                            onClick={() => handleCopiarAccionProcedimiento(selectedLinkedInspection.accionCorrectiva!)}
                            className="text-[10px] text-[#047857] hover:underline font-bold cursor-pointer"
                          >
                            Copiar a Procedimiento
                          </button>
                        </div>
                        <p className="text-[#0F172A] font-medium">{selectedLinkedInspection.accionCorrectiva}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Fila 6: Fotografía de Evidencia + Responsable de Atención */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Fotografía de Evidencia / Tópico
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="flex-1 flex items-center justify-center gap-2 p-2.5 rounded-lg border border-dashed border-[#CBD5E1] hover:border-[#047857] bg-white cursor-pointer text-xs text-[#475569] hover:text-[#0F172A] transition-colors">
                      <Camera className="w-4 h-4 text-[#047857]" />
                      <span>{imageFile ? imageFile.name : 'Adjuntar foto (máx. 8 MB)'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                      />
                    </label>
                    {typeof imagePreview === 'string' && imagePreview.trim().length > 0 && (
                      <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-[#047857] shrink-0">
                        <img src={imagePreview.trim()} alt="Preview" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => {
                            setImageFile(null);
                            setImagePreview(null);
                          }}
                          className="absolute inset-0 bg-black/60 text-white flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-[#475569]">
                      Atendido por (Responsable Tópico / Brigadista) *
                    </label>
                    <span className="text-[10px] text-[#047857] font-bold">
                      Autocompletable desde base de trabajadores
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    list="lista-brigadistas-atendido"
                    value={atendidoSearchTerm || formData.atendidoPor || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setAtendidoSearchTerm(val);
                      setFormData((prev) => ({ ...prev, atendidoPor: val }));
                      setIsAtendidoDropdownOpen(true);
                    }}
                    onFocus={() => setIsAtendidoDropdownOpen(true)}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
                    placeholder="Escriba o seleccione el nombre del colaborador que atiende..."
                  />
                  {isAtendidoDropdownOpen && brigadistasFiltrados.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-[#CBD5E1] rounded-lg shadow-xl z-30 divide-y divide-[#E2E8F0]">
                      {brigadistasFiltrados.map((t, idx) => (
                        <button
                          key={`atendido-${t.id || t.dni || idx}`}
                          type="button"
                          onClick={() => {
                            setFormData((prev) => ({ ...prev, atendidoPor: t.apellidosNombres }));
                            setAtendidoSearchTerm(t.apellidosNombres);
                            setIsAtendidoDropdownOpen(false);
                          }}
                          className="w-full p-2.5 text-left text-xs hover:bg-[#F1F5F9] transition-colors flex items-center justify-between cursor-pointer"
                        >
                          <div>
                            <div className="font-semibold text-[#0F172A]">{t.apellidosNombres}</div>
                            <div className="text-[11px] text-[#475569]">
                              DNI: {t.dni} • {t.puesto} • {t.area}
                            </div>
                          </div>
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] font-semibold">
                            {t.empresa}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                  <datalist id="lista-brigadistas-atendido">
                    {trabajadores
                      .filter((t) => t.condicion === 'Activo')
                      .sort((a, b) => String(a.apellidosNombres || '').localeCompare(String(b.apellidosNombres || '')))
                      .map((t, idx) => (
                        <option
                          key={`atendido-trab-${t.id || t.dni || idx}`}
                          value={t.apellidosNombres}
                        >
                          {t.puesto} • {t.area} ({t.empresa})
                        </option>
                      ))}
                  </datalist>
                  <span className="text-[10px] text-[#475569] block mt-1">
                    Seleccione un colaborador de la lista interactiva o comience a escribir para autocompletar.
                  </span>
                </div>
              </div>

              {/* Botones de acción modal */}
              <div className="pt-3 border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-[#475569] border border-[#CBD5E1] cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] disabled:opacity-60 text-xs font-bold text-white shadow-sm transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSubmitting ? 'Guardando...' : 'Guardar Atención'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DETALLE DE ATENCIÓN MÉDICA */}
      {viewDetailModal && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewDetailModal(null);
          }}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="fixed inset-0 -z-10 cursor-pointer"
            onClick={() => setViewDetailModal(null)}
            aria-hidden="true"
          />

          <div
            className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header del modal fijo */}
            <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className="p-2 rounded-lg bg-teal-50 text-teal-700 border border-teal-200 shrink-0">
                  <Cross className="w-5 h-5 text-teal-700" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-base font-bold text-[#263B5E] truncate">
                    Ficha Médica de Tópico — {viewDetailModal.codigoAtencion}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium truncate">
                    {viewDetailModal.empresa} • {viewDetailModal.personaAtendida}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewDetailModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer shrink-0"
                title="Cerrar ficha (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Contenido con scroll independiente */}
            <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-200">
                <div>
                  <span className="text-slate-500 font-medium">Fecha y Hora:</span>
                  <div className="font-bold text-slate-900">
                    {viewDetailModal.fecha} a las {viewDetailModal.hora || '10:00'}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Empresa:</span>
                  <div className="font-bold text-slate-900">{viewDetailModal.empresa}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Trabajador:</span>
                  <div className="font-bold text-slate-900">{viewDetailModal.personaAtendida}</div>
                  <div className="text-[11px] text-slate-500 font-mono">DNI: {viewDetailModal.dniPersona}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Área / Lugar Específico:</span>
                  <div className="font-bold text-slate-900">{viewDetailModal.area}</div>
                  <div className="text-[11px] text-slate-500">{viewDetailModal.lugarEspecifico || 'General'} • {viewDetailModal.puesto}</div>
                </div>
              </div>

              <div>
                <span className="text-slate-700 font-bold block mb-1">Lesiones / Síntomas:</span>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 leading-relaxed text-xs sm:text-sm">
                  {viewDetailModal.lesionesSintomas}
                </p>
              </div>

              <div>
                <span className="text-slate-700 font-bold block mb-1">Procedimiento Aplicado:</span>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 leading-relaxed text-xs sm:text-sm">
                  {viewDetailModal.procedimientoAplicado}
                </p>
              </div>

              <div>
                <span className="text-slate-700 font-bold block mb-1">Insumos y Medicamentos Dispensados:</span>
                <div className="bg-slate-50 rounded-xl border border-slate-200 p-3 space-y-1.5">
                  {(viewDetailModal.elementosConsumidos || []).map((el, i) => (
                    <div key={i} className="flex justify-between text-slate-800 text-[11px]">
                      <span className="font-medium">• {el.item}</span>
                      <span className="font-bold text-teal-700">
                        {el.cantidad} {el.unidad}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {viewDetailModal.inspeccionVinculadaId && (
                <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-xl text-slate-800 text-[11px]">
                  <span className="font-bold text-[#263B5E]">Inspección SST Vinculada:</span> {viewDetailModal.inspeccionVinculadaCodigo || viewDetailModal.inspeccionVinculadaId}
                  {viewDetailModal.inspeccionVinculadaDetalle && (
                    <div className="text-slate-600 mt-0.5">{viewDetailModal.inspeccionVinculadaDetalle}</div>
                  )}
                </div>
              )}

              {viewDetailModal.fotoUrl && (
                <div className="space-y-1.5">
                  <span className="text-slate-700 font-bold text-xs flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span>Evidencia Fotográfica de la Atención:</span>
                  </span>
                  <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-44 flex items-center justify-center p-1">
                    <DriveImage
                      src={viewDetailModal.fotoUrl}
                      driveId={viewDetailModal.fotoDriveId}
                      alt={`Evidencia atención - ${viewDetailModal.codigoAtencion}`}
                      className="max-h-full max-w-full object-contain rounded-lg"
                      containerClassName="w-full h-full flex items-center justify-center"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Footer fijo del modal */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-xs text-slate-600">
                Atendido por: <strong className="text-slate-900">{viewDetailModal.atendidoPor}</strong>
              </span>
              <button
                type="button"
                onClick={() => setViewDetailModal(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Modal de confirmación para eliminar atención */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalAtencion)}
        onClose={() => setDeleteModalAtencion(null)}
        onConfirm={confirmDeleteAtencion}
        title="Eliminar Registro de Atención"
        message="¿Estás seguro de que deseas eliminar este registro de atención médica y consumo de insumos?"
        itemIdentifier={
          deleteModalAtencion
            ? `${deleteModalAtencion.codigoAtencion}: ${deleteModalAtencion.personaAtendida} (${deleteModalAtencion.tipoAtencion})`
            : undefined
        }
        confirmButtonText="Eliminar Atención"
      />
    </div>
  );
};
