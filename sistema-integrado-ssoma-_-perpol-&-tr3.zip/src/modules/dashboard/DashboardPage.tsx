import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAppStore } from '../../store/appStore';
import { EMPRESAS } from '../../types';
import { MODULOS_SSOMA } from '../../components/layout/Sidebar';
import { GasApiClient } from '../../services/api';
import {
  Building2,
  ArrowRight
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const {
    empresaActiva,
    setEmpresaActiva,
    gasWebAppUrl,
    setIsSyncingWithSheets,
    cargarDatosDesdeSheets
  } = useAppStore();

  // Carga automática de datos de Google Sheets al ingresar a la pantalla inicial
  useEffect(() => {
    let isMounted = true;
    const cargarDatosIniciales = async () => {
      // Evitar llamadas duplicadas si dataLoader ya está descargando o si ya hay registros cargados
      const storeState = useAppStore.getState();
      if (storeState.isSyncingWithSheets || storeState.totalSincronizadosSheets > 0) {
        return;
      }

      const tieneGas =
        (typeof window !== 'undefined' && (window as any).google?.script?.run) ||
        (gasWebAppUrl && gasWebAppUrl.trim().length > 0);

      if (!tieneGas) return;

      try {
        setIsSyncingWithSheets(true);
        const res = await GasApiClient.obtenerDatosGoogleSheets();
        if (isMounted && res && res.success && res.data) {
          cargarDatosDesdeSheets(res.data);
        }
      } catch {
        // Fallback local silencioso si no hay respuesta de red inmediata
      } finally {
        if (isMounted) {
          setIsSyncingWithSheets(false);
        }
      }
    };

    cargarDatosIniciales();
    return () => {
      isMounted = false;
    };
  }, [gasWebAppUrl, cargarDatosDesdeSheets, setIsSyncingWithSheets]);

  return (
    <div className="space-y-6">
      {/* Banner de Bienvenida y Razón Social */}
      <div className="relative overflow-hidden rounded-2xl bg-white border border-[#E2E8F0] p-6 sm:p-8 shadow-xs">
        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A] tracking-tight">
                Panel de Control SST & Medio Ambiente
              </h1>
              <p className="text-sm text-[#475569] mt-2 max-w-3xl leading-relaxed">
                Plataforma centralizada para el control operativo, seguimiento de incidentes,
                inspecciones normativas, automatización documental y métricas SST con
                persistencia en Google Sheets y evidencias en Google Drive.
              </p>
            </div>
          </div>

          {/* Tarjetas de Razones Sociales */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6" role="group" aria-label="Seleccionar razón social">
            {/* PERPOL */}
            <div
              role="button"
              tabIndex={0}
              aria-pressed={empresaActiva === 'PERPOL'}
              aria-label={`Seleccionar empresa ${EMPRESAS.PERPOL.razonSocial}`}
              onClick={() => setEmpresaActiva('PERPOL')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setEmpresaActiva('PERPOL');
                }
              }}
              className={`cursor-pointer p-4 rounded-xl border transition-all focus:outline-hidden focus:ring-2 focus:ring-[#10B981] focus:ring-offset-2 ${
                empresaActiva === 'PERPOL'
                  ? 'bg-[#1E293B] text-white border-[#1E293B] shadow-xs'
                  : 'bg-white border-[#CBD5E1] text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`p-2 rounded-lg ${empresaActiva === 'PERPOL' ? 'bg-white/15 text-white' : 'bg-emerald-50 text-[#047857]'}`} aria-hidden="true">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className={`font-bold text-sm ${empresaActiva === 'PERPOL' ? 'text-white' : 'text-[#0F172A]'}`}>{EMPRESAS.PERPOL.razonSocial}</h3>
                    <p className={`text-xs font-mono ${empresaActiva === 'PERPOL' ? 'text-white/90' : 'text-[#475569]'}`}>RUC: {EMPRESAS.PERPOL.ruc}</p>
                  </div>
                </div>
                {empresaActiva === 'PERPOL' && (
                  <span className="text-xs font-semibold text-white bg-white/20 px-2 py-0.5 rounded border border-white/30">
                    Seleccionada
                  </span>
                )}
              </div>
              <p className={`text-[11px] mt-2.5 line-clamp-1 ${empresaActiva === 'PERPOL' ? 'text-white/90' : 'text-[#475569]'}`}>
                {EMPRESAS.PERPOL.direccion}
              </p>
            </div>

            {/* TR3 */}
            <div
              role="button"
              tabIndex={0}
              aria-pressed={empresaActiva === 'TR3'}
              aria-label={`Seleccionar empresa ${EMPRESAS.TR3.razonSocial}`}
              onClick={() => setEmpresaActiva('TR3')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setEmpresaActiva('TR3');
                }
              }}
              className={`cursor-pointer p-4 rounded-xl border transition-all focus:outline-hidden focus:ring-2 focus:ring-[#10B981] focus:ring-offset-2 ${
                empresaActiva === 'TR3'
                  ? 'bg-[#1E293B] text-white border-[#1E293B] shadow-xs'
                  : 'bg-white border-[#CBD5E1] text-[#475569] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`p-2 rounded-lg ${empresaActiva === 'TR3' ? 'bg-white/15 text-white' : 'bg-amber-50 text-[#B45309]'}`} aria-hidden="true">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className={`font-bold text-sm ${empresaActiva === 'TR3' ? 'text-white' : 'text-[#0F172A]'}`}>{EMPRESAS.TR3.razonSocial}</h3>
                    <p className={`text-xs font-mono ${empresaActiva === 'TR3' ? 'text-white/90' : 'text-[#475569]'}`}>RUC: {EMPRESAS.TR3.ruc}</p>
                  </div>
                </div>
                {empresaActiva === 'TR3' && (
                  <span className="text-xs font-semibold text-white bg-white/20 px-2 py-0.5 rounded border border-white/30">
                    Seleccionada
                  </span>
                )}
              </div>
              <p className={`text-[11px] mt-2.5 line-clamp-1 ${empresaActiva === 'TR3' ? 'text-white/90' : 'text-[#475569]'}`}>
                {EMPRESAS.TR3.direccion}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid con los 10 Módulos SSOMA */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#0F172A] tracking-tight">
              Módulos del Sistema Integrado SSOMA
            </h2>
          </div>
          <span className="text-xs text-[#475569] hidden sm:block">
            Módulos del Sistema 100% operativos
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {MODULOS_SSOMA.map((modulo) => (
            <Link
              key={modulo.id}
              to={modulo.ruta}
              className="group p-5 rounded-xl bg-white border border-[#E2E8F0] hover:border-[#10B981] hover:shadow-md transition-all flex flex-col justify-between shadow-2xs focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <div>
                <div className="mb-3">
                  <div className="inline-flex p-2.5 rounded-lg bg-emerald-50 text-[#047857] border border-emerald-200 group-hover:scale-105 transition-transform">
                    {modulo.icono}
                  </div>
                </div>
                <h3 className="font-bold text-[#0F172A] text-base group-hover:text-[#047857] transition-colors">
                  {modulo.nombre}
                </h3>
                <p className="text-xs text-[#475569] mt-1.5 line-clamp-2">
                  Gestión integral, validaciones normativas, tablas de seguimiento e importación de
                  datos masivos.
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#E2E8F0] flex items-center justify-between text-xs text-[#475569] group-hover:text-[#047857]">
                <span className="font-semibold">Abrir módulo</span>
                <ArrowRight className="w-4 h-4 text-[#047857] group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};
