import React, { useState, useMemo } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore } from '../../store/appStore';
import { ActoCondicionRecord } from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { DriveStorageService } from '../../services/driveService';
import { ExportUtils } from '../../utils/exportUtils';
import { ModuleToolbar, FilterChipOption } from '../../components/common/ModuleToolbar';
import { TablePagination } from '../../components/common/TablePagination';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import { StatusBadge } from '../../components/common/StatusBadge';
import { ImageLightboxModal } from '../../components/common/ImageLightboxModal';
import { DriveImage } from '../../components/common/DriveImage';
import {
  CATALOGO_CATEGORIAS_RIESGO,
  AREAS_EMPRESA,
  LUGARES_ESPECIFICOS,
  pgToPrioridad,
  pgToDiasPlazo
} from '../../utils/ssomaCatalogs';
import {
  ShieldAlert,
  AlertTriangle,
  UserX,
  Clock,
  CheckCircle2,
  Eye,
  Camera,
  Upload,
  Edit2,
  Trash2,
  X,
  Save,
  CheckSquare,
  RefreshCw
} from 'lucide-react';

export const ActosCondicionesPage: React.FC = () => {
  const {
    empresaActiva,
    trabajadores,
    getTrabajadoresActivos,
    addToast,
    incrementSync,
    decrementSync,
    actosCondiciones: registros,
    upsertActoCondicion,
    removeActoCondicion,
    batchUpsertActosCondiciones
  } = useAppStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [clasificacionFilter, setClasificacionFilter] = useState<'TODOS' | 'Acto Inseguro' | 'Condición Insegura'>('TODOS');
  const [areaFilter, setAreaFilter] = useState<string>('TODOS');
  const [estadoFilter, setEstadoFilter] = useState<'TODOS' | 'Pendiente' | 'En proceso' | 'Cerrado'>('TODOS');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isSyncingSheets, setIsSyncingSheets] = useState(false);

  const handleSyncSheets = async () => {
    setIsSyncingSheets(true);
    incrementSync();
    try {
      const res = await GasApiClient.obtenerDatosGoogleSheets();
      if (res && res.success && res.data) {
        useAppStore.getState().cargarDatosDesdeSheets(res.data);
        const count = useAppStore.getState().actosCondiciones.length;
        addToast({
          type: 'success',
          title: 'Google Sheets Sincronizado',
          message: `Se sincronizaron ${count} reportes de Actos y Condiciones correctamente.`
        });
      } else {
        addToast({
          type: 'error',
          title: 'Error de Sincronización',
          message: res?.error || 'No se recibieron datos de Google Sheets.'
        });
      }
    } catch (err: unknown) {
      addToast({
        type: 'error',
        title: 'Error de Conexión',
        message: err instanceof Error ? err.message : 'No se pudo contactar a Google Sheets.'
      });
    } finally {
      setIsSyncingSheets(false);
      decrementSync();
    }
  };

  // Modal de Nuevo / Edición Registro
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<ActoCondicionRecord | null>(null);
  const [deleteModalReporte, setDeleteModalReporte] = useState<ActoCondicionRecord | null>(null);
  const [viewDetailReporte, setViewDetailReporte] = useState<ActoCondicionRecord | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Form State Principal
  const [formData, setFormData] = useState<Partial<ActoCondicionRecord>>({
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: new Date().toISOString().slice(0, 10),
    reportadoPor: '',
    clasificacion: 'Acto Inseguro',
    categoriaCodigo: 'CAT-09',
    potencialGravedad: 2,
    prioridad: 'Media',
    descripcion: '',
    tipoPersonal: 'Propio',
    empresaPersonal: 'PERPOL IDEAS S.A.C.',
    trabajadorObservadoDni: '',
    trabajadorObservadoNombre: '',
    cargoObservado: '',
    areaActo: '',
    turnoActo: 'Mañana',
    areaCondicion: '',
    lugarEspecifico: '',
    estado: 'Pendiente',
    medidaCorrectiva: '',
    responsableSeguimiento: '',
    fechaCompromiso: ''
  });

  // Foto Inicial
  const [fotoFile, setFotoFile] = useState<File | null>(null);
  const [fotoPreview, setFotoPreview] = useState<string | null>(null);
  const [isCompressingFoto, setIsCompressingFoto] = useState(false);

  // Modal de Seguimiento / Cierre
  const [isSeguimientoModalOpen, setIsSeguimientoModalOpen] = useState(false);
  const [seguimientoRecord, setSeguimientoRecord] = useState<ActoCondicionRecord | null>(null);
  const [seguimientoForm, setSeguimientoForm] = useState({
    medidaCorrectiva: '',
    responsableSeguimiento: '',
    fechaCompromiso: '',
    estado: 'Pendiente' as 'Pendiente' | 'En proceso' | 'Cerrado',
    fechaCierre: new Date().toISOString().slice(0, 10),
    observacionCierre: ''
  });
  const [fotoCierreFile, setFotoCierreFile] = useState<File | null>(null);
  const [fotoCierrePreview, setFotoCierrePreview] = useState<string | null>(null);
  const [isCompressingCierre, setIsCompressingCierre] = useState(false);
  const [seguimientoError, setSeguimientoError] = useState<string | null>(null);

  // Trabajadores activos para autocompletado
  const trabajadoresActivos = useMemo(() => {
    return getTrabajadoresActivos(empresaActiva);
  }, [getTrabajadoresActivos, empresaActiva]);

  // Helper para asegurar nombre canónico actualizado de la categoría SST
  const getCategoriaNombre = (codigo?: string, fallbackNombre?: string): string => {
    if (!codigo) return fallbackNombre || 'General';
    const found = CATALOGO_CATEGORIAS_RIESGO.find((c) => c.codigo === codigo);
    return found?.nombre || fallbackNombre || 'General';
  };

  // Lista de áreas obtenidas del catálogo oficial de 29 áreas y de la base de trabajadores
  const areasTrabajadores = useMemo(() => {
    const setAreas = new Set<string>();
    AREAS_EMPRESA.forEach((a) => setAreas.add(a));
    trabajadores.forEach((t) => {
      const a = String(t.area || '').trim();
      if (a) setAreas.add(a);
    });
    return Array.from(setAreas).sort((a, b) => a.localeCompare(b));
  }, [trabajadores]);

  // Filtrado de la lista
  const filteredRegistros = useMemo(() => {
    return registros.filter((r) => {
      const matchEmpresa =
        empresaActiva === 'CONSOLIDADO' ? true : r.empresa === empresaActiva;
      const matchClasif =
        clasificacionFilter === 'TODOS' ? true : r.clasificacion === clasificacionFilter;
      const matchEstado =
        estadoFilter === 'TODOS' ? true : r.estado === estadoFilter;
      const matchArea =
        areaFilter === 'TODOS'
          ? true
          : r.areaActo === areaFilter || r.areaCondicion === areaFilter;

      const term = searchTerm.toLowerCase().trim();
      const matchSearch =
        !term ||
        String(r.codigoReporte || '').toLowerCase().includes(term) ||
        String(r.descripcion || '').toLowerCase().includes(term) ||
        getCategoriaNombre(r.categoriaCodigo, r.categoriaNombre).toLowerCase().includes(term) ||
        String(r.categoriaNombre || '').toLowerCase().includes(term) ||
        (r.trabajadorObservadoNombre && String(r.trabajadorObservadoNombre).toLowerCase().includes(term)) ||
        (r.lugarEspecifico && String(r.lugarEspecifico).toLowerCase().includes(term)) ||
        (r.areaActo && String(r.areaActo).toLowerCase().includes(term)) ||
        (r.areaCondicion && String(r.areaCondicion).toLowerCase().includes(term));

      return matchEmpresa && matchClasif && matchEstado && matchArea && matchSearch;
    });
  }, [registros, empresaActiva, clasificacionFilter, estadoFilter, areaFilter, searchTerm]);

  // Paginación, filtros rápidos y visor de imágenes
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);

  const statusOptions: FilterChipOption[] = useMemo(() => {
    const listEmpresa = registros.filter((r) =>
      empresaActiva === 'CONSOLIDADO' ? true : r.empresa === empresaActiva
    );
    const pendientes = listEmpresa.filter((r) => r.estado === 'Pendiente').length;
    const enProceso = listEmpresa.filter((r) => r.estado === 'En proceso').length;
    const cerrados = listEmpresa.filter((r) => r.estado === 'Cerrado').length;

    return [
      { id: 'TODOS', label: 'Todos', count: listEmpresa.length },
      { id: 'Pendiente', label: 'Pendientes', count: pendientes },
      { id: 'En proceso', label: 'En Proceso', count: enProceso },
      { id: 'Cerrado', label: 'Cerrados', count: cerrados }
    ];
  }, [registros, empresaActiva]);

  const paginatedRegistros = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRegistros.slice(start, start + pageSize);
  }, [filteredRegistros, currentPage, pageSize]);

  // Manejo de cambio de clasificación (Acto Inseguro vs Condición Insegura)
  const handleClasificacionChange = (newClasif: 'Acto Inseguro' | 'Condición Insegura') => {
    setFormData((prev) => ({
      ...prev,
      clasificacion: newClasif
    }));
  };

  // Manejo de cambio de categoría de riesgo (CAT-01 a CAT-12)
  const handleCategoriaChange = (cod: string) => {
    const cat = CATALOGO_CATEGORIAS_RIESGO.find((c) => c.codigo === cod);
    if (!cat) return;

    const pg = cat.pgSugerido;
    const prio = pgToPrioridad(pg);
    const dias = pgToDiasPlazo(pg);

    const fechaComp = new Date(Date.now() + dias * 86400000).toISOString().slice(0, 10);

    setFormData((prev) => ({
      ...prev,
      categoriaCodigo: cod,
      categoriaNombre: cat.nombre,
      potencialGravedad: pg,
      prioridad: prio,
      fechaCompromiso: prev.fechaCompromiso || fechaComp
    }));
  };

  // Autocompletado del trabajador observado (sincroniza puesto, área exacta de la base y empresa)
  const handleSelectTrabajadorObservado = (valor: string) => {
    const cleanVal = String(valor || '').trim().toLowerCase();
    const trab = trabajadoresActivos.find(
      (t) =>
        String(t.dni || '').trim().toLowerCase() === cleanVal ||
        String(t.apellidosNombres || '').trim().toLowerCase() === cleanVal
    );
    if (trab) {
      setFormData((prev) => ({
        ...prev,
        trabajadorObservadoDni: trab.dni,
        trabajadorObservadoNombre: trab.apellidosNombres,
        cargoObservado: trab.puesto || '',
        areaActo: trab.area || '',
        empresaPersonal: trab.empresa === 'PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.'
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        trabajadorObservadoDni: valor
      }));
    }
  };

  // Carga de Foto Inicial
  const handleFotoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      setFormError('La foto supera el límite de 8MB. Selecciona una imagen más liviana.');
      return;
    }
    if (!file.type.startsWith('image/')) {
      setFormError('El archivo debe ser una imagen válida (JPG, PNG, WebP).');
      return;
    }

    setFotoFile(file);
    setIsCompressingFoto(true);

    try {
      const compressed = await DriveStorageService.compressImage(file, {
        maxDimension: 1200,
        quality: 0.82
      });
      setFotoPreview(`data:image/jpeg;base64,${compressed.base64}`);
      setFormError(null);
    } catch {
      setFormError('Error al procesar la imagen en canvas.');
    } finally {
      setIsCompressingFoto(false);
    }
  };

  // Abrir modal de nuevo registro
  const handleOpenNuevoModal = () => {
    setEditingRecord(null);
    setFormError(null);
    setFotoFile(null);
    setFotoPreview(null);

    const defaultCat = CATALOGO_CATEGORIAS_RIESGO[8]; // CAT-09 EPP
    const dias = pgToDiasPlazo(defaultCat.pgSugerido);

    setFormData({
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      reportadoPor: '',
      clasificacion: 'Acto Inseguro',
      categoriaCodigo: defaultCat.codigo,
      categoriaNombre: defaultCat.nombre,
      potencialGravedad: defaultCat.pgSugerido,
      prioridad: pgToPrioridad(defaultCat.pgSugerido),
      descripcion: '',
      tipoPersonal: 'Propio',
      empresaPersonal: empresaActiva === 'TR3' ? 'TR3 ALIMENTOS S.A.C.' : 'PERPOL IDEAS S.A.C.',
      trabajadorObservadoDni: '',
      trabajadorObservadoNombre: '',
      cargoObservado: '',
      areaActo: '',
      turnoActo: 'Mañana',
      areaCondicion: '',
      lugarEspecifico: '',
      estado: 'Pendiente',
      medidaCorrectiva: '',
      responsableSeguimiento: '',
      fechaCompromiso: new Date(Date.now() + dias * 86400000).toISOString().slice(0, 10)
    });
    setIsModalOpen(true);
  };

  // Guardar Registro Principal
  const handleSaveRegistro = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!String(formData.descripcion || '').trim()) {
      setFormError('La descripción detallada del evento u observación es obligatoria.');
      return;
    }

    const isActo = formData.clasificacion === 'Acto Inseguro';

    // Validación condicional de campos según rama
    if (isActo) {
      if (!String(formData.trabajadorObservadoNombre || '').trim() && !String(formData.trabajadorObservadoDni || '').trim()) {
        setFormError('Para Actos Inseguros es obligatorio identificar al trabajador observado (DNI o nombre).');
        return;
      }
      if (!String(formData.cargoObservado || '').trim()) {
        setFormError('Para Actos Inseguros es obligatorio ingresar el puesto / cargo del colaborador.');
        return;
      }
      if (!String(formData.areaActo || '').trim()) {
        setFormError('Para Actos Inseguros es obligatorio indicar el área.');
        return;
      }
      if (!String(formData.lugarEspecifico || '').trim()) {
        setFormError('Para Actos Inseguros es obligatorio especificar el lugar físico.');
        return;
      }
      if (!formData.turnoActo) {
        setFormError('Para Actos Inseguros es obligatorio seleccionar el turno de trabajo.');
        return;
      }
    } else {
      // Condición Insegura
      if (!String(formData.areaCondicion || '').trim()) {
        setFormError('Para Condiciones Inseguras es obligatorio seleccionar el área.');
        return;
      }
      if (!String(formData.lugarEspecifico || '').trim()) {
        setFormError('Para Condiciones Inseguras es obligatorio especificar el lugar físico del riesgo.');
        return;
      }
    }

    let finalFotoUrl = editingRecord?.fotoUrl || '';
    let finalFotoDriveId = editingRecord?.fotoDriveId || '';

    if (fotoFile) {
      try {
        incrementSync();
        addToast({
          type: 'info',
          title: 'Subiendo Evidencia a Drive',
          message: 'Guardando foto de evidencia en Google Drive...'
        });

        const uploadResult = await DriveStorageService.uploadToDrive(fotoFile, {
          modulo: 'ACTOS_CONDICIONES',
          fileName: `acto_cond_${formData.categoriaCodigo}_${Date.now()}.jpg`,
          maxDimension: 1200
        });

        finalFotoUrl = uploadResult.fileUrl;
        finalFotoDriveId = uploadResult.fileId;
      } catch {
        finalFotoUrl = fotoPreview || '';
      } finally {
        decrementSync();
      }
    }

    // Generar correlativo incremental secuencial anual basado en cantidad de casos registrados si es nuevo
    let cod = editingRecord?.codigoReporte;
    if (!cod) {
      const anio = new Date().getFullYear();
      const totalAnio = registros.filter((r) => {
        const f = r.fecha || '';
        return f.startsWith(String(anio)) || (r.codigoReporte && r.codigoReporte.includes(`-${anio}-`));
      }).length;
      cod = `AC-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;
    }

    const catObj = CATALOGO_CATEGORIAS_RIESGO.find((c) => c.codigo === formData.categoriaCodigo);

    // Lógica estricta de guardado en la rama no seleccionada: campos nulos o vacíos
    const newRecord: ActoCondicionRecord = {
      id: editingRecord?.id || cod,
      codigoReporte: cod,
      empresa: formData.empresa as 'PERPOL' | 'TR3',
      fecha: formData.fecha || new Date().toISOString().slice(0, 10),
      reportadoPor: String(formData.reportadoPor || '').trim() || 'Inspector SSOMA',
      clasificacion: formData.clasificacion as 'Acto Inseguro' | 'Condición Insegura',
      categoriaCodigo: formData.categoriaCodigo || 'CAT-08',
      categoriaNombre: catObj ? catObj.nombre : (formData.categoriaNombre || 'General'),
      potencialGravedad: formData.potencialGravedad || 2,
      prioridad: pgToPrioridad(formData.potencialGravedad || 2),
      descripcion: String(formData.descripcion || '').trim(),
      fotoUrl: finalFotoUrl,
      fotoDriveId: finalFotoDriveId,

      // Rama Acto Inseguro: si es Condición Insegura, se guardan indefinidos
      tipoPersonal: isActo ? formData.tipoPersonal : undefined,
      empresaPersonal: isActo ? formData.empresaPersonal : undefined,
      trabajadorObservadoDni: isActo ? String(formData.trabajadorObservadoDni || '').trim() : undefined,
      trabajadorObservadoNombre: isActo ? String(formData.trabajadorObservadoNombre || '').trim() : undefined,
      cargoObservado: isActo ? String(formData.cargoObservado || '').trim() : undefined,
      areaActo: isActo ? String(formData.areaActo || '').trim() : undefined,
      turnoActo: isActo ? formData.turnoActo : undefined,

      // Rama Condición Insegura
      areaCondicion: !isActo ? String(formData.areaCondicion || '').trim() : undefined,
      lugarEspecifico: String(formData.lugarEspecifico || '').trim() || undefined,

      // Seguimiento y Cierre
      estado: (formData.estado as any) || 'Pendiente',
      medidaCorrectiva: String(formData.medidaCorrectiva || '').trim() || '',
      responsableSeguimiento: String(formData.responsableSeguimiento || '').trim() || '',
      fechaCompromiso: formData.fechaCompromiso || '',
      createdAt: editingRecord?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Actualización optimista en Zustand Store
    upsertActoCondicion(newRecord);

    setIsModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: editingRecord ? 'Reporte Actualizado' : 'Reporte Registrado',
      message: `${newRecord.codigoReporte} guardado con éxito.`
    });

    // Envío a Google Apps Script
    try {
      await GasApiClient.post({
        action: 'saveActoCondicion',
        sheetName: 'SSOMA_Actos_Condiciones',
        data: newRecord
      });
    } finally {
      decrementSync();
    }
  };

  // Abrir Modal de Seguimiento y Cierre
  const handleOpenSeguimiento = (record: ActoCondicionRecord) => {
    setSeguimientoRecord(record);
    setSeguimientoError(null);
    setFotoCierreFile(null);
    setFotoCierrePreview(record.fotoCierreUrl || null);

    setSeguimientoForm({
      medidaCorrectiva: record.medidaCorrectiva || '',
      responsableSeguimiento: record.responsableSeguimiento || '',
      fechaCompromiso: record.fechaCompromiso || new Date().toISOString().slice(0, 10),
      estado: record.estado || 'Pendiente',
      fechaCierre: record.fechaCierre || new Date().toISOString().slice(0, 10),
      observacionCierre: record.observacionCierre || ''
    });

    setIsSeguimientoModalOpen(true);
  };

  // Carga de Foto de Cierre
  const handleFotoCierreFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      setSeguimientoError('La foto de cierre supera los 8MB permitidos.');
      return;
    }
    if (!file.type.startsWith('image/')) {
      setSeguimientoError('Debe ser un archivo de imagen válido.');
      return;
    }

    setFotoCierreFile(file);
    setIsCompressingCierre(true);

    try {
      const compressed = await DriveStorageService.compressImage(file, {
        maxDimension: 1200,
        quality: 0.82
      });
      setFotoCierrePreview(`data:image/jpeg;base64,${compressed.base64}`);
      setSeguimientoError(null);
    } catch {
      setSeguimientoError('Error al comprimir la foto de cierre.');
    } finally {
      setIsCompressingCierre(false);
    }
  };

  // Guardar Seguimiento y Cierre (sin duplicar filas)
  const handleSaveSeguimiento = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!seguimientoRecord) return;
    setSeguimientoError(null);

    if (!String(seguimientoForm.medidaCorrectiva || '').trim()) {
      setSeguimientoError('Es obligatorio describir la medida correctiva o plan de acción implementado.');
      return;
    }
    if (!String(seguimientoForm.responsableSeguimiento || '').trim()) {
      setSeguimientoError('Es obligatorio asignar un responsable de seguimiento.');
      return;
    }
    if (!seguimientoForm.fechaCompromiso) {
      setSeguimientoError('La fecha de compromiso es obligatoria.');
      return;
    }

    // Si cambia a "Cerrado", exige fecha de cierre
    if (seguimientoForm.estado === 'Cerrado') {
      if (!seguimientoForm.fechaCierre) {
        setSeguimientoError('Para marcar el caso como Cerrado es obligatorio registrar la fecha de cierre.');
        return;
      }
    }

    let finalFotoCierreUrl = seguimientoRecord.fotoCierreUrl || '';
    let finalFotoCierreDriveId = seguimientoRecord.fotoCierreDriveId || '';

    if (fotoCierreFile) {
      try {
        incrementSync();
        addToast({
          type: 'info',
          title: 'Subiendo Evidencia de Cierre',
          message: 'Guardando foto de levantamiento en Google Drive...'
        });

        const uploadResult = await DriveStorageService.uploadToDrive(fotoCierreFile, {
          modulo: 'ACTOS_CONDICIONES_CIERRE',
          fileName: `cierre_${seguimientoRecord.codigoReporte}_${Date.now()}.jpg`,
          maxDimension: 1200
        });

        finalFotoCierreUrl = uploadResult.fileUrl;
        finalFotoCierreDriveId = uploadResult.fileId;
      } catch {
        finalFotoCierreUrl = fotoCierrePreview || '';
      } finally {
        decrementSync();
      }
    }

    const updatedRecord: ActoCondicionRecord = {
      ...seguimientoRecord,
      medidaCorrectiva: String(seguimientoForm.medidaCorrectiva || '').trim(),
      responsableSeguimiento: String(seguimientoForm.responsableSeguimiento || '').trim(),
      fechaCompromiso: seguimientoForm.fechaCompromiso,
      estado: seguimientoForm.estado,
      fechaCierre: seguimientoForm.estado === 'Cerrado' ? seguimientoForm.fechaCierre : undefined,
      observacionCierre: String(seguimientoForm.observacionCierre || '').trim() || undefined,
      fotoCierreUrl: finalFotoCierreUrl,
      fotoCierreDriveId: finalFotoCierreDriveId,
      updatedAt: new Date().toISOString()
    };

    // Actualización optimista sobre la misma fila en Zustand Store
    upsertActoCondicion(updatedRecord);

    setIsSeguimientoModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: 'Seguimiento Actualizado',
      message: `${updatedRecord.codigoReporte} ahora en estado '${updatedRecord.estado}'.`
    });

    try {
      await GasApiClient.post({
        action: 'updateSeguimientoActoCondicion',
        sheetName: 'SSOMA_Actos_Condiciones',
        id: updatedRecord.id,
        data: updatedRecord
      });
    } finally {
      decrementSync();
    }
  };

  const confirmDeleteReporte = async () => {
    if (!deleteModalReporte) return;
    const record = deleteModalReporte;

    removeActoCondicion(record.id);
    incrementSync();

    addToast({
      type: 'info',
      title: 'Reporte Eliminado',
      message: `${record.codigoReporte} eliminado.`
    });

    try {
      await GasApiClient.post({
        action: 'deleteActoCondicion',
        sheetName: 'SSOMA_Actos_Condiciones',
        id: record.id
      });
    } catch {
      // Fallback silencioso
    } finally {
      decrementSync();
      setDeleteModalReporte(null);
    }
  };

  // Exportaciones
  const handleExportExcel = () => {
    const exportData = filteredRegistros.map((r) => ({
      'Código': r.codigoReporte,
      'Empresa': r.empresa,
      'Fecha': r.fecha,
      'Reportado Por': r.reportadoPor,
      'Clasificación': r.clasificacion,
      'Categoría': `${r.categoriaCodigo} - ${getCategoriaNombre(r.categoriaCodigo, r.categoriaNombre)}`,
      'P.G.': `P.G. ${r.potencialGravedad}`,
      'Prioridad': r.prioridad,
      'Descripción': r.descripcion,
      'Área / Ubicación': r.clasificacion === 'Acto Inseguro' ? r.areaActo : `${r.areaCondicion} (${r.lugarEspecifico || ''})`,
      'Personal Observado': r.clasificacion === 'Acto Inseguro' ? `${r.trabajadorObservadoNombre || ''} (${r.cargoObservado || ''})` : 'N/A',
      'Turno': r.turnoActo || 'N/A',
      'Estado': r.estado,
      'Medida Correctiva': r.medidaCorrectiva || 'Sin plan',
      'Responsable Seguimiento': r.responsableSeguimiento || 'Sin asignar',
      'Fecha Compromiso': r.fechaCompromiso || 'N/A',
      'Fecha Cierre': r.fechaCierre || 'N/A',
      'URL Foto Evidencia': r.fotoUrl || 'Sin foto',
      'URL Foto Cierre': r.fotoCierreUrl || 'Sin foto'
    }));

    ExportUtils.exportToExcel(exportData, `Actos_Condiciones_Inseguras_${empresaActiva}`);
    addToast({
      type: 'success',
      title: 'Excel Descargado',
      message: 'Base de datos de actos y condiciones exportada.'
    });
  };

  const handleExportPdf = () => {
    ExportUtils.exportToPdf({
      title: 'REPORTE PREVENTIVO DE ACTOS Y CONDICIONES INSEGURAS',
      subtitle: `Empresa: ${empresaActiva} | Total registros: ${filteredRegistros.length}`,
      empresa: empresaActiva,
      fileName: `Actos_Condiciones_${empresaActiva}`,
      headers: ['Código', 'Fecha', 'Clasificación', 'Categoría', 'P.G.', 'Descripción / Ubicación', 'Responsable', 'Estado'],
      rows: filteredRegistros.map((r) => [
        r.codigoReporte,
        r.fecha,
        r.clasificacion,
        r.categoriaCodigo,
        `P.G. ${r.potencialGravedad}`,
        r.clasificacion === 'Acto Inseguro'
          ? `${r.trabajadorObservadoNombre || ''} - ${r.descripcion}`
          : `${r.lugarEspecifico || r.areaCondicion} - ${r.descripcion}`,
        r.responsableSeguimiento || '-',
        r.estado
      ]),
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'PDF Generado',
      message: 'Reporte oficial de actos y condiciones descargado.'
    });
  };

  // KPIs
  const totalActos = useMemo(
    () => filteredRegistros.filter((r) => r.clasificacion === 'Acto Inseguro').length,
    [filteredRegistros]
  );
  const totalCondiciones = useMemo(
    () => filteredRegistros.filter((r) => r.clasificacion === 'Condición Insegura').length,
    [filteredRegistros]
  );
  const totalPendientes = useMemo(
    () => filteredRegistros.filter((r) => r.estado !== 'Cerrado').length,
    [filteredRegistros]
  );
  const totalCerrados = useMemo(
    () => filteredRegistros.filter((r) => r.estado === 'Cerrado').length,
    [filteredRegistros]
  );

  return (
    <div className="space-y-6">
      <ModuleHeader
        codigo={4}
        titulo="Reporte de Actos y Condiciones Inseguras"
        subtitulo="Identificación preventiva de riesgos, catálogo de 12 categorías, lógica condicional por clasificación y seguimiento de cierre"
        icono={<ShieldAlert className="w-5 h-5" />}
        onNuevo={handleOpenNuevoModal}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS['actos-condiciones']}
        onImportSuccess={(rows) => {
          const mappedItems: ActoCondicionRecord[] = rows.map((r: any) => ({
            id: r.id ? String(r.id).trim() : `AC-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            codigoReporte: String(r.codigoRegistro || r.codigoReporte || `AC-${new Date().getFullYear()}-${Math.floor(Math.random() * 900 + 100)}`).trim(),
            empresa: (r.empresaAsignada as any) || empresaActiva,
            fecha: r.fecha ? String(r.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
            reportadoPor: String(r.reportadoPor || 'Inspector SSOMA').trim(),
            clasificacion: r.tipoReporte === 'Condición Insegura' ? 'Condición Insegura' : 'Acto Inseguro',
            categoriaCodigo: String(r.categoriaId || 'CAT-01').trim(),
            categoriaNombre: String(r.categoriaNombre || 'General').trim(),
            potencialGravedad: (Number(r.nivelRiesgo) as 1 | 2 | 3 | 4) || 2,
            prioridad: pgToPrioridad((Number(r.nivelRiesgo) as 1 | 2 | 3 | 4) || 2),
            descripcion: String(r.descripcion || '').trim(),
            tipoPersonal: r.tipoPersonal || undefined,
            empresaPersonal: r.empresaPersonal ? String(r.empresaPersonal).trim() : undefined,
            trabajadorObservadoDni: r.trabajadorObservadoDni ? String(r.trabajadorObservadoDni).trim() : undefined,
            trabajadorObservadoNombre: r.trabajadorObservadoNombre ? String(r.trabajadorObservadoNombre).trim() : undefined,
            cargoObservado: r.cargoObservado ? String(r.cargoObservado).trim() : undefined,
            areaActo: r.areaActo ? String(r.areaActo).trim() : undefined,
            areaCondicion: r.areaCondicion ? String(r.areaCondicion).trim() : undefined,
            lugarEspecifico: r.lugarEspecifico ? String(r.lugarEspecifico).trim() : undefined,
            estado: r.estado || 'Pendiente',
            createdAt: new Date().toISOString()
          }));
          batchUpsertActosCondiciones(mappedItems);
        }}
      />

      {/* Tarjetas de Indicadores */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <UserX className="w-4 h-4 text-[#B45309]" />
            <span className="font-semibold">Actos Inseguros</span>
          </div>
          <div className="text-2xl font-black text-[#B45309]">{totalActos}</div>
          <div className="text-[10px] text-[#475569] mt-1 font-medium">Comportamiento del personal</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <AlertTriangle className="w-4 h-4 text-[#DC2626]" />
            <span className="font-semibold">Condiciones Inseguras</span>
          </div>
          <div className="text-2xl font-black text-[#DC2626]">{totalCondiciones}</div>
          <div className="text-[10px] text-[#475569] mt-1 font-medium">Instalaciones y equipos</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <Clock className="w-4 h-4 text-[#0284C7]" />
            <span className="font-semibold">Casos Abiertos / Proceso</span>
          </div>
          <div className="text-2xl font-black text-[#0F172A]">{totalPendientes}</div>
          <div className="text-[10px] text-[#475569] mt-1 font-medium">Requieren plan de acción</div>
        </div>

        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-2xs">
          <div className="flex items-center gap-2 text-[#475569] text-xs mb-1">
            <CheckCircle2 className="w-4 h-4 text-[#047857]" />
            <span className="font-semibold">Casos Cerrados</span>
          </div>
          <div className="text-2xl font-black text-[#047857]">{totalCerrados}</div>
          <div className="text-[10px] text-[#475569] mt-1 font-medium">Con evidencia de levantamiento</div>
        </div>
      </div>

      {/* Barra de Filtros y Herramientas Estandarizada */}
      <ModuleToolbar
        searchQuery={searchTerm}
        onSearchChange={(val) => {
          setSearchTerm(val);
          setCurrentPage(1);
        }}
        searchPlaceholder="Buscar por código, descripción, trabajador, área o lugar..."
        statusFilter={estadoFilter}
        onStatusFilterChange={(id) => {
          setEstadoFilter(id as any);
          setCurrentPage(1);
        }}
        statusOptions={statusOptions}
        totalCount={registros.filter((r) => empresaActiva === 'CONSOLIDADO' ? true : r.empresa === empresaActiva).length}
        filteredCount={filteredRegistros.length}
        onExportExcel={handleExportExcel}
        onExportPdf={handleExportPdf}
        onNewRecord={handleOpenNuevoModal}
        newRecordLabel="Nuevo Reporte"
      >
        <button
          type="button"
          onClick={handleSyncSheets}
          disabled={isSyncingSheets}
          title="Sincronizar directamente con Google Sheets"
          className="flex items-center gap-1.5 bg-white border border-slate-200 hover:border-[#0F172A] text-slate-700 hover:text-[#0F172A] px-2.5 py-1.5 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-60"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncingSheets ? 'animate-spin text-emerald-600' : 'text-slate-500'}`} />
          <span className="hidden sm:inline">Sincronizar Sheets</span>
        </button>
        <select
          value={clasificacionFilter}
          onChange={(e) => {
            setClasificacionFilter(e.target.value as any);
            setCurrentPage(1);
          }}
          className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
        >
          <option value="TODOS">Todas las clasificaciones</option>
          <option value="Acto Inseguro">Solo Actos Inseguros</option>
          <option value="Condición Insegura">Solo Condiciones Inseguras</option>
        </select>
        <select
          value={areaFilter}
          onChange={(e) => {
            setAreaFilter(e.target.value);
            setCurrentPage(1);
          }}
          className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
        >
          <option value="TODOS">Todas las áreas</option>
          {AREAS_EMPRESA.map((area) => (
            <option key={area} value={area}>
              {area}
            </option>
          ))}
        </select>
      </ModuleToolbar>

      {/* Tabla de Actos y Condiciones */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1100px] text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
              <tr>
                <th className="px-4 py-3 w-28 whitespace-nowrap">Código</th>
                <th className="px-4 py-3 w-36 whitespace-nowrap">Clasificación & Fecha</th>
                <th className="px-4 py-3 min-w-[160px]">Categoría de Riesgo</th>
                <th className="px-4 py-3 w-32 whitespace-nowrap">P.G. / Prioridad</th>
                <th className="px-4 py-3 min-w-[160px]">Ubicación / Trabajador</th>
                <th className="px-4 py-3 min-w-[200px]">Descripción</th>
                <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Evidencias</th>
                <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Estado</th>
                <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRegistros.length === 0 ? (
                <TableEmptyState
                  isTableRow
                  colSpan={9}
                  title="No se encontraron reportes"
                  description={
                    searchTerm
                      ? `No hay coincidencias para "${searchTerm}". Prueba con otro término.`
                      : 'No hay reportes registrados que coincidan con los filtros seleccionados.'
                  }
                  actionLabel={
                    searchTerm || estadoFilter !== 'TODOS' || clasificacionFilter !== 'TODOS' || areaFilter !== 'TODOS'
                      ? 'Limpiar filtros'
                      : 'Nuevo Reporte'
                  }
                  actionIcon={
                    searchTerm || estadoFilter !== 'TODOS' || clasificacionFilter !== 'TODOS' || areaFilter !== 'TODOS'
                      ? 'clear'
                      : 'plus'
                  }
                  onAction={() => {
                    if (searchTerm || estadoFilter !== 'TODOS' || clasificacionFilter !== 'TODOS' || areaFilter !== 'TODOS') {
                      setSearchTerm('');
                      setEstadoFilter('TODOS');
                      setClasificacionFilter('TODOS');
                      setAreaFilter('TODOS');
                      setCurrentPage(1);
                    } else {
                      handleOpenNuevoModal();
                    }
                  }}
                />
              ) : (
                paginatedRegistros.map((r, rIdx) => (
                  <tr key={`${r.id || r.codigoReporte || ''}-${rIdx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                      {r.codigoReporte}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${
                          r.clasificacion === 'Acto Inseguro'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {r.clasificacion}
                      </span>
                      <div className="text-[10px] text-slate-500 mt-0.5">{r.fecha}</div>
                    </td>
                    <td className="px-4 py-3 max-w-[180px]">
                      <div className="font-semibold text-slate-800 truncate">{getCategoriaNombre(r.categoriaCodigo, r.categoriaNombre)}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{r.categoriaCodigo}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-slate-700">P.G. {r.potencialGravedad}</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-semibold ${
                            r.prioridad === 'Inmediata'
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : r.prioridad === 'Alta'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : r.prioridad === 'Media'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {r.prioridad}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 max-w-[190px]">
                      {r.clasificacion === 'Acto Inseguro' ? (
                        <div>
                          <div className="font-medium text-slate-800 truncate">
                            {r.trabajadorObservadoNombre || 'Personal no identificado'}
                          </div>
                          <div className="text-[10px] text-slate-500 line-clamp-1">
                            {r.cargoObservado || 'Sin cargo'} • {r.areaActo}
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="font-medium text-slate-800 truncate">{r.areaCondicion}</div>
                          <div className="text-[10px] text-slate-500 line-clamp-1">
                            {r.lugarEspecifico || 'Lugar general'}
                          </div>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      <p className="line-clamp-2 text-slate-600">{r.descripcion}</p>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        {r.fotoUrl ? (
                          <button
                            type="button"
                            onClick={() =>
                              setLightboxImage({
                                url: r.fotoUrl!,
                                title: `Evidencia Inicial - ${r.codigoReporte}`,
                                subtitle: r.descripcion
                              })
                            }
                            className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1 text-[10px] border border-slate-200 transition-colors cursor-pointer"
                            title="Ver evidencia inicial en grande"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Inicial</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-500 font-medium">Sin foto</span>
                        )}

                        {r.fotoCierreUrl && (
                          <button
                            type="button"
                            onClick={() =>
                              setLightboxImage({
                                url: r.fotoCierreUrl!,
                                title: `Evidencia de Cierre - ${r.codigoReporte}`,
                                subtitle: r.medidaCorrectiva || r.descripcion
                              })
                            }
                            className="p-1 rounded bg-emerald-50 text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1 text-[10px] border border-emerald-200 transition-colors cursor-pointer"
                            title="Ver evidencia de cierre en grande"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Cierre</span>
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge
                        status={r.estado}
                        onClick={() => handleOpenSeguimiento(r)}
                      />
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setViewDetailReporte(r)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
                          title="Ver Ficha de Reporte"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenSeguimiento(r)}
                          className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors"
                          title="Gestionar Seguimiento y Cierre"
                        >
                          <CheckSquare className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingRecord(r);
                            setFormData({ ...r });
                            setFotoPreview(r.fotoUrl || null);
                            setIsModalOpen(true);
                          }}
                          className="p-1.5 rounded hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors"
                          title="Editar Reporte"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteModalReporte(r)}
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-colors"
                          title="Eliminar Reporte"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginación */}
        <TablePagination
          currentPage={currentPage}
          totalItems={filteredRegistros.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
          onPageSizeChange={(newSize) => {
            setPageSize(newSize);
            setCurrentPage(1);
          }}
        />
      </div>

      {/* MODAL 1: FORMULARIO PRINCIPAL CON LÓGICA CONDICIONAL */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-700 border border-amber-200">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0F172A] text-base">
                    {editingRecord ? `Editar ${editingRecord.codigoReporte}` : 'Reportar Acto o Condición Insegura'}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">
                    Formulario dinámico con validaciones específicas por clasificación
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveRegistro} className="space-y-4 text-xs">
              {/* Selector de Clasificación (Acto vs Condición) */}
              <div>
                <label className="block text-[#475569] font-semibold mb-1.5">
                  Tipo de Clasificación Preventiva <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => handleClasificacionChange('Acto Inseguro')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                      formData.clasificacion === 'Acto Inseguro'
                        ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500 text-amber-900'
                        : 'bg-white border-[#CBD5E1] text-[#475569] hover:bg-slate-50'
                    }`}
                  >
                    <UserX className={`w-5 h-5 shrink-0 mt-0.5 ${formData.clasificacion === 'Acto Inseguro' ? 'text-amber-700' : 'text-slate-400'}`} />
                    <div>
                      <div className={`font-bold text-xs ${formData.clasificacion === 'Acto Inseguro' ? 'text-amber-900' : 'text-[#0F172A]'}`}>
                        Acto Inseguro
                      </div>
                      <div className={`text-[10px] mt-0.5 ${formData.clasificacion === 'Acto Inseguro' ? 'text-amber-800' : 'text-[#475569]'}`}>
                        Comportamiento o transgresión de normas del personal
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleClasificacionChange('Condición Insegura')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                      formData.clasificacion === 'Condición Insegura'
                        ? 'bg-rose-50 border-rose-500 ring-2 ring-rose-500 text-rose-900'
                        : 'bg-white border-[#CBD5E1] text-[#475569] hover:bg-slate-50'
                    }`}
                  >
                    <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${formData.clasificacion === 'Condición Insegura' ? 'text-rose-700' : 'text-slate-400'}`} />
                    <div>
                      <div className={`font-bold text-xs ${formData.clasificacion === 'Condición Insegura' ? 'text-rose-900' : 'text-[#0F172A]'}`}>
                        Condición Insegura
                      </div>
                      <div className={`text-[10px] mt-0.5 ${formData.clasificacion === 'Condición Insegura' ? 'text-rose-800' : 'text-[#475569]'}`}>
                        Falla física en instalaciones, máquinas o entorno
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Empresa, Fecha y Reportante */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Razón Social</label>
                  <select
                    value={formData.empresa}
                    onChange={(e) => setFormData({ ...formData, empresa: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                    <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Fecha del Hallazgo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.fecha}
                    onChange={(e) => setFormData({ ...formData, fecha: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Reportado Por <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="lista-reportantes"
                    placeholder="Nombre del reportante"
                    value={formData.reportadoPor}
                    onChange={(e) => setFormData({ ...formData, reportadoPor: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-reportantes">
                    {trabajadoresActivos.map((t, idx) => (
                      <option key={`${t.id || t.dni}-${idx}`} value={t.apellidosNombres} />
                    ))}
                  </datalist>
                </div>
              </div>

              {/* Catálogo de 12 Categorías (CAT-01 a CAT-12) */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div className="sm:col-span-2">
                    <label className="block text-[#475569] font-semibold mb-1">
                      Catálogo de Categoría de Riesgo (12 Categorías) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <select
                      value={formData.categoriaCodigo}
                      onChange={(e) => handleCategoriaChange(e.target.value)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    >
                      {CATALOGO_CATEGORIAS_RIESGO.map((cat) => (
                        <option key={cat.codigo} value={cat.codigo}>
                          {cat.codigo}: {cat.nombre}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#475569] font-semibold mb-1">Potencial de Gravedad (P.G.)</label>
                    <div className="flex items-center gap-2">
                      <select
                        value={formData.potencialGravedad}
                        onChange={(e) => {
                          const pg = Number(e.target.value) as 1 | 2 | 3 | 4;
                          setFormData({
                            ...formData,
                            potencialGravedad: pg,
                            prioridad: pgToPrioridad(pg)
                          });
                        }}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      >
                        <option value={1}>P.G. 1 (Bajo)</option>
                        <option value={2}>P.G. 2 (Medio)</option>
                        <option value={3}>P.G. 3 (Alto)</option>
                        <option value={4}>P.G. 4 (Crítico)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-[#475569] flex items-center justify-between">
                  <span>
                    Prioridad calculada automáticamente:{' '}
                    <strong className="text-[#047857] font-bold">{formData.prioridad}</strong>
                  </span>
                  <span>
                    Plazo sugerido: <strong className="text-[#0F172A]">{pgToDiasPlazo(formData.potencialGravedad || 2)} días</strong>
                  </span>
                </div>
              </div>

              {/* RAMA CONDICIONAL 1: ACTO INSEGURO */}
              {formData.clasificacion === 'Acto Inseguro' && (
                <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 space-y-3.5 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs">
                    <UserX className="w-4 h-4 text-amber-700" />
                    <span>Datos Obligatorios del Acto Inseguro</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Tipo de Personal <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <select
                        value={formData.tipoPersonal || 'Propio'}
                        onChange={() => setFormData({ ...formData, tipoPersonal: 'Propio' })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      >
                        <option value="Propio">Personal Propio (Planilla)</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[#475569] font-semibold mb-1">
                        Empresa del Personal Observado <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="PERPOL o TR3"
                        value={formData.empresaPersonal}
                        onChange={(e) => setFormData({ ...formData, empresaPersonal: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                    </div>
                  </div>

                  {/* Autocompletado del Colaborador */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Trabajador Observado (DNI) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        list="lista-trabajadores-dni"
                        placeholder="Escribe DNI o selecciona de la lista"
                        value={formData.trabajadorObservadoDni}
                        onChange={(e) => handleSelectTrabajadorObservado(e.target.value)}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-mono focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                      <datalist id="lista-trabajadores-dni">
                        {trabajadoresActivos.map((t, idx) => (
                          <option key={`${t.id || t.dni}-${idx}`} value={t.dni}>
                            {t.apellidosNombres} — {t.area || 'Sin Área'} ({t.empresa})
                          </option>
                        ))}
                      </datalist>
                    </div>

                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Nombres y Apellidos Observado
                      </label>
                      <input
                        type="text"
                        list="lista-trabajadores-nombres"
                        placeholder="Nombres completos o selecciona"
                        value={formData.trabajadorObservadoNombre}
                        onChange={(e) => {
                          const val = e.target.value;
                          setFormData((prev) => ({ ...prev, trabajadorObservadoNombre: val }));
                          const trab = trabajadoresActivos.find((t) => t.apellidosNombres === val);
                          if (trab) {
                            handleSelectTrabajadorObservado(trab.dni);
                          }
                        }}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                      <datalist id="lista-trabajadores-nombres">
                        {trabajadoresActivos.map((t, idx) => (
                          <option key={`nom-${t.id || t.dni}-${idx}`} value={t.apellidosNombres}>
                            DNI: {t.dni} — {t.puesto} — {t.area} ({t.empresa})
                          </option>
                        ))}
                      </datalist>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Cargo / Puesto <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ej: Operario de Calderas"
                        value={formData.cargoObservado}
                        onChange={(e) => setFormData({ ...formData, cargoObservado: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[#475569] font-semibold">
                          Área de Trabajo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                        </label>
                        {formData.areaActo && (
                          <span className="text-[10px] text-[#047857] font-semibold">
                            Base: {formData.areaActo}
                          </span>
                        )}
                      </div>
                      <select
                        required
                        value={formData.areaActo}
                        onChange={(e) => setFormData({ ...formData, areaActo: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      >
                        <option value="">Seleccione área de trabajo...</option>
                        {formData.areaActo && !areasTrabajadores.includes(formData.areaActo) && (
                          <option value={formData.areaActo}>{formData.areaActo} (Base)</option>
                        )}
                        {areasTrabajadores.map((a) => (
                          <option key={a} value={a}>
                            {a}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        list="lista-lugares-fisicos-acto"
                        placeholder="Escribe o selecciona lugar..."
                        value={formData.lugarEspecifico}
                        onChange={(e) => setFormData({ ...formData, lugarEspecifico: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                      <datalist id="lista-lugares-fisicos-acto">
                        {LUGARES_ESPECIFICOS.map((lug, idx) => (
                          <option key={`lug-acto-${idx}`} value={lug} />
                        ))}
                      </datalist>
                    </div>

                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Turno <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <select
                        value={formData.turnoActo}
                        onChange={(e) => setFormData({ ...formData, turnoActo: e.target.value as any })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      >
                        <option value="Mañana">Mañana (07:00 - 15:00)</option>
                        <option value="Tarde">Tarde (15:00 - 23:00)</option>
                        <option value="Noche">Noche (23:00 - 07:00)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* RAMA CONDICIONAL 2: CONDICIÓN INSEGURA */}
              {formData.clasificacion === 'Condición Insegura' && (
                <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 space-y-3.5 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-rose-900 font-bold text-xs">
                    <AlertTriangle className="w-4 h-4 text-rose-700" />
                    <span>Datos Obligatorios de la Condición Insegura</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Área Afectada <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <select
                        required
                        value={formData.areaCondicion}
                        onChange={(e) => setFormData({ ...formData, areaCondicion: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      >
                        <option value="">Seleccione área afectada...</option>
                        {formData.areaCondicion && !areasTrabajadores.includes(formData.areaCondicion) && (
                          <option value={formData.areaCondicion}>{formData.areaCondicion} (Base)</option>
                        )}
                        {areasTrabajadores.map((a) => (
                          <option key={a} value={a}>
                            {a}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[#475569] font-semibold mb-1">
                        Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        list="lista-lugares-fisicos-condicion"
                        placeholder="Escribe o selecciona lugar (ej: Caldero, Sala de compresores...)"
                        value={formData.lugarEspecifico}
                        onChange={(e) => setFormData({ ...formData, lugarEspecifico: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-1.5 text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                      <datalist id="lista-lugares-fisicos-condicion">
                        {LUGARES_ESPECIFICOS.map((lug, idx) => (
                          <option key={`lug-cond-${idx}`} value={lug} />
                        ))}
                      </datalist>
                    </div>
                  </div>
                </div>
              )}

              {/* Descripción Detallada */}
              <div>
                <label className="block text-[#475569] font-semibold mb-1">
                  Descripción Detallada del Hallazgo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Detalla con precisión el acto observado o la condición de peligro encontrada..."
                  value={formData.descripcion}
                  onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                />
              </div>

              {/* Foto Inicial de Evidencia */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-[#475569] font-semibold text-xs flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#047857]" />
                    <span>Foto de Evidencia Inicial (Google Drive)</span>
                  </label>
                  <span className="text-[10px] text-[#475569]">Máx 8MB • Compresión automática</span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <label className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[#047857] text-xs font-semibold cursor-pointer transition-colors shadow-2xs">
                    <Upload className="w-4 h-4 text-[#047857]" />
                    <span>Seleccionar Foto</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFotoFileChange}
                      className="hidden"
                    />
                  </label>

                  {isCompressingFoto && (
                    <span className="text-xs text-amber-600 animate-pulse font-medium">Comprimiendo...</span>
                  )}

                  {typeof fotoPreview === 'string' && fotoPreview.trim().length > 0 && (
                    <div className="flex items-center gap-3">
                      <img
                        src={fotoPreview.trim()}
                        alt="Evidencia"
                        className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                      />
                      <span className="text-[11px] text-[#047857] font-semibold">✓ Imagen optimizada</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Botones de acción */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs border border-slate-200 cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-bold text-xs transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingRecord ? 'Guardar Cambios' : 'Registrar Reporte'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: SEGUIMIENTO Y CIERRE (Exige plan, responsable, compromiso, y si es cerrado exige fecha y foto) */}
      {isSeguimientoModalOpen && seguimientoRecord && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsSeguimientoModalOpen(false);
          }}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckSquare className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0F172A] text-base">
                    Seguimiento y Cierre: {seguimientoRecord.codigoReporte}
                  </h3>
                  <p className="text-xs text-[#475569] font-medium">{getCategoriaNombre(seguimientoRecord.categoriaCodigo, seguimientoRecord.categoriaNombre)}</p>
                </div>
              </div>
              <button
                onClick={() => setIsSeguimientoModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {seguimientoError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{seguimientoError}</span>
              </div>
            )}

            <form onSubmit={handleSaveSeguimiento} className="space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Medida Correctiva / Plan de Acción Implementado <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Describe la solución aplicada para corregir el acto o subsanar la condición..."
                  value={seguimientoForm.medidaCorrectiva}
                  onChange={(e) => setSeguimientoForm({ ...seguimientoForm, medidaCorrectiva: e.target.value })}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Responsable del Seguimiento <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="lista-responsables"
                    placeholder="Selecciona o escribe responsable"
                    value={seguimientoForm.responsableSeguimiento}
                    onChange={(e) => setSeguimientoForm({ ...seguimientoForm, responsableSeguimiento: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-responsables">
                    {trabajadoresActivos.map((t, idx) => (
                      <option key={`${t.id || t.dni}-${idx}`} value={t.apellidosNombres} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Fecha Compromiso <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={seguimientoForm.fechaCompromiso}
                    onChange={(e) => setSeguimientoForm({ ...seguimientoForm, fechaCompromiso: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] mb-1">
                      Estado de la Acción <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    <select
                      value={seguimientoForm.estado}
                      onChange={(e) => setSeguimientoForm({ ...seguimientoForm, estado: e.target.value as any })}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    >
                      <option value="Pendiente">Pendiente</option>
                      <option value="En proceso">En proceso</option>
                      <option value="Cerrado">Cerrado (Subsanado)</option>
                    </select>
                  </div>

                  {seguimientoForm.estado === 'Cerrado' && (
                    <div>
                      <label className="block text-xs font-semibold text-[#475569] mb-1">
                        Fecha de Cierre Efectiva <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                      </label>
                      <input
                        type="date"
                        required
                        value={seguimientoForm.fechaCierre}
                        onChange={(e) => setSeguimientoForm({ ...seguimientoForm, fechaCierre: e.target.value })}
                        className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#047857] font-semibold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                      />
                    </div>
                  )}
                </div>

                {seguimientoForm.estado === 'Cerrado' && (
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] mb-1">Observaciones de Cierre</label>
                    <input
                      type="text"
                      placeholder="Conclusiones de verificación de eficacia..."
                      value={seguimientoForm.observacionCierre}
                      onChange={(e) => setSeguimientoForm({ ...seguimientoForm, observacionCierre: e.target.value })}
                      className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                    />
                  </div>
                )}
              </div>

              {/* Foto de Cierre / Evidencia de Corrección */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-slate-700 font-semibold text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Foto de Evidencia de Levantamiento / Cierre</span>
                  </label>
                  <span className="text-[10px] text-slate-500">Drive • Comprimida</span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <label className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 text-emerald-600" />
                    <span>Seleccionar Foto Cierre</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFotoCierreFileChange}
                      className="hidden"
                    />
                  </label>

                  {isCompressingCierre && (
                    <span className="text-xs text-amber-700 animate-pulse">Comprimiendo...</span>
                  )}

                  {typeof fotoCierrePreview === 'string' && fotoCierrePreview.trim().length > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg overflow-hidden border border-slate-300">
                        <DriveImage
                          src={fotoCierrePreview}
                          driveId={seguimientoRecord?.fotoCierreDriveId}
                          alt="Evidencia Cierre"
                          className="w-full h-full object-cover"
                          showOpenButton={false}
                        />
                      </div>
                      <span className="text-[11px] text-emerald-700 font-medium">✓ Evidencia lista</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsSeguimientoModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-semibold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4 text-white" />
                  <span>Actualizar Seguimiento</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL FICHA DETALLADA DE REPORTE */}
      {viewDetailReporte && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewDetailReporte(null);
          }}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="fixed inset-0 -z-10 cursor-pointer"
            onClick={() => setViewDetailReporte(null)}
            aria-hidden="true"
          />

          <div
            className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header del modal fijo */}
            <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className={`p-2 rounded-lg border shrink-0 ${
                  viewDetailReporte.clasificacion === 'Acto Inseguro'
                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200'
                }`}>
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-base font-bold text-[#0F172A] truncate">
                    Ficha de Reporte — {viewDetailReporte.codigoReporte}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium truncate">
                    {viewDetailReporte.clasificacion} • {getCategoriaNombre(viewDetailReporte.categoriaCodigo, viewDetailReporte.categoriaNombre)} ({viewDetailReporte.categoriaCodigo})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewDetailReporte(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer shrink-0"
                title="Cerrar ficha (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Contenido con scroll independiente */}
            <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Empresa</span>
                  <span className="text-slate-900 font-bold">{viewDetailReporte.empresa}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Fecha</span>
                  <span className="text-slate-900 font-mono font-medium">{viewDetailReporte.fecha}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Gravedad</span>
                  <span className="text-amber-800 font-bold font-mono">P.G. {viewDetailReporte.potencialGravedad} ({viewDetailReporte.prioridad})</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Estado</span>
                  <span className={`font-bold ${
                    viewDetailReporte.estado === 'Cerrado'
                      ? 'text-emerald-700'
                      : viewDetailReporte.estado === 'En proceso'
                      ? 'text-sky-700'
                      : 'text-amber-700'
                  }`}>
                    {viewDetailReporte.estado}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-slate-700 font-bold block mb-1">Descripción del Evento / Desvío:</span>
                <p className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-slate-800 leading-relaxed text-sm">
                  {viewDetailReporte.descripcion}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] space-y-2">
                  <span className="text-[#475569] text-xs uppercase font-bold block">Personal y Ubicación</span>
                  {viewDetailReporte.clasificacion === 'Acto Inseguro' ? (
                    <>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Colaborador: </span>
                        <span className="text-[#0F172A] font-bold">{viewDetailReporte.trabajadorObservadoNombre || 'No identificado'}</span>
                      </div>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Puesto: </span>
                        <span className="text-[#0F172A]">{viewDetailReporte.cargoObservado || 'Sin cargo'}</span>
                      </div>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Área de Trabajo: </span>
                        <span className="text-[#0F172A] font-bold">{viewDetailReporte.areaActo || viewDetailReporte.areaCondicion || 'General'}</span>
                      </div>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Lugar Físico Específico: </span>
                        <span className="text-[#0F172A] font-medium">{viewDetailReporte.lugarEspecifico || 'General'}</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Área de Condición: </span>
                        <span className="text-[#0F172A] font-bold">{viewDetailReporte.areaCondicion || viewDetailReporte.areaActo || 'General'}</span>
                      </div>
                      <div>
                        <span className="text-[#475569] text-xs font-semibold">Lugar Físico Específico: </span>
                        <span className="text-[#0F172A] font-medium">{viewDetailReporte.lugarEspecifico || 'General'}</span>
                      </div>
                    </>
                  )}
                  <div>
                    <span className="text-[#475569] text-xs font-semibold">Reportado Por: </span>
                    <span className="text-[#0F172A] font-medium">{viewDetailReporte.reportadoPor || 'Anónimo'}</span>
                  </div>
                </div>

                <div className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] space-y-2">
                  <span className="text-[#475569] text-xs uppercase font-bold block">Seguimiento y Cierre</span>
                  <div>
                    <span className="text-[#475569] text-xs font-semibold">Medida Correctiva: </span>
                    <span className="text-[#0F172A] font-medium">{viewDetailReporte.medidaCorrectiva || 'Sin acción registrada'}</span>
                  </div>
                  <div>
                    <span className="text-[#475569] text-xs font-semibold">Responsable Seguimiento: </span>
                    <span className="text-[#0F172A] font-medium">{viewDetailReporte.responsableSeguimiento || 'No asignado'}</span>
                  </div>
                  {viewDetailReporte.fechaCierre && (
                    <div>
                      <span className="text-[#475569] text-xs font-semibold">Fecha Cierre: </span>
                      <span className="text-[#047857] font-mono font-bold">{viewDetailReporte.fechaCierre}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Fotografías inicial y cierre */}
              {((typeof viewDetailReporte.fotoUrl === 'string' && viewDetailReporte.fotoUrl.trim().length > 0) || (typeof viewDetailReporte.fotoCierreUrl === 'string' && viewDetailReporte.fotoCierreUrl.trim().length > 0)) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {typeof viewDetailReporte.fotoUrl === 'string' && viewDetailReporte.fotoUrl.trim().length > 0 && (
                    <div>
                      <span className="text-slate-700 font-semibold block mb-1.5 flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-amber-600" />
                        <span>Fotografía Evidencia Inicial:</span>
                      </span>
                      <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-48 flex items-center justify-center p-1">
                        <DriveImage
                          src={viewDetailReporte.fotoUrl}
                          driveId={viewDetailReporte.fotoDriveId}
                          alt={`Evidencia inicial - ${viewDetailReporte.codigoReporte}`}
                          className="max-h-full max-w-full object-contain rounded-lg shadow-2xs"
                          containerClassName="w-full h-full flex items-center justify-center"
                          onClick={() =>
                            setLightboxImage({
                              url: viewDetailReporte.fotoUrl!,
                              title: `Evidencia Inicial - ${viewDetailReporte.codigoReporte}`,
                              subtitle: viewDetailReporte.descripcion
                            })
                          }
                        />
                      </div>
                    </div>
                  )}

                  {typeof viewDetailReporte.fotoCierreUrl === 'string' && viewDetailReporte.fotoCierreUrl.trim().length > 0 && (
                    <div>
                      <span className="text-slate-700 font-semibold block mb-1.5 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Fotografía Evidencia de Cierre:</span>
                      </span>
                      <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-48 flex items-center justify-center p-1">
                        <DriveImage
                          src={viewDetailReporte.fotoCierreUrl}
                          driveId={viewDetailReporte.fotoCierreDriveId}
                          alt={`Evidencia de cierre - ${viewDetailReporte.codigoReporte}`}
                          className="max-h-full max-w-full object-contain rounded-lg shadow-2xs"
                          containerClassName="w-full h-full flex items-center justify-center"
                          onClick={() =>
                            setLightboxImage({
                              url: viewDetailReporte.fotoCierreUrl!,
                              title: `Evidencia de Cierre - ${viewDetailReporte.codigoReporte}`,
                              subtitle: viewDetailReporte.medidaCorrectiva || viewDetailReporte.descripcion
                            })
                          }
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-slate-500 font-mono">ID: {viewDetailReporte.id}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const r = viewDetailReporte;
                    setViewDetailReporte(null);
                    handleOpenSeguimiento(r);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-emerald-700 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 cursor-pointer"
                >
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Gestionar Seguimiento</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewDetailReporte(null)}
                  className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de confirmación para eliminar reporte */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalReporte)}
        onClose={() => setDeleteModalReporte(null)}
        onConfirm={confirmDeleteReporte}
        title="Eliminar Reporte de Acto / Condición"
        message="¿Estás seguro de que deseas eliminar este reporte preventivo? Esta acción no se puede deshacer."
        itemIdentifier={
          deleteModalReporte
            ? `${deleteModalReporte.codigoReporte}: ${deleteModalReporte.clasificacion} (${getCategoriaNombre(deleteModalReporte.categoriaCodigo, deleteModalReporte.categoriaNombre)})`
            : undefined
        }
        confirmButtonText="Eliminar Reporte"
      />

      {/* Visor de imágenes Lightbox */}
      <ImageLightboxModal
        isOpen={Boolean(lightboxImage)}
        onClose={() => setLightboxImage(null)}
        imageUrl={lightboxImage?.url}
        title={lightboxImage?.title}
        subtitle={lightboxImage?.subtitle}
      />
    </div>
  );
};
