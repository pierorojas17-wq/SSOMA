import React, { useState, useMemo } from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { useAppStore } from '../../store/appStore';
import { TrabajadorRecord } from '../../types/modules';
import { GasApiClient } from '../../services/api';
import { ExportUtils } from '../../utils/exportUtils';
import { ModuleToolbar, FilterChipOption } from '../../components/common/ModuleToolbar';
import { TablePagination } from '../../components/common/TablePagination';
import { TableEmptyState } from '../../components/common/TableEmptyState';
import { StatusBadge } from '../../components/common/StatusBadge';
import { AREAS_EMPRESA } from '../../utils/ssomaCatalogs';
import {
  Users,
  Edit2,
  Trash2,
  Eye,
  AlertCircle,
  Save,
  X
} from 'lucide-react';

export const calcularEdad = (fechaNac?: string): number | null => {
  if (!fechaNac) return null;
  const birth = new Date(fechaNac);
  if (isNaN(birth.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age >= 0 && age < 120 ? age : null;
};

/**
 * Identifica el tipo de documento:
 * - DNI: 8 dígitos
 * - C.E. (Carné de Extranjería): cuando lleva más de 8 dígitos/caracteres (hasta 12 máx)
 */
export const getTipoDocumento = (doc?: string): 'DNI' | 'C.E.' => {
  const clean = String(doc || '').trim();
  return clean.length > 8 ? 'C.E.' : 'DNI';
};

export const TrabajadoresPage: React.FC = () => {
  const {
    empresaActiva,
    trabajadores,
    upsertTrabajador,
    batchUpsertTrabajadores,
    removeTrabajador,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [condicionFilter, setCondicionFilter] = useState<'TODAS' | 'Activo' | 'Inactivo' | 'Cesado'>('TODAS');
  
  // Modal de importación masiva
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Modal de registro individual
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTrabajador, setEditingTrabajador] = useState<TrabajadorRecord | null>(null);
  const [formData, setFormData] = useState<Partial<TrabajadorRecord>>({
    dni: '',
    apellidosNombres: '',
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    condicion: 'Activo',
    sexo: 'M',
    fechaIngreso: new Date().toISOString().slice(0, 10),
    fechaNacimiento: '',
    puesto: '',
    area: '',
    telefono: '',
    correo: ''
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [deleteModalTrabajador, setDeleteModalTrabajador] = useState<TrabajadorRecord | null>(null);
  const [viewDetailTrabajador, setViewDetailTrabajador] = useState<TrabajadorRecord | null>(null);

  const edadCalculada = useMemo(
    () => calcularEdad(formData.fechaNacimiento),
    [formData.fechaNacimiento]
  );

  // Filtrado de trabajadores
  const filteredTrabajadores = useMemo(() => {
    return trabajadores.filter((t) => {
      const matchEmpresa =
        empresaActiva === 'CONSOLIDADO' ? true : t.empresa === empresaActiva;
      const matchCondicion =
        condicionFilter === 'TODAS' ? true : t.condicion === condicionFilter;
      const term = searchTerm.toLowerCase().trim();
      const dniStr = String(t.dni || '').toLowerCase();
      const nombresStr = String(t.apellidosNombres || '').toLowerCase();
      const puestoStr = String(t.puesto || '').toLowerCase();
      const areaStr = String(t.area || '').toLowerCase();

      const matchSearch =
        !term ||
        dniStr.includes(term) ||
        nombresStr.includes(term) ||
        puestoStr.includes(term) ||
        areaStr.includes(term);

      return matchEmpresa && matchCondicion && matchSearch;
    });
  }, [trabajadores, empresaActiva, condicionFilter, searchTerm]);

  // Paginación y opciones de filtro rápido
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const conditionOptions: FilterChipOption[] = useMemo(() => {
    const listEmpresa = trabajadores.filter((t) =>
      empresaActiva === 'CONSOLIDADO' ? true : t.empresa === empresaActiva
    );
    const activos = listEmpresa.filter((t) => t.condicion === 'Activo').length;
    const inactivos = listEmpresa.filter((t) => t.condicion === 'Inactivo').length;
    const cesados = listEmpresa.filter((t) => t.condicion === 'Cesado').length;

    return [
      { id: 'TODAS', label: 'Todos', count: listEmpresa.length },
      { id: 'Activo', label: 'Activos', count: activos },
      { id: 'Inactivo', label: 'Inactivos', count: inactivos },
      { id: 'Cesado', label: 'Cesados', count: cesados }
    ];
  }, [trabajadores, empresaActiva]);

  const paginatedTrabajadores = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredTrabajadores.slice(start, start + pageSize);
  }, [filteredTrabajadores, currentPage, pageSize]);

  // Manejo de Modal de Registro
  const handleOpenModal = (trabajador?: TrabajadorRecord) => {
    setFormError(null);
    if (trabajador) {
      setEditingTrabajador(trabajador);
      setFormData({
        dni: trabajador.dni !== undefined && trabajador.dni !== null ? String(trabajador.dni) : '',
        apellidosNombres: trabajador.apellidosNombres !== undefined && trabajador.apellidosNombres !== null ? String(trabajador.apellidosNombres) : '',
        empresa: trabajador.empresa || (empresaActiva === 'TR3' ? 'TR3' : 'PERPOL'),
        condicion: trabajador.condicion || 'Activo',
        sexo: trabajador.sexo || 'M',
        fechaIngreso: trabajador.fechaIngreso || '',
        fechaNacimiento: trabajador.fechaNacimiento || '',
        puesto: trabajador.puesto || '',
        area: trabajador.area || '',
        telefono: trabajador.telefono || '',
        correo: trabajador.correo || ''
      });
    } else {
      setEditingTrabajador(null);
      setFormData({
        dni: '',
        apellidosNombres: '',
        empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
        condicion: 'Activo',
        sexo: 'M',
        fechaIngreso: new Date().toISOString().slice(0, 10),
        fechaNacimiento: '',
        puesto: '',
        area: '',
        telefono: '',
        correo: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSaveTrabajador = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const dni = formData.dni !== undefined && formData.dni !== null ? String(formData.dni).trim().toUpperCase() : '';
    const nombres = formData.apellidosNombres !== undefined && formData.apellidosNombres !== null ? String(formData.apellidosNombres).trim() : '';

    if (!dni || !nombres) {
      setFormError('El DNI / C.E. y los Apellidos y Nombres son obligatorios.');
      return;
    }

    if (dni.length > 12) {
      setFormError('El documento (C.E.) no puede exceder los 12 caracteres.');
      return;
    }

    if (dni.length < 8) {
      setFormError('El documento debe tener 8 dígitos para DNI o entre 9 y 12 caracteres para C.E.');
      return;
    }

    // Validación estricta para evitar duplicados por DNI / C.E.
    const duplicate = trabajadores.find(
      (t) =>
        String(t.dni || '').toLowerCase().trim() === dni.toLowerCase() &&
        (!editingTrabajador || String(t.id) !== String(editingTrabajador.id))
    );

    if (duplicate) {
      setFormError(
        `Ya existe un colaborador registrado con el DNI / C.E. '${dni}' (${duplicate.apellidosNombres} - ${duplicate.empresa}).`
      );
      return;
    }

    const newRecord: TrabajadorRecord = {
      id: editingTrabajador?.id || `TRAB-${dni}`,
      dni,
      apellidosNombres: nombres,
      empresa: formData.empresa as 'PERPOL' | 'TR3',
      condicion: (formData.condicion as 'Activo' | 'Inactivo' | 'Cesado') || 'Activo',
      sexo: (formData.sexo as 'M' | 'F') || 'M',
      fechaIngreso: formData.fechaIngreso || new Date().toISOString().slice(0, 10),
      fechaNacimiento: formData.fechaNacimiento || '',
      puesto: String(formData.puesto || '').trim(),
      area: String(formData.area || '').trim(),
      telefono: String(formData.telefono || '').trim(),
      correo: String(formData.correo || '').trim(),
      createdAt: editingTrabajador?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncStatus: 'pending'
    };

    // Actualización optimista inmediata en UI
    upsertTrabajador(newRecord);
    setIsModalOpen(false);
    incrementSync();

    addToast({
      type: 'success',
      title: editingTrabajador ? 'Colaborador Actualizado' : 'Colaborador Registrado',
      message: `${newRecord.apellidosNombres} guardado en el padrón.`
    });

    // Envío en segundo plano al backend GAS
    try {
      await GasApiClient.post({
        action: 'saveTrabajador',
        sheetName: 'SSOMA_Trabajadores',
        data: newRecord
      });
    } catch {
      // Sincronización en segundo plano completada con fallback local
    } finally {
      decrementSync();
    }
  };

  const confirmDeleteTrabajador = async () => {
    if (!deleteModalTrabajador) return;
    const t = deleteModalTrabajador;

    removeTrabajador(t.id);
    incrementSync();
    addToast({
      type: 'info',
      title: 'Colaborador Eliminado',
      message: `${t.apellidosNombres} fue removido del padrón.`
    });

    try {
      await GasApiClient.post({
        action: 'deleteTrabajador',
        sheetName: 'SSOMA_Trabajadores',
        id: t.id
      });
    } catch {
      // Fallback silencioso
    } finally {
      decrementSync();
      setDeleteModalTrabajador(null);
    }
  };

  // Exportaciones a Excel y PDF en Cliente (Padrón de Trabajadores)
  const handleExportExcel = () => {
    const exportData = filteredTrabajadores.map((t) => ({
      'DNI / C.E.': t.dni,
      'Tipo Doc': getTipoDocumento(t.dni),
      'Apellidos y Nombres': t.apellidosNombres,
      'Empresa': t.empresa === 'PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.',
      'Puesto / Cargo': t.puesto,
      'Área': t.area || 'Sin Área',
      'Condición': t.condicion,
      'Sexo': t.sexo === 'M' ? 'Masculino' : 'Femenino',
      'Fecha de Nacimiento': t.fechaNacimiento || '',
      'Edad': calcularEdad(t.fechaNacimiento) ?? '',
      'Fecha de Ingreso': t.fechaIngreso,
      'Teléfono': t.telefono,
      'Correo': t.correo
    }));
    ExportUtils.exportToExcel(exportData, `Padron_Trabajadores_${empresaActiva}`);

    addToast({
      type: 'success',
      title: 'Exportación a Excel Completa',
      message: 'El padrón de colaboradores fue procesado y descargado en el cliente.'
    });
  };

  const handleExportPdf = () => {
    ExportUtils.exportToPdf({
      title: 'PADRÓN GENERAL DE TRABAJADORES',
      subtitle: `Empresa: ${empresaActiva} | Total registros: ${filteredTrabajadores.length}`,
      empresa: empresaActiva,
      fileName: `Padron_Trabajadores_${empresaActiva}`,
      headers: ['DNI / C.E.', 'Tipo', 'Apellidos y Nombres', 'Empresa', 'Puesto', 'Área', 'Condición', 'F. Nac. (Edad)', 'Ingreso', 'Contacto'],
      rows: filteredTrabajadores.map((t) => [
        t.dni,
        getTipoDocumento(t.dni),
        t.apellidosNombres,
        t.empresa,
        t.puesto || '-',
        t.area || '-',
        t.condicion,
        t.fechaNacimiento ? `${t.fechaNacimiento} (${calcularEdad(t.fechaNacimiento)} a.)` : '-',
        t.fechaIngreso || '-',
        t.telefono || t.correo || '-'
      ]),
      orientation: 'landscape'
    });

    addToast({
      type: 'success',
      title: 'Exportación a PDF Completa',
      message: 'Documento PDF del padrón generado profesionalmente en el navegador.'
    });
  };

  return (
    <div className="space-y-6">
      <ModuleHeader
        codigo={6}
        titulo="Base de Trabajadores"
        subtitulo="Gestión integral del padrón de personal, cargos, áreas, datos de contacto y condiciones laborales (PERPOL & TR3)"
        icono={<Users className="w-5 h-5 text-blue-400" />}
        onNuevo={() => handleOpenModal()}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.trabajadores}
        onImportSuccess={(rows) => {
          batchUpsertTrabajadores(rows as any);
        }}
      />

      <div className="space-y-4">
        {/* Barra de herramientas estandarizada */}
        <ModuleToolbar
          searchQuery={searchTerm}
          onSearchChange={(val) => {
            setSearchTerm(val);
            setCurrentPage(1);
          }}
          searchPlaceholder="Buscar por DNI, nombres, puesto o área..."
          statusFilter={condicionFilter}
          onStatusFilterChange={(id) => {
            setCondicionFilter(id as any);
            setCurrentPage(1);
          }}
          statusOptions={conditionOptions}
          totalCount={trabajadores.filter((t) => empresaActiva === 'CONSOLIDADO' ? true : t.empresa === empresaActiva).length}
          filteredCount={filteredTrabajadores.length}
          onExportExcel={handleExportExcel}
          onExportPdf={handleExportPdf}
          onNewRecord={() => handleOpenModal()}
          newRecordLabel="Registrar Colaborador"
        />

        {/* Tabla de Trabajadores */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1050px] text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
                <tr>
                  <th className="px-4 py-3 w-32 whitespace-nowrap">DNI / C.E.</th>
                  <th className="px-4 py-3 min-w-[180px]">Apellidos y Nombres</th>
                  <th className="px-4 py-3 w-28 whitespace-nowrap">Empresa</th>
                  <th className="px-4 py-3 min-w-[150px]">Puesto / Cargo</th>
                  <th className="px-4 py-3 min-w-[140px]">Área</th>
                  <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Condición</th>
                  <th className="px-4 py-3 w-28 whitespace-nowrap">F. Nacimiento</th>
                  <th className="px-4 py-3 w-28 whitespace-nowrap">Ingreso</th>
                  <th className="px-4 py-3 min-w-[130px]">Contacto</th>
                  <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedTrabajadores.length === 0 ? (
                  <TableEmptyState
                    isTableRow
                    colSpan={10}
                    title="No se encontraron colaboradores"
                    description={
                      searchTerm
                        ? `No hay resultados para "${searchTerm}". Prueba con otro término o limpia los filtros.`
                        : 'No hay colaboradores registrados para los filtros seleccionados.'
                    }
                    actionLabel={searchTerm || condicionFilter !== 'TODAS' ? 'Limpiar filtros' : 'Registrar Colaborador'}
                    actionIcon={searchTerm || condicionFilter !== 'TODAS' ? 'clear' : 'plus'}
                    onAction={() => {
                      if (searchTerm || condicionFilter !== 'TODAS') {
                        setSearchTerm('');
                        setCondicionFilter('TODAS');
                        setCurrentPage(1);
                      } else {
                        handleOpenModal();
                      }
                    }}
                  />
                ) : (
                  paginatedTrabajadores.map((t, idx) => (
                    <tr key={`${t.id || t.dni}-${t.empresa || ''}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-mono font-semibold text-slate-800 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{t.dni}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider uppercase border ${
                              getTipoDocumento(t.dni) === 'C.E.'
                                ? 'bg-amber-50 text-amber-700 border-amber-200'
                                : 'bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                            title={getTipoDocumento(t.dni) === 'C.E.' ? 'Carné de Extranjería' : 'Documento Nacional de Identidad'}
                          >
                            {getTipoDocumento(t.dni)}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-800">{t.apellidosNombres}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                            t.empresa === 'PERPOL'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-sky-50 text-sky-700 border-sky-200'
                          }`}
                        >
                          {t.empresa}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-700">{t.puesto || '-'}</td>
                      <td className="px-4 py-3 text-slate-700">{t.area || '-'}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <StatusBadge status={t.condicion} />
                      </td>
                      <td className="px-4 py-3 text-slate-700 text-[11px] font-mono whitespace-nowrap">
                        {t.fechaNacimiento ? (
                          <div>
                            <span>{t.fechaNacimiento}</span>
                            {calcularEdad(t.fechaNacimiento) !== null && (
                              <span className="ml-1 text-[10px] text-emerald-700 font-sans font-medium">
                                ({calcularEdad(t.fechaNacimiento)} a.)
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-500 font-medium">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-700 font-mono text-[11px]">
                        {t.fechaIngreso || '-'}
                      </td>
                      <td className="px-4 py-3 text-slate-700 text-[11px]">
                        <div>{t.telefono || '-'}</div>
                        <div className="text-[10px] text-slate-500 font-medium">{t.correo}</div>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setViewDetailTrabajador(t)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                            title="Ver ficha del colaborador"
                            aria-label={`Ver ficha del colaborador ${t.apellidosNombres} (${t.dni})`}
                          >
                            <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenModal(t)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                            title="Editar colaborador"
                            aria-label={`Editar datos de ${t.apellidosNombres} (${t.dni})`}
                          >
                            <Edit2 className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteModalTrabajador(t)}
                            className="p-1.5 rounded hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Eliminar registro"
                            aria-label={`Eliminar colaborador ${t.apellidosNombres} (${t.dni})`}
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          <TablePagination
            currentPage={currentPage}
            totalItems={filteredTrabajadores.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
          />
        </div>
      </div>

      {/* MODAL PARA REGISTRO Y EDICIÓN INDIVIDUAL */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in overflow-y-auto cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsModalOpen(false);
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="trabajador-form-modal-title"
            className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-slate-800 cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-teal-50 border border-teal-200 text-teal-700" aria-hidden="true">
                  <Users className="w-5 h-5 text-teal-600" />
                </div>
                <div>
                  <h3 id="trabajador-form-modal-title" className="font-bold text-[#0F172A] text-base">
                    {editingTrabajador ? 'Editar Datos del Trabajador' : 'Registrar Nuevo Trabajador'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Padrón oficial para validación de incidentes e inspecciones
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                title="Cerrar modal de colaborador (Esc)"
                aria-label="Cerrar modal de colaborador"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveTrabajador} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[#475569] font-semibold">
                      DNI / C.E. <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                    </label>
                    {String(formData.dni || '').trim().length > 0 && (
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors ${
                          getTipoDocumento(formData.dni) === 'C.E.'
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : 'bg-sky-50 text-[#0284C7] border-sky-200'
                        }`}
                      >
                        {getTipoDocumento(formData.dni) === 'C.E.' ? 'C.E. (Carné de Extranjería)' : 'DNI (8 dígitos)'}
                      </span>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={12}
                    placeholder="DNI (8 dígitos) o C.E. (máx 12)"
                    value={formData.dni}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^a-zA-Z0-9]/g, '').slice(0, 12).toUpperCase();
                      setFormData({ ...formData, dni: val });
                    }}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981] uppercase"
                  />
                  <div className="flex justify-between text-[10px] text-[#475569] mt-1">
                    <span>DNI: 8 dígitos | C.E.: más de 8 hasta 12 car.</span>
                    <span className="font-mono">{String(formData.dni || '').length}/12</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Razón Social / Empresa <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.empresa}
                    onChange={(e) => setFormData({ ...formData, empresa: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                    <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#475569] font-semibold mb-1">
                  Apellidos y Nombres <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Quispe Huamán, Juan Carlos"
                  value={formData.apellidosNombres}
                  onChange={(e) => setFormData({ ...formData, apellidosNombres: e.target.value })}
                  className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Condición <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.condicion}
                    onChange={(e) => setFormData({ ...formData, condicion: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                    <option value="Cesado">Cesado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">
                    Sexo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <select
                    value={formData.sexo}
                    onChange={(e) => setFormData({ ...formData, sexo: e.target.value as any })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  >
                    <option value="M">Masculino</option>
                    <option value="F">Femenino</option>
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[#475569] font-semibold">F. Nacimiento</label>
                    {edadCalculada !== null && (
                      <span className="text-[10px] text-[#047857] font-bold">
                        {edadCalculada} años
                      </span>
                    )}
                  </div>
                  <input
                    type="date"
                    value={formData.fechaNacimiento || ''}
                    onChange={(e) => setFormData({ ...formData, fechaNacimiento: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Fecha Ingreso</label>
                  <input
                    type="date"
                    value={formData.fechaIngreso || ''}
                    onChange={(e) => setFormData({ ...formData, fechaIngreso: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Puesto / Cargo</label>
                  <input
                    type="text"
                    placeholder="Ej: Operario de Envasado"
                    value={formData.puesto || ''}
                    onChange={(e) => setFormData({ ...formData, puesto: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Área / Ubicación</label>
                  <input
                    type="text"
                    list="lista-areas-colaborador"
                    placeholder="Ej: Producción Lácteos"
                    value={formData.area || ''}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                  <datalist id="lista-areas-colaborador">
                    {AREAS_EMPRESA.map((area, idx) => (
                      <option key={`${area}-${idx}`} value={area} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Teléfono</label>
                  <input
                    type="tel"
                    placeholder="Ej: 987654321"
                    value={formData.telefono || ''}
                    onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-[#94A3B8] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] font-semibold mb-1">Correo Electrónico</label>
                  <input
                    type="email"
                    placeholder="Ej: colaborador@empresa.com"
                    value={formData.correo || ''}
                    onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-[#0F172A] placeholder:text-[#94A3B8] font-mono focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-[#475569] font-semibold text-xs border border-[#CBD5E1] transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white font-bold text-xs transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingTrabajador ? 'Guardar Cambios' : 'Registrar Colaborador'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Modal Ficha Detalle del Colaborador */}
      {viewDetailTrabajador && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewDetailTrabajador(null);
          }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="trabajador-detail-modal-title"
        >
          <div
            className="fixed inset-0 -z-10 cursor-pointer"
            onClick={() => setViewDetailTrabajador(null)}
            aria-hidden="true"
          />

          <div
            className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header del modal */}
            <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className="w-9 h-9 rounded-lg bg-emerald-50 text-[#047857] flex items-center justify-center shrink-0 border border-emerald-100" aria-hidden="true">
                  <Users className="w-5 h-5 text-[#047857]" />
                </div>
                <div className="min-w-0">
                  <h3 id="trabajador-detail-modal-title" className="text-sm sm:text-base font-bold text-[#0F172A] flex items-center gap-2 truncate">
                    <span>Ficha del Colaborador — {viewDetailTrabajador.dni}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        getTipoDocumento(viewDetailTrabajador.dni) === 'C.E.'
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-sky-50 text-[#0284C7] border-sky-200'
                      }`}
                    >
                      {getTipoDocumento(viewDetailTrabajador.dni) === 'C.E.' ? 'Carné de Extranjería' : 'DNI'}
                    </span>
                  </h3>
                  <p className="text-xs text-[#475569] font-medium truncate">
                    {viewDetailTrabajador.apellidosNombres}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewDetailTrabajador(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200 active:bg-slate-300 transition-colors cursor-pointer shrink-0"
                title="Cerrar ficha (Esc)"
                aria-label="Cerrar ficha del colaborador"
              >
                <X className="w-5 h-5 text-slate-600" aria-hidden="true" />
              </button>
            </div>

            {/* Contenido con scroll */}
            <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Empresa</span>
                  <span className="text-[#0F172A] font-bold">{viewDetailTrabajador.empresa === 'PERPOL' ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Condición</span>
                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                    viewDetailTrabajador.condicion === 'Activo'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : viewDetailTrabajador.condicion === 'Inactivo'
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-rose-50 text-rose-800 border-rose-200'
                  }`}>
                    {viewDetailTrabajador.condicion}
                  </span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Sexo</span>
                  <span className="text-[#0F172A] font-semibold">{viewDetailTrabajador.sexo === 'M' ? 'Masculino' : 'Femenino'}</span>
                </div>
                <div>
                  <span className="text-[#475569] block text-[10px] uppercase font-bold">Fecha Ingreso</span>
                  <span className="text-[#0F172A] font-mono font-semibold">{viewDetailTrabajador.fechaIngreso || 'No registrada'}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-[11px] font-bold uppercase text-[#0F172A] tracking-wider">Datos Personales y Nacimiento</h4>
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Fecha de Nacimiento:</span>
                    <span className="text-[#0F172A] font-mono font-semibold">
                      {viewDetailTrabajador.fechaNacimiento || 'No registrada'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Edad Actual:</span>
                    <span className="text-[#047857] font-bold">
                      {calcularEdad(viewDetailTrabajador.fechaNacimiento) !== null
                        ? `${calcularEdad(viewDetailTrabajador.fechaNacimiento)} años`
                        : 'No calculada'}
                    </span>
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-[11px] font-bold uppercase text-[#0F172A] tracking-wider">Puesto y Ubicación</h4>
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Puesto / Cargo:</span>
                    <span className="text-[#0F172A] font-semibold">{viewDetailTrabajador.puesto || 'Sin puesto'}</span>
                  </div>
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Área Operativa:</span>
                    <span className="text-[#0F172A] font-medium">{viewDetailTrabajador.area || 'Sin área'}</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                <h4 className="text-[11px] font-bold uppercase text-[#0F172A] tracking-wider">Información de Contacto</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Teléfono / Celular:</span>
                    <span className="text-[#0F172A] font-mono font-medium">{viewDetailTrabajador.telefono || 'Sin teléfono registrado'}</span>
                  </div>
                  <div>
                    <span className="text-[#475569] text-[10px] font-semibold block">Correo Electrónico:</span>
                    <span className="text-[#0F172A] font-mono font-medium">{viewDetailTrabajador.correo || 'Sin correo registrado'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-slate-500 font-mono">DNI: {viewDetailTrabajador.dni}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const t = viewDetailTrabajador;
                    setViewDetailTrabajador(null);
                    handleOpenModal(t);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5 text-teal-600" />
                  <span>Editar Colaborador</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewDetailTrabajador(null)}
                  className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 active:bg-slate-400 border border-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer shadow-xs"
                >
                  Cerrar Ficha
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de confirmación para eliminar */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalTrabajador)}
        onClose={() => setDeleteModalTrabajador(null)}
        onConfirm={confirmDeleteTrabajador}
        title="Eliminar Colaborador del Padrón"
        message="¿Estás seguro de que deseas eliminar este colaborador? Esta acción removerá el registro del padrón oficial."
        itemIdentifier={
          deleteModalTrabajador
            ? `${deleteModalTrabajador.apellidosNombres} (${getTipoDocumento(deleteModalTrabajador.dni)}: ${deleteModalTrabajador.dni} - ${deleteModalTrabajador.empresa})`
            : undefined
        }
        confirmButtonText="Eliminar Colaborador"
      />
    </div>
  );
};
