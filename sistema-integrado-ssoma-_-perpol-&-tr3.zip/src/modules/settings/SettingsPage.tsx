import React, { useState, useEffect } from 'react';
import { useAppStore } from '../../store/appStore';
import { GasApiClient, DEFAULT_GAS_URL, PERMANENT_GAS_URL } from '../../services/api';
import {
  Settings,
  Database,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  FileCode,
  Info,
  HelpCircle,
  DownloadCloud,
  RotateCcw,
  Globe,
  Share2
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const {
    gasWebAppUrl,
    setGasWebAppUrl,
    driveFolderId,
    setDriveFolderId,
    isBackendConnected,
    setIsBackendConnected,
    cargarDatosDesdeSheets,
    totalSincronizadosSheets,
    lastSyncSheetsTime,
    isSyncingWithSheets,
    setIsSyncingWithSheets,
    resetearContadoresModulos,
    addToast
  } = useAppStore();

  const [inputUrl, setInputUrl] = useState(gasWebAppUrl || PERMANENT_GAS_URL);
  const [inputFolderId, setInputFolderId] = useState(driveFolderId);
  const [testing, setTesting] = useState(false);
  const [syncingNow, setSyncingNow] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  // Sincronizar automáticamente si el store o localStorage rehidratan
  useEffect(() => {
    if (gasWebAppUrl && gasWebAppUrl.trim().length > 0) {
      setInputUrl(gasWebAppUrl);
    } else {
      setInputUrl(PERMANENT_GAS_URL);
      setGasWebAppUrl(PERMANENT_GAS_URL);
    }
  }, [gasWebAppUrl, setGasWebAppUrl]);

  useEffect(() => {
    if (driveFolderId) {
      setInputFolderId(driveFolderId);
    }
  }, [driveFolderId]);

  const handleUrlChange = (value: string) => {
    setInputUrl(value);
    setGasWebAppUrl(value);
  };

  const handleRestoreDefaultUrl = () => {
    setInputUrl(PERMANENT_GAS_URL);
    setGasWebAppUrl(PERMANENT_GAS_URL);
    addToast({
      type: 'info',
      title: 'URL Permanente Restaurada',
      message: 'Se cargó la URL oficial del Google Apps Script Web App permanente.'
    });
  };

  const handleFolderIdChange = (value: string) => {
    setInputFolderId(value);
    setDriveFolderId(value);
  };

  const handleSaveAndTest = async () => {
    setTesting(true);
    setTestResult(null);

    const cleanUrl = inputUrl.trim() || DEFAULT_GAS_URL;
    const cleanFolderId = inputFolderId.trim();

    setGasWebAppUrl(cleanUrl);
    setDriveFolderId(cleanFolderId);

    const result = await GasApiClient.testConnection(cleanUrl);
    setTestResult(result);
    setIsBackendConnected(result.success);

    if (result.success) {
      addToast({
        type: 'success',
        title: 'Conexión Exitosa',
        message: 'El backend de Google Apps Script y Google Sheets respondió correctamente y quedó vinculado.'
      });

      // Sincronización automática inmediata al verificar conexión exitosa
      try {
        setSyncingNow(true);
        setIsSyncingWithSheets(true);
        const syncRes = await GasApiClient.obtenerDatosGoogleSheets();
        if (syncRes && syncRes.success && syncRes.data) {
          cargarDatosDesdeSheets(syncRes.data);
          const count = useAppStore.getState().totalSincronizadosSheets;
          addToast({
            type: 'success',
            title: 'Sincronización Completada',
            message: `Descargados exitosamente ${count} registros desde Google Sheets.`
          });
        }
      } catch (syncErr) {
        console.warn('Advertencia en sincronización inicial:', syncErr);
      } finally {
        setSyncingNow(false);
        setIsSyncingWithSheets(false);
      }
    } else {
      addToast({
        type: 'warning',
        title: 'Verificación de Conexión',
        message: result.message
      });
    }
    setTesting(false);
  };

  const handleForceManualSync = async () => {
    setSyncingNow(true);
    setIsSyncingWithSheets(true);
    try {
      const syncRes = await GasApiClient.obtenerDatosGoogleSheets();
      if (syncRes && syncRes.success && syncRes.data) {
        cargarDatosDesdeSheets(syncRes.data);
        const count = useAppStore.getState().totalSincronizadosSheets;
        addToast({
          type: 'success',
          title: 'Sincronización Completada',
          message: `Sincronizados ${count} registros desde Google Sheets.`
        });
      } else {
        addToast({
          type: 'error',
          title: 'Error de Sincronización',
          message: syncRes?.error || syncRes?.message || 'No se pudieron descargar los datos de Google Sheets.'
        });
      }
    } catch (err: unknown) {
      addToast({
        type: 'error',
        title: 'Fallo de Red',
        message: err instanceof Error ? err.message : 'Error al comunicar con Google Sheets'
      });
    } finally {
      setSyncingNow(false);
      setIsSyncingWithSheets(false);
    }
  };

  const handleCopyCodeSnippet = () => {
    navigator.clipboard.writeText(`// Consulta el archivo completo en /google-apps-script/Code.gs`);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
    addToast({
      type: 'info',
      title: 'Ubicación del Backend',
      message: 'El código completo de Code.gs se encuentra en la carpeta /google-apps-script/Code.gs'
    });
  };

  const handleExecuteResetCounters = () => {
    resetearContadoresModulos();
    setConfirmResetOpen(false);
    addToast({
      type: 'success',
      title: 'Contadores Reiniciados a 0001',
      message: 'Los correlativos de todos los módulos transaccionales han sido reiniciados. El próximo registro nuevo se creará con el número 0001 (ACC-2026-0001, AC-2026-0001, INSP-2026-0001, etc.).'
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-brand-subtle border border-brand-subtle text-brand">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Configuración del Sistema SSOMA
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Integración con Google Apps Script, Google Sheets y Google Drive
            </p>
          </div>
        </div>
      </div>

      {/* Integración de Backend con Google Sheets y Drive */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Panel Izquierdo: Formulario de Conexión */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-600" />
                <span>Parámetros de Integración Web App</span>
              </h2>
              {lastSyncSheetsTime && (
                <span className="text-[11px] text-slate-500 font-mono">
                  Última sincr.: {lastSyncSheetsTime} ({totalSincronizadosSheets} registros)
                </span>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="gas-webapp-url-input" className="block text-xs font-semibold text-slate-700">
                  URL Permanente de Google Apps Script Web App (doPost)
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(PERMANENT_GAS_URL);
                      addToast({
                        type: 'success',
                        title: 'URL Copiada',
                        message: 'La URL permanente se copió al portapapeles.'
                      });
                    }}
                    className="text-[11px] text-slate-600 hover:text-slate-800 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copiar URL</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleRestoreDefaultUrl}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                    title="Cargar la URL oficial del Web App"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restablecer Permanente</span>
                  </button>
                </div>
              </div>
              <div className="flex gap-2">
                <input
                  id="gas-webapp-url-input"
                  type="text"
                  value={inputUrl}
                  aria-describedby="gas-url-help"
                  onChange={(e) => handleUrlChange(e.target.value)}
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  className="flex-1 bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-600 font-mono"
                />
              </div>

              {/* Tarjeta de Garantía de Conexión Permanente */}
              <div className="mt-2.5 p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg text-emerald-950 text-xs flex items-start gap-2.5">
                <Globe className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-emerald-900">
                    Conexión Permanente Global para Todos los Dispositivos
                  </span>
                  <p className="mt-0.5 text-emerald-800 leading-relaxed text-[11px]">
                    Esta URL está vinculada permanentemente en el código del sistema y en el servidor. Al compartir tu enlace público, cualquier dispositivo (móviles, tablets, ordenadores) se conectará de manera inmediata y automática con Google Apps Script y Google Sheets, sin requerir reconfiguración.
                  </p>
                </div>
              </div>

              {inputUrl.includes('/macros/library/') && (
                <div className="mt-2.5 p-3 bg-amber-50 border border-amber-300 rounded-lg text-amber-900 text-xs flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-amber-950">Atención: Has ingresado una URL de Biblioteca (/macros/library/d/...)</span>
                    <p className="mt-1 leading-relaxed text-amber-900">
                      Las bibliotecas no aceptan peticiones HTTP (<code>doPost</code>). Para conectar tu base de datos de Google Sheets:
                      en Apps Script haz clic en <strong>Implementar &gt; Nueva implementación</strong>, selecciona el tipo <strong>Aplicación web (Web App)</strong> con acceso para <strong>Cualquier persona</strong> y copia la URL resultante (debe terminar en <code>/exec</code>).
                    </p>
                  </div>
                </div>
              )}
              <p id="gas-url-help" className="text-[11px] text-slate-500 mt-1">
                Conexión segura mediante proxy interno y directo. Debe terminar en <code className="text-emerald-700 font-mono font-semibold">/exec</code>.
              </p>
            </div>

            <div>
              <label htmlFor="drive-folder-id-input" className="block text-xs font-semibold text-slate-700 mb-1.5">
                ID de Carpeta Designada en Google Drive (Para Fotos y Firmas)
              </label>
              <input
                id="drive-folder-id-input"
                type="text"
                value={inputFolderId}
                aria-describedby="drive-folder-help"
                onChange={(e) => handleFolderIdChange(e.target.value)}
                placeholder="Ej: 1A2b3C4d5E6F... (Opcional, si se deja vacío creará 'SSOMA_Evidencias_PERPOL_TR3')"
                className="w-full bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-600 font-mono"
              />
              <p id="drive-folder-help" className="text-[11px] text-slate-500 mt-1">
                Garantiza que ninguna imagen base64 se almacene en celdas de Sheets, protegiendo el límite de 50k caracteres.
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    isBackendConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                  }`}
                />
                <span className="text-xs text-slate-700 font-medium">
                  {isBackendConnected
                    ? 'Conexión activa con Google Sheets & Drive'
                    : 'Modo Local / Desconectado'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleForceManualSync}
                  disabled={syncingNow || isSyncingWithSheets}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50"
                  title="Descargar todos los registros actuales de Google Sheets"
                >
                  <DownloadCloud className={`w-4 h-4 ${syncingNow ? 'animate-bounce' : ''}`} />
                  <span>{syncingNow ? 'Descargando...' : 'Sincronizar Todo Ahora'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveAndTest}
                  disabled={testing}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${testing ? 'animate-spin' : ''}`} />
                  <span>{testing ? 'Comprobando...' : 'Guardar y Probar Conexión'}</span>
                </button>
              </div>
            </div>

            {testResult && (
              <div
                className={`p-4 rounded-lg border text-xs flex items-start gap-3 ${
                  testResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <div>
                  <p className="font-semibold">
                    {testResult.success ? 'Respuesta exitosa del servidor' : 'Aviso de conexión'}
                  </p>
                  <p className="mt-0.5 opacity-90">{testResult.message}</p>
                </div>
              </div>
            )}
          </div>

          {/* Información del archivo backend generado */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  Código de Backend Generado (/google-apps-script/Code.gs)
                </h3>
              </div>
              <button
                onClick={handleCopyCodeSnippet}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-medium transition-colors cursor-pointer"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copiado</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Ruta</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              El archivo <code className="text-emerald-700 bg-emerald-50 px-1 py-0.5 rounded border border-emerald-200 font-mono">google-apps-script/Code.gs</code> contiene
              la implementación completa solicitada en la Fase 1: <code className="text-slate-800 font-mono">doGet(e)</code>, <code className="text-slate-800 font-mono">doPost(e)</code>, enrutador interno, persistencia dinámica de pestañas y conversión física de Base64 a Blobs en Google Drive.
            </p>
          </div>

          {/* Mantenimiento de Contadores de Código */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2 text-slate-900">
              <RotateCcw className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-sm">Control y Reinicio de Contadores de Código</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              La regla oficial de generación de correlativos es <strong>Secuencial anual incremental basado en cantidad de casos registrados</strong> (<code className="text-slate-800 font-mono">PREFIJO-YYYY-XXXX</code>). Si deseas reiniciar la secuencia para que el siguiente caso empiece en <strong>0001</strong> (<code className="text-emerald-700 font-mono font-semibold">ACC-2026-0001</code>, <code className="text-emerald-700 font-mono font-semibold">AC-2026-0001</code>, <code className="text-emerald-700 font-mono font-semibold">INSP-2026-0001</code>, etc.), utiliza el botón a continuación.
            </p>

            {confirmResetOpen ? (
              <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-xs space-y-2.5">
                <div className="flex items-start gap-2 text-amber-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    ¿Confirmas reiniciar los contadores de todos los módulos transaccionales? El próximo registro nuevo se creará desde el número <strong>0001</strong>. (El Padrón de Trabajadores y Horas-Hombre no se tocan).
                  </span>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleExecuteResetCounters}
                    className="px-3 py-1.5 rounded-md bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                  >
                    Sí, Reiniciar Contadores a 0001
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmResetOpen(false)}
                    className="px-3 py-1.5 rounded-md bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium text-xs cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmResetOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer border border-slate-300"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
                <span>Reiniciar Contadores de Todos los Módulos (0001)</span>
              </button>
            )}
          </div>
        </div>

        {/* Panel Derecho: Instrucciones de Despliegue */}
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Info className="w-4 h-4 text-emerald-600" />
              <span>Pasos para desplegar en Google Apps Script</span>
            </h3>

            <ol className="text-xs text-slate-600 space-y-3 list-decimal list-inside leading-relaxed">
              <li className="pl-1">
                Abre tu Google Sheets corporativo (o crea una nueva hoja para SSOMA).
              </li>
              <li className="pl-1">
                Dirígete a <strong className="text-slate-900">Extensiones &gt; Apps Script</strong>.
              </li>
              <li className="pl-1">
                Reemplaza el contenido de <strong className="text-slate-900">Code.gs</strong> con el código generado en <code className="text-emerald-700 bg-emerald-50 px-1 rounded border border-emerald-200 font-mono">google-apps-script/Code.gs</code>.
              </li>
              <li className="pl-1">
                Haz clic en <strong className="text-emerald-700">Implementar &gt; Nueva implementación</strong>.
              </li>
              <li className="pl-1">
                Selecciona tipo <strong className="text-slate-900">Aplicación web</strong>.
              </li>
              <li className="pl-1">
                Ejecutar como: <strong className="text-slate-900">Yo (tu cuenta)</strong>.
              </li>
              <li className="pl-1">
                Quién tiene acceso: <strong className="text-slate-900">Cualquier usuario (Anyone)</strong>.
              </li>
              <li className="pl-1">
                Copia la URL <code className="text-slate-500 font-mono">/exec</code> y pégala en el campo de la izquierda.
              </li>
            </ol>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 leading-normal">
              <strong className="text-slate-800 block mb-1">Empresas Soportadas:</strong>
              • PERPOL IDEAS S.A.C. (RUC 20392729977)
              <br />
              • TR3 ALIMENTOS S.A.C. (RUC 20550842891)
            </div>
          </div>

          <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-5 shadow-xs space-y-3">
            <h4 className="font-bold text-xs text-amber-800 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>¿Cómo evitar desconexiones al actualizar?</span>
            </h4>
            <div className="text-[11px] text-slate-700 space-y-2 leading-relaxed">
              <p>
                <strong className="text-amber-900">1. Al editar Code.gs en Google:</strong> No hagas clic en <em>"Nueva implementación"</em> porque Google creará una URL diferente. En su lugar, ve a <strong>Implementar &gt; Administrar implementaciones &gt; Editar (icono lápiz) &gt; Versión: Nueva versión &gt; Implementar</strong>. De este modo, la URL se mantiene idéntica para siempre.
              </p>
              <p>
                <strong className="text-amber-900">2. Acceso público:</strong> El parámetro <em>"Quién tiene acceso"</em> debe ser <strong>Cualquier usuario (Anyone)</strong>. Si está en "Solo yo", Google exige cookies de sesión y bloquea la conexión cruzada por CORS.
              </p>
              <p>
                <strong className="text-emerald-800">3. Reconexión Automática:</strong> El sistema ahora guarda la URL en almacenamiento local permanente y verifica la conexión automáticamente en segundo plano en cada recarga de página.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
