import { AtencionMedicaRecord } from '../../../types/modules';
import { GasApiClient } from '../../../services/api';
import { ExportUtils } from '../../../utils/exportUtils';
import { EmpresaId } from '../../../types';

export class AtencionesMedicasService {
  /**
   * Guarda o actualiza una atención médica en Google Apps Script
   */
  static async saveAtencion(record: AtencionMedicaRecord) {
    return await GasApiClient.sendRequest({
      action: 'saveAtencionMedica',
      sheetName: 'SSOMA_AtencionesMedicas',
      data: record
    });
  }

  /**
   * Elimina una atención médica en Google Apps Script
   */
  static async deleteAtencion(idAtencion: string) {
    return await GasApiClient.sendRequest({
      action: 'deleteAtencionMedica',
      sheetName: 'SSOMA_AtencionesMedicas',
      data: { idAtencion }
    });
  }

  /**
   * Exporta a Excel
   */
  static exportExcel(records: AtencionMedicaRecord[], filename: string) {
    const data = records.map((a) => ({
      'ID Atención': a.idAtencion,
      'Fecha': a.fechaAtencion,
      'Hora': a.horaAtencion,
      'Empresa': a.empresa,
      'Caso Accidente': a.codigoAccidente || 'N/A',
      'Trabajador': a.trabajadorNombre,
      'DNI': a.trabajadorDni,
      'Puesto': a.puesto,
      'Área': a.area,
      'Lugar': a.lugarAtencion,
      'Diagnóstico': a.diagnostico,
      'Tratamiento': a.tratamiento,
      'Descanso': a.generaDescanso ? 'SÍ' : 'NO',
      'Días Descanso': a.diasDescanso || 0,
      'Estado': a.estado
    }));
    ExportUtils.exportToExcel(data, filename, 'Atenciones Médicas');
  }

  /**
   * Exporta a PDF
   */
  static exportPDF(records: AtencionMedicaRecord[], filename: string, title: string, empresa: EmpresaId = 'CONSOLIDADO') {
    ExportUtils.exportToPdf({
      title,
      empresa,
      fileName: filename,
      headers: ['ID', 'Fecha', 'Trabajador', 'DNI', 'Diagnóstico', 'Descanso', 'Estado'],
      rows: records.map((r) => [
        r.idAtencion,
        r.fechaAtencion,
        r.trabajadorNombre,
        r.trabajadorDni,
        r.diagnostico,
        r.generaDescanso ? `${r.diasDescanso || 0} d.` : 'No',
        r.estado
      ]),
      orientation: 'landscape'
    });
  }
}
