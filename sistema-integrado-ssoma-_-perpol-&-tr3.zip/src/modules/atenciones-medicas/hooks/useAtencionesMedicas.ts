import { useState, useMemo, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAppStore } from '../../../store/appStore';
import { AtencionMedicaRecord, TrabajadorRecord } from '../../../types/modules';
import { AtencionesTab, AtencionesMedicasMetricas } from '../types/atencionesMedicas';
import { AtencionesMedicasService } from '../services/atencionesMedicasService';
import { FilterChipOption } from '../../../components/common/ModuleToolbar';

export function useAtencionesMedicas() {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    upsertAtencionMedica,
    batchUpsertAtencionesMedicas,
    removeAtencionMedica,
    upsertAccidente,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  // Tabs
  const [activeTab, setActiveTab] = useState<AtencionesTab>('historial');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [estadoFilter, setEstadoFilter] = useState<string>('TODOS');
  const [descansoFilter, setDescansoFilter] = useState<string>('TODOS');
  const [accidenteFilter, setAccidenteFilter] = useState<string>('TODOS');
  const [areaFilter, setAreaFilter] = useState<string>('TODOS');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Línea de tiempo
  const [selectedTimelineCaso, setSelectedTimelineCaso] = useState<string>('');
  const [isAddAtencionModalOpen, setIsAddAtencionModalOpen] = useState(false);
  const [isModalSaving, setIsModalSaving] = useState(false);
  const [modalFormError, setModalFormError] = useState<string | null>(null);

  // Formulario del Modal "+ Agregar Atención Médica"
  const [modalFormData, setModalFormData] = useState({
    codigoCaso: '',
    fechaAtencion: new Date().toISOString().slice(0, 10),
    horaAtencion: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
    centroMedico: 'Clínica SCTR / Policlínico',
    diagnostico: '',
    tipoAtencion: 'Atención médica ambulatoria',
    generaDescanso: 'NO' as 'SI' | 'NO',
    tipoCertificadoDescanso: 'Descanso SCTR',
    nroCertificadoMedico: '',
    cie10: '',
    fechaInicioDescanso: '',
    fechaFinDescanso: '',
    diasDescanso: 0,
    proximaCita: '',
    tratamiento: '',
    medicamentosPrescritos: '',
    medicoTratante: '',
    estado: 'En seguimiento'
  });

  // Modales
  const [viewModal, setViewModal] = useState<AtencionMedicaRecord | null>(null);
  const [deleteModalItem, setDeleteModalItem] = useState<AtencionMedicaRecord | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [workerSearchTerm, setWorkerSearchTerm] = useState('');
  const [isWorkerDropdownOpen, setIsWorkerDropdownOpen] = useState(false);

  const initialFormData: Partial<AtencionMedicaRecord> = {
    fechaAtencion: new Date().toISOString().slice(0, 10),
    horaAtencion: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    trabajadorNombre: '',
    trabajadorDni: '',
    puesto: '',
    area: '',
    lugarEspecifico: '',
    turno: 'Mañana',
    lugarAtencion: 'Tópico de Planta',
    tipoAtencion: 'Primeros auxilios tópicos',
    diagnostico: '',
    tratamiento: '',
    medicamentosPrescritos: '',
    generaDescanso: 'NO',
    tipoCertificadoDescanso: 'Descanso SCTR',
    nroCertificadoMedico: '',
    cie10: '',
    fechaInicioDescanso: '',
    fechaFinDescanso: '',
    diasDescanso: 0,
    restriccionesLaborales: '',
    proximaCita: '',
    estado: 'En seguimiento',
    medicoTratante: '',
    observaciones: '',
    idAccidente: '',
    codigoAccidente: ''
  };

  const [formData, setFormData] = useState<Partial<AtencionMedicaRecord>>(initialFormData);

  // Escuchar si viene redirigido desde el Módulo 1 (Accidentes)
  useEffect(() => {
    if (location.state) {
      const s = location.state as any;
      if (s.filtroCodigoCaso) {
        setSearchTerm(s.filtroCodigoCaso);
        setActiveTab('historial');
        addToast({
          type: 'info',
          title: 'Historial Localizado',
          message: `Mostrando atenciones vinculadas al caso ${s.filtroCodigoCaso}.`
        });
      } else if (s.idAccidenteOrigen || s.codigoCasoAccidente) {
        const accId = s.idAccidenteOrigen || s.codigoCasoAccidente;
        const acc = accidentes.find((a) => a.id === accId || a.codigoCaso === accId);
        const partes = acc?.partesCuerpoAfectadas || [];
        const lesion = acc?.lesionReferida || [];
        const mecanismo = acc?.mecanismoEvento || [];
        const agente = acc?.agenteEvento || [];
        const desc = acc?.descripcion || '';
        const cInm = acc?.causaInmediata || '';
        const fAcc = acc?.fecha || s.fechaEvento || '';
        const hAcc = acc?.hora || '';
        const tipoEv = acc?.tipoEvento || 'Accidente de trabajo';
        const lugAcc = acc?.lugarExacto || acc?.area || '';

        const esIncapacitante = acc?.tipoEvento === 'Accidente incapacitante';
        const diagSugerido = `Atención clínica de urgencia por ${lesion.join(', ') || 'lesión física'} en ${partes.join(', ') || 'zona corporal afectada'} debido a ${tipoEv}. Caso SST ${s.codigoCasoAccidente || acc?.codigoCaso}.`;
        const tratamientoSugerido = `Evaluación clínica de urgencia de zona afectada (${partes.join(', ') || 's/n'}), curación tópica con antiséptico, pauta analgésica y reposo.`;

        setFormData((prev) => ({
          ...prev,
          idAccidente: s.idAccidenteOrigen || acc?.id || '',
          codigoAccidente: s.codigoCasoAccidente || acc?.codigoCaso || '',
          trabajadorDni: s.dniTrabajador || acc?.trabajadorDni || prev.trabajadorDni,
          trabajadorNombre: s.nombreTrabajador || acc?.trabajadorNombre || prev.trabajadorNombre,
          empresa: (s.empresa || acc?.empresa || prev.empresa) as any,
          puesto: s.puesto || acc?.cargo || prev.puesto,
          area: s.area || acc?.area || prev.area,
          turno: s.turno || acc?.turno || prev.turno,
          tipoAtencion: esIncapacitante ? 'Atención médica ambulatoria' : 'Primeros auxilios tópicos',
          fechaAtencion: s.fechaEvento || acc?.fecha || prev.fechaAtencion,
          fechaAccidente: fAcc,
          horaAccidente: hAcc,
          tipoEvento: tipoEv,
          lugarAccidente: lugAcc,
          lugarEspecifico: lugAcc,
          partesCuerpoAfectadas: partes,
          lesionReferida: lesion,
          mecanismoEvento: mecanismo,
          agenteEvento: agente,
          descripcionAccidente: desc,
          causaInmediata: cInm,
          diagnostico: prev.diagnostico || diagSugerido,
          tratamiento: prev.tratamiento || tratamientoSugerido,
          generaDescanso: esIncapacitante ? 'SI' : prev.generaDescanso,
          fechaInicioDescanso: esIncapacitante ? (fAcc || prev.fechaAtencion) : prev.fechaInicioDescanso,
          fechaFinDescanso: esIncapacitante ? (fAcc || prev.fechaAtencion) : prev.fechaFinDescanso,
          diasDescanso: esIncapacitante && prev.diasDescanso === 0 ? 1 : prev.diasDescanso
        }));

        if (s.nombreTrabajador || acc?.trabajadorNombre) {
          setWorkerSearchTerm(s.nombreTrabajador || acc?.trabajadorNombre);
        }
        setActiveTab('nuevo');
        addToast({
          type: 'info',
          title: 'Datos de Accidente Heredados',
          message: `Se cargó la ficha del caso ${s.codigoCasoAccidente || s.idAccidenteOrigen} con trabajador, lesión y área.`
        });
      }
    }
  }, [location.state, accidentes, addToast]);

  // Selección manual de accidente para heredar datos automáticamente
  const handleSelectAccidente = (accId: string) => {
    if (!accId) {
      setFormData((prev) => ({
        ...prev,
        idAccidente: '',
        codigoAccidente: '',
        fechaAccidente: '',
        horaAccidente: '',
        tipoEvento: '',
        lugarAccidente: '',
        partesCuerpoAfectadas: [],
        lesionReferida: [],
        mecanismoEvento: [],
        agenteEvento: [],
        descripcionAccidente: '',
        causaInmediata: ''
      }));
      return;
    }

    const acc = accidentes.find((a) => a.id === accId || a.codigoCaso === accId);
    if (!acc) return;

    const partes = acc.partesCuerpoAfectadas || [];
    const lesion = acc.lesionReferida || [];
    const mecanismo = acc.mecanismoEvento || [];
    const agente = acc.agenteEvento || [];

    let diagSugerido = formData.diagnostico || '';
    if (!diagSugerido.trim() && (lesion.length > 0 || partes.length > 0)) {
      const lStr = lesion.join(', ');
      const pStr = partes.join(', ');
      diagSugerido = `Atención clínica por ${lStr ? lStr : 'lesión física'} en ${pStr ? pStr : 'zona corporal referida'} asociada al caso SST ${acc.codigoCaso}.`;
    }

    const esIncapacitante = acc.tipoEvento === 'Accidente incapacitante';
    const tratamientoSugerido =
      formData.tratamiento ||
      `Evaluación clínica de zona afectada (${partes.join(', ') || 's/n'}), desinfección y curación tópica con antiséptico, pauta analgésica y reposo.`;

    setFormData((prev) => ({
      ...prev,
      idAccidente: acc.id,
      codigoAccidente: acc.codigoCaso,
      empresa: acc.empresa,
      trabajadorDni: acc.trabajadorDni,
      trabajadorNombre: acc.trabajadorNombre,
      puesto: acc.cargo,
      area: acc.area,
      turno: acc.turno,
      tipoAtencion: esIncapacitante ? 'Atención médica ambulatoria' : (prev.tipoAtencion || 'Primeros auxilios tópicos'),
      fechaAtencion: acc.fecha || prev.fechaAtencion,
      fechaAccidente: acc.fecha,
      horaAccidente: acc.hora,
      tipoEvento: acc.tipoEvento,
      lugarAccidente: acc.lugarExacto,
      lugarEspecifico: acc.lugarExacto,
      partesCuerpoAfectadas: partes,
      lesionReferida: lesion,
      mecanismoEvento: mecanismo,
      agenteEvento: agente,
      descripcionAccidente: acc.descripcion,
      causaInmediata: acc.causaInmediata,
      diagnostico: diagSugerido,
      tratamiento: tratamientoSugerido,
      generaDescanso: esIncapacitante ? 'SI' : prev.generaDescanso,
      fechaInicioDescanso: esIncapacitante ? (prev.fechaInicioDescanso || acc.fecha) : prev.fechaInicioDescanso,
      fechaFinDescanso: esIncapacitante ? (prev.fechaFinDescanso || acc.fecha) : prev.fechaFinDescanso,
      diasDescanso: esIncapacitante && prev.diasDescanso === 0 ? 1 : prev.diasDescanso,
      tipoCertificadoDescanso: prev.tipoCertificadoDescanso || 'Descanso SCTR'
    }));

    setWorkerSearchTerm(acc.trabajadorNombre);
    addToast({
      type: 'success',
      title: 'Caso SST Vinculado',
      message: `Datos heredados del caso ${acc.codigoCaso}: colaborador, área y detalles del accidente cargados.`
    });
  };

  // Cálculo automático de días de descanso médico
  useEffect(() => {
    if (formData.generaDescanso === 'SI' && formData.fechaInicioDescanso && formData.fechaFinDescanso) {
      const fInicio = new Date(formData.fechaInicioDescanso);
      const fFin = new Date(formData.fechaFinDescanso);
      const diffTime = fFin.getTime() - fInicio.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      const dias = diffDays > 0 ? diffDays : 1;
      setFormData((prev) => (prev.diasDescanso !== dias ? { ...prev, diasDescanso: dias } : prev));
    } else if (formData.generaDescanso === 'NO') {
      setFormData((prev) => (prev.diasDescanso !== 0 ? { ...prev, diasDescanso: 0 } : prev));
    }
  }, [formData.generaDescanso, formData.fechaInicioDescanso, formData.fechaFinDescanso]);

  // Cálculo de días en el modal de la línea de tiempo
  useEffect(() => {
    if (modalFormData.generaDescanso === 'SI' && modalFormData.fechaInicioDescanso && modalFormData.fechaFinDescanso) {
      const fInicio = new Date(modalFormData.fechaInicioDescanso);
      const fFin = new Date(modalFormData.fechaFinDescanso);
      const diffTime = fFin.getTime() - fInicio.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      const dias = diffDays > 0 ? diffDays : 1;
      setModalFormData((prev) => (prev.diasDescanso !== dias ? { ...prev, diasDescanso: dias } : prev));
    } else if (modalFormData.generaDescanso === 'NO') {
      setModalFormData((prev) => (prev.diasDescanso !== 0 ? { ...prev, diasDescanso: 0 } : prev));
    }
  }, [modalFormData.generaDescanso, modalFormData.fechaInicioDescanso, modalFormData.fechaFinDescanso]);

  // Trabajadores filtrados para autocompletar
  const trabajadoresFiltrados = useMemo(() => {
    return trabajadores
      .filter((t) => {
        if (t.condicion !== 'Activo') return false;
        if (formData.empresa && t.empresa !== formData.empresa) return false;
        if (!workerSearchTerm.trim()) return true;
        const q = workerSearchTerm.toLowerCase();
        return (
          String(t.apellidosNombres || '').toLowerCase().includes(q) ||
          String(t.dni || '').includes(q) ||
          String(t.puesto || '').toLowerCase().includes(q)
        );
      })
      .slice(0, 15);
  }, [trabajadores, formData.empresa, workerSearchTerm]);

  const handleSelectTrabajador = (t: TrabajadorRecord) => {
    setFormData((prev) => ({
      ...prev,
      trabajadorNombre: t.apellidosNombres,
      trabajadorDni: t.dni,
      puesto: t.puesto,
      area: t.area,
      empresa: t.empresa
    }));
    setWorkerSearchTerm(t.apellidosNombres);
    setIsWorkerDropdownOpen(false);
  };

  // Filtrado de atenciones
  const filteredAtenciones = useMemo(() => {
    return atencionesMedicas.filter((item) => {
      if (empresaActiva !== 'CONSOLIDADO' && item.empresa !== empresaActiva) return false;
      if (estadoFilter !== 'TODOS' && item.estado !== estadoFilter) return false;
      if (descansoFilter !== 'TODOS' && item.generaDescanso !== descansoFilter) return false;
      if (accidenteFilter === 'CON_ACCIDENTE' && !item.codigoAccidente && !item.idAccidente) return false;
      if (accidenteFilter === 'SIN_ACCIDENTE' && (item.codigoAccidente || item.idAccidente)) return false;
      if (areaFilter !== 'TODOS' && item.area !== areaFilter) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchId = String(item.idAtencion || '').toLowerCase().includes(q);
        const matchAcc =
          String(item.codigoAccidente || '').toLowerCase().includes(q) ||
          String(item.idAccidente || '').toLowerCase().includes(q);
        const matchWorker = String(item.trabajadorNombre || '').toLowerCase().includes(q);
        const matchDni = String(item.trabajadorDni || '').toLowerCase().includes(q);
        const matchDiag = String(item.diagnostico || '').toLowerCase().includes(q);
        const matchLugar = String(item.lugarAtencion || '').toLowerCase().includes(q);
        if (!matchId && !matchAcc && !matchWorker && !matchDni && !matchDiag && !matchLugar) return false;
      }
      return true;
    });
  }, [atencionesMedicas, empresaActiva, estadoFilter, descansoFilter, accidenteFilter, areaFilter, searchTerm]);

  const paginatedAtenciones = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return filteredAtenciones.slice(startIndex, startIndex + pageSize);
  }, [filteredAtenciones, currentPage, pageSize]);

  // KPIs
  const metricas: AtencionesMedicasMetricas = useMemo(() => {
    const list = atencionesMedicas.filter((m) => empresaActiva === 'CONSOLIDADO' || m.empresa === empresaActiva);
    return {
      total: list.length,
      conDescanso: list.filter((m) => m.generaDescanso === 'SI').length,
      diasTotales: list.reduce((acc, m) => acc + (Number(m.diasDescanso) || 0), 0),
      enSeguimiento: list.filter((m) => m.estado === 'En seguimiento').length,
      conAlta: list.filter((m) => m.estado === 'Alta / reincorporado').length,
      vinculadasAccidente: list.filter((m) => Boolean(m.codigoAccidente || m.idAccidente)).length
    };
  }, [atencionesMedicas, empresaActiva]);

  // Status options para la Toolbar
  const statusOptions: FilterChipOption[] = useMemo(() => {
    const list = atencionesMedicas.filter((m) => empresaActiva === 'CONSOLIDADO' || m.empresa === empresaActiva);
    return [
      { id: 'TODOS', label: 'Todos', count: list.length },
      { id: 'En seguimiento', label: 'En seguimiento', count: list.filter((m) => m.estado === 'En seguimiento').length, color: 'text-amber-400' },
      { id: 'Alta / reincorporado', label: 'Alta médica', count: list.filter((m) => m.estado === 'Alta / reincorporado').length, color: 'text-emerald-400' },
      { id: 'Alta con restricciones', label: 'Con restricciones', count: list.filter((m) => m.estado === 'Alta con restricciones').length, color: 'text-purple-400' },
      { id: 'Derivado a especialista', label: 'Derivados', count: list.filter((m) => m.estado === 'Derivado a especialista').length, color: 'text-blue-400' },
      { id: 'Cerrado', label: 'Cerrados', count: list.filter((m) => m.estado === 'Cerrado').length, color: 'text-slate-400' }
    ];
  }, [atencionesMedicas, empresaActiva]);

  // Datos para la línea de tiempo
  const selectedAccident = useMemo(() => {
    if (!selectedTimelineCaso) return undefined;
    return accidentes.find((a) => a.codigoCaso === selectedTimelineCaso || a.id === selectedTimelineCaso);
  }, [selectedTimelineCaso, accidentes]);

  const atencionesCasoTimeline = useMemo(() => {
    if (!selectedAccident) return [];
    return atencionesMedicas
      .filter((m) => m.codigoAccidente === selectedAccident.codigoCaso || m.idAccidente === selectedAccident.id)
      .sort((a, b) => new Date(a.fechaAtencion).getTime() - new Date(b.fechaAtencion).getTime());
  }, [selectedAccident, atencionesMedicas]);

  const metricasCasoTimeline = useMemo(() => {
    const total = atencionesCasoTimeline.length;
    const diasAcumulados = atencionesCasoTimeline.reduce((acc, m) => acc + (Number(m.diasDescanso) || 0), 0);
    const ultimaAtencion = atencionesCasoTimeline[atencionesCasoTimeline.length - 1];
    const estadoActual = ultimaAtencion ? ultimaAtencion.estado : 'Sin atenciones';
    const atencionesConCita = atencionesCasoTimeline.filter((m) => Boolean(m.proximaCita));
    const proximaCita = atencionesConCita.length > 0 ? atencionesConCita[atencionesConCita.length - 1].proximaCita || '' : '';
    return { total, diasAcumulados, estadoActual, proximaCita };
  }, [atencionesCasoTimeline]);

  // Editar atención
  const handleEdit = (item: AtencionMedicaRecord) => {
    setEditingId(item.id || item.idAtencion);
    setFormData({ ...item });
    setWorkerSearchTerm(item.trabajadorNombre);
    setActiveTab('nuevo');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    addToast({
      type: 'info',
      title: 'Modo Edición',
      message: `Cargando atención ${item.idAtencion} para su edición.`
    });
  };

  // Abrir modal nueva atención desde línea de tiempo
  const abrirModalNuevaAtencion = (codigoCaso: string) => {
    setModalFormError(null);
    setModalFormData({
      codigoCaso,
      fechaAtencion: new Date().toISOString().slice(0, 10),
      horaAtencion: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false }),
      centroMedico: 'Clínica SCTR / Policlínico',
      diagnostico: '',
      tipoAtencion: 'Atención médica ambulatoria',
      generaDescanso: 'NO',
      tipoCertificadoDescanso: 'Descanso SCTR',
      nroCertificadoMedico: '',
      cie10: '',
      fechaInicioDescanso: '',
      fechaFinDescanso: '',
      diasDescanso: 0,
      proximaCita: '',
      tratamiento: '',
      medicamentosPrescritos: '',
      medicoTratante: '',
      estado: 'En seguimiento'
    });
    setIsAddAtencionModalOpen(true);
  };

  const cerrarModalNuevaAtencion = () => {
    setIsAddAtencionModalOpen(false);
    setModalFormError(null);
  };

  // Guardar atención desde el modal rápido
  const handleSaveModalAtencion = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalFormError(null);

    const codCaso = modalFormData.codigoCaso;
    if (!codCaso) {
      setModalFormError('Error: No se identificó el código de caso del accidente.');
      return;
    }
    if (!modalFormData.centroMedico.trim()) {
      setModalFormError('El centro médico o lugar de atención es obligatorio.');
      return;
    }
    if (!modalFormData.diagnostico.trim()) {
      setModalFormError('El diagnóstico clínico es obligatorio.');
      return;
    }
    if (modalFormData.generaDescanso === 'SI' && (!modalFormData.fechaInicioDescanso || !modalFormData.fechaFinDescanso)) {
      setModalFormError('Debe ingresar la fecha de inicio y fin de descanso médico.');
      return;
    }

    setIsModalSaving(true);
    incrementSync();

    try {
      const acc = accidentes.find((a) => a.codigoCaso === codCaso || a.id === codCaso);
      const anio = new Date().getFullYear();
      const totalAnio = atencionesMedicas.filter((m) => {
        const f = m.fechaAtencion || '';
        return f.startsWith(String(anio)) || (m.idAtencion && m.idAtencion.includes(`-${anio}-`));
      }).length;
      const correlativo = `ATN-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;
      const empresa = acc?.empresa || (empresaActiva === 'TR3' ? 'TR3' : 'PERPOL');
      const trabajadorDni = acc?.trabajadorDni || '';
      const trabajadorNombre = acc?.trabajadorNombre || '';
      const puesto = acc?.cargo || '';
      const area = acc?.area || '';
      const turno = acc?.turno || 'Mañana';

      const fullRecord: AtencionMedicaRecord = {
        id: correlativo,
        idAtencion: correlativo,
        idAccidente: acc?.id || codCaso,
        codigoAccidente: acc?.codigoCaso || codCaso,
        empresa,
        trabajadorDni,
        trabajadorNombre,
        puesto,
        area,
        turno,
        tipoAtencion: modalFormData.tipoAtencion || 'Atención médica ambulatoria',
        lugarAtencion: modalFormData.centroMedico,
        fechaAtencion: modalFormData.fechaAtencion,
        horaAtencion: modalFormData.horaAtencion || '09:00',
        diagnostico: modalFormData.diagnostico,
        tratamiento: modalFormData.tratamiento || undefined,
        medicamentosPrescritos: modalFormData.medicamentosPrescritos || undefined,
        generaDescanso: modalFormData.generaDescanso as 'SI' | 'NO',
        tipoCertificadoDescanso: modalFormData.generaDescanso === 'SI' ? modalFormData.tipoCertificadoDescanso : undefined,
        nroCertificadoMedico: modalFormData.generaDescanso === 'SI' ? modalFormData.nroCertificadoMedico : undefined,
        cie10: modalFormData.cie10 || undefined,
        fechaInicioDescanso: modalFormData.generaDescanso === 'SI' ? modalFormData.fechaInicioDescanso : undefined,
        fechaFinDescanso: modalFormData.generaDescanso === 'SI' ? modalFormData.fechaFinDescanso : undefined,
        diasDescanso: Number(modalFormData.diasDescanso) || 0,
        proximaCita: modalFormData.proximaCita || undefined,
        estado: (modalFormData.estado as any) || 'En seguimiento',
        medicoTratante: modalFormData.medicoTratante || undefined,
        fechaAccidente: acc?.fecha,
        horaAccidente: acc?.hora,
        tipoEvento: acc?.tipoEvento,
        lugarAccidente: acc?.lugarExacto,
        partesCuerpoAfectadas: acc?.partesCuerpoAfectadas || [],
        lesionReferida: acc?.lesionReferida || [],
        mecanismoEvento: acc?.mecanismoEvento || [],
        agenteEvento: acc?.agenteEvento || [],
        descripcionAccidente: acc?.descripcion,
        causaInmediata: acc?.causaInmediata,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      upsertAtencionMedica(fullRecord);

      if (acc) {
        const otrasAtenciones = atencionesMedicas.filter(
          (m) =>
            m.id !== fullRecord.id &&
            m.idAtencion !== fullRecord.idAtencion &&
            (m.idAccidente === acc.id || m.codigoAccidente === acc.codigoCaso)
        );
        const totalDias = otrasAtenciones.reduce(
          (sum, m) => sum + (Number(m.diasDescanso) || 0),
          Number(fullRecord.diasDescanso) || 0
        );
        upsertAccidente({
          ...acc,
          diasDescanso: totalDias
        });
      }

      try {
        await AtencionesMedicasService.saveAtencion(fullRecord);
      } catch {
        // En background
      }

      addToast({
        type: 'success',
        title: 'Atención Médica Guardada',
        message: `Se registró la atención ${correlativo} para el caso ${codCaso}. Línea de tiempo actualizada.`
      });

      cerrarModalNuevaAtencion();
    } catch {
      setModalFormError('Ocurrió un error al guardar la atención médica en Google Apps Script.');
    } finally {
      setIsModalSaving(false);
      decrementSync();
    }
  };

  // Guardar formulario principal (Tab 3)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.trabajadorNombre?.trim() || !formData.trabajadorDni?.trim()) {
      setFormError('Debe ingresar los datos del trabajador atendido.');
      return;
    }
    if (!formData.area?.trim()) {
      setFormError('Debe indicar el área de trabajo.');
      return;
    }
    if (!formData.lugarEspecifico?.trim() && !formData.lugarAccidente?.trim()) {
      setFormError('Debe indicar el lugar físico específico.');
      return;
    }
    if (!formData.lugarAtencion?.trim()) {
      setFormError('Debe indicar el lugar o centro médico de atención.');
      return;
    }
    if (!formData.diagnostico?.trim()) {
      setFormError('El diagnóstico clínico es obligatorio.');
      return;
    }
    if (formData.generaDescanso === 'SI' && (!formData.fechaInicioDescanso || !formData.fechaFinDescanso)) {
      setFormError('Debe ingresar la fecha de inicio y fin del descanso médico.');
      return;
    }

    setIsSubmitting(true);
    incrementSync();

    try {
      const existingAtn = editingId ? atencionesMedicas.find((m) => m.id === editingId || m.idAtencion === editingId) : null;
      let correlativo = existingAtn?.idAtencion || (existingAtn?.id && existingAtn.id.startsWith('ATN-') ? existingAtn.id : undefined);
      if (!correlativo) {
        const anio = new Date(formData.fechaAtencion || Date.now()).getFullYear();
        const totalAnio = atencionesMedicas.filter((m) => {
          const f = m.fechaAtencion || '';
          return f.startsWith(String(anio)) || (m.idAtencion && m.idAtencion.includes(`-${anio}-`));
        }).length;
        correlativo = `ATN-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;
      }

      const fullRecord: AtencionMedicaRecord = {
        id: editingId || correlativo,
        idAtencion: editingId || correlativo,
        idAccidente: formData.idAccidente,
        codigoAccidente: formData.codigoAccidente,
        empresa: formData.empresa as 'PERPOL' | 'TR3',
        trabajadorDni: formData.trabajadorDni!,
        trabajadorNombre: formData.trabajadorNombre!,
        puesto: formData.puesto,
        area: formData.area,
        lugarEspecifico: formData.lugarEspecifico || formData.lugarAccidente,
        turno: formData.turno,
        lugarAtencion: formData.lugarAtencion!,
        tipoAtencion: formData.tipoAtencion,
        fechaAtencion: formData.fechaAtencion || new Date().toISOString().slice(0, 10),
        horaAtencion: formData.horaAtencion || '09:00',
        diagnostico: formData.diagnostico!,
        tratamiento: formData.tratamiento,
        medicamentosPrescritos: formData.medicamentosPrescritos,
        generaDescanso: formData.generaDescanso as 'SI' | 'NO',
        tipoCertificadoDescanso: formData.tipoCertificadoDescanso,
        nroCertificadoMedico: formData.nroCertificadoMedico,
        cie10: formData.cie10,
        fechaInicioDescanso: formData.fechaInicioDescanso,
        fechaFinDescanso: formData.fechaFinDescanso,
        diasDescanso: Number(formData.diasDescanso) || 0,
        restriccionesLaborales: formData.restriccionesLaborales,
        proximaCita: formData.proximaCita,
        estado: (formData.estado as any) || 'En seguimiento',
        medicoTratante: formData.medicoTratante,
        observaciones: formData.observaciones,
        fechaAccidente: formData.fechaAccidente,
        horaAccidente: formData.horaAccidente,
        tipoEvento: formData.tipoEvento,
        lugarAccidente: formData.lugarAccidente,
        partesCuerpoAfectadas: formData.partesCuerpoAfectadas || [],
        lesionReferida: formData.lesionReferida || [],
        mecanismoEvento: formData.mecanismoEvento || [],
        agenteEvento: formData.agenteEvento || [],
        descripcionAccidente: formData.descripcionAccidente,
        causaInmediata: formData.causaInmediata,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      upsertAtencionMedica(fullRecord);

      if (formData.codigoAccidente || formData.idAccidente) {
        const acc = accidentes.find(
          (a) => a.id === formData.idAccidente || a.codigoCaso === formData.codigoAccidente
        );
        if (acc) {
          const otrasAtenciones = atencionesMedicas.filter(
            (m) =>
              m.id !== fullRecord.id &&
              m.idAtencion !== fullRecord.idAtencion &&
              (m.idAccidente === acc.id || m.codigoAccidente === acc.codigoCaso)
          );
          const totalDias = otrasAtenciones.reduce(
            (sum, m) => sum + (Number(m.diasDescanso) || 0),
            Number(fullRecord.diasDescanso) || 0
          );
          upsertAccidente({
            ...acc,
            diasDescanso: totalDias
          });
        }
      }

      await AtencionesMedicasService.saveAtencion(fullRecord);

      addToast({
        type: 'success',
        title: 'Atención Médica Guardada',
        message: `Atención ${correlativo} guardada en Google Sheets.`
      });

      setEditingId(null);
      setActiveTab('historial');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar la atención médica';
      setFormError(msg);
      addToast({ type: 'error', title: 'Error', message: msg });
    } finally {
      setIsSubmitting(false);
      decrementSync();
    }
  };

  // Confirmar eliminación
  const confirmDelete = async () => {
    if (!deleteModalItem) return;
    const item = deleteModalItem;
    removeAtencionMedica(item.id);
    addToast({ type: 'info', title: 'Atención Eliminada', message: `Atención ${item.idAtencion} eliminada.` });

    try {
      await AtencionesMedicasService.deleteAtencion(item.idAtencion);
    } catch {
      // Ignorar fallback
    } finally {
      setDeleteModalItem(null);
    }
  };

  // Exportar Excel
  const handleExportExcel = () => {
    AtencionesMedicasService.exportExcel(
      filteredAtenciones,
      `Atenciones_Medicas_${empresaActiva}_${new Date().toISOString().slice(0, 10)}`
    );
    addToast({ type: 'success', title: 'Exportación Excel', message: 'Reporte de atenciones médicas generado.' });
  };

  // Exportar PDF
  const handleExportPDF = () => {
    AtencionesMedicasService.exportPDF(
      filteredAtenciones,
      `Reporte_Atenciones_${empresaActiva}`,
      `HISTORIAL DE ATENCIONES MÉDICAS Y PRIMEROS AUXILIOS - ${empresaActiva}`
    );
    addToast({ type: 'success', title: 'PDF Generado', message: 'Reporte de atenciones médicas descargado.' });
  };

  // Limpiar filtros
  const clearFilters = () => {
    setSearchTerm('');
    setEstadoFilter('TODOS');
    setDescansoFilter('TODOS');
    setAccidenteFilter('TODOS');
    setAreaFilter('TODOS');
    setCurrentPage(1);
  };

  // Nuevo registro limpio
  const handleNuevoRegistro = () => {
    setEditingId(null);
    setFormData({
      ...initialFormData,
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL'
    });
    setWorkerSearchTerm('');
    setActiveTab('nuevo');
  };

  // Navegar a accidente
  const handleNavigateToAccidente = (codigoCaso: string, idAccidente?: string) => {
    navigate('/accidentes', {
      state: {
        filtroCodigoCaso: codigoCaso,
        filtroIdAccidente: idAccidente
      }
    });
    addToast({
      type: 'info',
      title: 'Ver Evento SST',
      message: `Abriendo caso ${codigoCaso} en Accidentes de Trabajo.`
    });
  };

  return {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    searchTerm,
    setSearchTerm,
    estadoFilter,
    setEstadoFilter,
    descansoFilter,
    setDescansoFilter,
    accidenteFilter,
    setAccidenteFilter,
    areaFilter,
    setAreaFilter,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    selectedTimelineCaso,
    setSelectedTimelineCaso,
    isAddAtencionModalOpen,
    modalFormData,
    setModalFormData,
    modalFormError,
    isModalSaving,
    viewModal,
    setViewModal,
    deleteModalItem,
    setDeleteModalItem,
    isSubmitting,
    formError,
    editingId,
    formData,
    setFormData,
    workerSearchTerm,
    setWorkerSearchTerm,
    isWorkerDropdownOpen,
    setIsWorkerDropdownOpen,
    trabajadoresFiltrados,
    filteredAtenciones,
    paginatedAtenciones,
    metricas,
    statusOptions,
    selectedAccident,
    atencionesCasoTimeline,
    metricasCasoTimeline,
    handleSelectAccidente,
    handleSelectTrabajador,
    handleEdit,
    handleSubmit,
    confirmDelete,
    abrirModalNuevaAtencion,
    cerrarModalNuevaAtencion,
    handleSaveModalAtencion,
    handleExportExcel,
    handleExportPDF,
    clearFilters,
    handleNuevoRegistro,
    handleNavigateToAccidente,
    batchUpsertAtencionesMedicas
  };
}
