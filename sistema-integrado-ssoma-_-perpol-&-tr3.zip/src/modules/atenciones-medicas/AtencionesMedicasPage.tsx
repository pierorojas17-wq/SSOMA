import React from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { ModuleToolbar } from '../../components/common/ModuleToolbar';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { AtencionMedicaRecord } from '../../types/modules';

// Subcomponentes del módulo
import { AtencionesStats } from './components/AtencionesStats';
import { AtencionesTable } from './components/AtencionesTable';
import { AtencionesTimeline } from './components/AtencionesTimeline';
import { AtencionesForm } from './components/AtencionesForm';
import { AtencionesDetailModal } from './components/AtencionesDetailModal';
import { AtencionesAddModal } from './components/AtencionesAddModal';

// Hook personalizado
import { useAtencionesMedicas } from './hooks/useAtencionesMedicas';

// Iconos
import { HeartPulse, History, Plus, Upload } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { AREAS_EMPRESA } from '../../utils/ssomaCatalogs';

export const AtencionesMedicasPage: React.FC = () => {
  const { addToast } = useAppStore();

  const {
    empresaActiva,
    trabajadores,
    accidentes,
    atencionesMedicas,
    activeTab,
    setActiveTab,
    isImportModalOpen,
    setIsImportModalOpen,
    searchTerm,
    setSearchTerm,
    estadoFilter,
    setEstadoFilter,
    descansoFilter,
    setDescansoFilter,
    accidenteFilter,
    setAccidenteFilter,
    areaFilter,
    setAreaFilter,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    selectedTimelineCaso,
    setSelectedTimelineCaso,
    isAddAtencionModalOpen,
    modalFormData,
    setModalFormData,
    modalFormError,
    isModalSaving,
    viewModal,
    setViewModal,
    deleteModalItem,
    setDeleteModalItem,
    isSubmitting,
    formError,
    editingId,
    formData,
    setFormData,
    workerSearchTerm,
    setWorkerSearchTerm,
    isWorkerDropdownOpen,
    setIsWorkerDropdownOpen,
    trabajadoresFiltrados,
    filteredAtenciones,
    paginatedAtenciones,
    metricas,
    statusOptions,
    selectedAccident,
    atencionesCasoTimeline,
    metricasCasoTimeline,
    handleSelectAccidente,
    handleSelectTrabajador,
    handleEdit,
    handleSubmit,
    confirmDelete,
    abrirModalNuevaAtencion,
    cerrarModalNuevaAtencion,
    handleSaveModalAtencion,
    handleExportExcel,
    handleExportPDF,
    clearFilters,
    handleNuevoRegistro,
    handleNavigateToAccidente,
    batchUpsertAtencionesMedicas
  } = useAtencionesMedicas();

  return (
    <div className="space-y-6">
      {/* Header estandarizado */}
      <ModuleHeader
        codigo={2}
        titulo="Atenciones Médicas y Primeros Auxilios"
        subtitulo="Módulo especializado para el registro de atenciones clínicas, diagnóstico médico, descansos laborales y reincorporación"
        icono={<HeartPulse className="w-5 h-5 text-emerald-400" />}
        onNuevo={handleNuevoRegistro}
      />

      {/* Tarjetas KPI */}
      <AtencionesStats metricas={metricas} />

      {/* Tabs Principales */}
      <div className="flex border-b border-[#E2E8F0] bg-white px-2 rounded-t-xl gap-1">
        <button
          onClick={() => setActiveTab('historial')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'historial'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <HeartPulse className="w-4 h-4" />
          <span>Historial de Atenciones</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'historial' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#1E293B]'
            }`}
          >
            {filteredAtenciones.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('lineaTiempo')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'lineaTiempo'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Línea de Tiempo por Accidente</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'lineaTiempo' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#1E293B]'
            }`}
          >
            {accidentes.filter((a) => (empresaActiva === 'CONSOLIDADO' ? true : a.empresa === empresaActiva)).length} Casos
          </span>
        </button>

        <button
          onClick={() => setActiveTab('nuevo')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'nuevo'
              ? 'bg-[#1E293B] text-white shadow-xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>{editingId ? `Editando Atención ${editingId}` : 'Registrar Nueva Atención'}</span>
        </button>
      </div>

      {/* CONTENIDO TAB 1: HISTORIAL DE ATENCIONES */}
      {activeTab === 'historial' && (
        <div className="space-y-4">
          <ModuleToolbar
            searchQuery={searchTerm}
            onSearchChange={(val) => {
              setSearchTerm(val);
              setCurrentPage(1);
            }}
            searchPlaceholder="Buscar por ID, accidente vinculado, trabajador, DNI, diagnóstico o lugar..."
            statusFilter={estadoFilter}
            onStatusFilterChange={(id) => {
              setEstadoFilter(id);
              setCurrentPage(1);
            }}
            statusOptions={statusOptions}
            totalCount={
              atencionesMedicas.filter((m) => (empresaActiva === 'CONSOLIDADO' ? true : m.empresa === empresaActiva)).length
            }
            filteredCount={filteredAtenciones.length}
            onExportExcel={handleExportExcel}
            onExportPdf={handleExportPDF}
            onNewRecord={() => setActiveTab('nuevo')}
            newRecordLabel="Nueva Atención"
          >
            <select
              value={descansoFilter}
              onChange={(e) => {
                setDescansoFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todos los descansos</option>
              <option value="SI">Con Descanso Médico</option>
              <option value="NO">Sin Descanso Médico</option>
            </select>

            <select
              value={accidenteFilter}
              onChange={(e) => {
                setAccidenteFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todas las atenciones</option>
              <option value="CON_ACCIDENTE">Vinculadas a Accidente SST</option>
              <option value="SIN_ACCIDENTE">Atenciones directas / comunes</option>
            </select>

            <select
              value={areaFilter}
              onChange={(e) => {
                setAreaFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-[#263B5E] shadow-2xs cursor-pointer font-medium"
            >
              <option value="TODOS">Todas las áreas</option>
              {AREAS_EMPRESA.map((area) => (
                <option key={area} value={area}>
                  {area}
                </option>
              ))}
            </select>

            <button
              onClick={() => setIsImportModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-xs font-semibold text-sky-700 transition-colors shadow-2xs cursor-pointer"
              title="Importar Atenciones desde Excel o CSV"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Importar</span>
            </button>
          </ModuleToolbar>

          <AtencionesTable
            items={paginatedAtenciones}
            searchTerm={searchTerm}
            estadoFilter={estadoFilter}
            descansoFilter={descansoFilter}
            accidenteFilter={accidenteFilter}
            areaFilter={areaFilter}
            currentPage={currentPage}
            pageSize={pageSize}
            totalItems={filteredAtenciones.length}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
            onView={(item) => setViewModal(item)}
            onEdit={handleEdit}
            onDelete={(item) => setDeleteModalItem(item)}
            onNavigateToAccidente={handleNavigateToAccidente}
            onOpenTimeline={(codigoRef) => {
              setSelectedTimelineCaso(codigoRef);
              setActiveTab('lineaTiempo');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onClearFilters={clearFilters}
            onNewRecord={() => setActiveTab('nuevo')}
          />
        </div>
      )}

      {/* CONTENIDO TAB 2: LÍNEA DE TIEMPO DE ATENCIONES POR CASO SST */}
      {activeTab === 'lineaTiempo' && (
        <AtencionesTimeline
          selectedTimelineCaso={selectedTimelineCaso}
          setSelectedTimelineCaso={setSelectedTimelineCaso}
          selectedAccident={selectedAccident}
          atencionesCasoTimeline={atencionesCasoTimeline}
          metricasCasoTimeline={metricasCasoTimeline}
          empresaActiva={empresaActiva}
          accidentes={accidentes}
          atencionesMedicas={atencionesMedicas}
          onNavigateToAccidente={handleNavigateToAccidente}
          onOpenAddModal={abrirModalNuevaAtencion}
          onView={(item) => setViewModal(item)}
          onEdit={handleEdit}
        />
      )}

      {/* CONTENIDO TAB 3: FORMULARIO DE ATENCIÓN MÉDICA */}
      {activeTab === 'nuevo' && (
        <AtencionesForm
          formData={formData}
          setFormData={setFormData}
          editingId={editingId}
          formError={formError}
          isSubmitting={isSubmitting}
          empresaActiva={empresaActiva}
          accidentes={accidentes}
          trabajadores={trabajadores}
          trabajadoresFiltrados={trabajadoresFiltrados}
          workerSearchTerm={workerSearchTerm}
          setWorkerSearchTerm={setWorkerSearchTerm}
          isWorkerDropdownOpen={isWorkerDropdownOpen}
          setIsWorkerDropdownOpen={setIsWorkerDropdownOpen}
          onSelectAccidente={handleSelectAccidente}
          onSelectTrabajador={handleSelectTrabajador}
          onNavigateToAccidente={handleNavigateToAccidente}
          onSubmit={handleSubmit}
          onCancel={() => {
            handleNuevoRegistro();
            setActiveTab('historial');
          }}
        />
      )}

      {/* MODAL FICHA CLÍNICA DETALLADA */}
      <AtencionesDetailModal
        item={viewModal}
        onClose={() => setViewModal(null)}
        onNavigateToAccidente={handleNavigateToAccidente}
      />

      {/* MODAL EMERGENTE: REGISTRAR NUEVA ATENCIÓN MÉDICA EN LÍNEA DE TIEMPO */}
      <AtencionesAddModal
        isOpen={isAddAtencionModalOpen}
        onClose={cerrarModalNuevaAtencion}
        selectedAccident={selectedAccident}
        modalFormData={modalFormData}
        setModalFormData={setModalFormData}
        modalFormError={modalFormError}
        isModalSaving={isModalSaving}
        onSubmit={handleSaveModalAtencion}
      />

      {/* MODAL CONFIRMAR ELIMINAR */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalItem)}
        onClose={() => setDeleteModalItem(null)}
        onConfirm={confirmDelete}
        title="Eliminar Atención Médica"
        message={`¿Estás seguro de que deseas eliminar este registro de atención médica correspondiente a ${deleteModalItem?.trabajadorNombre} (${deleteModalItem?.idAtencion})? Esta acción eliminará el registro en la base de datos.`}
      />

      {/* MODAL DE IMPORTACIÓN GENÉRICA MASIVA */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.atencionesMedicas}
        onImportSuccess={(importedRows) => {
          batchUpsertAtencionesMedicas(importedRows as unknown as AtencionMedicaRecord[]);
          addToast({
            type: 'success',
            title: 'Importación Exitosa',
            message: `Se importaron ${importedRows.length} atenciones médicas al sistema.`
          });
        }}
      />
    </div>
  );
};
