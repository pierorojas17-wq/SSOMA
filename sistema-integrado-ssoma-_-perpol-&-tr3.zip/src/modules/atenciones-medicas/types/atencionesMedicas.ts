export * from '../../../types/modules/atenciones';
export type { AccidenteRecord, TrabajadorRecord } from '../../../types/modules';

export type AtencionesTab = 'historial' | 'lineaTiempo' | 'nuevo';

export interface AtencionesMedicasMetricas {
  total: number;
  conDescanso: number;
  diasTotales: number;
  enSeguimiento: number;
  conAlta: number;
  vinculadasAccidente: number;
}
