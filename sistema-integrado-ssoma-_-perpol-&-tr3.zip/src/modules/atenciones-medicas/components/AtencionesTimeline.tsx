import React from 'react';
import { AccidenteRecord, AtencionMedicaRecord } from '../../../types/modules';
import {
  ShieldAlert,
  ExternalLink,
  History,
  Plus,
  AlertOctagon,
  HeartPulse,
  Calendar,
  Eye,
  Edit2,
  Hospital,
  Clock,
  CalendarDays,
  CalendarCheck
} from 'lucide-react';
import { StatusBadge } from '../../../components/common/StatusBadge';

interface AtencionesTimelineProps {
  selectedTimelineCaso: string;
  setSelectedTimelineCaso: (caso: string) => void;
  selectedAccident: AccidenteRecord | undefined;
  atencionesCasoTimeline: AtencionMedicaRecord[];
  metricasCasoTimeline: {
    total: number;
    diasAcumulados: number;
    estadoActual: string;
    proximaCita: string;
  };
  empresaActiva: string;
  accidentes: AccidenteRecord[];
  atencionesMedicas: AtencionMedicaRecord[];
  onNavigateToAccidente: (codigoCaso: string, idAccidente?: string) => void;
  onOpenAddModal: (codigoCaso: string) => void;
  onView: (item: AtencionMedicaRecord) => void;
  onEdit: (item: AtencionMedicaRecord) => void;
}

export const AtencionesTimeline: React.FC<AtencionesTimelineProps> = ({
  selectedTimelineCaso,
  setSelectedTimelineCaso,
  selectedAccident,
  atencionesCasoTimeline,
  metricasCasoTimeline,
  empresaActiva,
  accidentes,
  atencionesMedicas,
  onNavigateToAccidente,
  onOpenAddModal,
  onView,
  onEdit
}) => {
  return (
    <div className="space-y-5">
      {/* Selector de Caso de Accidente */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between shadow-2xs">
        <div className="flex-1 w-full">
          <label className="block text-xs font-bold text-[#0F172A] mb-1.5 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-[#DC2626]" />
            <span>Seleccionar Caso de Accidente de Trabajo (Módulo 1):</span>
          </label>
          <select
            value={selectedTimelineCaso}
            onChange={(e) => setSelectedTimelineCaso(e.target.value)}
            className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] font-medium cursor-pointer"
          >
            <option value="">-- Seleccionar caso de accidente para ver su línea de tiempo --</option>
            {accidentes
              .filter((a) => empresaActiva === 'CONSOLIDADO' || a.empresa === empresaActiva)
              .map((acc, aIdx) => {
                const cantAtenciones = atencionesMedicas.filter(
                  (m) => m.codigoAccidente === acc.codigoCaso || m.idAccidente === acc.id
                ).length;
                return (
                  <option key={`${acc.id || acc.codigoCaso}-${aIdx}`} value={acc.codigoCaso || acc.id}>
                    {acc.codigoCaso} | {acc.fecha} | {acc.trabajadorNombre} | {acc.tipoEvento} ({cantAtenciones} atenciones registradas)
                  </option>
                );
              })}
          </select>
        </div>

        {selectedAccident && (
          <div className="flex items-center gap-2 self-end md:self-center shrink-0">
            <button
              type="button"
              onClick={() => onNavigateToAccidente(selectedAccident.codigoCaso, selectedAccident.id)}
              className="px-3 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-xs font-semibold text-[#DC2626] border border-rose-200 flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <span>Ver en Módulo Accidentes</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {selectedAccident ? (
        <div className="space-y-5">
          {/* Tarjeta de Resumen del Caso y Trabajador */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-2xs space-y-4">
            <div className="flex flex-col sm:row sm:items-center justify-between pb-3 border-b border-[#E2E8F0] gap-2">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-[#DC2626]">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-[#0F172A]">
                      Caso SST: {selectedAccident.codigoCaso}
                    </h3>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        selectedAccident.tipoEvento === 'Accidente incapacitante'
                          ? 'bg-rose-50 text-[#DC2626] border border-rose-200'
                          : 'bg-amber-50 text-[#B45309] border border-amber-200'
                      }`}
                    >
                      {selectedAccident.tipoEvento || 'Accidente de Trabajo'}
                    </span>
                  </div>
                  <p className="text-xs text-[#475569] mt-0.5">
                    Colaborador: <strong className="text-[#0F172A]">{selectedAccident.trabajadorNombre}</strong> (DNI: {selectedAccident.trabajadorDni}) • {selectedAccident.cargo} • Área: {selectedAccident.area}
                  </p>
                </div>
              </div>
              <div className="text-left sm:text-right">
                <span className="text-xs text-[#475569] block font-medium">Ocurrencia del Suceso:</span>
                <span className="text-sm font-bold text-[#0F172A]">
                  {selectedAccident.fecha} {selectedAccident.hora ? `a las ${selectedAccident.hora}` : ''}
                </span>
                <span className="text-[11px] text-[#475569] block">{selectedAccident.lugarExacto || 'Área de operación'}</span>
              </div>
            </div>

            {/* Métricas rápidas del Caso de Accidente */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] flex flex-col justify-between">
                <span className="text-[11px] text-[#475569] font-medium">Atenciones Registradas</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-xl font-bold text-[#0F172A] font-mono">{metricasCasoTimeline.total}</span>
                  <span className="text-[10px] text-[#475569]">atención(es)</span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] flex flex-col justify-between">
                <span className="text-[11px] text-[#475569] font-medium">Descanso Acumulado</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-xl font-bold text-[#DC2626] font-mono">{metricasCasoTimeline.diasAcumulados}</span>
                  <span className="text-[10px] text-[#DC2626]">días en total</span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] flex flex-col justify-between">
                <span className="text-[11px] text-[#475569] font-medium">Estado Clínico</span>
                <div className="mt-1">
                  <span
                    className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                      metricasCasoTimeline.estadoActual === 'Alta / reincorporado'
                        ? 'bg-emerald-50 text-[#047857] border border-emerald-200'
                        : metricasCasoTimeline.estadoActual === 'En seguimiento'
                        ? 'bg-amber-50 text-[#B45309] border border-amber-200'
                        : 'bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1]'
                    }`}
                  >
                    {metricasCasoTimeline.estadoActual}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] flex flex-col justify-between">
                <span className="text-[11px] text-[#475569] font-medium">Próxima Cita / Control</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <CalendarCheck className="w-4 h-4 text-[#0284C7] shrink-0" />
                  <span className="text-xs font-bold text-[#0284C7]">
                    {metricasCasoTimeline.proximaCita || 'Sin cita pendiente'}
                  </span>
                </div>
              </div>
            </div>

            {/* Lesiones y afectaciones reportadas en el accidente */}
            {((selectedAccident.partesCuerpoAfectadas || []).length > 0 ||
              (selectedAccident.lesionReferida || []).length > 0 ||
              selectedAccident.descripcion) && (
              <div className="pt-2 text-xs text-[#475569] border-t border-[#E2E8F0] flex flex-wrap gap-2 items-center">
                <span className="font-semibold text-[#0F172A]">Lesión Inicial SST:</span>
                {(selectedAccident.partesCuerpoAfectadas || []).map((p, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded bg-rose-50 text-[#DC2626] border border-rose-200 text-[10px] font-semibold">
                    {p}
                  </span>
                ))}
                {(selectedAccident.lesionReferida || []).map((l, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded bg-rose-50 text-[#DC2626] border border-rose-200 text-[10px] font-semibold">
                    {l}
                  </span>
                ))}
                {selectedAccident.descripcion && (
                  <span className="text-[#475569] italic block w-full mt-1">
                    "{selectedAccident.descripcion}"
                  </span>
                )}
              </div>
            )}
          </div>

          {/* BARRA SUPERIOR DE ACCIONES */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-xl bg-white border border-[#E2E8F0] shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[#047857]">
                <History className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                  <span>Línea de Tiempo de Atenciones Médicas</span>
                  <span className="px-2 py-0.5 rounded-full bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] text-[10px] font-mono font-bold">
                    {atencionesCasoTimeline.length} Registros
                  </span>
                </h4>
                <p className="text-xs text-[#475569]">
                  Historial evolutivo cronológico: urgencias, citas de control, curaciones y reevaluaciones
                </p>
              </div>
            </div>

            <button
              type="button"
              id="btnAgregarAtencionMedica"
              onClick={() => onOpenAddModal(selectedAccident.codigoCaso)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#047857] hover:bg-[#065F46] text-white text-xs font-bold shadow-2xs transition-all cursor-pointer hover:scale-[1.02] shrink-0 focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
            >
              <Plus className="w-4 h-4" />
              <span>+ Agregar Atención Médica</span>
            </button>
          </div>

          {/* LÍNEA DE TIEMPO VISUAL DINÁMICA */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-6 shadow-2xs">
            <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#E2E8F0]">
              {/* HITO 0: OCURRENCIA DEL ACCIDENTE SST */}
              <div className="relative">
                <div className="absolute -left-6 sm:-left-8 top-1 w-6 h-6 rounded-full bg-rose-50 border-2 border-[#DC2626] flex items-center justify-center text-[#DC2626] shadow-2xs">
                  <AlertOctagon className="w-3.5 h-3.5" />
                </div>
                <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] shadow-2xs space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-rose-100 text-[#DC2626] text-[10px] font-bold border border-rose-200 uppercase tracking-wider">
                        Evento Inicial SST
                      </span>
                      <span className="text-xs font-bold text-[#0F172A]">
                        Ocurrencia del Accidente / Incidente
                      </span>
                    </div>
                    <span className="text-xs font-mono text-[#475569]">
                      {selectedAccident.fecha} {selectedAccident.hora ? `a las ${selectedAccident.hora}` : ''}
                    </span>
                  </div>
                  <p className="text-xs text-[#0F172A]">
                    {selectedAccident.descripcion || 'Registro oficial del accidente laboral en Módulo 1.'}
                  </p>
                  <div className="flex items-center gap-2 text-[11px] text-[#475569]">
                    <span>Lugar: <strong className="text-[#0F172A]">{selectedAccident.lugarExacto}</strong></span>
                    <span>•</span>
                    <span>Responsable: <strong className="text-[#0F172A]">{selectedAccident.responsableArea}</strong></span>
                  </div>
                </div>
              </div>

              {/* LISTA DE ATENCIONES MÉDICAS */}
              {atencionesCasoTimeline.length === 0 ? (
                <div className="relative">
                  <div className="absolute -left-6 sm:-left-8 top-1 w-6 h-6 rounded-full bg-[#F1F5F9] border-2 border-[#CBD5E1] flex items-center justify-center text-[#475569]">
                    <HeartPulse className="w-3.5 h-3.5" />
                  </div>
                  <div className="p-5 rounded-xl border border-dashed border-[#CBD5E1] text-center space-y-2 bg-[#F8FAFC]">
                    <p className="text-xs font-semibold text-[#0F172A]">
                      Aún no hay atenciones médicas registradas para el caso {selectedAccident.codigoCaso}
                    </p>
                    <p className="text-[11px] text-[#475569]">
                      Haga clic en "+ Agregar Atención Médica" arriba para registrar la atención inicial en tópico o clínica.
                    </p>
                  </div>
                </div>
              ) : (
                atencionesCasoTimeline.map((atn, idx) => {
                  const tieneDescanso = atn.generaDescanso === 'SI';
                  return (
                    <div key={`${atn.id || atn.idAtencion}-${idx}`} className="relative">
                      <div
                        className={`absolute -left-6 sm:-left-8 top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center shadow-2xs ${
                          tieneDescanso
                            ? 'bg-rose-50 border-rose-500 text-[#DC2626]'
                            : 'bg-emerald-50 border-emerald-500 text-[#047857]'
                        }`}
                      >
                        <HeartPulse className="w-3.5 h-3.5" />
                      </div>

                      <div className="p-5 rounded-xl bg-white border border-[#E2E8F0] shadow-2xs space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#E2E8F0]">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-[#047857]">
                              {atn.idAtencion}
                            </span>
                            <StatusBadge status={atn.estado} />
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <div className="text-[#475569] font-medium flex items-center gap-1 font-mono">
                              <Calendar className="w-3.5 h-3.5 text-[#475569]" />
                              <span className="text-[#0F172A] font-semibold">{atn.fechaAtencion}</span>
                              {atn.horaAtencion && <span className="text-[#475569]">a las {atn.horaAtencion}</span>}
                            </div>
                            <div className="flex items-center gap-1 ml-2">
                              <button
                                type="button"
                                onClick={() => onView(atn)}
                                className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                                title="Ver Ficha Clínica Detallada"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => onEdit(atn)}
                                className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569] hover:text-[#047857] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                                title="Editar Atención"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Centro Médico y Tipo de Atención */}
                        <div className="flex flex-wrap items-center gap-3 text-xs">
                          <div className="flex items-center gap-1.5 text-[#0F172A] font-semibold">
                            <Hospital className="w-4 h-4 text-[#0284C7]" />
                            <span className="text-[#475569]">Centro Médico:</span>
                            <span className="text-[#0F172A]">{atn.lugarAtencion}</span>
                          </div>
                          <span className="text-[#CBD5E1]">•</span>
                          <div className="text-[#475569]">
                            Tipo: <span className="text-[#0F172A] font-semibold">{atn.tipoAtencion || 'Atención médica'}</span>
                          </div>
                          {atn.medicoTratante && (
                            <>
                              <span className="text-[#CBD5E1]">•</span>
                              <div className="text-[#475569]">
                                Médico: <span className="text-[#0F172A] font-semibold">{atn.medicoTratante}</span>
                              </div>
                            </>
                          )}
                        </div>

                        {/* Diagnóstico Médico */}
                        <div className="space-y-1">
                          <span className="text-[11px] font-semibold text-[#475569] block">
                            Diagnóstico Clínico / Evolución:
                          </span>
                          <p className="text-xs text-[#0F172A] bg-[#F8FAFC] p-2.5 rounded-lg border border-[#E2E8F0] font-medium">
                            {atn.diagnostico}
                          </p>
                        </div>

                        {/* Tratamiento y Medicamentos si existen */}
                        {(atn.tratamiento || atn.medicamentosPrescritos) && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            {atn.tratamiento && (
                              <div className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0]">
                                <span className="text-[11px] font-semibold text-[#475569] block mb-0.5">
                                  Tratamiento Prescrito:
                                </span>
                                <p className="text-[#0F172A] text-[11px] whitespace-pre-line">{atn.tratamiento}</p>
                              </div>
                            )}
                            {atn.medicamentosPrescritos && (
                              <div className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0]">
                                <span className="text-[11px] font-semibold text-[#475569] block mb-0.5">
                                  Medicamentos e Insumos:
                                </span>
                                <p className="text-[#0F172A] text-[11px] whitespace-pre-line">{atn.medicamentosPrescritos}</p>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Badges de Descanso Médico y Próxima Cita */}
                        <div className="pt-2 border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div className="flex items-center gap-2 flex-wrap">
                            {tieneDescanso ? (
                              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 text-[#DC2626] text-xs font-semibold">
                                <Clock className="w-3.5 h-3.5 text-[#DC2626]" />
                                <span>Descanso Médico: {atn.diasDescanso} día(s)</span>
                                <span className="text-[10px] text-[#DC2626] font-mono">
                                  ({atn.fechaInicioDescanso} al {atn.fechaFinDescanso})
                                </span>
                                {atn.cie10 && (
                                  <span className="ml-1 px-1.5 py-0.2 rounded bg-rose-200 text-[#DC2626] font-mono text-[10px] font-bold">
                                    CIE-10: {atn.cie10}
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-[#475569] text-xs font-medium">Sin descanso médico en esta atención</span>
                            )}
                          </div>
                          {atn.proximaCita && (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-50 border border-sky-200 text-[#0284C7] text-xs font-semibold">
                              <CalendarDays className="w-3.5 h-3.5 text-[#0284C7]" />
                              <span className="text-[#475569]">Próxima Cita / Control:</span>
                              <span className="font-mono text-[#0284C7] font-bold">{atn.proximaCita}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-[#E2E8F0] rounded-2xl p-12 text-center space-y-4 shadow-2xs">
          <div className="w-12 h-12 rounded-2xl bg-[#F1F5F9] border border-[#CBD5E1] flex items-center justify-center text-[#475569] mx-auto">
            <History className="w-6 h-6 text-[#475569]" />
          </div>
          <h3 className="text-base font-bold text-[#0F172A]">Seleccione un Caso de Accidente de Trabajo</h3>
          <p className="text-xs text-[#475569] max-w-md mx-auto">
            Para visualizar la línea de tiempo completa y agregar atenciones médicas evolutivas (urgencias, curaciones, controles y descansos), elija un caso en el selector superior.
          </p>
        </div>
      )}
    </div>
  );
};
