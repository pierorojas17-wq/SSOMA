import React from 'react';
import { AccidenteRecord } from '../../../types/modules';
import { Plus, X, AlertTriangle, Hospital, Clock, CalendarDays, Save } from 'lucide-react';

interface AtencionesAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAccident: AccidenteRecord | undefined;
  modalFormData: {
    codigoCaso: string;
    fechaAtencion: string;
    horaAtencion: string;
    centroMedico: string;
    diagnostico: string;
    tipoAtencion: string;
    generaDescanso: 'SI' | 'NO';
    tipoCertificadoDescanso: string;
    nroCertificadoMedico: string;
    cie10: string;
    fechaInicioDescanso: string;
    fechaFinDescanso: string;
    diasDescanso: number;
    proximaCita: string;
    tratamiento: string;
    medicamentosPrescritos: string;
    medicoTratante: string;
    estado: string;
  };
  setModalFormData: React.Dispatch<React.SetStateAction<{
    codigoCaso: string;
    fechaAtencion: string;
    horaAtencion: string;
    centroMedico: string;
    diagnostico: string;
    tipoAtencion: string;
    generaDescanso: 'SI' | 'NO';
    tipoCertificadoDescanso: string;
    nroCertificadoMedico: string;
    cie10: string;
    fechaInicioDescanso: string;
    fechaFinDescanso: string;
    diasDescanso: number;
    proximaCita: string;
    tratamiento: string;
    medicamentosPrescritos: string;
    medicoTratante: string;
    estado: string;
  }>>;
  modalFormError: string | null;
  isModalSaving: boolean;
  onSubmit: (e: React.FormEvent) => void;
}

export const AtencionesAddModal: React.FC<AtencionesAddModalProps> = ({
  isOpen,
  onClose,
  selectedAccident,
  modalFormData,
  setModalFormData,
  modalFormError,
  isModalSaving,
  onSubmit
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto cursor-pointer"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl text-slate-800 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header del Modal */}
        <div className="sticky top-0 z-10 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-teal-50 border border-teal-200 text-teal-700">
              <Plus className="w-5 h-5 text-teal-600" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                <span>Agregar Nueva Atención Médica</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-200 text-[10px] font-mono font-bold">
                  Caso: {modalFormData.codigoCaso}
                </span>
              </h3>
              <p className="text-[11px] text-[#475569] font-medium">
                Registrar cita de urgencia, control evolutivo, curación o reevaluación para este accidente
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            title="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulario del Modal */}
        <form onSubmit={onSubmit} className="p-6 space-y-4 text-xs">
          <input
            type="hidden"
            id="modalHiddenCodigoCaso"
            name="codigoCaso"
            value={modalFormData.codigoCaso}
          />

          {modalFormError && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{modalFormError}</span>
            </div>
          )}

          {/* Ficha Resumen del Accidente Vinculado */}
          {selectedAccident && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 font-medium">Trabajador Lesionado: </span>
                <strong className="text-slate-900 font-bold">{selectedAccident.trabajadorNombre}</strong>
                <span className="text-slate-500 font-mono ml-1">({selectedAccident.trabajadorDni})</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Puesto / Área: </span>
                <span className="text-slate-800">{selectedAccident.cargo} • {selectedAccident.area}{selectedAccident.lugarExacto ? ` (${selectedAccident.lugarExacto})` : ''}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Fecha Accidente: </span>
                <span className="text-slate-900 font-semibold font-mono">{selectedAccident.fecha}</span>
              </div>
            </div>
          )}

          {/* Campo 1: Fecha y Hora de Atención */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Fecha de Atención Médica <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              <input
                type="date"
                required
                id="modalFechaAtencion"
                name="fechaAtencion"
                value={modalFormData.fechaAtencion}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, fechaAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Hora de Atención
              </label>
              <input
                type="time"
                id="modalHoraAtencion"
                name="horaAtencion"
                value={modalFormData.horaAtencion}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, horaAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] font-medium"
              />
            </div>
          </div>

          {/* Campo 2: Centro Médico / Lugar de Atención */}
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1 flex items-center justify-between">
              <span>
                Centro Médico / Lugar de Atención <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </span>
              <span className="text-[10px] text-[#475569] font-normal">Clínica SCTR, Policlínico o Tópico</span>
            </label>
            <div className="relative">
              <Hospital className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                required
                id="modalCentroMedico"
                name="centroMedico"
                list="lista-centros-medicos"
                placeholder="Escribe o selecciona (ej: Tópico Central de Planta, Clínica San Gabriel SCTR...)"
                value={modalFormData.centroMedico}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, centroMedico: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg pl-9 pr-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] font-medium"
              />
              <datalist id="lista-centros-medicos">
                <option value="Tópico Central de Planta (Tópico SSOMA)" />
                <option value="Clínica San Gabriel SCTR" />
                <option value="Hospital EsSalud Aurelio Díaz Ufano" />
                <option value="Policlínico Prevención y Salud SSOMA" />
                <option value="Centro Médico Bellavista SCTR" />
                <option value="Clínica Internacional (Red SCTR)" />
                <option value="Hospital Nacional Hipólito Unanue" />
              </datalist>
            </div>
          </div>

          {/* Campo 3: Diagnóstico */}
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1 flex items-center justify-between">
              <span>
                Diagnóstico Médico / Juicio Clínico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </span>
              <span className="text-[10px] text-[#475569] font-normal">Evaluación de la lesión o estado físico</span>
            </label>
            <textarea
              required
              rows={2}
              id="modalDiagnostico"
              name="diagnostico"
              placeholder="Diagnóstico médico, hallazgos clínicos, grado de evolución de la lesión, herida o traumatismo..."
              value={modalFormData.diagnostico}
              onChange={(e) => setModalFormData((prev) => ({ ...prev, diagnostico: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] leading-relaxed font-medium"
            />
          </div>

          {/* Campo 4: Días de descanso médico */}
          <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-[#047857]" />
                <span>Días de Descanso Médico (Reposo Laboral)</span>
              </span>
              <div className="flex items-center gap-2">
                <label className="text-[11px] text-[#475569] font-medium">¿Genera Descanso?</label>
                <select
                  id="modalGeneraDescanso"
                  name="generaDescanso"
                  value={modalFormData.generaDescanso}
                  onChange={(e) => {
                    const val = e.target.value as 'SI' | 'NO';
                    setModalFormData((prev) => ({
                      ...prev,
                      generaDescanso: val,
                      fechaInicioDescanso: val === 'SI' ? (prev.fechaInicioDescanso || prev.fechaAtencion) : '',
                      fechaFinDescanso: val === 'SI' ? (prev.fechaFinDescanso || prev.fechaAtencion) : '',
                      diasDescanso: val === 'SI' ? (prev.diasDescanso || 1) : 0
                    }));
                  }}
                  className="bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-xs text-[#0F172A] font-bold focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                >
                  <option value="NO">NO</option>
                  <option value="SI">SÍ</option>
                </select>
              </div>
            </div>

            {modalFormData.generaDescanso === 'SI' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 animate-in fade-in">
                <div>
                  <label className="block text-[11px] text-[#475569] font-semibold mb-1">
                    Fecha Inicio Descanso <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    id="modalFechaInicioDescanso"
                    name="fechaInicioDescanso"
                    value={modalFormData.fechaInicioDescanso}
                    onChange={(e) => setModalFormData((prev) => ({ ...prev, fechaInicioDescanso: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#475569] font-semibold mb-1">
                    Fecha Fin Descanso <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    id="modalFechaFinDescanso"
                    name="fechaFinDescanso"
                    value={modalFormData.fechaFinDescanso}
                    onChange={(e) => setModalFormData((prev) => ({ ...prev, fechaFinDescanso: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded-lg px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#475569] font-semibold mb-1">
                    Días de Descanso Calculados
                  </label>
                  <div className="px-3 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold font-mono flex items-center justify-between">
                    <span>{modalFormData.diasDescanso} día(s)</span>
                    <span className="text-[10px] text-rose-600 font-normal">Inclusivo</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Campo 5: Próxima cita y Estado */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1 flex items-center gap-1.5">
                <CalendarDays className="w-3.5 h-3.5 text-[#047857]" />
                <span>Fecha de la Próxima Cita / Control</span>
              </label>
              <input
                type="date"
                id="modalProximaCita"
                name="proximaCita"
                value={modalFormData.proximaCita}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, proximaCita: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Estado Actual del Colaborador
              </label>
              <select
                id="modalEstado"
                name="estado"
                value={modalFormData.estado}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, estado: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981] font-bold"
              >
                <option value="En seguimiento">En seguimiento / Tratamiento activo</option>
                <option value="Alta / reincorporado">Alta médica / Reincorporado a labores</option>
                <option value="Alta con restricciones">Alta médica con restricciones físicas</option>
                <option value="Derivado a especialista">Derivado a especialista / Centro SCTR</option>
                <option value="Cerrado">Caso cerrado</option>
              </select>
            </div>
          </div>

          {/* Tratamiento y Medicamentos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-[11px] font-semibold text-[#475569] mb-1">
                Tratamiento y Procedimientos Realizados
              </label>
              <textarea
                rows={2}
                id="modalTratamiento"
                name="tratamiento"
                placeholder="Curación de herida, vendaje, sutura, fisioterapia..."
                value={modalFormData.tratamiento}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, tratamiento: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-[#475569] mb-1">
                Medicamentos e Insumos Prescritos
              </label>
              <textarea
                rows={2}
                id="modalMedicamentosPrescritos"
                name="medicamentosPrescritos"
                placeholder="Paracetamol, Ibuprofeno, gasas estériles, apósitos..."
                value={modalFormData.medicamentosPrescritos}
                onChange={(e) => setModalFormData((prev) => ({ ...prev, medicamentosPrescritos: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
              />
            </div>
          </div>

          {/* Botones de acción del Modal */}
          <div className="pt-4 border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 border border-[#CBD5E1] transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isModalSaving}
              className="flex items-center gap-2 px-6 py-2 rounded-xl bg-[#047857] hover:bg-[#065F46] disabled:opacity-50 text-xs font-bold text-white shadow-2xs transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isModalSaving ? 'Guardando en Apps Script...' : 'Guardar Atención Médica'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
