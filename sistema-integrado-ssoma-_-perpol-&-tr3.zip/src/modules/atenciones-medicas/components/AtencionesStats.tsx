import React from 'react';
import { HeartPulse, Clock, Activity, CheckCircle2, Stethoscope } from 'lucide-react';
import { AtencionesMedicasMetricas } from '../types/atencionesMedicas';

interface AtencionesStatsProps {
  metricas: AtencionesMedicasMetricas;
}

export const AtencionesStats: React.FC<AtencionesStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Total Atenciones</span>
          <HeartPulse className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-2xl font-bold text-[#0F172A] mt-2">{metricas.total}</div>
        <div className="text-[11px] text-[#475569] mt-1">Registros clínicos</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Con Descanso</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626]"></span>
        </div>
        <div className="text-2xl font-bold text-[#DC2626] mt-2">{metricas.conDescanso}</div>
        <div className="text-[11px] text-[#475569] mt-1">Descanso médico</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Días D.M. Totales</span>
          <Clock className="w-4 h-4 text-[#DC2626]" />
        </div>
        <div className="text-2xl font-bold text-[#DC2626] mt-2">{metricas.diasTotales}</div>
        <div className="text-[11px] text-[#475569] mt-1">Jornadas acumuladas</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>En Seguimiento</span>
          <Activity className="w-4 h-4 text-[#D97706]" />
        </div>
        <div className="text-2xl font-bold text-[#D97706] mt-2">{metricas.enSeguimiento}</div>
        <div className="text-[11px] text-[#475569] mt-1">Tratamiento activo</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Alta / Reincorporado</span>
          <CheckCircle2 className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-2xl font-bold text-[#047857] mt-2">{metricas.conAlta}</div>
        <div className="text-[11px] text-[#475569] mt-1">Aptos para trabajar</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Vinculadas SST</span>
          <Stethoscope className="w-4 h-4 text-[#0284C7]" />
        </div>
        <div className="text-2xl font-bold text-[#0284C7] mt-2">{metricas.vinculadasAccidente}</div>
        <div className="text-[11px] text-[#475569] mt-1">Derivadas de accidentes</div>
      </div>
    </div>
  );
};
