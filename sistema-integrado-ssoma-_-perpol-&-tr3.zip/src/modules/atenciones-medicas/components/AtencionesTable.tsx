import React from 'react';
import { AtencionMedicaRecord } from '../../../types/modules';
import { TablePagination } from '../../../components/common/TablePagination';
import { TableEmptyState } from '../../../components/common/TableEmptyState';
import { StatusBadge } from '../../../components/common/StatusBadge';
import {
  ExternalLink,
  History,
  Edit2,
  Eye,
  Trash2
} from 'lucide-react';

interface AtencionesTableProps {
  items: AtencionMedicaRecord[];
  searchTerm: string;
  estadoFilter: string;
  descansoFilter: string;
  accidenteFilter: string;
  areaFilter?: string;
  currentPage: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  onView: (item: AtencionMedicaRecord) => void;
  onEdit: (item: AtencionMedicaRecord) => void;
  onDelete: (item: AtencionMedicaRecord) => void;
  onNavigateToAccidente: (codigoRef: string, idAccidente?: string) => void;
  onOpenTimeline: (codigoRef: string) => void;
  onClearFilters: () => void;
  onNewRecord: () => void;
}

export const AtencionesTable: React.FC<AtencionesTableProps> = ({
  items,
  searchTerm,
  estadoFilter,
  descansoFilter,
  accidenteFilter,
  areaFilter = 'TODOS',
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  onView,
  onEdit,
  onDelete,
  onNavigateToAccidente,
  onOpenTimeline,
  onClearFilters,
  onNewRecord
}) => {
  const hasActiveFilters =
    Boolean(searchTerm) ||
    estadoFilter !== 'TODOS' ||
    descansoFilter !== 'TODOS' ||
    accidenteFilter !== 'TODOS' ||
    areaFilter !== 'TODOS';

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1150px] text-left text-xs text-slate-700">
          <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-semibold border-b border-slate-200 tracking-wider">
            <tr>
              <th className="px-4 py-3 w-28 whitespace-nowrap">ID Atención</th>
              <th className="px-4 py-3 w-32 whitespace-nowrap">Fecha / Hora</th>
              <th className="px-4 py-3 w-28 whitespace-nowrap">ID Accidente</th>
              <th className="px-4 py-3 min-w-[180px]">Trabajador</th>
              <th className="px-4 py-3 w-32 whitespace-nowrap">Lugar Atención</th>
              <th className="px-4 py-3 min-w-[180px]">Diagnóstico Médico</th>
              <th className="px-4 py-3 w-24 text-center whitespace-nowrap">Descanso</th>
              <th className="px-4 py-3 w-16 text-center whitespace-nowrap">Días</th>
              <th className="px-4 py-3 w-28 whitespace-nowrap">Próx. Cita</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Estado</th>
              <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.length === 0 ? (
              <TableEmptyState
                isTableRow
                colSpan={11}
                title="No se encontraron atenciones médicas"
                description={
                  searchTerm
                    ? `No hay atenciones que coincidan con "${searchTerm}".`
                    : 'No hay registros de atenciones médicas con los filtros aplicados.'
                }
                actionLabel={hasActiveFilters ? 'Limpiar filtros' : 'Nueva Atención'}
                actionIcon={hasActiveFilters ? 'clear' : 'plus'}
                onAction={() => {
                  if (hasActiveFilters) {
                    onClearFilters();
                  } else {
                    onNewRecord();
                  }
                }}
              />
            ) : (
              items.map((item, idx) => {
                const tieneAccidente = Boolean(item.codigoAccidente || item.idAccidente);
                const codigoRef = item.codigoAccidente || item.idAccidente || '';
                return (
                  <tr key={`${item.id || item.idAtencion}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-semibold text-teal-700 whitespace-nowrap">
                      {item.idAtencion}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="text-slate-800 font-medium">{item.fechaAtencion}</div>
                      <div className="text-[11px] text-slate-500">{item.horaAtencion}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {tieneAccidente ? (
                        <button
                          type="button"
                          onClick={() => onNavigateToAccidente(codigoRef, item.idAccidente)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-colors"
                          title="Ver Evento SST en Accidentes de Trabajo"
                        >
                          <span>{codigoRef}</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500 font-medium italic">Directa</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-slate-800 font-medium">{item.trabajadorNombre}</div>
                      <div className="text-[11px] text-slate-500">
                        DNI / C.E.: {item.trabajadorDni} • {item.puesto}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-slate-700">
                      {item.lugarAtencion}
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      <div className="text-slate-700 truncate" title={item.diagnostico}>
                        {item.diagnostico}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {item.generaDescanso === 'SI' ? (
                        <div className="text-[11px]">
                          <span className="font-bold text-rose-600">SÍ</span>
                          <div className="text-[10px] text-slate-500">
                            {item.fechaInicioDescanso} al {item.fechaFinDescanso}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-500 font-medium">NO</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-bold">
                      {item.diasDescanso > 0 ? (
                        <span className="text-rose-600">{item.diasDescanso} d.</span>
                      ) : (
                        <span className="text-slate-500 font-medium">0</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-[11px] text-slate-600">
                      {item.proximaCita || '-'}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={item.estado} />
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {tieneAccidente && (
                          <button
                            type="button"
                            onClick={() => onOpenTimeline(codigoRef)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-sky-600 transition-colors cursor-pointer"
                            title="Ver Línea de Tiempo del Caso"
                            aria-label={`Ver línea de tiempo del caso ${codigoRef}`}
                          >
                            <History className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                          title="Editar Atención"
                          aria-label={`Editar atención médica ${item.idAtencion}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                          title="Ver Ficha Clínica"
                          aria-label={`Ver ficha clínica de la atención ${item.idAtencion}`}
                        >
                          <Eye className="w-4 h-4" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete(item)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Eliminar"
                          aria-label={`Eliminar atención médica ${item.idAtencion}`}
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <TablePagination
        currentPage={currentPage}
        totalItems={totalItems}
        pageSize={pageSize}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        pageSizeOptions={[10, 25, 50, 100]}
      />
    </div>
  );
};
