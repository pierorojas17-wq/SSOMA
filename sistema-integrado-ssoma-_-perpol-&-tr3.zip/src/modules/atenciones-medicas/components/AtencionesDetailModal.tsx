import React from 'react';
import { AtencionMedicaRecord } from '../../../types/modules';
import { HeartPulse, X, ShieldAlert, ExternalLink, CalendarDays } from 'lucide-react';

interface AtencionesDetailModalProps {
  item: AtencionMedicaRecord | null;
  onClose: () => void;
  onNavigateToAccidente: (codigoCaso: string, idAccidente?: string) => void;
}

export const AtencionesDetailModal: React.FC<AtencionesDetailModalProps> = ({
  item,
  onClose,
  onNavigateToAccidente
}) => {
  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 pr-2">
            <div className="w-9 h-9 rounded-lg bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center shrink-0">
              <HeartPulse className="w-5 h-5 text-teal-600" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-[#0F172A] flex items-center gap-2 truncate">
                <span>Ficha de Atención Médica</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-teal-100 text-teal-800 border border-teal-200 font-bold shrink-0">
                  {item.idAtencion}
                </span>
              </h3>
              <p className="text-[11px] text-[#475569] font-medium truncate">
                Expediente clínico individual e historial asistencial de salud en el trabajo
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200 active:bg-slate-300 transition-colors cursor-pointer shrink-0"
            title="Cerrar ficha (Esc)"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Contenido con scroll */}
        <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Fecha y Hora</span>
              <span className="text-slate-900 font-semibold font-mono">
                {item.fechaAtencion} <span className="text-slate-500 font-normal">({item.horaAtencion || '09:00'})</span>
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Empresa</span>
              <span className="text-slate-900 font-bold">{item.empresa}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Colaborador</span>
              <span className="text-slate-900 font-bold block truncate">{item.trabajadorNombre}</span>
              <span className="text-[10px] text-slate-500 font-mono">DNI: {item.trabajadorDni}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Estado Clínico</span>
              <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                {item.estado}
              </span>
            </div>
          </div>

          {/* Puesto, Área y Lugar Físico */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold block">Puesto / Cargo</span>
              <span className="text-slate-800 font-medium">{item.puesto || 'No especificado'}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold block">Área Operativa</span>
              <span className="text-slate-800 font-medium">{item.area || 'No especificada'}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold block">Lugar Físico Específico</span>
              <span className="text-slate-800 font-medium">{item.lugarEspecifico || item.lugarAccidente || 'General'}</span>
            </div>
          </div>

          {/* Ficha Resumen del Evento SST si está vinculado */}
          {item.codigoAccidente && (
            <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200 space-y-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-rose-200">
                <span className="font-bold text-rose-900 flex items-center gap-1.5 text-xs">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  Caso SST Vinculado: {item.codigoAccidente}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateToAccidente(item.codigoAccidente!, item.idAccidente);
                  }}
                  className="text-[11px] text-rose-700 hover:text-rose-900 hover:underline flex items-center gap-1 font-bold cursor-pointer"
                >
                  <span>Ver Evento en Accidentes</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500 block">Fecha Suceso:</span>
                  <span className="text-slate-900 font-semibold font-mono">
                    {item.fechaAccidente || '-'} {item.horaAccidente ? `(${item.horaAccidente})` : ''}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Tipo de Evento SST:</span>
                  <span className="text-amber-800 font-semibold">{item.tipoEvento || 'Accidente de Trabajo'}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block">Lugar del Suceso:</span>
                  <span className="text-slate-800 font-medium">{item.lugarAccidente || 'Área de operación'}</span>
                </div>
              </div>
              {((item.partesCuerpoAfectadas || []).length > 0 || (item.lesionReferida || []).length > 0) && (
                <div className="pt-2 border-t border-rose-200 grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-600 block mb-1 font-semibold">Partes Afectadas:</span>
                    <div className="flex flex-wrap gap-1">
                      {(item.partesCuerpoAfectadas || []).map((p, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 border border-rose-200 text-[10px] font-medium">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-600 block mb-1 font-semibold">Lesión Referida:</span>
                    <div className="flex flex-wrap gap-1">
                      {(item.lesionReferida || []).map((l, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 border border-rose-200 text-[10px] font-medium">
                          {l}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {item.descripcionAccidente && (
                <div className="pt-2 border-t border-rose-200 text-[11px]">
                  <span className="text-slate-600 block mb-0.5 font-semibold">Descripción del suceso SST:</span>
                  <p className="text-slate-800 italic bg-white p-2.5 rounded-lg border border-rose-200">
                    "{item.descripcionAccidente}"
                  </p>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-bold block mb-0.5 text-[10px] uppercase">Tipo de Atención</span>
              <div className="text-slate-900 font-semibold">{item.tipoAtencion || 'Primeros auxilios'}</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-bold block mb-0.5 text-[10px] uppercase">Lugar de Atención</span>
              <div className="text-slate-900 font-semibold">{item.lugarAtencion}</div>
            </div>
          </div>

          <div>
            <span className="text-slate-700 font-bold block mb-1 text-[11px] uppercase tracking-wider">
              Diagnóstico Clínico / Juicio Médico
            </span>
            <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-900 font-semibold leading-relaxed">
              {item.diagnostico}
            </p>
          </div>

          {item.tratamiento && (
            <div>
              <span className="text-slate-700 font-bold block mb-1 text-[11px] uppercase tracking-wider">
                Tratamiento y Procedimientos Realizados
              </span>
              <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 whitespace-pre-line leading-relaxed">
                {item.tratamiento}
              </p>
            </div>
          )}

          {item.medicamentosPrescritos && (
            <div>
              <span className="text-slate-700 font-bold block mb-1 text-[11px] uppercase tracking-wider">
                Medicamentos e Insumos Administrados
              </span>
              <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 whitespace-pre-line leading-relaxed">
                {item.medicamentosPrescritos}
              </p>
            </div>
          )}

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
              <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                <CalendarDays className="w-4 h-4 text-teal-600" />
                Descanso Médico y Reposo Ocupacional
              </span>
              <span className="font-bold text-xs">
                {item.generaDescanso === 'SI' ? (
                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200 font-bold text-[11px]">
                    {item.diasDescanso} Días Otorgados
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[11px] font-semibold">
                    Sin descanso médico
                  </span>
                )}
              </span>
            </div>

            {item.generaDescanso === 'SI' && (
              <div className="grid grid-cols-2 gap-2.5 text-[11px] pt-1">
                <div>
                  <span className="text-slate-500 font-semibold block">Período de Descanso:</span>
                  <div className="text-slate-900 font-bold font-mono">
                    {item.fechaInicioDescanso} al {item.fechaFinDescanso}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 font-semibold block">Tipo de Certificado:</span>
                  <div className="text-slate-800 font-medium">{item.tipoCertificadoDescanso || 'Descanso SCTR'}</div>
                </div>
                {item.nroCertificadoMedico && (
                  <div>
                    <span className="text-slate-500 font-semibold block">N° Certificado / CITT:</span>
                    <div className="text-slate-900 font-mono font-semibold">{item.nroCertificadoMedico}</div>
                  </div>
                )}
                {item.cie10 && (
                  <div>
                    <span className="text-slate-500 font-semibold block">Código CIE-10:</span>
                    <div className="text-slate-900 font-mono font-bold">{item.cie10}</div>
                  </div>
                )}
                {item.restriccionesLaborales && (
                  <div className="col-span-2 pt-2 border-t border-slate-200">
                    <span className="text-slate-500 font-semibold block">Restricciones al Reincorporarse:</span>
                    <div className="text-amber-800 font-medium">{item.restriccionesLaborales}</div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-bold block mb-0.5 text-[10px] uppercase">Profesional Tratante</span>
              <div className="text-slate-800 font-semibold">{item.medicoTratante || 'No especificado'}</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-bold block mb-0.5 text-[10px] uppercase">Próxima Cita de Control</span>
              <div className="text-slate-800 font-semibold">{item.proximaCita || 'Sin cita programada'}</div>
            </div>
          </div>

          {item.observaciones && (
            <div>
              <span className="text-slate-700 font-bold block mb-1 text-[11px] uppercase tracking-wider">
                Indicaciones / Observaciones
              </span>
              <p className="text-slate-700 text-xs bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                {item.observaciones}
              </p>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono">ID: {item.id}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 active:bg-slate-400 border border-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer shadow-xs"
          >
            Cerrar Ficha
          </button>
        </div>
      </div>
    </div>
  );
};
