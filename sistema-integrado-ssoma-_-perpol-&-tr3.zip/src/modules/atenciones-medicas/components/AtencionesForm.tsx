import React from 'react';
import { AccidenteRecord, AtencionMedicaRecord, TrabajadorRecord } from '../../../types/modules';
import { AREAS_EMPRESA, LUGARES_ESPECIFICOS } from '../../../utils/ssomaCatalogs';
import {
  HeartPulse,
  ShieldAlert,
  AlertTriangle,
  X,
  ExternalLink,
  User,
  Hospital,
  Sparkles,
  CalendarDays,
  Save
} from 'lucide-react';

interface AtencionesFormProps {
  formData: Partial<AtencionMedicaRecord>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<AtencionMedicaRecord>>>;
  editingId: string | null;
  formError: string | null;
  isSubmitting: boolean;
  empresaActiva: string;
  accidentes: AccidenteRecord[];
  trabajadores: TrabajadorRecord[];
  trabajadoresFiltrados: TrabajadorRecord[];
  workerSearchTerm: string;
  setWorkerSearchTerm: (term: string) => void;
  isWorkerDropdownOpen: boolean;
  setIsWorkerDropdownOpen: (open: boolean) => void;
  onSelectAccidente: (id: string) => void;
  onSelectTrabajador: (trabajador: TrabajadorRecord) => void;
  onNavigateToAccidente: (codigoCaso: string, idAccidente?: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
}

export const AtencionesForm: React.FC<AtencionesFormProps> = ({
  formData,
  setFormData,
  editingId,
  formError,
  isSubmitting,
  empresaActiva,
  accidentes,
  trabajadores,
  trabajadoresFiltrados,
  workerSearchTerm,
  setWorkerSearchTerm,
  isWorkerDropdownOpen,
  setIsWorkerDropdownOpen,
  onSelectAccidente,
  onSelectTrabajador,
  onNavigateToAccidente,
  onSubmit,
  onCancel
}) => {
  return (
    <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-2xs">
      <div className="flex items-center justify-between pb-4 border-b border-[#E2E8F0] mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-[#047857]">
            <HeartPulse className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#0F172A]">
              {editingId ? `Edición de Atención Médica ${editingId}` : 'Registro Oficial de Atención Médica / Primeros Auxilios'}
            </h3>
            <p className="text-xs text-[#475569]">
              Módulo independiente de salud ocupacional — Diagnóstico clínico, descansos y citas médicas
            </p>
          </div>
        </div>
        {formData.codigoAccidente && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-[#DC2626] text-xs font-semibold">
            <ShieldAlert className="w-4 h-4 text-[#DC2626]" />
            <span>Vinculado al Caso SST: {formData.codigoAccidente}</span>
          </div>
        )}
      </div>

      <form onSubmit={onSubmit} className="space-y-5">
        {formError && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-[#DC2626] text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-[#DC2626]" />
            <span>{formError}</span>
          </div>
        )}

        {/* SECCIÓN 1: VINCULACIÓN CON ACCIDENTE DE TRABAJO */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#DC2626]" />
              <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
                1. Vinculación con Caso de Accidente / Incidente SST (Herencia Automática)
              </span>
            </div>
            {formData.codigoAccidente && (
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-rose-50 text-[#DC2626] border border-rose-200 font-mono font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#DC2626] animate-pulse"></span>
                Vinculado: {formData.codigoAccidente}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-[11px] text-[#0F172A] mb-1 font-semibold">
                Seleccionar Caso Registrado en Accidentes de Trabajo:
              </label>
              <select
                value={formData.idAccidente || formData.codigoAccidente || ''}
                onChange={(e) => onSelectAccidente(e.target.value)}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              >
                <option value="">-- Atención médica independiente / Sin accidente registrado --</option>
                {accidentes
                  .filter((a) => empresaActiva === 'CONSOLIDADO' || a.empresa === empresaActiva)
                  .map((acc, aIdx) => (
                    <option key={`${acc.id || acc.codigoCaso}-${aIdx}`} value={acc.id}>
                      {acc.codigoCaso} | {acc.fecha} | {acc.trabajadorNombre} | {acc.tipoEvento} {acc.necesidadAtencion === 'SI' ? '⚡ (Requiere Atención)' : ''}
                    </option>
                  ))}
              </select>
            </div>

            {formData.codigoAccidente && (
              <div className="flex items-end">
                <button
                  type="button"
                  onClick={() => onSelectAccidente('')}
                  className="w-full py-2 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 text-[#DC2626] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-rose-200 cursor-pointer shadow-2xs focus-visible:ring-2 focus-visible:ring-[#10B981]"
                >
                  <X className="w-3.5 h-3.5 text-[#DC2626]" />
                  <span>Desvincular Accidente</span>
                </button>
              </div>
            )}
          </div>

          {/* Ficha Resumen de Datos Heredados del Accidente */}
          {formData.codigoAccidente && (
            <div className="p-3.5 rounded-lg bg-white border border-[#E2E8F0] space-y-2.5 text-xs shadow-2xs">
              <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
                <span className="font-bold text-[#DC2626] flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-[#DC2626]" />
                  Datos Heredados del Evento SST: {formData.codigoAccidente}
                </span>
                <button
                  type="button"
                  onClick={() => onNavigateToAccidente(formData.codigoAccidente!, formData.idAccidente)}
                  className="text-[11px] text-[#0284C7] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                >
                  <span>Ver Ficha en Módulo Accidentes</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div>
                  <span className="text-[#475569] block">Fecha del Evento:</span>
                  <span className="text-[#0F172A] font-mono font-semibold">{formData.fechaAccidente || '-'}</span>
                </div>
                <div>
                  <span className="text-[#475569] block">Tipo Evento SST:</span>
                  <span className="text-[#D97706] font-semibold">{formData.tipoEvento || 'Accidente'}</span>
                </div>
                <div className="sm:col-span-2">
                  <span className="text-[#475569] block">Lugar del Evento:</span>
                  <span className="text-[#0F172A] font-semibold">{formData.lugarAccidente || '-'}</span>
                </div>
              </div>

              {((formData.partesCuerpoAfectadas || []).length > 0 || (formData.lesionReferida || []).length > 0) && (
                <div className="pt-2 border-t border-[#E2E8F0] grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[#475569] block mb-1 font-semibold">Partes del cuerpo afectadas:</span>
                    <div className="flex flex-wrap gap-1">
                      {(formData.partesCuerpoAfectadas || []).map((p, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-rose-50 text-[#DC2626] border border-rose-200 text-[10px] font-semibold">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-[#475569] block mb-1 font-semibold">Lesión referida:</span>
                    <div className="flex flex-wrap gap-1">
                      {(formData.lesionReferida || []).map((l, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-rose-50 text-[#DC2626] border border-rose-200 text-[10px] font-semibold">
                          {l}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {formData.descripcionAccidente && (
                <div className="pt-2 border-t border-[#E2E8F0] text-[11px]">
                  <span className="text-[#475569] font-medium block mb-0.5">Descripción circunstanciada del evento SST:</span>
                  <p className="text-[#0F172A] italic bg-[#F8FAFC] p-2.5 rounded border border-[#E2E8F0]">
                    "{formData.descripcionAccidente}"
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* SECCIÓN 2: DATOS DE LA ATENCIÓN Y COLABORADOR ATENDIDO */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-[#047857]" />
              <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
                2. Datos de la Atención y Colaborador Atendido
              </span>
            </div>
            {formData.trabajadorNombre && (
              <span className="text-[11px] text-[#047857] font-mono font-semibold">DNI / C.E.: {formData.trabajadorDni}</span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">Empresa *</label>
              <select
                value={formData.empresa}
                onChange={(e) => setFormData((prev) => ({ ...prev, empresa: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              >
                <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
                <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">Fecha de Atención *</label>
              <input
                type="date"
                required
                value={formData.fechaAtencion}
                onChange={(e) => setFormData((prev) => ({ ...prev, fechaAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">Hora de Atención *</label>
              <input
                type="time"
                required
                value={formData.horaAtencion}
                onChange={(e) => setFormData((prev) => ({ ...prev, horaAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">Estado de la Atención *</label>
              <select
                value={formData.estado}
                onChange={(e) => setFormData((prev) => ({ ...prev, estado: e.target.value as any }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] font-bold"
              >
                <option value="En seguimiento">En seguimiento</option>
                <option value="Alta / reincorporado">Alta / reincorporado</option>
                <option value="Alta con restricciones">Alta con restricciones</option>
                <option value="Derivado a especialista">Derivado a especialista / SCTR</option>
                <option value="Cerrado">Cerrado</option>
              </select>
            </div>
          </div>

          {/* Autocompletado del Colaborador */}
          <div className="space-y-2 pt-1">
            <label className="block text-[11px] font-semibold text-[#0F172A]">
              Buscar Colaborador (Base de Trabajadores Activos) *
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Escriba el nombre o DNI del trabajador..."
                value={workerSearchTerm}
                onChange={(e) => {
                  setWorkerSearchTerm(e.target.value);
                  setIsWorkerDropdownOpen(true);
                }}
                onFocus={() => setIsWorkerDropdownOpen(true)}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
              {isWorkerDropdownOpen && (
                <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-[#CBD5E1] rounded-lg shadow-xl z-20 divide-y divide-[#E2E8F0]">
                  {trabajadoresFiltrados.length === 0 ? (
                    <div className="p-2.5 text-xs text-[#475569] text-center">
                      No se encontraron trabajadores en {formData.empresa}
                    </div>
                  ) : (
                    trabajadoresFiltrados.map((t, idx) => (
                      <button
                        key={`${t.id || t.dni}-${t.empresa || ''}-${idx}`}
                        type="button"
                        onClick={() => onSelectTrabajador(t)}
                        className="w-full p-2.5 text-left text-xs hover:bg-[#F1F5F9] transition-colors flex items-center justify-between cursor-pointer"
                      >
                        <div>
                          <div className="font-semibold text-[#0F172A]">{t.apellidosNombres}</div>
                          <div className="text-[11px] text-[#475569]">
                            DNI: {t.dni} • {t.puesto} • {t.area}
                          </div>
                        </div>
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] font-semibold">
                          {t.empresa}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
              <div>
                <label className="block text-[11px] text-[#475569] mb-0.5 font-medium">Puesto / Cargo</label>
                <input
                  type="text"
                  value={formData.puesto}
                  onChange={(e) => setFormData((prev) => ({ ...prev, puesto: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-0.5 font-medium">
                  Área de Trabajo <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <select
                  required
                  value={formData.area}
                  onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                >
                  <option value="">Seleccione área...</option>
                  {formData.area && !AREAS_EMPRESA.includes(formData.area) && (
                    <option value={formData.area}>{formData.area}</option>
                  )}
                  {AREAS_EMPRESA.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-0.5 font-medium">
                  Lugar Físico Específico <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
                </label>
                <input
                  type="text"
                  required
                  list="lista-lugares-atencion"
                  placeholder="Escribe o selecciona lugar..."
                  value={formData.lugarEspecifico || formData.lugarAccidente || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, lugarEspecifico: e.target.value, lugarAccidente: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]"
                />
                <datalist id="lista-lugares-atencion">
                  {LUGARES_ESPECIFICOS.map((lug, idx) => (
                    <option key={`lug-atn-${idx}`} value={lug} />
                  ))}
                </datalist>
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-0.5 font-medium">Turno</label>
                <select
                  value={formData.turno}
                  onChange={(e) => setFormData((prev) => ({ ...prev, turno: e.target.value as any }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
                >
                  <option value="Mañana">Mañana</option>
                  <option value="Tarde">Tarde</option>
                  <option value="Noche">Noche</option>
                  <option value="Rotativo">Rotativo</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* SECCIÓN 3: DETALLE MÉDICO, LUGAR Y DIAGNÓSTICO */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="flex items-center gap-2">
            <Hospital className="w-4 h-4 text-[#0284C7]" />
            <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
              3. Detalle Asistencial, Diagnóstico y Tratamiento Clínico
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Lugar / Centro Médico de Atención *
              </label>
              <input
                type="text"
                required
                list="lista-lugares-atencion"
                placeholder="Ej: Tópico de Planta, Clínica San Gabriel SCTR, Hospital EsSalud..."
                value={formData.lugarAtencion}
                onChange={(e) => setFormData((prev) => ({ ...prev, lugarAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981] font-medium"
              />
              <datalist id="lista-lugares-atencion">
                <option value="Tópico de Planta" />
                <option value="Clínica SCTR / Policlínico" />
                <option value="Hospital EsSalud" />
                <option value="Clínica Particular" />
                <option value="Centro de Salud / MINSA" />
              </datalist>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Tipo de Atención Médica
              </label>
              <input
                type="text"
                placeholder="Ej: Primeros auxilios, Consulta de urgencia, Control y curación, Reevaluación..."
                value={formData.tipoAtencion}
                onChange={(e) => setFormData((prev) => ({ ...prev, tipoAtencion: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-[#0F172A]">
                Diagnóstico Clínico / Juicio Médico *
              </label>
              {formData.codigoAccidente && (
                <button
                  type="button"
                  onClick={() => {
                    const lesion = formData.lesionReferida || [];
                    const partes = formData.partesCuerpoAfectadas || [];
                    const sug = `Atención clínica y evaluación por ${lesion.join(', ') || 'lesión física'} en ${partes.join(', ') || 'zona corporal afectada'}. Caso SST ${formData.codigoAccidente}.`;
                    setFormData((prev) => ({ ...prev, diagnostico: sug }));
                  }}
                  className="text-[11px] text-[#047857] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-[#047857]" />
                  <span>Sugerir según lesión SST</span>
                </button>
              )}
            </div>
            <textarea
              required
              rows={2}
              placeholder="Diagnóstico médico detallado, hallazgos clínicos y estado de la lesión..."
              value={formData.diagnostico}
              onChange={(e) => setFormData((prev) => ({ ...prev, diagnostico: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Tratamiento Prescrito y Procedimientos Realizados
              </label>
              <textarea
                rows={3}
                placeholder="Curación, lavado de herida, vendaje compresivo, sutura, inmovilización, pautas terapéuticas..."
                value={formData.tratamiento || ''}
                onChange={(e) => setFormData((prev) => ({ ...prev, tratamiento: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Medicamentos e Insumos Administrados / Recetados
              </label>
              <textarea
                rows={3}
                placeholder="Analgésicos (Paracetamol/Ibuprofeno), antisépticos (clorhexidina), gasas estériles, apósitos..."
                value={formData.medicamentosPrescritos || ''}
                onChange={(e) => setFormData((prev) => ({ ...prev, medicamentosPrescritos: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#64748B] focus:outline-hidden focus:ring-2 focus:ring-[#10B981]/30 focus:border-[#10B981]"
              />
            </div>
          </div>
        </div>

        {/* SECCIÓN 4: GESTIÓN DE DESCANSO MÉDICO, CERTIFICADOS Y SEGUIMIENTO */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-[#047857]" />
              <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
                4. Descanso Médico, Reposo Laboral y Certificados
              </span>
            </div>
            {formData.generaDescanso === 'SI' && (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-[#DC2626] border border-rose-200">
                Requiere Reposo ({formData.diasDescanso} Días Otorgados)
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                ¿Genera Descanso Médico? *
              </label>
              <select
                value={formData.generaDescanso}
                onChange={(e) => {
                  const val = e.target.value as 'SI' | 'NO';
                  setFormData((prev) => ({
                    ...prev,
                    generaDescanso: val,
                    fechaInicioDescanso: val === 'SI' ? (prev.fechaInicioDescanso || prev.fechaAtencion || '') : '',
                    fechaFinDescanso: val === 'SI' ? (prev.fechaFinDescanso || prev.fechaAtencion || '') : '',
                    diasDescanso: val === 'SI' ? (prev.diasDescanso || 1) : 0
                  }));
                }}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-2 text-xs text-[#0F172A] font-bold"
              >
                <option value="NO">NO (Sin descanso médico)</option>
                <option value="SI">SÍ (Requiere reposo laboral)</option>
              </select>
            </div>

            {formData.generaDescanso === 'SI' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                    Tipo de Certificado *
                  </label>
                  <select
                    value={formData.tipoCertificadoDescanso || 'Descanso SCTR'}
                    onChange={(e) => setFormData((prev) => ({ ...prev, tipoCertificadoDescanso: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-2 text-xs text-[#0F172A]"
                  >
                    <option value="Descanso SCTR">Descanso Médico por Clínica SCTR</option>
                    <option value="CITT EsSalud">Certificado CITT EsSalud</option>
                    <option value="Certificado Particular">Certificado Médico Particular</option>
                    <option value="Descanso Interno Tópico">Descanso Interno Preventivo Tópico</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                    N° Certificado / CITT
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: CITT-123456 / CMP-789"
                    value={formData.nroCertificadoMedico || ''}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nroCertificadoMedico: e.target.value }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-2 text-xs text-[#0F172A]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                    Código Diagnóstico CIE-10
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: S61.0, S93.4, T14.0"
                    value={formData.cie10 || ''}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cie10: e.target.value.toUpperCase() }))}
                    className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-2 text-xs text-[#0F172A] font-mono"
                  />
                </div>
              </>
            )}
          </div>

          {formData.generaDescanso === 'SI' && (
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">Inicio de Descanso *</label>
                <input
                  type="date"
                  required
                  value={formData.fechaInicioDescanso}
                  onChange={(e) => setFormData((prev) => ({ ...prev, fechaInicioDescanso: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">Fin de Descanso *</label>
                <input
                  type="date"
                  required
                  value={formData.fechaFinDescanso}
                  onChange={(e) => setFormData((prev) => ({ ...prev, fechaFinDescanso: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Días de Descanso (Calculado)
                </label>
                <div className="px-3 py-1.5 rounded bg-rose-50 border border-rose-200 text-[#DC2626] text-xs font-bold font-mono flex items-center justify-between">
                  <span>{formData.diasDescanso} día(s)</span>
                  <span className="text-[10px] text-[#DC2626] font-normal">Inclusivo</span>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Restricciones al Reincorporarse
                </label>
                <input
                  type="text"
                  placeholder="Ej: No cargar peso > 5kg, reposo visual..."
                  value={formData.restriccionesLaborales || ''}
                  onChange={(e) => setFormData((prev) => ({ ...prev, restriccionesLaborales: e.target.value }))}
                  className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Médico o Profesional Tratante
              </label>
              <input
                type="text"
                list="lista-profesionales-tratantes"
                placeholder="Nombre y colegiatura (CMP / CEP)..."
                value={formData.medicoTratante}
                onChange={(e) => setFormData((prev) => ({ ...prev, medicoTratante: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
              />
              <datalist id="lista-profesionales-tratantes">
                {trabajadores
                  .filter((t) => t.condicion === 'Activo')
                  .map((t, idx) => (
                    <option key={`med-t-${t.id || t.dni || idx}`} value={t.apellidosNombres}>
                      {t.puesto} • {t.area} ({t.empresa})
                    </option>
                  ))}
              </datalist>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Próxima Cita Médica / Control
              </label>
              <input
                type="date"
                value={formData.proximaCita}
                onChange={(e) => setFormData((prev) => ({ ...prev, proximaCita: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                Observaciones / Pautas Médicas
              </label>
              <input
                type="text"
                placeholder="Indicaciones para el colaborador o recomendaciones..."
                value={formData.observaciones}
                onChange={(e) => setFormData((prev) => ({ ...prev, observaciones: e.target.value }))}
                className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A]"
              />
            </div>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="pt-4 border-t border-[#E2E8F0] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-lg bg-white hover:bg-[#F1F5F9] text-xs font-semibold text-[#1E293B] border border-[#CBD5E1] cursor-pointer transition-colors focus-visible:ring-2 focus-visible:ring-[#10B981]"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center gap-1.5 px-6 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] disabled:opacity-50 text-xs font-bold text-white shadow-2xs transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981]"
          >
            <Save className="w-4 h-4" />
            <span>{isSubmitting ? 'Guardando...' : editingId ? 'Guardar Cambios' : 'Registrar Atención Médica'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
