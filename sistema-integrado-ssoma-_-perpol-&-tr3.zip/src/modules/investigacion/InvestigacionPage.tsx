import React from 'react';
import { ModuleHeader } from '../../components/common/ModuleHeader';
import { GenericImportModal } from '../../components/common/GenericImportModal';
import { DeleteConfirmModal } from '../../components/common/DeleteConfirmModal';
import { MODULE_IMPORT_SCHEMAS } from '../../utils/moduleImportSchemas';
import { ModuleToolbar } from '../../components/common/ModuleToolbar';
import { Search, Edit2 } from 'lucide-react';

import { useInvestigacion } from './hooks/useInvestigacion';
import { InvestigacionStats } from './components/InvestigacionStats';
import { InvestigacionTable } from './components/InvestigacionTable';
import { InvestigacionForm } from './components/InvestigacionForm';
import { InvestigacionDetailModal } from './components/InvestigacionDetailModal';
import { InvestigacionSignatureModal } from './components/InvestigacionSignatureModal';

export const InvestigacionPage: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    searchTerm,
    setSearchTerm,
    estadoFilter,
    setEstadoFilter,
    statusOptions,
    isImportModalOpen,
    setIsImportModalOpen,
    viewDetailModal,
    setViewDetailModal,
    deleteModalInvestigacion,
    setDeleteModalInvestigacion,
    isSignatureModalOpen,
    setIsSignatureModalOpen,
    currentInvestigadorIndex,
    canvasRef,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    editingId,
    isSubmitting,
    formError,
    closureErrorsList,
    selectedCaseId,
    formData,
    setFormData,
    filteredInvestigaciones,
    paginatedInvestigaciones,
    accidentesCandidatos,
    accidentes,
    areasTrabajadores,
    trabajadoresActivos,
    metricas,
    initializeCanvas,
    startDrawing,
    draw,
    stopDrawing,
    getDiasDescansoCaso,
    createDraftFromCase,
    calculateProgress,
    handleOpenSignatureModal,
    handleSaveSignature,
    handleInvestigadorNombreChange,
    handleSelectResponsableMedida,
    handleClearSignature,
    handleAddInvestigador,
    handleAddMedida,
    handleSave,
    handleExportarExcel,
    handleExportarPDF,
    confirmDeleteInvestigacion,
    handleNuevo,
    handleEdit,
    batchUpsertInvestigaciones
  } = useInvestigacion();

  return (
    <div className="space-y-6">
      {/* Encabezado */}
      <ModuleHeader
        codigo={11}
        titulo="Investigación de Accidentes e Incidentes"
        subtitulo="Metodologías de Causa Raíz (5 Porqués / Ishikawa), medidas correctivas y captura de firmas en Drive"
        icono={<Search className="w-5 h-5 text-indigo-400" />}
        onNuevo={handleNuevo}
        onImportar={() => setIsImportModalOpen(true)}
      />

      {/* Modal de Importación Masiva */}
      <GenericImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={MODULE_IMPORT_SCHEMAS.investigacion}
        onImportSuccess={(rows) => {
          batchUpsertInvestigaciones(rows as any);
        }}
      />

      {/* Tarjetas KPI */}
      <InvestigacionStats metricas={metricas} />

      {/* Tabs */}
      <div className="flex border-b border-[#E2E8F0] bg-white px-2 rounded-t-xl gap-1">
        <button
          onClick={() => setActiveTab('lista')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'lista'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>Expedientes de Investigación</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'lista' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#0F172A]'
            }`}
          >
            {filteredInvestigaciones.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('formulario')}
          className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-t-lg transition-all cursor-pointer ${
            activeTab === 'formulario'
              ? 'bg-[#1E293B] text-white shadow-2xs active'
              : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
          }`}
        >
          <Edit2 className="w-4 h-4" />
          <span>
            {editingId ? `Editando Ficha ${editingId}` : 'Ficha Normativa de 11 Secciones'}
          </span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'formulario' ? 'bg-white/20 text-white' : 'bg-[#F1F5F9] text-[#0F172A]'
            }`}
          >
            {calculateProgress()}%
          </span>
        </button>
      </div>

      {/* TAB 1: LISTADO DE EXPEDIENTES */}
      {activeTab === 'lista' && (
        <div className="space-y-4">
          <ModuleToolbar
            searchPlaceholder="Buscar por código de investigación, trabajador, DNI, área o código de accidente..."
            searchQuery={searchTerm}
            onSearchChange={setSearchTerm}
            statusOptions={statusOptions}
            statusFilter={estadoFilter}
            onStatusFilterChange={(val: string) => setEstadoFilter(val as any)}
            onExportExcel={handleExportarExcel}
            onExportPdf={handleExportarPDF}
          />

          <InvestigacionTable
            items={paginatedInvestigaciones}
            searchTerm={searchTerm}
            estadoFilter={estadoFilter}
            currentPage={currentPage}
            pageSize={pageSize}
            totalItems={filteredInvestigaciones.length}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
            onView={(item) => setViewDetailModal(item)}
            onEdit={handleEdit}
            onDelete={(item) => setDeleteModalInvestigacion(item)}
            onClearFilters={() => {
              setSearchTerm('');
              setEstadoFilter('TODOS');
            }}
            onNewRecord={handleNuevo}
          />
        </div>
      )}

      {/* TAB 2: FICHA DE 11 SECCIONES */}
      {activeTab === 'formulario' && (
        <InvestigacionForm
          editingId={editingId}
          formData={formData}
          setFormData={setFormData}
          selectedCaseId={selectedCaseId}
          createDraftFromCase={createDraftFromCase}
          accidentesCandidatos={accidentesCandidatos}
          accidentes={accidentes}
          areasTrabajadores={areasTrabajadores}
          trabajadoresActivos={trabajadoresActivos}
          getDiasDescansoCaso={getDiasDescansoCaso}
          calculateProgress={calculateProgress}
          closureErrorsList={closureErrorsList}
          formError={formError}
          isSubmitting={isSubmitting}
          handleAddMedida={handleAddMedida}
          handleSelectResponsableMedida={handleSelectResponsableMedida}
          handleAddInvestigador={handleAddInvestigador}
          handleInvestigadorNombreChange={handleInvestigadorNombreChange}
          handleOpenSignatureModal={handleOpenSignatureModal}
          handleClearSignature={handleClearSignature}
          handleSave={handleSave}
          onCancel={() => {
            setActiveTab('lista');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {/* Modal de Detalle */}
      <InvestigacionDetailModal
        item={viewDetailModal}
        onClose={() => setViewDetailModal(null)}
      />

      {/* Modal de Firma en Canvas */}
      <InvestigacionSignatureModal
        isOpen={isSignatureModalOpen}
        onClose={() => setIsSignatureModalOpen(false)}
        canvasRef={canvasRef}
        currentInvestigadorIndex={currentInvestigadorIndex}
        investigadores={formData.investigadores}
        startDrawing={startDrawing}
        draw={draw}
        stopDrawing={stopDrawing}
        initializeCanvas={initializeCanvas}
        handleSaveSignature={handleSaveSignature}
      />

      {/* Modal de Confirmación para Eliminar */}
      <DeleteConfirmModal
        isOpen={Boolean(deleteModalInvestigacion)}
        onClose={() => setDeleteModalInvestigacion(null)}
        onConfirm={confirmDeleteInvestigacion}
        title="Eliminar Investigación de Accidente"
        message="¿Estás seguro de que deseas eliminar este informe de investigación oficial?"
        itemIdentifier={
          deleteModalInvestigacion
            ? `${deleteModalInvestigacion.codigoInvestigacion}: ${deleteModalInvestigacion.datosTrabajador.nombre} (${deleteModalInvestigacion.empresa})`
            : undefined
        }
        confirmButtonText="Eliminar Investigación"
      />
    </div>
  );
};
