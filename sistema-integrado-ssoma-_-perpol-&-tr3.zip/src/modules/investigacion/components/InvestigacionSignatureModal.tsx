import React from 'react';
import { PenTool, X, RotateCcw, CheckCircle2 } from 'lucide-react';

interface InvestigacionSignatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  currentInvestigadorIndex: number | null;
  investigadores: Array<{ nombre: string; cargo: string; rol: string }> | undefined;
  startDrawing: (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => void;
  draw: (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => void;
  stopDrawing: () => void;
  initializeCanvas: () => void;
  handleSaveSignature: () => void;
}

export const InvestigacionSignatureModal: React.FC<InvestigacionSignatureModalProps> = ({
  isOpen,
  onClose,
  canvasRef,
  currentInvestigadorIndex,
  investigadores,
  startDrawing,
  draw,
  stopDrawing,
  initializeCanvas,
  handleSaveSignature
}) => {
  if (!isOpen) return null;

  const currentMember =
    currentInvestigadorIndex !== null && investigadores?.[currentInvestigadorIndex]
      ? investigadores[currentInvestigadorIndex]
      : null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto cursor-pointer"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl text-slate-800 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
              <PenTool className="w-5 h-5 text-indigo-700" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0F172A]">
                Captura de Firma Digital en Google Drive (900 × 270 px)
              </h3>
              {currentMember && (
                <p className="text-xs text-indigo-700 font-semibold mt-0.5">
                  Miembro: {currentMember.nombre || 'Sin nombre asignado'} — Rol: {currentMember.rol} ({currentMember.cargo || 'Puesto no asignado'})
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600">
            Dibuje la rúbrica o firma con el mouse o pantalla táctil. La imagen se optimizará
            con fondo blanco y trazo institucional (#163D2C) y se almacenará en Google Drive.
          </p>

          {/* Contenedor del Canvas */}
          <div className="border-2 border-dashed border-indigo-300 rounded-xl overflow-hidden bg-white shadow-inner flex items-center justify-center">
            <canvas
              ref={canvasRef}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="w-full h-auto max-h-[270px] cursor-crosshair touch-none"
              style={{ aspectRatio: '900 / 270' }}
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={initializeCanvas}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Limpiar Trazo</span>
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveSignature}
                className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-sm transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>Confirmar y Subir a Drive</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
