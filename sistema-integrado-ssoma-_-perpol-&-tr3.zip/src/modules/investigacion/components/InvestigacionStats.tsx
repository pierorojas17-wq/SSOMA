import React from 'react';
import { Search, GitBranch, ShieldCheck } from 'lucide-react';
import { InvestigacionMetricas } from '../types/investigacion';

interface InvestigacionStatsProps {
  metricas: InvestigacionMetricas;
}

export const InvestigacionStats: React.FC<InvestigacionStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Expedientes</span>
          <Search className="w-4 h-4 text-[#1E293B]" />
        </div>
        <div className="text-2xl font-bold text-[#0F172A] mt-2">{metricas.total}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Investigaciones totales</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>En Proceso</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#D97706]"></span>
        </div>
        <div className="text-2xl font-bold text-[#B45309] mt-2">{metricas.abiertas}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Borrador / Revisión</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Cerradas</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#059669]"></span>
        </div>
        <div className="text-2xl font-bold text-[#047857] mt-2">{metricas.cerradas}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Con medidas verificadas</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Total Medidas</span>
          <GitBranch className="w-4 h-4 text-[#0284C7]" />
        </div>
        <div className="text-2xl font-bold text-[#0284C7] mt-2">{metricas.totalMedidas}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Plan de acción formulado</div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 flex flex-col justify-between shadow-2xs">
        <div className="flex items-center justify-between text-[#475569] text-xs font-semibold">
          <span>Verificadas</span>
          <ShieldCheck className="w-4 h-4 text-[#047857]" />
        </div>
        <div className="text-2xl font-bold text-[#047857] mt-2">{metricas.medidasVerificadas}</div>
        <div className="text-[11px] text-[#475569] mt-1 font-medium">Eficacia comprobada</div>
      </div>
    </div>
  );
};
