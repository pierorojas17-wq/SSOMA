import React from 'react';
import { InvestigacionRecord } from '../../../types/modules';
import { TablePagination } from '../../../components/common/TablePagination';
import { TableEmptyState } from '../../../components/common/TableEmptyState';
import { StatusBadge } from '../../../components/common/StatusBadge';
import { Eye, Edit2, Trash2 } from 'lucide-react';

interface InvestigacionTableProps {
  items: InvestigacionRecord[];
  searchTerm: string;
  estadoFilter: string;
  currentPage: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  onView: (item: InvestigacionRecord) => void;
  onEdit: (item: InvestigacionRecord) => void;
  onDelete: (item: InvestigacionRecord) => void;
  onClearFilters: () => void;
  onNewRecord: () => void;
}

export const InvestigacionTable: React.FC<InvestigacionTableProps> = ({
  items,
  searchTerm,
  estadoFilter,
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  onView,
  onEdit,
  onDelete,
  onClearFilters,
  onNewRecord
}) => {
  return (
    <div id="tabla-investigaciones" className="bg-white border border-[#E2E8F0] rounded-xl overflow-hidden shadow-2xs">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1080px] text-left text-xs text-[#0F172A]">
          <thead className="bg-[#F8FAFC] text-[#475569] uppercase text-[10px] font-semibold border-b border-[#E2E8F0] tracking-wider">
            <tr>
              <th className="px-4 py-3 w-28 whitespace-nowrap">Código</th>
              <th className="px-4 py-3 w-32 whitespace-nowrap">Caso Accidente</th>
              <th className="px-4 py-3 w-28 whitespace-nowrap">Empresa</th>
              <th className="px-4 py-3 min-w-[180px]">Trabajador (Snapshot)</th>
              <th className="px-4 py-3 min-w-[150px]">Área / Ocurrencia</th>
              <th className="px-4 py-3 min-w-[160px]">Contacto / Agente</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Medidas</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Avance</th>
              <th className="px-4 py-3 w-28 text-center whitespace-nowrap">Estado</th>
              <th className="px-4 py-3 w-24 text-right whitespace-nowrap">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F1F5F9]">
            {items.length === 0 ? (
              <TableEmptyState
                isTableRow
                colSpan={10}
                title="No se encontraron expedientes de investigación"
                description={
                  searchTerm
                    ? `No hay expedientes que coincidan con "${searchTerm}".`
                    : 'No se encontraron expedientes de investigación con los filtros actuales.'
                }
                actionLabel={searchTerm || estadoFilter !== 'TODOS' ? 'Limpiar filtros' : 'Nueva Investigación'}
                actionIcon={searchTerm || estadoFilter !== 'TODOS' ? 'clear' : 'plus'}
                onAction={() => {
                  if (searchTerm || estadoFilter !== 'TODOS') {
                    onClearFilters();
                  } else {
                    onNewRecord();
                  }
                }}
              />
            ) : (
              items.map((item, idx) => {
                const medidasVerificadas = (item.medidasCorrectivas || []).filter((m) => m.estado === 'Verificada').length;
                return (
                  <tr key={`${item.id || item.codigoInvestigacion || ''}-${idx}`} className="hover:bg-[#F8FAFC] transition-colors">
                    <td className="px-4 py-3 font-bold text-[#0F172A] whitespace-nowrap">
                      {item.codigoInvestigacion}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-[#DC2626] font-bold">{item.accidenteId}</span>
                      <div className="text-[10px] text-[#475569]">{item.fechaAccidente}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          item.empresa === 'PERPOL'
                            ? 'bg-blue-50 text-[#0284C7] border-blue-200'
                            : 'bg-amber-50 text-[#B45309] border-amber-200'
                        }`}
                      >
                        {item.empresa}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-[#0F172A] font-medium">{item.datosTrabajador.nombre}</div>
                      <div className="text-[11px] text-[#475569]">
                        DNI: {item.datosTrabajador.dni} • {item.datosTrabajador.edad} años
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-[#0F172A] font-medium">{item.area}</div>
                      <div className="text-[11px] text-[#475569]">{item.turno} • {item.diasDescanso} días descanso</div>
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      <div className="text-[#0F172A] font-medium truncate">{item.tipoContacto}</div>
                      <div className="text-[11px] text-[#475569] truncate">{item.agenteCausante}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="text-[#0F172A] font-semibold">
                        {medidasVerificadas} / {(item.medidasCorrectivas || []).length}
                      </span>
                      <div className="text-[10px] text-[#047857] font-medium">verificadas</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-[#F1F5F9] border border-[#E2E8F0] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#047857] rounded-full"
                            style={{ width: `${item.porcentajeAvance}%` }}
                          />
                        </div>
                        <span className="text-[11px] text-[#475569] font-mono font-semibold">{item.porcentajeAvance}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={item.estado} />
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="p-1.5 rounded-md hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Ver Expediente"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="p-1.5 rounded-md hover:bg-[#F1F5F9] text-[#475569] hover:text-[#0F172A] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete(item)}
                          className="p-1.5 rounded-md hover:bg-rose-50 text-[#475569] hover:text-[#DC2626] transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#10B981] focus-visible:outline-hidden"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <TablePagination
        currentPage={currentPage}
        totalItems={totalItems}
        pageSize={pageSize}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        pageSizeOptions={[10, 25, 50, 100]}
      />
    </div>
  );
};
