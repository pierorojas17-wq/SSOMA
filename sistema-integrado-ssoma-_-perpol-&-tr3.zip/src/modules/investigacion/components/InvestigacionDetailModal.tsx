import React from 'react';
import { InvestigacionRecord } from '../../../types/modules';
import { FileSearch, X } from 'lucide-react';
import { DriveImage } from '../../../components/common/DriveImage';

interface InvestigacionDetailModalProps {
  item: InvestigacionRecord | null;
  onClose: () => void;
}

export const InvestigacionDetailModal: React.FC<InvestigacionDetailModalProps> = ({ item, onClose }) => {
  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-slate-900/60 backdrop-blur-xs cursor-pointer select-none transition-opacity"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="fixed inset-0 -z-10 cursor-pointer"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="relative z-10 bg-white border border-slate-200 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-800 cursor-default select-text"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header del modal fijo */}
        <div className="sticky top-0 z-20 px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 pr-2">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 shrink-0">
              <FileSearch className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-mono text-indigo-700 font-bold block truncate">
                {item.codigoInvestigacion}
              </span>
              <h3 className="text-base font-bold text-[#0F172A] truncate">
                Expediente de Causa Raíz e Informe SST
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer shrink-0"
            title="Cerrar expediente (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido con scroll independiente */}
        <div className="p-6 space-y-4 text-xs text-slate-700 overflow-y-auto flex-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Caso Vinculado</span>
              <span className="font-bold text-rose-700 font-mono">{item.accidenteId}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Empresa</span>
              <span className="font-bold text-slate-900">{item.empresa}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Trabajador</span>
              <span className="font-bold text-slate-900">{item.datosTrabajador.nombre}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Estado</span>
              <span className="font-bold text-indigo-700">{item.estado}</span>
            </div>
          </div>

          <div>
            <span className="font-bold text-slate-700 block mb-1">Circunstancias del Evento:</span>
            <p className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 leading-relaxed text-sm">
              {item.descripcionCircunstancias}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="font-bold text-slate-700 block mb-1">Tipo de Contacto:</span>
              <span className="text-slate-900 font-medium">{item.tipoContacto}</span>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="font-bold text-slate-700 block mb-1">Agente Causante:</span>
              <span className="text-slate-900 font-medium">{item.agenteCausante}</span>
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <span className="font-bold text-emerald-800 block text-xs">
              Análisis Causa Raíz ({item.causaRaizMetodo}):
            </span>
            <pre className="font-mono text-[11px] whitespace-pre-wrap text-slate-800 bg-white p-3 rounded-lg border border-slate-200">
              {item.analisisCausaRaiz}
            </pre>
            <div className="pt-2 border-t border-slate-200 text-xs">
              <span className="font-bold text-slate-700">Conclusión: </span>
              <span className="text-emerald-800 font-bold">{item.conclusionCausaRaiz}</span>
            </div>
          </div>

          <div>
            <span className="font-bold text-slate-700 block mb-2">
              Medidas Correctivas ({(item.medidasCorrectivas || []).length}):
            </span>
            <div className="space-y-1.5">
              {(item.medidasCorrectivas || []).map((m, idx) => (
                <div key={idx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-[11px]">
                  <div>
                    <span className="font-bold text-slate-900">{m.descripcion}</span>
                    <div className="text-slate-500">Resp: {m.responsable} • Plazo: {m.plazo} ({m.tipoAccion})</div>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      m.estado === 'Verificada'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {m.estado}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <span className="font-bold text-slate-700 block mb-2">Firmas de Investigadores:</span>
            <div className="grid grid-cols-2 gap-3">
              {(item.investigadores || []).map((inv, idx) => (
                <div key={idx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-3">
                  {typeof inv.firmaUrl === 'string' && inv.firmaUrl.trim().length > 0 && (
                    <div className="h-10 w-24 bg-white rounded border border-slate-200 p-0.5 overflow-hidden flex items-center justify-center">
                      <DriveImage
                        src={inv.firmaUrl}
                        driveId={inv.firmaDriveId}
                        alt={`Firma ${inv.nombre}`}
                        className="max-h-full max-w-full object-contain"
                        containerClassName="w-full h-full flex items-center justify-center"
                        showOpenButton={false}
                      />
                    </div>
                  )}
                  <div>
                    <div className="font-bold text-slate-900 text-[11px]">{inv.nombre}</div>
                    <div className="text-slate-500 text-[10px]">{inv.cargo} ({inv.rol})</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer fijo del modal */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono">ID: {item.id}</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
