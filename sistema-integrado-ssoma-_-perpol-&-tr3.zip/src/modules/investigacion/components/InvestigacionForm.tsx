import React from 'react';
import {
  InvestigacionRecord,
  AccidenteRecord,
  TrabajadorRecord,
  RolInvestigador
} from '../../../types/modules';
import {
  CATALOGO_TIPOS_CONTACTO,
  CATALOGO_ACTOS_SUBESTANDAR,
  CATALOGO_CONDICIONES_SUBESTANDAR,
  CATALOGO_FACTORES_PERSONALES,
  CATALOGO_FACTORES_TRABAJO,
  TURNOS_TRABAJO,
  PARTES_CUERPO_AFECTADAS,
  LUGARES_ESPECIFICOS
} from '../../../utils/ssomaCatalogs';
import {
  Save,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  User,
  GitBranch,
  CheckSquare,
  Plus,
  Trash2,
  PenTool,
  X
} from 'lucide-react';

const ROLES_COMISION: RolInvestigador[] = [
  'Investigador Principal',
  'Responsable del área',
  'Representante del CSST',
  'Responsable SSOMA',
  'Representante del Empleador'
];

interface InvestigacionFormProps {
  editingId: string | null;
  formData: Partial<InvestigacionRecord>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<InvestigacionRecord>>>;
  selectedCaseId: string;
  createDraftFromCase: (caseId: string) => void;
  accidentesCandidatos: AccidenteRecord[];
  accidentes: AccidenteRecord[];
  areasTrabajadores: string[];
  trabajadoresActivos: TrabajadorRecord[];
  getDiasDescansoCaso: (acc: AccidenteRecord) => number;
  calculateProgress: () => number;
  closureErrorsList: string[] | undefined;
  formError: string | null;
  isSubmitting: boolean;
  handleAddMedida: () => void;
  handleSelectResponsableMedida: (mIdx: number, val: string) => void;
  handleAddInvestigador: () => void;
  handleInvestigadorNombreChange: (iIdx: number, val: string) => void;
  handleOpenSignatureModal: (iIdx: number) => void;
  handleClearSignature: (iIdx: number) => void;
  handleSave: (intentarCerrar: boolean) => void;
  onCancel: () => void;
}

export const InvestigacionForm: React.FC<InvestigacionFormProps> = ({
  editingId,
  formData,
  setFormData,
  selectedCaseId,
  createDraftFromCase,
  accidentesCandidatos,
  accidentes,
  areasTrabajadores,
  trabajadoresActivos,
  getDiasDescansoCaso,
  calculateProgress,
  closureErrorsList = [],
  formError,
  isSubmitting,
  handleAddMedida,
  handleSelectResponsableMedida,
  handleAddInvestigador,
  handleInvestigadorNombreChange,
  handleOpenSignatureModal,
  handleClearSignature,
  handleSave,
  onCancel
}) => {
  return (
    <div className="bg-white border border-[#E2E8F0] rounded-2xl p-6 shadow-sm space-y-6 text-[#0F172A]">
      {/* Header Formulario */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#E2E8F0] gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] font-mono text-xs font-bold">
              {editingId || 'NUEVA INVESTIGACIÓN'}
            </span>
            <span className="text-xs text-[#475569]">
              Formato Oficial R.M. 050-2013-TR / Ley 29783
            </span>
          </div>
          <h2 className="text-lg font-bold text-[#0F172A] mt-1">
            Ficha Técnica de Causa Raíz y Plan de Acción
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs text-[#475569]">Avance de Formulario</div>
            <div className="text-sm font-bold text-[#047857]">{calculateProgress()}% Completado</div>
          </div>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSave(false)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#1E293B] border border-[#CBD5E1] text-xs font-bold transition-colors shadow-2xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
          >
            <Save className="w-4 h-4 text-[#475569]" />
            <span>Guardar Borrador</span>
          </button>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSave(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-xs font-bold text-white transition-colors shadow-sm cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Verificar y Cerrar Investigación</span>
          </button>
        </div>
      </div>

      {/* Banner de Errores de Cierre */}
      {closureErrorsList.length > 0 && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs space-y-2">
          <div className="font-bold flex items-center gap-2 text-rose-800">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>Regla de Cierre Incompleta (closureErrors):</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 text-rose-950 font-medium">
            {closureErrorsList.map((err, idx) => (
              <li key={idx}>{err}</li>
            ))}
          </ul>
          <div className="text-[11px] text-rose-700 pt-1 font-semibold">
            Subsanar estos puntos para autorizar el pase a estado "Cerrada".
          </div>
        </div>
      )}

      {formError && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
          <span className="font-medium">{formError}</span>
        </div>
      )}

      {/* SECCIÓN 1: SELECCIÓN Y SNAPSHOT DEL CASO DE ACCIDENTE */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A] flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 text-rose-600" />
            1. Referencia del Evento (Copia Snapshot desde Módulo 1)
          </span>
          {selectedCaseId && (
            <span className="text-xs font-mono text-[#047857] font-bold">Caso Activo: {selectedCaseId}</span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="sm:col-span-2">
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">
              Vincular Caso de Accidente / Incidente <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <select
              value={selectedCaseId}
              onChange={(e) => createDraftFromCase(e.target.value)}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-semibold"
            >
              <option value="">Seleccione un caso de accidente...</option>
              {accidentesCandidatos.map((acc, aIdx) => (
                <option key={`${acc.id || acc.codigoCaso || 'acc'}-${aIdx}`} value={acc.codigoCaso}>
                  {acc.codigoCaso} - {acc.fecha} - {acc.trabajadorNombre} ({acc.tipoEvento})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] text-[#475569] font-semibold">
                Empresa <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
              {selectedCaseId && formData.empresa && (
                <span className="text-[10px] text-[#047857] font-bold">✓ Auto</span>
              )}
            </div>
            <select
              value={formData.empresa}
              onChange={(e) => setFormData((prev) => ({ ...prev, empresa: e.target.value as any }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
            >
              <option value="PERPOL">PERPOL IDEAS S.A.C.</option>
              <option value="TR3">TR3 ALIMENTOS S.A.C.</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">Fecha de Investigación</label>
            <input
              type="date"
              value={formData.fechaInvestigacion}
              onChange={(e) => setFormData((prev) => ({ ...prev, fechaInvestigacion: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
        </div>

        {/* Datos copiados de la ocurrencia */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-2 border-t border-[#E2E8F0]">
          <div>
            <span className="text-[10px] text-[#475569] uppercase block font-bold">Fecha Ocurrencia</span>
            <input
              type="date"
              value={formData.fechaAccidente}
              onChange={(e) => setFormData((prev) => ({ ...prev, fechaAccidente: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <span className="text-[10px] text-[#475569] uppercase block font-bold">Hora / Turno</span>
            <div className="flex gap-1">
              <input
                type="time"
                value={formData.horaAccidente}
                onChange={(e) => setFormData((prev) => ({ ...prev, horaAccidente: e.target.value }))}
                className="w-1/2 bg-white border border-[#CBD5E1] rounded px-2 py-1 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              />
              <select
                value={formData.turno}
                onChange={(e) => setFormData((prev) => ({ ...prev, turno: e.target.value }))}
                className="w-1/2 bg-white border border-[#CBD5E1] rounded px-1.5 py-1 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              >
                {TURNOS_TRABAJO.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <span className="text-[10px] text-[#475569] uppercase block font-bold">
              Hora Inicio Laboral <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </span>
            <input
              type="time"
              required
              value={formData.horaInicioLaboral || '07:00'}
              onChange={(e) => setFormData((prev) => ({ ...prev, horaInicioLaboral: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-0.5">
              <span className="text-[10px] text-[#475569] uppercase block font-bold">Área de Trabajo</span>
              {selectedCaseId && formData.area && (
                <span className="text-[10px] text-[#047857] font-bold">✓ Auto</span>
              )}
            </div>
            <select
              value={formData.area}
              onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value="">Seleccione área...</option>
              {formData.area && !areasTrabajadores.includes(formData.area) && (
                <option value={formData.area}>{formData.area} (Base)</option>
              )}
              {areasTrabajadores.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div className="flex items-center justify-between mb-0.5">
              <span className="text-[10px] text-[#475569] uppercase block font-bold">Lugar Físico Específico</span>
              {selectedCaseId && formData.lugarExacto && (
                <span className="text-[10px] text-[#047857] font-bold">✓ Auto</span>
              )}
            </div>
            <input
              type="text"
              required
              list="lista-lugares-investigacion"
              placeholder="Escribe o selecciona lugar..."
              value={formData.lugarExacto || ''}
              onChange={(e) => setFormData((prev) => ({ ...prev, lugarExacto: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
            <datalist id="lista-lugares-investigacion">
              {LUGARES_ESPECIFICOS.map((lug, idx) => (
                <option key={`lug-inv-${idx}`} value={lug} />
              ))}
            </datalist>
          </div>
          <div>
            <div className="flex items-center justify-between mb-0.5">
              <span className="text-[10px] text-[#475569] uppercase block font-bold">
                Días Descanso Médico
              </span>
              {selectedCaseId && (
                <button
                  type="button"
                  onClick={() => {
                    const targetAcc = accidentes.find(
                      (a) => a.id === selectedCaseId || a.codigoCaso === selectedCaseId
                    );
                    if (targetAcc) {
                      const d = getDiasDescansoCaso(targetAcc);
                      setFormData((prev) => ({ ...prev, diasDescanso: d }));
                    }
                  }}
                  className="text-[10px] text-[#047857] hover:underline font-bold cursor-pointer"
                  title="Volver a sincronizar los días de descanso médico del caso"
                >
                  Sincronizar
                </button>
              )}
            </div>
            <input
              type="number"
              min={0}
              value={formData.diasDescanso ?? 0}
              onChange={(e) => setFormData((prev) => ({ ...prev, diasDescanso: Number(e.target.value) || 0 }))}
              className="w-full bg-white border border-[#CBD5E1] rounded px-2 py-1 text-xs text-rose-700 font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 2: SNAPSHOT DEL TRABAJADOR AFECTADO */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A] flex items-center gap-2">
            <User className="w-4 h-4 text-[#0284C7]" />
            2. Datos del Trabajador Afectado (Snapshot Estático e Inmutable)
          </span>
          <span className="text-[11px] text-[#475569]">
            La modificación futura del colaborador en nómina no alterará este expediente histórico.
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">Nombre Completo</label>
            <input
              type="text"
              value={formData.datosTrabajador?.nombre}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  datosTrabajador: { ...prev.datosTrabajador!, nombre: e.target.value }
                }))
              }
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-semibold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">DNI</label>
            <input
              type="text"
              value={formData.datosTrabajador?.dni}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  datosTrabajador: { ...prev.datosTrabajador!, dni: e.target.value }
                }))
              }
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-mono font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">Edad al Ocurrir (Auto)</label>
            <input
              type="number"
              value={formData.datosTrabajador?.edad}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  datosTrabajador: { ...prev.datosTrabajador!, edad: Number(e.target.value) || 0 }
                }))
              }
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">Tiempo en el Puesto (Auto)</label>
            <input
              type="text"
              value={formData.datosTrabajador?.antiguedadPuesto}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  datosTrabajador: { ...prev.datosTrabajador!, antiguedadPuesto: e.target.value }
                }))
              }
              className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 3: DESCRIPCIÓN CIRCUNSTANCIAL Y TESTIGOS */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A] block">
            3. Descripción Circunstancial del Evento y Testigos
          </span>
          {selectedCaseId && formData.responsableArea && (
            <span className="text-[10px] text-[#047857] font-bold">
              ✓ Datos de jefe responsable y partes afectadas vinculados del caso {selectedCaseId}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">
              N° de Trabajadores Afectados <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <input
              type="number"
              min={1}
              required
              value={formData.numTrabajadoresAfectados ?? 1}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  numTrabajadoresAfectados: Math.max(1, parseInt(e.target.value) || 1)
                }))
              }
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-bold"
              placeholder="Ej: 1"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] text-[#475569] font-semibold">
                Jefe de Área / Responsable Inmediato (Heredado de Accidente de Trabajo) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
              </label>
            </div>
            <input
              type="text"
              required
              value={formData.responsableArea || ''}
              onChange={(e) => setFormData((prev) => ({ ...prev, responsableArea: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-medium"
              placeholder="Nombre y cargo del responsable inmediato del área..."
            />
          </div>
        </div>

        {/* Partes del cuerpo afectadas */}
        <div className="space-y-1.5 p-3 rounded-lg bg-white border border-[#E2E8F0]">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-semibold text-[#0F172A] flex items-center gap-1.5">
              <span>Partes del Cuerpo Afectadas (Datos registrados en Accidente de Trabajo)</span>
            </label>
            {(formData.partesCuerpoAfectadas || []).length > 0 && (
              <span className="text-[10px] font-mono text-[#047857] font-bold">
                {(formData.partesCuerpoAfectadas || []).length} seleccionada(s)
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {PARTES_CUERPO_AFECTADAS.map((op) => {
              const isSelected = (formData.partesCuerpoAfectadas || []).includes(op);
              return (
                <button
                  key={op}
                  type="button"
                  onClick={() => {
                    setFormData((prev) => {
                      const current = prev.partesCuerpoAfectadas || [];
                      const next = current.includes(op) ? current.filter((p) => p !== op) : [...current, op];
                      return { ...prev, partesCuerpoAfectadas: next };
                    });
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-100 border-[#047857] text-[#047857] font-bold shadow-2xs'
                      : 'bg-white border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1] hover:text-[#0F172A]'
                  }`}
                >
                  {isSelected ? '✓ ' : ''}{op}
                </button>
              );
            })}
          </div>
        </div>

        {/* Relato detallado y Testigos */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="sm:col-span-2">
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">
              Relato Detallado de los Hechos (Qué hacía, cómo ocurrió, dónde cayó) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <textarea
              rows={3}
              value={formData.descripcionCircunstancias}
              onChange={(e) => setFormData((prev) => ({ ...prev, descripcionCircunstancias: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              placeholder="Detalle la secuencia del evento..."
            />
          </div>
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">Testigos Presenciales</label>
            <textarea
              rows={3}
              value={formData.testigos}
              onChange={(e) => setFormData((prev) => ({ ...prev, testigos: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              placeholder="Nombres y cargos de quienes presenciaron el suceso..."
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 4 & 5: TIPO DE CONTACTO Y AGENTE CAUSANTE */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-[#0F172A] mb-1">
              4. Tipo de Contacto Normativo (Catálogo de 10) <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <select
              value={formData.tipoContacto}
              onChange={(e) => setFormData((prev) => ({ ...prev, tipoContacto: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              {CATALOGO_TIPOS_CONTACTO.map((tipo) => (
                <option key={tipo} value={tipo}>
                  {tipo}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-[#0F172A] mb-1">
              5. Agente Causante / Objeto del Contacto <span className="text-[#DC2626] font-bold ml-0.5" title="Campo obligatorio">*</span>
            </label>
            <input
              type="text"
              placeholder="Ej: Faja transportadora, vapor caliente, tubería a nivel de piso, cuchilla..."
              value={formData.agenteCausante}
              onChange={(e) => setFormData((prev) => ({ ...prev, agenteCausante: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 6: ACTOS SUBESTÁNDAR */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A]">
            6. Actos Subestándar Identificados (Catálogo de 15)
          </span>
          <span className="text-[11px] text-[#047857] font-mono font-bold">
            {formData.causasInmediatas?.actosSubestandar?.length || 0} seleccionados
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 max-h-52 overflow-y-auto p-2.5 bg-white rounded-lg border border-[#E2E8F0]">
          {CATALOGO_ACTOS_SUBESTANDAR.map((acto) => {
            const checked = formData.causasInmediatas?.actosSubestandar?.includes(acto) || false;
            return (
              <label
                key={acto}
                className={`flex items-start gap-2 p-2 rounded text-[11px] cursor-pointer transition-colors ${
                  checked ? 'bg-emerald-50 text-[#047857] border border-emerald-300 font-semibold' : 'text-[#475569] hover:bg-[#F1F5F9]'
                }`}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => {
                    setFormData((prev) => {
                      const current = prev.causasInmediatas?.actosSubestandar || [];
                      const updated = checked ? current.filter((a) => a !== acto) : [...current, acto];
                      return {
                        ...prev,
                        causasInmediatas: {
                          ...prev.causasInmediatas!,
                          actosSubestandar: updated
                        }
                      };
                    });
                  }}
                  className="mt-0.5 rounded border-[#CBD5E1] text-[#047857] focus:ring-[#10B981]"
                />
                <span>{acto}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* SECCIÓN 7: CONDICIONES SUBESTÁNDAR */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A]">
            7. Condiciones Subestándar Identificadas (Catálogo de 15)
          </span>
          <span className="text-[11px] text-[#B45309] font-mono font-bold">
            {formData.causasInmediatas?.condicionesSubestandar?.length || 0} seleccionadas
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 max-h-52 overflow-y-auto p-2.5 bg-white rounded-lg border border-[#E2E8F0]">
          {CATALOGO_CONDICIONES_SUBESTANDAR.map((cond) => {
            const checked = formData.causasInmediatas?.condicionesSubestandar?.includes(cond) || false;
            return (
              <label
                key={cond}
                className={`flex items-start gap-2 p-2 rounded text-[11px] cursor-pointer transition-colors ${
                  checked ? 'bg-amber-50 text-[#B45309] border border-amber-300 font-semibold' : 'text-[#475569] hover:bg-[#F1F5F9]'
                }`}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => {
                    setFormData((prev) => {
                      const current = prev.causasInmediatas?.condicionesSubestandar || [];
                      const updated = checked ? current.filter((c) => c !== cond) : [...current, cond];
                      return {
                        ...prev,
                        causasInmediatas: {
                          ...prev.causasInmediatas!,
                          condicionesSubestandar: updated
                        }
                      };
                    });
                  }}
                  className="mt-0.5 rounded border-[#CBD5E1] text-[#B45309] focus:ring-[#10B981]"
                />
                <span>{cond}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* SECCIÓN 8 & 9: FACTORES PERSONALES Y FACTORES DE TRABAJO */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Factores Personales */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#0F172A]">
              8. Factores Personales (Catálogo de 7)
            </span>
            <span className="text-[11px] text-[#0284C7] font-mono font-bold">
              {formData.causasBasicas?.factoresPersonales?.length || 0} seleccionados
            </span>
          </div>
          <div className="space-y-1.5 max-h-48 overflow-y-auto p-2.5 bg-white rounded-lg border border-[#E2E8F0]">
            {CATALOGO_FACTORES_PERSONALES.map((fp) => {
              const checked = formData.causasBasicas?.factoresPersonales?.includes(fp) || false;
              return (
                <label
                  key={fp}
                  className={`flex items-start gap-2 p-2 rounded text-[11px] cursor-pointer transition-colors ${
                    checked ? 'bg-sky-50 text-[#0284C7] border border-sky-300 font-semibold' : 'text-[#475569] hover:bg-[#F1F5F9]'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => {
                      setFormData((prev) => {
                        const current = prev.causasBasicas?.factoresPersonales || [];
                        const updated = checked ? current.filter((f) => f !== fp) : [...current, fp];
                        return {
                          ...prev,
                          causasBasicas: {
                            ...prev.causasBasicas!,
                            factoresPersonales: updated
                          }
                        };
                      });
                    }}
                    className="mt-0.5 rounded border-[#CBD5E1] text-[#0284C7] focus:ring-[#10B981]"
                  />
                  <span>{fp}</span>
                </label>
              );
            })}
          </div>
        </div>

        {/* Factores de Trabajo */}
        <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#0F172A]">
              9. Factores de Trabajo (Catálogo de 8)
            </span>
            <span className="text-[11px] text-[#6366F1] font-mono font-bold">
              {formData.causasBasicas?.factoresTrabajo?.length || 0} seleccionados
            </span>
          </div>
          <div className="space-y-1.5 max-h-48 overflow-y-auto p-2.5 bg-white rounded-lg border border-[#E2E8F0]">
            {CATALOGO_FACTORES_TRABAJO.map((ft) => {
              const checked = formData.causasBasicas?.factoresTrabajo?.includes(ft) || false;
              return (
                <label
                  key={ft}
                  className={`flex items-start gap-2 p-2 rounded text-[11px] cursor-pointer transition-colors ${
                    checked ? 'bg-indigo-50 text-[#4338CA] border border-indigo-300 font-semibold' : 'text-[#475569] hover:bg-[#F1F5F9]'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => {
                      setFormData((prev) => {
                        const current = prev.causasBasicas?.factoresTrabajo || [];
                        const updated = checked ? current.filter((f) => f !== ft) : [...current, ft];
                        return {
                          ...prev,
                          causasBasicas: {
                            ...prev.causasBasicas!,
                            factoresTrabajo: updated
                          }
                        };
                      });
                    }}
                    className="mt-0.5 rounded border-[#CBD5E1] text-[#4338CA] focus:ring-[#10B981]"
                  />
                  <span>{ft}</span>
                </label>
              );
            })}
          </div>
        </div>
      </div>

      {/* SECCIÓN 10: ANÁLISIS DE CAUSA RAÍZ */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F172A] flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-[#047857]" />
            10. Metodología de Causa Raíz
          </span>
          <div className="flex items-center gap-2">
            <label className="text-[11px] text-[#475569] font-semibold">Método:</label>
            <select
              value={formData.causaRaizMetodo}
              onChange={(e) => setFormData((prev) => ({ ...prev, causaRaizMetodo: e.target.value as any }))}
              className="bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-xs text-[#0F172A] font-bold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
            >
              <option value="5 Porqués">Método de los 5 Porqués</option>
              <option value="Ishikawa">Diagrama de Ishikawa (6M)</option>
            </select>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">
              Desarrollo del Análisis ({formData.causaRaizMetodo}) *
            </label>
            <textarea
              rows={4}
              value={formData.analisisCausaRaiz}
              onChange={(e) => setFormData((prev) => ({ ...prev, analisisCausaRaiz: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg p-2.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981] font-mono"
              placeholder="1. ¿Por qué ocurrió el hecho?...&#10;2. ¿Por qué?...&#10;3. ¿Por qué?...&#10;4. ¿Por qué?...&#10;5. ¿Por qué ocurrió la falla de control?"
            />
          </div>
          <div>
            <label className="block text-[11px] text-[#475569] mb-1 font-semibold">
              Conclusión de Causa Raíz Identificada *
            </label>
            <input
              type="text"
              value={formData.conclusionCausaRaiz}
              onChange={(e) => setFormData((prev) => ({ ...prev, conclusionCausaRaiz: e.target.value }))}
              className="w-full bg-white border border-[#CBD5E1] rounded-lg px-3 py-2 text-xs text-[#047857] font-bold placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
              placeholder="Defina la falla del sistema de gestión raíz a corregir..."
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 11: PLAN DE MEDIDAS CORRECTIVAS Y COMISIÓN INVESTIGADORA */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#0F172A] flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-[#047857]" />
              11. Plan de Medidas Correctivas y Comisión Investigadora
            </span>
            <p className="text-[11px] text-[#475569] mt-0.5">
              Formule las medidas preventivas/correctivas con jerarquía de controles y plazos.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAddMedida}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-[#1E293B] text-xs font-bold cursor-pointer transition-colors shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5 text-[#047857]" />
            <span>Agregar Medida</span>
          </button>
        </div>

        {/* Lista de Medidas */}
        <div className="space-y-2.5">
          {(formData.medidasCorrectivas || []).length === 0 ? (
            <div className="p-4 text-center text-xs text-[#475569] border border-dashed border-[#CBD5E1] rounded-lg bg-white">
              No hay medidas correctivas formuladas. Haga clic en "Agregar Medida".
            </div>
          ) : (
            formData.medidasCorrectivas?.map((med, mIdx) => (
              <div
                key={med.id || mIdx}
                className="p-3.5 rounded-lg bg-white border border-[#E2E8F0] shadow-2xs flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between"
              >
                <div className="flex-1 w-full space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] text-[10px] font-mono font-bold">
                      {med.id}
                    </span>
                    <select
                      value={med.tipoAccion}
                      onChange={(e) => {
                        const updated = [...(formData.medidasCorrectivas || [])];
                        updated[mIdx] = { ...updated[mIdx], tipoAccion: e.target.value as any };
                        setFormData((prev) => ({ ...prev, medidasCorrectivas: updated }));
                      }}
                      className="bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[11px] text-[#0F172A] font-semibold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    >
                      <option value="Eliminación">Eliminación</option>
                      <option value="Sustitución">Sustitución</option>
                      <option value="Control de Ingeniería">Control de Ingeniería</option>
                      <option value="Control Administrativo">Control Administrativo</option>
                      <option value="EPP">EPP</option>
                    </select>
                    <select
                      value={med.estado}
                      onChange={(e) => {
                        const updated = [...(formData.medidasCorrectivas || [])];
                        const newEstado = e.target.value as any;
                        updated[mIdx] = {
                          ...updated[mIdx],
                          estado: newEstado,
                          fechaVerificacion: newEstado === 'Verificada' ? new Date().toISOString().slice(0, 10) : undefined
                        };
                        setFormData((prev) => ({ ...prev, medidasCorrectivas: updated }));
                      }}
                      className={`rounded px-2.5 py-1 text-[11px] font-bold border ${
                        med.estado === 'Verificada'
                          ? 'bg-emerald-50 text-[#047857] border-emerald-300'
                          : med.estado === 'Implementada'
                          ? 'bg-blue-50 text-[#0284C7] border-blue-300'
                          : 'bg-amber-50 text-[#B45309] border-amber-300'
                      }`}
                    >
                      <option value="Pendiente">Pendiente</option>
                      <option value="Implementada">Implementada</option>
                      <option value="Verificada">Verificada</option>
                    </select>
                  </div>

                  <input
                    type="text"
                    placeholder="Descripción de la acción correctiva o preventiva..."
                    value={med.descripcion}
                    onChange={(e) => {
                      const updated = [...(formData.medidasCorrectivas || [])];
                      updated[mIdx] = { ...updated[mIdx], descripcion: e.target.value };
                      setFormData((prev) => ({ ...prev, medidasCorrectivas: updated }));
                    }}
                    className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                  />

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-[11px] w-full">
                    <div className="flex-1">
                      <label className="block text-[10px] text-[#475569] mb-0.5 font-semibold">
                        Responsable de la Medida (Autocompletar de base de trabajadores):
                      </label>
                      <input
                        type="text"
                        list={`list-trabajadores-medida-${mIdx}`}
                        placeholder="Escriba o seleccione responsable de nómina..."
                        value={med.responsable}
                        onChange={(e) => handleSelectResponsableMedida(mIdx, e.target.value)}
                        className="w-full bg-white border border-[#CBD5E1] rounded px-2.5 py-1 text-[#0F172A] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                      />
                      <datalist id={`list-trabajadores-medida-${mIdx}`}>
                        {trabajadoresActivos.map((t) => (
                          <option key={t.id || t.dni} value={t.apellidosNombres}>
                            {t.apellidosNombres} — {t.puesto} • {t.area} ({t.empresa})
                          </option>
                        ))}
                      </datalist>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                      <span className="text-[10px] text-[#475569] font-bold">Plazo:</span>
                      <input
                        type="date"
                        value={med.plazo}
                        onChange={(e) => {
                          const updated = [...(formData.medidasCorrectivas || [])];
                          updated[mIdx] = { ...updated[mIdx], plazo: e.target.value };
                          setFormData((prev) => ({ ...prev, medidasCorrectivas: updated }));
                        }}
                        className="bg-white border border-[#CBD5E1] rounded px-2 py-1 text-[#0F172A] text-xs focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setFormData((prev) => ({
                      ...prev,
                      medidasCorrectivas: prev.medidasCorrectivas?.filter((_, idx) => idx !== mIdx)
                    }));
                  }}
                  className="p-1.5 rounded hover:bg-rose-50 text-[#475569] hover:text-rose-600 self-center cursor-pointer transition-colors"
                  title="Eliminar medida"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Comisión Investigadora y Firmas */}
        <div className="pt-4 border-t border-[#E2E8F0] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-[#0F172A] flex items-center gap-1.5">
                <PenTool className="w-4 h-4 text-[#047857]" />
                Comisión Investigadora y Firmas Digitales (Captura Canvas en Google Drive)
              </span>
              <p className="text-[11px] text-[#475569] mt-0.5">
                Seleccione los miembros de la comisión, asigne sus roles normativos y registre su firma digital individual.
              </p>
            </div>
            <button
              type="button"
              onClick={handleAddInvestigador}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] border border-[#CBD5E1] text-[#1E293B] text-xs font-bold cursor-pointer transition-colors shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5 text-[#047857]" />
              <span>Agregar Miembro</span>
            </button>
          </div>

          <div className="space-y-3">
            {formData.investigadores?.map((inv, iIdx) => (
              <div
                key={iIdx}
                className="p-3.5 rounded-xl bg-white border border-[#E2E8F0] shadow-2xs space-y-3"
              >
                <div className="flex flex-col sm:flex-row gap-2.5 items-start sm:items-center justify-between">
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <span className="w-6 h-6 rounded-full bg-[#1E293B] text-white flex items-center justify-center text-[11px] font-bold shrink-0">
                      {iIdx + 1}
                    </span>
                    <select
                      value={inv.rol}
                      onChange={(e) => {
                        const updated = [...(formData.investigadores || [])];
                        updated[iIdx] = { ...updated[iIdx], rol: e.target.value as any };
                        setFormData((prev) => ({ ...prev, investigadores: updated }));
                      }}
                      className="bg-[#F8FAFC] border border-[#CBD5E1] rounded px-2.5 py-1 text-xs text-[#0F172A] font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    >
                      {ROLES_COMISION.map((rol) => (
                        <option key={rol} value={rol}>
                          {rol}
                        </option>
                      ))}
                    </select>
                  </div>

                  {formData.investigadores && formData.investigadores.length > 1 && (
                    <button
                      type="button"
                      onClick={() => {
                        setFormData((prev) => ({
                          ...prev,
                          investigadores: prev.investigadores?.filter((_, idx) => idx !== iIdx)
                        }));
                      }}
                      className="p-1 rounded text-[#475569] hover:text-rose-600 hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
                      title="Eliminar miembro de la comisión"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Nombre y Puesto */}
                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] text-[#475569] block mb-0.5 font-semibold">
                      Nombres y Apellidos (Autocompletar de base de trabajadores):
                    </label>
                    <input
                      type="text"
                      list={`list-inv-nombres-${iIdx}`}
                      placeholder="Escriba o seleccione nombre del miembro..."
                      value={inv.nombre}
                      onChange={(e) => handleInvestigadorNombreChange(iIdx, e.target.value)}
                      className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-semibold focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <datalist id={`list-inv-nombres-${iIdx}`}>
                      {trabajadoresActivos.map((t) => (
                        <option key={t.id || t.dni} value={t.apellidosNombres}>
                          {t.apellidosNombres} — {t.puesto} • {t.area} ({t.empresa})
                        </option>
                      ))}
                    </datalist>
                  </div>
                  <div>
                    <label className="text-[10px] text-[#475569] block mb-0.5 font-semibold">
                      Puesto / Cargo de Trabajo:
                    </label>
                    <input
                      type="text"
                      placeholder="Puesto de trabajo en la empresa..."
                      value={inv.cargo}
                      onChange={(e) => {
                        const updated = [...(formData.investigadores || [])];
                        updated[iIdx] = { ...updated[iIdx], cargo: e.target.value };
                        setFormData((prev) => ({ ...prev, investigadores: updated }));
                      }}
                      className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded px-2.5 py-1.5 text-xs text-[#0F172A] font-medium focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                  </div>
                </div>

                {/* Previsualización y firma */}
                <div className="pt-2.5 border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-2">
                  {typeof inv.firmaUrl === 'string' && inv.firmaUrl.trim().length > 0 ? (
                    <div className="flex items-center gap-2">
                      <img
                        src={inv.firmaUrl.trim()}
                        alt={`Firma de ${inv.nombre || 'Investigador'}`}
                        className="h-10 w-28 object-contain bg-white rounded border border-[#CBD5E1] p-0.5 shadow-2xs"
                      />
                      <div className="flex flex-col">
                        <span className="text-[10px] text-[#047857] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-[#047857]" />
                          Firmado ({inv.fechaFirma || 'Registrado'})
                        </span>
                        <span className="text-[9px] text-[#475569] font-mono truncate max-w-[120px]">
                          Google Drive
                        </span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-[11px] text-[#B45309] italic flex items-center gap-1 font-semibold">
                      <PenTool className="w-3.5 h-3.5 text-[#B45309]" />
                      Pendiente de firma
                    </span>
                  )}

                  <div className="flex items-center gap-1.5 ml-auto">
                    {inv.firmaUrl && (
                      <button
                        type="button"
                        onClick={() => handleClearSignature(iIdx)}
                        className="px-2 py-1 rounded bg-[#F1F5F9] hover:bg-rose-50 text-[#475569] hover:text-rose-600 border border-[#CBD5E1] text-xs font-medium cursor-pointer transition-colors"
                        title="Remover firma para volver a dibujar"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleOpenSignatureModal(iIdx)}
                      className="px-3 py-1.5 rounded-lg bg-[#047857] hover:bg-[#065F46] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                    >
                      <PenTool className="w-3.5 h-3.5" />
                      <span>{inv.firmaUrl ? 'Cambiar Firma' : 'Dibujar Firma'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Botones de pie */}
      <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E2E8F0]">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-[#475569] border border-[#CBD5E1] cursor-pointer transition-colors"
        >
          Cancelar
        </button>
        <button
          type="button"
          disabled={isSubmitting}
          onClick={() => handleSave(false)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#F1F5F9] hover:bg-[#E2E8F0] text-xs font-bold text-[#1E293B] border border-[#CBD5E1] transition-colors shadow-2xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
        >
          <Save className="w-4 h-4 text-[#475569]" />
          <span>Guardar Borrador</span>
        </button>
        <button
          type="button"
          disabled={isSubmitting}
          onClick={() => handleSave(true)}
          className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#047857] hover:bg-[#065F46] text-xs font-bold text-white transition-colors shadow-sm cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#10B981]"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Validar y Cerrar Investigación</span>
        </button>
      </div>
    </div>
  );
};
