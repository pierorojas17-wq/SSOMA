export * from '../../../types/modules/investigacion';
export type { AccidenteRecord, TrabajadorRecord } from '../../../types/modules';

export type InvestigacionTab = 'lista' | 'formulario';

export interface InvestigacionMetricas {
  total: number;
  abiertas: number;
  cerradas: number;
  totalMedidas: number;
  medidasVerificadas: number;
}
