import { InvestigacionRecord } from '../../../types/modules';
import { GasApiClient } from '../../../services/api';
import { DriveStorageService } from '../../../services/driveService';
import { ExportUtils } from '../../../utils/exportUtils';
import { EmpresaId } from '../../../types';

export class InvestigacionService {
  /**
   * Guarda o actualiza una investigación en Google Apps Script
   */
  static async saveInvestigacion(record: InvestigacionRecord) {
    return await GasApiClient.sendRequest({
      action: 'saveInvestigacion',
      sheetName: 'SSOMA_Investigaciones',
      data: record
    });
  }

  /**
   * Elimina una investigación en Google Apps Script
   */
  static async deleteInvestigacion(codigoInvestigacion: string) {
    return await GasApiClient.sendRequest({
      action: 'deleteInvestigacion',
      sheetName: 'SSOMA_Investigaciones',
      data: { codigoInvestigacion }
    });
  }

  /**
   * Sube una firma digital a Google Drive
   */
  static async uploadFirma(file: File, codigoInvestigacion: string, rol: string) {
    return await DriveStorageService.uploadToDrive(file, {
      modulo: 'investigacion',
      fileName: `Firma_${codigoInvestigacion}_${rol.replace(/\s+/g, '_')}_${Date.now()}.png`,
      maxDimension: 800,
      quality: 0.9
    });
  }

  /**
   * Exporta a Excel
   */
  static exportExcel(records: InvestigacionRecord[], filename: string) {
    const data = records.map((inv) => ({
      'Código Investigación': inv.codigoInvestigacion,
      'Código Accidente (M1)': inv.accidenteId,
      'Empresa': inv.empresa,
      'Fecha Investigación': inv.fechaInvestigacion,
      'Fecha Accidente': inv.fechaAccidente,
      'Trabajador (Snapshot)': inv.datosTrabajador?.nombre,
      'DNI': inv.datosTrabajador?.dni,
      'Edad': inv.datosTrabajador?.edad,
      'Puesto': inv.datosTrabajador?.puesto,
      'Área': inv.area,
      'Antigüedad en Puesto': inv.datosTrabajador?.antiguedadPuesto,
      'Tipo de Contacto': inv.tipoContacto,
      'Agente Causante': inv.agenteCausante,
      'Método Causa Raíz': inv.causaRaizMetodo,
      'Conclusión Causa Raíz': inv.conclusionCausaRaiz,
      'N° Medidas': (inv.medidasCorrectivas || []).length,
      'N° Medidas Verificadas': (inv.medidasCorrectivas || []).filter((m) => m.estado === 'Verificada').length,
      'Avance': `${inv.porcentajeAvance}%`,
      'Estado': inv.estado
    }));
    ExportUtils.exportToExcel(data, filename, 'Investigación de Accidentes');
  }

  /**
   * Exporta a PDF
   */
  static exportPDF(records: InvestigacionRecord[], filename: string, title: string, empresa: EmpresaId = 'CONSOLIDADO') {
    ExportUtils.exportToPdf({
      title,
      empresa,
      fileName: filename,
      headers: ['Código', 'Fecha Evento', 'Empresa', 'Trabajador Afectado', 'Área', 'Días Descanso', 'Estado'],
      rows: records.map((inv) => [
        inv.codigoInvestigacion,
        `${inv.fechaAccidente} ${inv.horaAccidente || ''}`.trim(),
        inv.empresa,
        `${inv.datosTrabajador?.nombre || '-'} (${inv.datosTrabajador?.dni || '-'})`,
        inv.area,
        inv.diasDescanso > 0 ? `${inv.diasDescanso} d.` : '0',
        inv.estado
      ]),
      orientation: 'landscape'
    });
  }
}
