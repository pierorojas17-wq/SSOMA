import { useState, useMemo, useRef, useEffect } from 'react';
import { useAppStore } from '../../../store/appStore';
import {
  InvestigacionRecord,
  AccidenteRecord,
  TrabajadorRecord
} from '../../../types/modules';
import { InvestigacionMetricas, InvestigacionTab } from '../types/investigacion';
import { InvestigacionService } from '../services/investigacionService';
import { DriveStorageService } from '../../../services/driveService';
import { GasApiClient } from '../../../services/api';
import {
  CATALOGO_TIPOS_CONTACTO,
  AREAS_EMPRESA
} from '../../../utils/ssomaCatalogs';
import { FilterChipOption } from '../../../components/common/ModuleToolbar';

export function useInvestigacion() {
  const {
    empresaActiva,
    accidentes,
    atencionesMedicas,
    trabajadores,
    investigaciones,
    upsertInvestigacion,
    batchUpsertInvestigaciones,
    removeInvestigacion,
    upsertAccidente,
    addToast,
    incrementSync,
    decrementSync
  } = useAppStore();

  // Estados de vista
  const [activeTab, setActiveTab] = useState<InvestigacionTab>('lista');
  const [searchTerm, setSearchTerm] = useState('');
  const [estadoFilter, setEstadoFilter] = useState<'TODOS' | 'Borrador' | 'En revision' | 'Cerrada'>('TODOS');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // Modales
  const [viewDetailModal, setViewDetailModal] = useState<InvestigacionRecord | null>(null);
  const [deleteModalInvestigacion, setDeleteModalInvestigacion] = useState<InvestigacionRecord | null>(null);

  // Canvas de Firma
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  const [currentInvestigadorIndex, setCurrentInvestigadorIndex] = useState<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isCanvasDrawing, setIsCanvasDrawing] = useState(false);
  const [hasCanvasStrokes, setHasCanvasStrokes] = useState(false);

  // Estados del Formulario
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [closureErrorsList, setClosureErrorsList] = useState<string[]>([]);
  const [selectedCaseId, setSelectedCaseId] = useState<string>('');

  // Paginación
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Estado del registro de investigación
  const [formData, setFormData] = useState<Partial<InvestigacionRecord>>({
    empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
    fechaInvestigacion: new Date().toISOString().slice(0, 10),
    fechaAccidente: new Date().toISOString().slice(0, 10),
    horaAccidente: '10:00',
    horaInicioLaboral: '07:00',
    turno: 'Mañana',
    area: '',
    lugarExacto: '',
    diasDescanso: 0,
    numTrabajadoresAfectados: 1,
    responsableArea: '',
    partesCuerpoAfectadas: [],
    datosTrabajador: {
      nombre: '',
      dni: '',
      edad: 0,
      genero: 'M',
      puesto: '',
      area: '',
      fechaIngreso: '',
      antiguedadPuesto: ''
    },
    descripcionCircunstancias: '',
    testigos: '',
    tipoContacto: CATALOGO_TIPOS_CONTACTO[0],
    agenteCausante: '',
    causasInmediatas: {
      actosSubestandar: [],
      condicionesSubestandar: []
    },
    causasBasicas: {
      factoresPersonales: [],
      factoresTrabajo: []
    },
    causaRaizMetodo: '5 Porqués',
    analisisCausaRaiz: '',
    conclusionCausaRaiz: '',
    medidasCorrectivas: [],
    investigadores: [
      {
        nombre: 'Ing. Supervisor SSOMA',
        cargo: 'Responsable de Seguridad y Salud Ocupacional',
        rol: 'Investigador Principal'
      }
    ],
    porcentajeAvance: 20,
    estado: 'Borrador'
  });

  // Filtrado de lista por empresa y estado
  const filteredInvestigaciones = useMemo(() => {
    return investigaciones.filter((item) => {
      if (empresaActiva !== 'CONSOLIDADO' && item.empresa !== empresaActiva) return false;
      if (estadoFilter !== 'TODOS' && item.estado !== estadoFilter) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchCode = String(item.codigoInvestigacion || '').toLowerCase().includes(q);
        const matchAcc = String(item.accidenteId || '').toLowerCase().includes(q);
        const matchWorker = String(item.datosTrabajador?.nombre || '').toLowerCase().includes(q);
        const matchDni = String(item.datosTrabajador?.dni || '').toLowerCase().includes(q);
        const matchArea = String(item.area || '').toLowerCase().includes(q);
        if (!matchCode && !matchAcc && !matchWorker && !matchDni && !matchArea) return false;
      }
      return true;
    });
  }, [investigaciones, empresaActiva, estadoFilter, searchTerm]);

  const statusOptions: FilterChipOption[] = useMemo(() => {
    const list = investigaciones.filter((i) => empresaActiva === 'CONSOLIDADO' || i.empresa === empresaActiva);
    return [
      { id: 'TODOS', label: 'Todos', count: list.length },
      { id: 'Borrador', label: 'Borradores', count: list.filter((i) => i.estado === 'Borrador').length },
      { id: 'En revision', label: 'En Revisión', count: list.filter((i) => i.estado === 'En revision').length },
      { id: 'Cerrada', label: 'Cerradas', count: list.filter((i) => i.estado === 'Cerrada').length }
    ];
  }, [investigaciones, empresaActiva]);

  const paginatedInvestigaciones = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredInvestigaciones.slice(start, start + pageSize);
  }, [filteredInvestigaciones, currentPage, pageSize]);

  // Lista de casos de accidentes elegibles para investigar
  const accidentesCandidatos = useMemo(() => {
    return accidentes.filter((acc) => {
      if (empresaActiva !== 'CONSOLIDADO' && acc.empresa !== empresaActiva) return false;
      return true;
    });
  }, [accidentes, empresaActiva]);

  // Áreas obtenidas del catálogo oficial de 29 áreas y de la base de trabajadores
  const areasTrabajadores = useMemo(() => {
    const setAreas = new Set<string>();
    AREAS_EMPRESA.forEach((a) => setAreas.add(a));
    trabajadores.forEach((t) => {
      const a = String(t.area || '').trim();
      if (a) setAreas.add(a);
    });
    return Array.from(setAreas).sort((a, b) => a.localeCompare(b));
  }, [trabajadores]);

  // Lista de trabajadores activos
  const trabajadoresActivos = useMemo(() => {
    if (!trabajadores || trabajadores.length === 0) return [];
    const list = trabajadores.filter((t) => t.condicion === 'Activo' || !t.condicion);
    const sourceList = list.length > 0 ? list : trabajadores;
    return [...sourceList].sort((a, b) => {
      if (formData.empresa) {
        if (a.empresa === formData.empresa && b.empresa !== formData.empresa) return -1;
        if (a.empresa !== formData.empresa && b.empresa === formData.empresa) return 1;
      }
      return String(a.apellidosNombres || '').localeCompare(String(b.apellidosNombres || ''));
    });
  }, [trabajadores, formData.empresa]);

  // Métricas de investigaciones
  const metricas: InvestigacionMetricas = useMemo(() => {
    const list = investigaciones.filter(
      (inv) => empresaActiva === 'CONSOLIDADO' || inv.empresa === empresaActiva
    );
    const total = list.length;
    const abiertas = list.filter((i) => i.estado === 'Borrador' || i.estado === 'En revision').length;
    const cerradas = list.filter((i) => i.estado === 'Cerrada').length;
    const totalMedidas = list.reduce((acc, i) => acc + (i.medidasCorrectivas?.length || 0), 0);
    const medidasVerificadas = list.reduce(
      (acc, i) => acc + (i.medidasCorrectivas?.filter((m) => m.estado === 'Verificada').length || 0),
      0
    );

    return {
      total,
      abiertas,
      cerradas,
      totalMedidas,
      medidasVerificadas
    };
  }, [investigaciones, empresaActiva]);

  // Inicializar Canvas de Firma
  const initializeCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 900;
    canvas.height = 270;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, 900, 270);

    ctx.strokeStyle = '#163D2C';
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    setHasCanvasStrokes(false);
  };

  useEffect(() => {
    if (isSignatureModalOpen) {
      setTimeout(initializeCanvas, 100);
    }
  }, [isSignatureModalOpen]);

  // Dibujo en Canvas
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsCanvasDrawing(true);
    setHasCanvasStrokes(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isCanvasDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isCanvasDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.closePath();
    setIsCanvasDrawing(false);
  };

  // Calcular Edad respecto al evento
  const calcularEdad = (fechaNacimiento: string | undefined, fechaEvento: string): number => {
    if (!fechaNacimiento) return 0;
    const dNac = new Date(fechaNacimiento);
    const dEvt = new Date(fechaEvento);
    let age = dEvt.getFullYear() - dNac.getFullYear();
    const m = dEvt.getMonth() - dNac.getMonth();
    if (m < 0 || (m === 0 && dEvt.getDate() < dNac.getDate())) {
      age--;
    }
    return Math.max(18, age);
  };

  // Calcular Antigüedad en el Puesto
  const calcularAntiguedad = (fechaIngreso: string | undefined, fechaEvento: string): string => {
    if (!fechaIngreso) return 'No registrada';
    const dIng = new Date(fechaIngreso);
    const dEvt = new Date(fechaEvento);
    if (isNaN(dIng.getTime()) || isNaN(dEvt.getTime())) return 'No registrada';

    let years = dEvt.getFullYear() - dIng.getFullYear();
    let months = dEvt.getMonth() - dIng.getMonth();

    if (months < 0) {
      years--;
      months += 12;
    }
    if (dEvt.getDate() < dIng.getDate()) {
      months--;
      if (months < 0) {
        years--;
        months += 12;
      }
    }

    if (years <= 0 && months <= 0) return 'Menos de 1 mes';
    if (years <= 0) return `${months} mes(es)`;
    return `${years} año(s), ${months} mes(es)`;
  };

  // Obtener días de descanso médico calculados
  const getDiasDescansoCaso = (accCase?: AccidenteRecord | null): number => {
    if (!accCase) return 0;
    const atnsCaso = (atencionesMedicas || []).filter(
      (m) =>
        (m.idAccidente && (String(m.idAccidente) === String(accCase.id) || String(m.idAccidente) === String(accCase.codigoCaso))) ||
        (m.codigoAccidente && (String(m.codigoAccidente) === String(accCase.codigoCaso) || String(m.codigoAccidente) === String(accCase.id)))
    );
    const diasDesdeAtenciones = atnsCaso.reduce(
      (sum, m) => sum + (Number(m.diasDescanso) || 0),
      0
    );
    const rawAcc = accCase as any;
    const diasDirectosAcc =
      Number(accCase.diasDescanso) ||
      Number(rawAcc.diasDescansoMedico) ||
      Number(rawAcc['diasDescanso']) ||
      Number(rawAcc['diasDescansoMedico']) ||
      Number(rawAcc['Días Descanso']) ||
      Number(rawAcc['Días Descanso Médico']) ||
      Number(rawAcc['Dias Descanso']) ||
      Number(rawAcc['Dias Descanso Medico']) ||
      Number(rawAcc.diasPerdidos) ||
      0;
    return diasDesdeAtenciones > 0 ? diasDesdeAtenciones : diasDirectosAcc;
  };

  // createDraft: copia información de Módulo 1 y genera snapshot estático
  const createDraftFromCase = (caseId: string) => {
    const acc = accidentes.find((a) => a.id === caseId || a.codigoCaso === caseId);
    if (!acc) return;

    setSelectedCaseId(acc.codigoCaso);

    const worker = trabajadores.find(
      (t) =>
        (t.dni && String(t.dni).trim() === String(acc.trabajadorDni || '').trim()) ||
        (t.apellidosNombres && String(t.apellidosNombres).trim().toLowerCase() === String(acc.trabajadorNombre || '').trim().toLowerCase())
    );

    const edad = calcularEdad(worker?.fechaNacimiento, acc.fecha);
    const antiguedad = calcularAntiguedad(worker?.fechaIngreso, acc.fecha);
    const diasDescansoCalculados = getDiasDescansoCaso(acc);

    const horaInicioDefault = acc.turno === 'Tarde' ? '15:00' : acc.turno === 'Noche' ? '23:00' : '07:00';
    const empresaAuto = (worker?.empresa || acc.empresa) as 'PERPOL' | 'TR3';
    const areaAuto = worker?.area || acc.area || '';

    setFormData((prev) => ({
      ...prev,
      accidenteId: acc.codigoCaso,
      empresa: empresaAuto,
      fechaAccidente: acc.fecha,
      horaAccidente: acc.hora,
      horaInicioLaboral: prev.horaInicioLaboral || horaInicioDefault,
      turno: acc.turno,
      area: areaAuto,
      lugarExacto: acc.lugarExacto,
      diasDescanso: diasDescansoCalculados,
      numTrabajadoresAfectados: prev.numTrabajadoresAfectados || 1,
      responsableArea: acc.responsableArea || '',
      partesCuerpoAfectadas: Array.isArray(acc.partesCuerpoAfectadas) ? acc.partesCuerpoAfectadas : [],
      descripcionCircunstancias: acc.descripcion,
      datosTrabajador: {
        nombre: worker?.apellidosNombres || acc.trabajadorNombre,
        dni: worker?.dni || acc.trabajadorDni,
        edad: edad || ((acc as any).edad ? Number((acc as any).edad) : 30),
        genero: worker?.sexo || 'M',
        puesto: worker?.puesto || acc.cargo,
        area: areaAuto,
        fechaIngreso: worker?.fechaIngreso || '',
        antiguedadPuesto: antiguedad
      },
      conclusionCausaRaiz: acc.causaInmediata || '',
      investigadores: prev.investigadores?.length
        ? prev.investigadores
        : [
            {
              nombre: 'Ing. Supervisor SSOMA',
              cargo: 'Responsable de Seguridad y Salud Ocupacional',
              rol: 'Investigador Principal'
            }
          ]
    }));

    addToast({
      type: 'info',
      title: 'Snapshot Generado',
      message: `Copiados datos del caso ${acc.codigoCaso} (Empresa: ${empresaAuto}, Área: ${areaAuto || 'N/A'}) y colaborador ${acc.trabajadorNombre} como copia estática.`
    });
  };

  // Cálculo del porcentaje de avance del formulario
  const calculateProgress = (): number => {
    let score = 0;
    if (formData.accidenteId) score += 10;
    if (formData.datosTrabajador?.nombre && formData.datosTrabajador?.dni) score += 15;
    if (formData.descripcionCircunstancias) score += 10;
    if (formData.tipoContacto && formData.agenteCausante) score += 10;
    if (
      (formData.causasInmediatas?.actosSubestandar?.length || 0) > 0 ||
      (formData.causasInmediatas?.condicionesSubestandar?.length || 0) > 0
    ) {
      score += 15;
    }
    if (
      (formData.causasBasicas?.factoresPersonales?.length || 0) > 0 ||
      (formData.causasBasicas?.factoresTrabajo?.length || 0) > 0
    ) {
      score += 15;
    }
    if (formData.analisisCausaRaiz && formData.conclusionCausaRaiz) score += 15;
    if ((formData.medidasCorrectivas?.length || 0) > 0) score += 10;
    return Math.min(100, score);
  };

  // closureErrors: regla estricta que bloquea el cierre
  const validateClosureRules = (): string[] => {
    const errors: string[] = [];

    if (!String(formData.descripcionCircunstancias || '').trim()) {
      errors.push('Falta detallar la descripción circunstancial del evento.');
    }
    if (!String(formData.tipoContacto || '').trim()) {
      errors.push('Debe seleccionar el Tipo de Contacto normativo.');
    }
    if (!String(formData.agenteCausante || '').trim()) {
      errors.push('Debe especificar el Agente Causante del daño/lesión.');
    }
    if (!String(formData.analisisCausaRaiz || '').trim() || !String(formData.conclusionCausaRaiz || '').trim()) {
      errors.push('Debe completar el Análisis de Causa Raíz (5 Porqués / Ishikawa) y su Conclusión.');
    }

    const medidas = formData.medidasCorrectivas || [];
    if (medidas.length === 0) {
      errors.push('Debe registrar al menos una medida correctiva.');
    } else {
      const tieneVerificada = medidas.some((m) => m.estado === 'Verificada');
      if (!tieneVerificada) {
        errors.push('Regla de Cierre: Al menos una medida correctiva debe estar en estado "Verificada".');
      }
    }

    const investigadoresConFirma = (formData.investigadores || []).filter((inv) => !!inv.firmaUrl);
    if (investigadoresConFirma.length === 0) {
      errors.push('Regla de Cierre: La comisión debe registrar al menos una firma digital en el canvas.');
    }

    return errors;
  };

  // Abrir modal de firma
  const handleOpenSignatureModal = (index: number) => {
    setCurrentInvestigadorIndex(index);
    setIsSignatureModalOpen(true);
  };

  // Guardar firma desde canvas a Google Drive
  const handleSaveSignature = async () => {
    if (!hasCanvasStrokes) {
      addToast({
        type: 'warning',
        title: 'Trazo Requerido',
        message: 'Debe dibujar la firma en el recuadro antes de confirmarla.'
      });
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas || currentInvestigadorIndex === null) return;

    try {
      addToast({
        type: 'info',
        title: 'Procesando Firma',
        message: 'Optimizando trazo para envío seguro a Google Drive...'
      });

      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      const file = new File([blob], `Firma_Investigador_${Date.now()}.jpg`, { type: 'image/jpeg' });

      const invActual = currentInvestigadorIndex !== null && formData.investigadores ? formData.investigadores[currentInvestigadorIndex] : null;
      const nombreLimpio = invActual?.nombre ? invActual.nombre.replace(/[^a-zA-Z0-9]/g, '_') : 'Investigador';
      const uploadRes = await DriveStorageService.uploadToDrive(file, {
        modulo: 'investigacion',
        fileName: `Firma_${formData.empresa || 'SST'}_${nombreLimpio}_${Date.now()}.jpg`,
        maxDimension: 900,
        quality: 0.85
      });

      if (uploadRes.fileUrl) {
        setFormData((prev) => {
          const updatedInvestigadores = [...(prev.investigadores || [])];
          if (updatedInvestigadores[currentInvestigadorIndex]) {
            updatedInvestigadores[currentInvestigadorIndex] = {
              ...updatedInvestigadores[currentInvestigadorIndex],
              firmaUrl: uploadRes.fileUrl,
              firmaDriveId: uploadRes.fileId,
              fechaFirma: new Date().toISOString().slice(0, 10)
            };
          }
          return { ...prev, investigadores: updatedInvestigadores };
        });

        addToast({
          type: 'success',
          title: 'Firma Registrada',
          message: 'Firma digital vinculada a la investigación con éxito.'
        });
      }

      setIsSignatureModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar la firma';
      addToast({ type: 'error', title: 'Error de Firma', message: msg });
    }
  };

  // Cambio de nombre de investigador
  const handleInvestigadorNombreChange = (index: number, nombre: string) => {
    const cleanNombre = nombre.trim().toLowerCase();
    const matchedWorker = trabajadoresActivos.find(
      (t) =>
        t.apellidosNombres.toLowerCase() === cleanNombre ||
        String(t.dni || '').trim() === cleanNombre
    );
    setFormData((prev) => {
      const updated = [...(prev.investigadores || [])];
      if (updated[index]) {
        updated[index] = {
          ...updated[index],
          nombre: matchedWorker ? matchedWorker.apellidosNombres : nombre,
          cargo: matchedWorker ? (matchedWorker.puesto || matchedWorker.area || updated[index].cargo) : updated[index].cargo
        };
      }
      return { ...prev, investigadores: updated };
    });
  };

  // Asignar Responsable en Medida Correctiva
  const handleSelectResponsableMedida = (index: number, valor: string) => {
    const cleanVal = valor.trim().toLowerCase();
    const worker = trabajadoresActivos.find(
      (t) =>
        t.apellidosNombres.toLowerCase() === cleanVal ||
        String(t.dni || '').trim() === cleanVal
    );
    const nombre = worker ? worker.apellidosNombres : valor;
    setFormData((prev) => {
      const updated = [...(prev.medidasCorrectivas || [])];
      if (updated[index]) {
        updated[index] = {
          ...updated[index],
          responsable: nombre
        };
      }
      return { ...prev, medidasCorrectivas: updated };
    });
  };

  // Limpiar firma de un miembro
  const handleClearSignature = (index: number) => {
    setFormData((prev) => {
      const updated = [...(prev.investigadores || [])];
      if (updated[index]) {
        updated[index] = {
          ...updated[index],
          firmaUrl: undefined,
          firmaDriveId: undefined,
          fechaFirma: undefined
        };
      }
      return { ...prev, investigadores: updated };
    });
    addToast({
      type: 'info',
      title: 'Firma Removida',
      message: 'Se removió la firma del integrante. Puede volver a dibujar la firma en el canvas.'
    });
  };

  // Añadir Investigador
  const handleAddInvestigador = () => {
    setFormData((prev) => ({
      ...prev,
      investigadores: [
        ...(prev.investigadores || []),
        {
          nombre: '',
          cargo: '',
          rol: 'Responsable del área'
        }
      ]
    }));
  };

  // Añadir Medida Correctiva
  const handleAddMedida = () => {
    const newId = `MED-${String((formData.medidasCorrectivas?.length || 0) + 1).padStart(3, '0')}`;
    setFormData((prev) => ({
      ...prev,
      medidasCorrectivas: [
        ...(prev.medidasCorrectivas || []),
        {
          id: newId,
          descripcion: '',
          tipoAccion: 'Control de Ingeniería',
          responsable: '',
          plazo: new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10),
          estado: 'Pendiente'
        }
      ]
    }));
  };

  // Guardar Borrador o Cerrar Investigación
  const handleSave = async (intentarCerrar: boolean = false) => {
    setFormError(null);
    setClosureErrorsList([]);

    if (!formData.accidenteId) {
      setFormError('Debe asociar un caso de accidente (Módulo 1).');
      return;
    }
    if (!formData.datosTrabajador?.nombre) {
      setFormError('Debe ingresar o seleccionar el trabajador afectado.');
      return;
    }

    if (intentarCerrar) {
      const errors = validateClosureRules();
      if (errors.length > 0) {
        setClosureErrorsList(errors);
        addToast({
          type: 'error',
          title: 'Bloqueo de Cierre (Regla Normativa)',
          message: 'No es posible cerrar la investigación hasta subsanar los requisitos obligatorios.'
        });
        return;
      }
    }

    setIsSubmitting(true);
    incrementSync();

    try {
      const anio = new Date().getFullYear();
      const totalAnio = investigaciones.filter((inv) => {
        const f = inv.fechaInvestigacion || inv.fechaAccidente || '';
        return f.startsWith(String(anio)) || (inv.codigoInvestigacion && inv.codigoInvestigacion.includes(`-${anio}-`));
      }).length;
      const existingInv = editingId ? investigaciones.find((inv) => inv.id === editingId || inv.codigoInvestigacion === editingId) : null;
      const correlativoCodigo =
        formData.codigoInvestigacion ||
        existingInv?.codigoInvestigacion ||
        (editingId && !editingId.includes('-17') && !editingId.includes('-16') ? editingId : undefined) ||
        `INV-${anio}-${String(totalAnio + 1).padStart(4, '0')}`;

      const nuevoEstado: 'Borrador' | 'En revision' | 'Cerrada' = intentarCerrar
        ? 'Cerrada'
        : calculateProgress() >= 80
        ? 'En revision'
        : 'Borrador';

      const fullRecord: InvestigacionRecord = {
        id: editingId || correlativoCodigo,
        codigoInvestigacion: correlativoCodigo,
        accidenteId: formData.accidenteId!,
        empresa: formData.empresa as 'PERPOL' | 'TR3',
        fechaInvestigacion: formData.fechaInvestigacion || new Date().toISOString().slice(0, 10),
        fechaAccidente: formData.fechaAccidente!,
        horaAccidente: formData.horaAccidente || '10:00',
        horaInicioLaboral: formData.horaInicioLaboral || '',
        turno: formData.turno || 'Mañana',
        area: formData.area || '',
        lugarExacto: formData.lugarExacto || '',
        diasDescanso: Number(formData.diasDescanso) || 0,
        numTrabajadoresAfectados: Number(formData.numTrabajadoresAfectados) || 1,
        responsableArea: formData.responsableArea || '',
        partesCuerpoAfectadas: Array.isArray(formData.partesCuerpoAfectadas) ? formData.partesCuerpoAfectadas : [],
        datosTrabajador: {
          nombre: formData.datosTrabajador!.nombre,
          dni: formData.datosTrabajador!.dni,
          edad: Number(formData.datosTrabajador!.edad) || 30,
          genero: formData.datosTrabajador!.genero || 'M',
          puesto: formData.datosTrabajador!.puesto || '',
          area: formData.datosTrabajador!.area || '',
          fechaIngreso: formData.datosTrabajador!.fechaIngreso || '',
          antiguedadPuesto: formData.datosTrabajador!.antiguedadPuesto || ''
        },
        descripcionCircunstancias: formData.descripcionCircunstancias || '',
        testigos: formData.testigos || '',
        tipoContacto: formData.tipoContacto || CATALOGO_TIPOS_CONTACTO[0],
        agenteCausante: formData.agenteCausante || '',
        causasInmediatas: {
          actosSubestandar: formData.causasInmediatas?.actosSubestandar || [],
          condicionesSubestandar: formData.causasInmediatas?.condicionesSubestandar || []
        },
        causasBasicas: {
          factoresPersonales: formData.causasBasicas?.factoresPersonales || [],
          factoresTrabajo: formData.causasBasicas?.factoresTrabajo || []
        },
        causaRaizMetodo: formData.causaRaizMetodo || '5 Porqués',
        analisisCausaRaiz: formData.analisisCausaRaiz || '',
        conclusionCausaRaiz: formData.conclusionCausaRaiz || '',
        medidasCorrectivas: formData.medidasCorrectivas || [],
        investigadores: formData.investigadores || [],
        porcentajeAvance: calculateProgress(),
        estado: nuevoEstado,
        fechaCierre: nuevoEstado === 'Cerrada' ? new Date().toISOString().slice(0, 10) : undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      upsertInvestigacion(fullRecord);

      if (nuevoEstado === 'Cerrada') {
        const accTarget = accidentes.find(
          (a) => a.id === fullRecord.accidenteId || a.codigoCaso === fullRecord.accidenteId
        );
        if (accTarget) {
          upsertAccidente({
            ...accTarget,
            estadoCaso: 'Cerrado',
            fechaCierre: new Date().toISOString().slice(0, 10),
            conclusionesInvestigacion: fullRecord.conclusionCausaRaiz
          });
        }
      }

      const apiRes = await GasApiClient.sendRequest({
        action: 'persistDraft',
        sheetName: 'SSOMA_Investigaciones',
        data: fullRecord
      });

      if (apiRes.success) {
        addToast({
          type: 'success',
          title: 'Investigación Guardada',
          message: `${correlativoCodigo} persistido en Sheets (Avance: ${fullRecord.porcentajeAvance}%).`
        });
      } else {
        addToast({
          type: 'warning',
          title: 'Almacenado Local',
          message: 'Investigación guardada localmente.'
        });
      }

      if (intentarCerrar) {
        setActiveTab('lista');
        setEditingId(null);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al guardar la investigación';
      setFormError(msg);
      addToast({ type: 'error', title: 'Error', message: msg });
    } finally {
      setIsSubmitting(false);
      decrementSync();
    }
  };

  const handleExportarExcel = () => {
    InvestigacionService.exportExcel(
      filteredInvestigaciones,
      `SSOMA_Investigaciones_${empresaActiva}_${new Date().toISOString().slice(0, 10)}`
    );
    addToast({ type: 'success', title: 'Exportación', message: 'Reporte de investigaciones descargado.' });
  };

  const handleExportarPDF = () => {
    InvestigacionService.exportPDF(
      filteredInvestigaciones,
      `Investigaciones_${empresaActiva}`,
      `REGISTRO DE INVESTIGACIÓN DE ACCIDENTES E INCIDENTES - ${empresaActiva}`
    );
    addToast({ type: 'success', title: 'PDF Generado', message: 'Reporte de investigaciones descargado.' });
  };

  const confirmDeleteInvestigacion = async () => {
    if (!deleteModalInvestigacion) return;
    const item = deleteModalInvestigacion;
    removeInvestigacion(item.id);
    addToast({ type: 'info', title: 'Eliminado', message: `Investigación ${item.codigoInvestigacion} borrada.` });
    setDeleteModalInvestigacion(null);
  };

  const handleNuevo = () => {
    setEditingId(null);
    setFormData({
      empresa: empresaActiva === 'TR3' ? 'TR3' : 'PERPOL',
      fechaInvestigacion: new Date().toISOString().slice(0, 10),
      fechaAccidente: new Date().toISOString().slice(0, 10),
      horaAccidente: '10:00',
      horaInicioLaboral: '07:00',
      turno: 'Mañana',
      area: '',
      lugarExacto: '',
      diasDescanso: 0,
      numTrabajadoresAfectados: 1,
      responsableArea: '',
      partesCuerpoAfectadas: [],
      datosTrabajador: {
        nombre: '',
        dni: '',
        edad: 0,
        genero: 'M',
        puesto: '',
        area: '',
        fechaIngreso: '',
        antiguedadPuesto: ''
      },
      descripcionCircunstancias: '',
      testigos: '',
      tipoContacto: CATALOGO_TIPOS_CONTACTO[0],
      agenteCausante: '',
      causasInmediatas: { actosSubestandar: [], condicionesSubestandar: [] },
      causasBasicas: { factoresPersonales: [], factoresTrabajo: [] },
      causaRaizMetodo: '5 Porqués',
      analisisCausaRaiz: '',
      conclusionCausaRaiz: '',
      medidasCorrectivas: [],
      investigadores: [
        {
          nombre: 'Ing. Supervisor SSOMA',
          cargo: 'Responsable de Seguridad y Salud Ocupacional',
          rol: 'Investigador Principal'
        }
      ],
      porcentajeAvance: 20,
      estado: 'Borrador'
    });
    setSelectedCaseId('');
    setClosureErrorsList([]);
    setFormError(null);
    setActiveTab('formulario');
  };

  const handleEdit = (item: InvestigacionRecord) => {
    setEditingId(item.id);
    setFormData(item);
    setSelectedCaseId(item.accidenteId);
    setClosureErrorsList([]);
    setActiveTab('formulario');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return {
    empresaActiva,
    activeTab,
    setActiveTab,
    searchTerm,
    setSearchTerm,
    estadoFilter,
    setEstadoFilter,
    statusOptions,
    isImportModalOpen,
    setIsImportModalOpen,
    viewDetailModal,
    setViewDetailModal,
    deleteModalInvestigacion,
    setDeleteModalInvestigacion,
    isSignatureModalOpen,
    setIsSignatureModalOpen,
    currentInvestigadorIndex,
    canvasRef,
    currentPage,
    setCurrentPage,
    pageSize,
    setPageSize,
    editingId,
    setEditingId,
    isSubmitting,
    formError,
    closureErrorsList,
    selectedCaseId,
    formData,
    setFormData,
    filteredInvestigaciones,
    paginatedInvestigaciones,
    accidentesCandidatos,
    accidentes,
    areasTrabajadores,
    trabajadoresActivos,
    metricas,
    initializeCanvas,
    startDrawing,
    draw,
    stopDrawing,
    getDiasDescansoCaso,
    createDraftFromCase,
    calculateProgress,
    handleOpenSignatureModal,
    handleSaveSignature,
    handleInvestigadorNombreChange,
    handleSelectResponsableMedida,
    handleClearSignature,
    handleAddInvestigador,
    handleAddMedida,
    handleSave,
    handleExportarExcel,
    handleExportarPDF,
    confirmDeleteInvestigacion,
    handleNuevo,
    handleEdit,
    batchUpsertInvestigaciones
  };
}
