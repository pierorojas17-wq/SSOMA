import { useState } from 'react';
import { inspectFile, parseExcelSheet, parseCsv, SpreadsheetInfo, ParseResult } from '../utils/import';
import { useToast } from './useToast';

export function useImport() {
  const [loading, setLoading] = useState(false);
  const [fileInfo, setFileInfo] = useState<SpreadsheetInfo | null>(null);
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const { showError } = useToast();

  const handleInspect = async (file: File) => {
    try {
      setLoading(true);
      const info = await inspectFile(file);
      setFileInfo(info);
      return info;
    } catch (err: unknown) {
      showError('Error de archivo', err instanceof Error ? err.message : 'No se pudo leer el archivo.');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const handleParse = async (file: File, sheetName?: string) => {
    try {
      setLoading(true);
      const extension = file.name.split('.').pop()?.toLowerCase();
      let res: ParseResult;
      if (extension === 'csv') {
        res = await parseCsv(file);
      } else {
        res = await parseExcelSheet(file, sheetName);
      }
      setParseResult(res);
      return res;
    } catch (err: unknown) {
      showError('Error de importación', err instanceof Error ? err.message : 'Error al procesar los datos.');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setFileInfo(null);
    setParseResult(null);
  };

  return {
    loading,
    fileInfo,
    parseResult,
    inspectFile: handleInspect,
    parseFile: handleParse,
    reset
  };
}
