import { useState } from 'react';
import { exportToExcel, exportToPdf, exportToCsv, PdfExportOptions } from '../utils/export';
import { useToast } from './useToast';

export function useExport() {
  const [exporting, setExporting] = useState(false);
  const { showSuccess, showError } = useToast();

  const handleExportExcel = async <T extends Record<string, unknown>>(
    data: T[],
    fileName: string,
    sheetName?: string
  ) => {
    try {
      setExporting(true);
      exportToExcel(data, fileName, sheetName);
      showSuccess('Exportación Exitosa', `Archivo ${fileName}.xlsx descargado correctamente.`);
      return true;
    } catch (err: unknown) {
      showError('Error al exportar', err instanceof Error ? err.message : 'No se pudo generar el archivo Excel.');
      return false;
    } finally {
      setExporting(false);
    }
  };

  const handleExportPdf = async (options: PdfExportOptions) => {
    try {
      setExporting(true);
      exportToPdf(options);
      showSuccess('PDF Generado', `Reporte ${options.fileName}.pdf descargado correctamente.`);
      return true;
    } catch (err: unknown) {
      showError('Error al exportar', err instanceof Error ? err.message : 'No se pudo generar el reporte PDF.');
      return false;
    } finally {
      setExporting(false);
    }
  };

  const handleExportCsv = async <T extends Record<string, unknown>>(
    data: T[],
    fileName: string
  ) => {
    try {
      setExporting(true);
      exportToCsv(data, fileName);
      showSuccess('CSV Descargado', `Archivo ${fileName}.csv descargado correctamente.`);
      return true;
    } catch (err: unknown) {
      showError('Error al exportar', err instanceof Error ? err.message : 'No se pudo generar el archivo CSV.');
      return false;
    } finally {
      setExporting(false);
    }
  };

  return {
    exporting,
    exportToExcel: handleExportExcel,
    exportToPdf: handleExportPdf,
    exportToCsv: handleExportCsv
  };
}
