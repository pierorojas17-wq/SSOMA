import {
  useQuery,
  useMutation,
  useQueryClient,
  UseQueryOptions,
  UseMutationOptions
} from '@tanstack/react-query';

/**
 * Hook genérico para consultar datos de módulos SSOMA con caché inteligente
 * Aplica staleTime de 5 min y gcTime de 10 min por defecto.
 */
export function useModuleData<T>(
  moduleKey: string | readonly unknown[],
  fetchFn: () => Promise<T>,
  options?: Omit<UseQueryOptions<T, Error, T, readonly unknown[]>, 'queryKey' | 'queryFn'>
) {
  const queryKey = Array.isArray(moduleKey) ? moduleKey : [moduleKey];

  return useQuery<T, Error, T, readonly unknown[]>({
    queryKey,
    queryFn: fetchFn,
    staleTime: 5 * 60 * 1000, // 5 minutos de frescura de caché
    gcTime: 10 * 60 * 1000,    // 10 minutos antes de recolección de basura
    retry: 2,
    refetchOnWindowFocus: false,
    ...options
  });
}

/**
 * Hook genérico para mutaciones de módulos con invalidación automática de caché
 */
export function useModuleMutation<TData, TVariables = void>(
  moduleKey: string | readonly unknown[],
  mutationFn: (variables: TVariables) => Promise<TData>,
  options?: UseMutationOptions<TData, Error, TVariables>
) {
  const queryClient = useQueryClient();
  const targetKey = Array.isArray(moduleKey) ? moduleKey : [moduleKey];

  return useMutation<TData, Error, TVariables>({
    mutationFn,
    onSuccess: (...args: any[]) => {
      // Invalida la caché del módulo para refrescar datos automáticamente
      queryClient.invalidateQueries({ queryKey: targetKey });
      if (options?.onSuccess) {
        (options.onSuccess as any)(...args);
      }
    },
    ...options
  });
}
