import { useAppStore } from '../store/appStore';
import { ThemeColor, ThemeBackground } from '../types/theme';

export function useTheme() {
  const themeColor = useAppStore((state) => state.themeColor);
  const customBrandHex = useAppStore((state) => state.customBrandHex);
  const themeBackground = useAppStore((state) => state.themeBackground);
  const setThemeColor = useAppStore((state) => state.setThemeColor);
  const setCustomBrandHex = useAppStore((state) => state.setCustomBrandHex);
  const setThemeBackground = useAppStore((state) => state.setThemeBackground);
  const resetTheme = useAppStore((state) => state.resetTheme);

  return {
    themeColor,
    customBrandHex,
    themeBackground,
    setThemeColor: (color: ThemeColor) => setThemeColor(color),
    setCustomBrandHex: (hex: string) => setCustomBrandHex(hex),
    setThemeBackground: (bg: ThemeBackground) => setThemeBackground(bg),
    resetTheme
  };
}
