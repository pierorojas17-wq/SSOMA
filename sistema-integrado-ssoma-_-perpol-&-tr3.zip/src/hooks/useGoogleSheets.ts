import { useState } from 'react';
import { useAppStore } from '../store/appStore';
import { GasApiClient } from '../services/api';
import { useToast } from './useToast';
import { queryClient } from '../services/queryClient';

export function useGoogleSheets() {
  const {
    isBackendConnected,
    isSyncingWithSheets,
    lastSyncSheetsTime,
    totalSincronizadosSheets,
    setIsSyncingWithSheets,
    cargarDatosDesdeSheets,
    gasWebAppUrl
  } = useAppStore();

  const { showSuccess, showError, showWarning } = useToast();
  const [syncing, setSyncing] = useState(false);

  const sincronizar = async (mostrarNotificacion = true) => {
    if (!gasWebAppUrl && !window.google?.script?.run) {
      if (mostrarNotificacion) {
        showWarning('Desconectado', 'No se ha configurado la URL de Google Apps Script.');
      }
      return false;
    }

    try {
      setSyncing(true);
      setIsSyncingWithSheets(true);

      const res = await GasApiClient.obtenerDatosGoogleSheets();
      if (res && res.success && res.data) {
        cargarDatosDesdeSheets(res.data);
        // Invalida caché de TanStack Query para reflejar los datos frescos de Sheets
        queryClient.invalidateQueries();
        if (mostrarNotificacion) {
          const total = useAppStore.getState().totalSincronizadosSheets;
          showSuccess('Sincronización Exitosa', `Se actualizaron ${total} registros desde Google Sheets.`);
        }
        return true;
      } else {
        if (mostrarNotificacion) {
          showError('Error de sincronización', res?.error || res?.message || 'No se pudieron descargar los datos.');
        }
        return false;
      }
    } catch (err: unknown) {
      if (mostrarNotificacion) {
        showError('Fallo de red', err instanceof Error ? err.message : 'Error al conectar con Google Sheets.');
      }
      return false;
    } finally {
      setSyncing(false);
      setIsSyncingWithSheets(false);
    }
  };

  return {
    isBackendConnected,
    isSyncing: syncing || isSyncingWithSheets,
    lastSyncTime: lastSyncSheetsTime,
    totalRecords: totalSincronizadosSheets,
    sincronizar
  };
}
