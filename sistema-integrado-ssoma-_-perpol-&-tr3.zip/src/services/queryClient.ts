/**
 * Configuración de TanStack Query (React Query)
 * Preparado para Optimistic Updates, sincronización en segundo plano y manejo de caché.
 */
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 3, // 3 minutos de frescura de datos
      gcTime: 1000 * 60 * 30, // 30 minutos en caché de memoria
      retry: 1,
      refetchOnWindowFocus: false
    },
    mutations: {
      retry: 1
    }
  }
});
