import { useAppStore } from '../store/appStore';
import { GasApiClient } from './api';

/**
 * Servicio de Carga Automática de Datos (Requerimiento 1)
 *
 * Utiliza el evento DOMContentLoaded y google.script.run para llamar
 * a la función backend .gs (obtenerDatos) e imprimir los registros
 * de Google Sheets en la interfaz inmediatamente al cargar la página.
 */
export function inicializarCargaAutomatica(): void {
  const procesarRespuesta = (respuesta: any) => {
    if (!respuesta) return;
    const store = useAppStore.getState();
    const data = respuesta.data || respuesta;
    store.cargarDatosDesdeSheets(data);
    store.setIsBackendConnected(true);
  };

  // Exponer función global para que el script de index.html la invoque
  window.__ssomaCargarDatosEnPantalla = procesarRespuesta;

  // Si index.html ya recibió datos antes de que este módulo se ejecute
  if (window.__ssomaDatosPendientes) {
    procesarRespuesta(window.__ssomaDatosPendientes);
    window.__ssomaDatosPendientes = null;
  }

  const ejecutarCarga = async () => {
    const store = useAppStore.getState();

    // 1. Verificar si estamos en el entorno embebido de Google Apps Script
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      store.setIsSyncingWithSheets(true);
      window.google.script.run
        .withSuccessHandler((res: any) => {
          procesarRespuesta(res);
          store.setIsSyncingWithSheets(false);
        })
        .withFailureHandler(() => {
          store.setIsSyncingWithSheets(false);
        })
        .obtenerDatos();
      return;
    }

    // 2. Si estamos en entorno web (Vite / Standalone), solo consultar si hay URL configurada
    const gasUrl = store.gasWebAppUrl?.trim() || GasApiClient.getGasUrl();
    if (!gasUrl) {
      return;
    }

    try {
      store.setIsSyncingWithSheets(true);
      const res = await GasApiClient.obtenerDatosGoogleSheets();
      if (res && res.success && res.data) {
        procesarRespuesta(res.data);
      } else {
        // Reintento automático tras 3.5 segundos en caso de arranque en frío
        setTimeout(async () => {
          try {
            const retryRes = await GasApiClient.obtenerDatosGoogleSheets();
            if (retryRes && retryRes.success && retryRes.data) {
              procesarRespuesta(retryRes.data);
            }
          } catch {}
        }, 3500);
      }
    } catch {
      // Reintento automático tras 3.5 segundos
      setTimeout(async () => {
        try {
          const retryRes = await GasApiClient.obtenerDatosGoogleSheets();
          if (retryRes && retryRes.success && retryRes.data) {
            procesarRespuesta(retryRes.data);
          }
        } catch {}
      }, 3500);
    } finally {
      store.setIsSyncingWithSheets(false);
    }
  };

  // Escuchar DOMContentLoaded si el documento aún se está cargando
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ejecutarCarga);
  } else {
    // Si ya se disparó DOMContentLoaded, ejecutar de inmediato
    ejecutarCarga();
  }
}
