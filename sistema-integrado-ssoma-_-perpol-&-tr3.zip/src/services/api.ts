/**
 * Servicio Cliente HTTP para Google Apps Script (GAS) Web App
 * Soporta peticiones POST estructuradas, manejo de CORS para GAS,
 * subida de archivos hacia Google Drive y comunicación directa con Google Sheets.
 * SIN persistencia ni zona local oculta: opera 100% sincronizado con Sheets.
 */
import { GasRequestPayload, GasApiResponse } from '../types';
import { useAppStore } from '../store/appStore';
import { buildAntiCacheUrl, getCorsSafeAntiCacheHeaders, applyAntiCacheToPayload } from '../utils/antiCache';

/**
 * Timeout por defecto para peticiones (en ms).
 * Google Apps Script tiene un límite de 6 minutos, pero para UI mantenemos 35 segundos.
 */
const DEFAULT_TIMEOUT_MS = 35000;
export const PERMANENT_GAS_URL = 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';
export const DEFAULT_GAS_URL = PERMANENT_GAS_URL;

export class GasApiClient {
  /**
   * Obtiene la URL configurada de GAS desde el store o variables de entorno,
   * garantizando que la URL permanente oficial sea siempre el estándar inviolable.
   */
  public static getGasUrl(): string {
    const storeUrl = useAppStore.getState().gasWebAppUrl;
    if (storeUrl && storeUrl.trim().startsWith('http')) {
      return storeUrl.trim();
    }
    try {
      const direct = localStorage.getItem('ssoma_gas_webapp_url');
      if (direct && direct.trim().startsWith('http')) {
        return direct.trim();
      }
    } catch {}
    const envUrl = ((import.meta as unknown as { env?: { VITE_GAS_API_URL?: string } })?.env?.VITE_GAS_API_URL) || '';
    if (envUrl && envUrl.trim().startsWith('http')) {
      return envUrl.trim();
    }
    return PERMANENT_GAS_URL;
  }

  /**
   * Alias de compatibilidad para post
   */
  public static async sendRequest<T = unknown>(payload: GasRequestPayload): Promise<GasApiResponse<T>> {
    return this.post<T>(payload);
  }

  /**
   * Envía una petición POST estructurada al Google Apps Script Web App.
   * Implementa Anti-Caché 100% compatible con CORS:
   * 1. A través del proxy backend (/api/gas): cabeceras no-cache + URL timestamped.
   * 2. En fallback directo a GAS: URL cache-busting (?_t=...&_cb=...) y CORS simple headers
   *    sin cabeceras custom para no disparar preflight OPTIONS que rompería CORS.
   */
  public static async post<T = unknown>(payload: GasRequestPayload): Promise<GasApiResponse<T>> {
    const gasUrl = this.getGasUrl() || PERMANENT_GAS_URL;

    // Inyectar IDs de Drive / Sheets si están en el store y no vinieron en el payload
    const store = useAppStore.getState();
    if (!payload.driveFolderId && store.driveFolderId) {
      payload.driveFolderId = store.driveFolderId;
    }

    // Enriquecer el payload con timestamp y nonce anti-caché
    const payloadWithAntiCache = applyAntiCacheToPayload(payload);

    // 1. Intentar primero a través del proxy backend /api/gas con URL y headers anti-caché
    try {
      const proxyController = new AbortController();
      const proxyTimeout = setTimeout(() => proxyController.abort(), DEFAULT_TIMEOUT_MS);
      const proxyUrl = buildAntiCacheUrl('/api/gas');

      const proxyRes = await fetch(proxyUrl, {
        method: 'POST',
        cache: 'no-store',
        headers: {
          ...getCorsSafeAntiCacheHeaders(false),
          'x-gas-url': gasUrl
        },
        body: JSON.stringify(payloadWithAntiCache),
        signal: proxyController.signal
      });

      clearTimeout(proxyTimeout);

      const contentType = proxyRes.headers.get('content-type') || '';
      if (proxyRes.ok && (contentType.includes('application/json') || contentType.includes('text/plain'))) {
        const text = await proxyRes.text();
        try {
          const data = JSON.parse(text);
          if (data && (data.success === true || data.data)) {
            useAppStore.getState().setIsBackendConnected(true);
            return data as GasApiResponse<T>;
          }
        } catch {
          // No es JSON válido desde el proxy, continuar al fallback directo
        }
      }
    } catch {
      // Si el proxy falla o no está disponible en este host, continuar de inmediato al fallback directo
    }

    // 2. Fallback: petición directa a Google Apps Script Web App
    // CRÍTICO PARA CORS: usar URL timestamped y cabeceras safelisted de texto plano (isDirectCors=true)
    // para NUNCA disparar HTTP OPTIONS preflight que Google Apps Script rechazaría.
    const directController = new AbortController();
    const directTimeout = setTimeout(() => directController.abort(), DEFAULT_TIMEOUT_MS);
    const directUrl = buildAntiCacheUrl(gasUrl);

    try {
      const response = await fetch(directUrl, {
        method: 'POST',
        cache: 'no-store',
        headers: getCorsSafeAntiCacheHeaders(true),
        body: JSON.stringify(payloadWithAntiCache),
        signal: directController.signal,
        redirect: 'follow'
      });

      clearTimeout(directTimeout);

      if (!response.ok) {
        throw new Error(`Error en servidor GAS HTTP ${response.status}: ${response.statusText}`);
      }

      const responseText = await response.text();
      let result: GasApiResponse<T>;

      try {
        result = JSON.parse(responseText);
      } catch {
        throw new Error(`La respuesta de Google Apps Script no es un JSON válido: ${responseText.slice(0, 150)}`);
      }

      if (result.success) {
        useAppStore.getState().setIsBackendConnected(true);
      }

      return result;
    } catch (err: unknown) {
      clearTimeout(directTimeout);
      const errorMessage = err instanceof Error ? err.message : 'Error desconocido al comunicar con Google Apps Script';
      
      useAppStore.getState().setIsBackendConnected(false);
      
      return {
        success: false,
        error: errorMessage,
        message: `Error al comunicar con Google Apps Script: ${errorMessage}`,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Verifica la conectividad con el script de Google Apps Script
   */
  public static async testConnection(urlToTest?: string): Promise<{ success: boolean; message: string }> {
    const url = (urlToTest && urlToTest.trim()) || this.getGasUrl() || PERMANENT_GAS_URL;

    if (url.includes('/macros/library/')) {
      return {
        success: false,
        message: 'La URL ingresada corresponde a una BIBLIOTECA (/macros/library/d/...), no a una Aplicación Web. Para procesar llamadas doPost debes implementar como "Aplicación web" (la URL debe terminar en /exec).'
      };
    }

    // 1. Probar vía proxy /api/gas con Anti-Caché
    try {
      const proxyController = new AbortController();
      const proxyTimeout = setTimeout(() => proxyController.abort(), 15000);
      const proxyUrl = buildAntiCacheUrl('/api/gas');

      const proxyRes = await fetch(proxyUrl, {
        method: 'POST',
        cache: 'no-store',
        headers: {
          ...getCorsSafeAntiCacheHeaders(false),
          'x-gas-url': url
        },
        body: JSON.stringify(applyAntiCacheToPayload({ action: 'ping' })),
        signal: proxyController.signal
      });

      clearTimeout(proxyTimeout);

      if (proxyRes.ok) {
        const text = await proxyRes.text();
        try {
          const data = JSON.parse(text);
          if (data.success === true) {
            useAppStore.getState().setIsBackendConnected(true);
            return {
              success: true,
              message: data.message || 'Conexión permanente establecida exitosamente con Google Apps Script y Google Sheets.'
            };
          }
        } catch {
          // No es JSON, continuar al fallback directo
        }
      }
    } catch {
      // Fallback a directo
    }

    // 2. Directo a Google Apps Script con Anti-Caché compatible con CORS
    try {
      const directController = new AbortController();
      const directTimeout = setTimeout(() => directController.abort(), 15000);
      const directUrl = buildAntiCacheUrl(url);

      const response = await fetch(directUrl, {
        method: 'POST',
        cache: 'no-store',
        headers: getCorsSafeAntiCacheHeaders(true),
        body: JSON.stringify(applyAntiCacheToPayload({ action: 'ping' })),
        signal: directController.signal,
        redirect: 'follow'
      });

      clearTimeout(directTimeout);

      if (!response.ok) {
        return { success: false, message: `Error HTTP ${response.status}: ${response.statusText}` };
      }

      const rawText = await response.text();
      let data: any;
      try {
        data = JSON.parse(rawText);
      } catch {
        if (rawText.includes('Page Not Found') || rawText.includes('Google Drive')) {
          return {
            success: false,
            message: 'Google devolvió "Página no encontrada". Verifica que la Web App esté implementada con acceso para "Cualquier persona" (Anyone) y termine en /exec.'
          };
        }
        return {
          success: false,
          message: 'La respuesta de Google Apps Script no contiene JSON válido. Verifica la configuración de la Web App.'
        };
      }

      if (data.success === true) {
        useAppStore.getState().setIsBackendConnected(true);
      }

      return {
        success: data.success === true,
        message: data.message || 'Conexión permanente establecida exitosamente con Google Apps Script y Google Sheets.'
      };
    } catch (error: unknown) {
      return {
        success: false,
        message: error instanceof Error ? error.message : 'No se pudo contactar el endpoint de Google Apps Script.'
      };
    }
  }

  /**
   * Requerimiento 1: Obtiene todos los datos desde Google Sheets en tiempo real.
   * Soporta tanto google.script.run (entorno nativo Apps Script) como fetch HTTP (entorno web).
   */
  public static async obtenerDatosGoogleSheets(): Promise<GasApiResponse<any>> {
    // 1. Si estamos dentro de Google Apps Script con google.script.run disponible
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      return new Promise((resolve) => {
        window.google!.script!.run
          .withSuccessHandler((res: any) => {
            resolve({
              success: true,
              data: res?.data || res,
              timestamp: new Date().toISOString()
            });
          })
          .withFailureHandler((err: any) => {
            console.error('Error en google.script.run.obtenerDatos():', err);
            resolve({
              success: false,
              error: err instanceof Error ? err.message : String(err),
              data: null,
              timestamp: new Date().toISOString()
            });
          })
          .obtenerDatos();
      });
    }

    // 2. Si estamos en modo Web conectado por URL Web App
    return this.post<any>({
      action: 'obtenerDatos'
    });
  }
}
