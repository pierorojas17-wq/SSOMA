/**
 * Servicio de Manejo y Optimización de Archivos / Imágenes para Google Drive
 * Cumple con el requerimiento crítico:
 * "Para evitar superar los límites de celdas de Google Sheets (50,000 caracteres),
 * ninguna imagen, foto de evidencia o firma en canvas debe guardarse en formato Base64
 * en la hoja de cálculo. El frontend comprimirá las imágenes y las enviará a Google Apps Script,
 * el cual las guardará como archivos físicos en una carpeta designada de Google Drive."
 */

import { GasApiClient } from './api';

export interface UploadOptions {
  fileName?: string;
  modulo: string;
  maxDimension?: number; // Por defecto 1200px según especificación técnica
  quality?: number; // 0.8 por defecto
}

export class DriveStorageService {
  /**
   * Comprime una imagen en el navegador mediante canvas y retorna el base64 optimizado
   */
  public static async compressImage(
    fileOrDataUrl: File | string,
    options: { maxDimension?: number; quality?: number } = {}
  ): Promise<{ base64: string; mimeType: string }> {
    const maxDimension = options.maxDimension || 1200;
    const quality = options.quality ?? 0.82;

    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('No se pudo inicializar el contexto de canvas'));
          return;
        }

        // Fondo blanco para imágenes con transparencia antes de convertir a JPEG
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const mimeType = 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, quality);
        const base64Data = dataUrl.split(',')[1] || dataUrl;

        resolve({
          base64: base64Data,
          mimeType
        });
      };

      img.onerror = (err) => reject(new Error('Error al cargar la imagen para compresión: ' + err));

      if (typeof fileOrDataUrl === 'string') {
        img.src = fileOrDataUrl;
      } else {
        const reader = new FileReader();
        reader.onload = (e) => {
          img.src = e.target?.result as string;
        };
        reader.onerror = (e) => reject(e);
        reader.readAsDataURL(fileOrDataUrl);
      }
    });
  }

  /**
   * Sube una imagen o firma a Google Drive a través de Google Apps Script
   * y devuelve exclusivamente el link permanente y el ID del archivo físico en Drive.
   */
  public static async uploadToDrive(
    source: File | string,
    options: UploadOptions
  ): Promise<{ fileUrl: string; fileId: string }> {
    // 1. Comprimir en cliente a max 1200px
    const { base64, mimeType } = await this.compressImage(source, {
      maxDimension: options.maxDimension,
      quality: options.quality
    });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safeName = options.fileName 
      ? options.fileName.replace(/[^a-zA-Z0-9_-]/g, '_')
      : `evidencia_${options.modulo}_${timestamp}.jpg`;

    // 2. Enviar a GAS para que lo guarde en Google Drive
    const response = await GasApiClient.post<{ fileUrl: string; fileId: string }>({
      action: 'uploadDriveFile',
      fileData: {
        base64,
        mimeType,
        fileName: safeName,
        modulo: options.modulo
      }
    });

    if (!response.success) {
      throw new Error(response.error || response.message || 'Error al guardar archivo en Google Drive');
    }

    const fileId = response.fileId || '';
    const fileUrl = fileId
      ? `https://lh3.googleusercontent.com/d/${fileId}`
      : (response.fileUrl || '');

    return {
      fileUrl,
      fileId
    };
  }
}
