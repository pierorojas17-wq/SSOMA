/**
 * Pruebas unitarias para los sanitizadores y normalizadores de datos SST.
 * Utiliza el runner nativo node:test y assertions de node:assert.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  ensureUniqueIds,
  sanitizeTrabajador,
  sanitizeAccidente,
  sanitizeAtencionMedica,
  sanitizeInspeccion,
  sanitizeConsumoBotiquin,
  sanitizeInvestigacion,
  sanitizeSimulacionCostos,
  sanitizeActoCondicion,
  sanitizeProgramaAnual,
  sanitizeHorasHombre
} from '../sanitizers.ts';

describe('Sanitizers SSOMA Suite', () => {
  describe('ensureUniqueIds', () => {
    it('debe asignar identificador único y no duplicar IDs existentes', () => {
      const records = [
        { id: 'REC-1', name: 'Item 1' },
        { id: 'REC-1', name: 'Item 2' },
        { id: '', dni: '44556677', name: 'Item 3' },
        { name: 'Item 4' }
      ];
      const result = ensureUniqueIds(records, 'TEST');
      assert.equal(result.length, 4);
      assert.equal(result[0].id, 'REC-1');
      assert.ok(result[1].id?.includes('REC-1'));
      assert.notEqual(result[1].id, 'REC-1');
      assert.equal(result[2].id, '44556677');
      assert.ok(result[3].id?.includes('TEST-'));
    });

    it('debe manejar arrays vacíos o nulos sin lanzar errores', () => {
      assert.deepEqual(ensureUniqueIds([]), []);
      assert.deepEqual(ensureUniqueIds(null as any), []);
    });
  });

  describe('sanitizeTrabajador', () => {
    it('debe normalizar DNI y valores obligatorios', () => {
      const raw = {
        dni: ' 72819283 ',
        apellidosNombres: ' Perez Juan ',
        empresa: 'TR3 ALIMENTOS'
      };
      const result = sanitizeTrabajador(raw);
      assert.equal(result.dni, '72819283');
      assert.equal(result.apellidosNombres, 'Perez Juan');
      assert.equal(result.empresa, 'TR3');
      assert.equal(result.condicion, 'Activo');
      assert.equal(result.id, 'TRAB-72819283');
    });

    it('debe generar valores seguros cuando el objeto es nulo o indefinido', () => {
      const result = sanitizeTrabajador(null);
      assert.ok(result.id?.includes('TRAB-'));
      assert.equal(result.dni, '');
      assert.equal(result.condicion, 'Activo');
      assert.equal(result.empresa, 'PERPOL');
    });
  });

  describe('sanitizeAccidente', () => {
    it('debe asignar ID único si falta y normalizar fecha', () => {
      const raw = {
        codigoCaso: 'ACC-001',
        fecha: '2026-10-08T14:23:00Z',
        partesCuerpoAfectadas: '["Mano", "Dedo"]',
        diasDescanso: '5'
      };
      const result = sanitizeAccidente(raw);
      assert.equal(result.id, 'ACC-001');
      assert.equal(result.codigoCaso, 'ACC-001');
      assert.match(result.fecha, /^\d{4}-\d{2}-\d{2}$/);
      assert.deepEqual(result.partesCuerpoAfectadas, ['Mano', 'Dedo']);
      assert.equal(result.diasDescanso, 5);
    });

    it('debe sanitizar listas separadas por coma', () => {
      const raw = {
        mecanismoEvento: 'Golpe por objeto, Caída a nivel'
      };
      const result = sanitizeAccidente(raw);
      assert.deepEqual(result.mecanismoEvento, ['Golpe por objeto', 'Caída a nivel']);
    });
  });

  describe('sanitizeAtencionMedica', () => {
    it('debe asignar identificador y estado por defecto', () => {
      const raw = {
        idAtencion: 'ATN-2026-01',
        trabajadorNombre: 'Ana Lopez',
        generaDescanso: 'SI',
        diasDescanso: 3
      };
      const result = sanitizeAtencionMedica(raw);
      assert.equal(result.id, 'ATN-2026-01');
      assert.equal(result.generaDescanso, 'SI');
      assert.equal(result.diasDescanso, 3);
      assert.equal(result.estado, 'En seguimiento');
    });
  });

  describe('sanitizeInspeccion', () => {
    it('debe sanitizar gravedad y evidencias', () => {
      const raw = {
        codigoInspeccion: 'INSP-100',
        potencialGravedad: '3',
        evidenciasIniciales: '["https://drive.google.com/img1.jpg"]'
      };
      const result = sanitizeInspeccion(raw);
      assert.equal(result.potencialGravedad, 3);
      assert.equal(result.evidenciasIniciales?.length, 1);
      assert.equal(result.prioridad, 'Media');
    });
  });

  describe('sanitizeConsumoBotiquin', () => {
    it('debe parsear elementos consumidos de forma segura', () => {
      const raw = {
        codigoAtencion: 'BOT-05',
        elementosConsumidos: '[{"item":"Paracetamol","cantidad":"2","unidad":"Tabletas"}]'
      };
      const result = sanitizeConsumoBotiquin(raw);
      assert.deepEqual(result.elementosConsumidos, [
        { item: 'Paracetamol', cantidad: 2, unidad: 'Tabletas' }
      ]);
    });
  });

  describe('sanitizeInvestigacion', () => {
    it('debe inicializar método de causa raíz y porcentajes', () => {
      const raw = {
        codigoInvestigacion: 'INV-2026-01',
        causaRaizMetodo: 'Ishikawa',
        porcentajeAvance: '80'
      };
      const result = sanitizeInvestigacion(raw);
      assert.equal(result.causaRaizMetodo, 'Ishikawa');
      assert.equal(result.porcentajeAvance, 80);
      assert.ok(result.datosTrabajador);
    });
  });

  describe('sanitizeSimulacionCostos', () => {
    it('debe calcular o normalizar montos numéricos', () => {
      const raw = {
        codigoSimulacion: 'SIM-01',
        remuneracionDiaria: '100',
        diasSimulados: '4'
      };
      const result = sanitizeSimulacionCostos(raw);
      assert.equal(result.remuneracionDiaria, 100);
      assert.equal(result.diasSimulados, 4);
      assert.ok(result.costosDirectos);
    });
  });

  describe('sanitizeActoCondicion', () => {
    it('debe detectar clasificación de acto o condición', () => {
      const rawActo = {
        clasificacion: 'Acto Inseguro',
        descripcion: 'No uso de EPP'
      };
      const rawCond = {
        clasificacion: 'Condición Subestándar',
        descripcion: 'Piso resbaloso'
      };
      assert.equal(sanitizeActoCondicion(rawActo).clasificacion, 'Acto Inseguro');
      assert.equal(sanitizeActoCondicion(rawCond).clasificacion, 'Condición Insegura');
    });
  });

  describe('sanitizeProgramaAnual', () => {
    it('debe garantizar 12 meses en matrices de programación y ejecución', () => {
      const raw = {
        actividad: 'Capacitación en Primeros Auxilios',
        programacionMeses: [true, false, true]
      };
      const result = sanitizeProgramaAnual(raw);
      assert.equal(result.programacionMeses.length, 12);
      assert.equal(result.ejecucionMeses.length, 12);
      assert.equal(result.metaPorcentaje, 100);
    });
  });

  describe('sanitizeHorasHombre', () => {
    it('debe totalizar trabajadores y horas hombre correctamente', () => {
      const raw = {
        anio: 2026,
        mes: 3,
        trabajadoresPerpol: 50,
        hhPerpol: 9600,
        trabajadoresTr3: 20,
        hhTr3: 3840
      };
      const result = sanitizeHorasHombre(raw);
      assert.equal(result.totalTrabajadores, 70);
      assert.equal(result.totalHH, 13440);
      assert.equal(result.id, '2026-03');
    });
  });
});
