/**
 * useGoogleSheetsStore: Store para los endpoints, carpetas y estado
 * de sincronización en vivo con Google Apps Script y Google Sheets.
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const DEFAULT_GAS_ENDPOINT =
  'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';

export interface GoogleSheetsState {
  gasWebAppUrl: string;
  setGasWebAppUrl: (url: string) => void;
  driveFolderId: string;
  setDriveFolderId: (folderId: string) => void;
  spreadsheetId: string;
  setSpreadsheetId: (sheetId: string) => void;
  isBackendConnected: boolean;
  setIsBackendConnected: (status: boolean) => void;

  // Estado de sincronización
  lastSyncSheetsTime: string | null;
  isSyncingWithSheets: boolean;
  totalSincronizadosSheets: number;
  setLastSyncSheetsTime: (time: string | null) => void;
  setIsSyncingWithSheets: (status: boolean) => void;
  setTotalSincronizadosSheets: (count: number) => void;
}

export const useGoogleSheetsStore = create<GoogleSheetsState>()(
  persist(
    (set) => ({
      gasWebAppUrl: DEFAULT_GAS_ENDPOINT,
      setGasWebAppUrl: (url) => set({ gasWebAppUrl: url }),
      driveFolderId: '',
      setDriveFolderId: (folderId) => set({ driveFolderId: folderId }),
      spreadsheetId: '',
      setSpreadsheetId: (sheetId) => set({ spreadsheetId: sheetId }),
      isBackendConnected: false,
      setIsBackendConnected: (status) => set({ isBackendConnected: status }),

      lastSyncSheetsTime: null,
      isSyncingWithSheets: false,
      totalSincronizadosSheets: 0,
      setLastSyncSheetsTime: (time) => set({ lastSyncSheetsTime: time }),
      setIsSyncingWithSheets: (status) => set({ isSyncingWithSheets: status }),
      setTotalSincronizadosSheets: (count) => set({ totalSincronizadosSheets: count })
    }),
    {
      name: 'ssoma-gas-config',
      onRehydrateStorage: () => (state) => {
        if (state) {
          if (
            !state.gasWebAppUrl ||
            state.gasWebAppUrl.trim().length === 0 ||
            !state.gasWebAppUrl.includes('/exec')
          ) {
            state.gasWebAppUrl = DEFAULT_GAS_ENDPOINT;
          }
        }
      },
      partialize: (state) => ({
        gasWebAppUrl: state.gasWebAppUrl,
        driveFolderId: state.driveFolderId,
        spreadsheetId: state.spreadsheetId,
        isBackendConnected: state.isBackendConnected
      })
    }
  )
);
