/**
 * Zustand Store: Estado global de la aplicación SSOMA
 * Maneja la empresa activa (PERPOL / TR3 / CONSOLIDADO), la configuración del backend GAS,
 * la lista maestra de trabajadores (autocompletado en toda la app), resumen del Programa Anual,
 * notificaciones y sincronización optimista.
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { EmpresaId } from '../types';
import { ThemeColor, ThemeBackground } from '../types/theme';
import { applyTheme } from '../utils/themeUtils';
import {
  TrabajadorRecord,
  ProgramaResumenAnual,
  ConsumoBotiquinRecord,
  AccidenteRecord,
  InspeccionRecord,
  InvestigacionRecord,
  SimulacionCostosRecord,
  ActoCondicionRecord,
  ProgramaAnualRecord,
  ResumenMensualHH,
  MetaIndicadoresSST,
  EstadisticasDashboardData,
  AtencionMedicaRecord
} from '../types/modules';
import { CATALOGO_CATEGORIAS_RIESGO } from '../utils/ssomaCatalogs';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  timestamp: number;
}

// Metas Anuales SST por defecto (Módulo 8)
const DEFAULT_METAS_INDICADORES: MetaIndicadoresSST = {
  empresa: 'CONSOLIDADO',
  periodoAnio: 2026,
  metaIF: 2.5,
  metaIS: 25.0,
  metaIA: 0.06,
  metaCumplimientoPrograma: 90.0,
  metaInspeccionesSubsanadas: 85.0
};

// Helper universal para asegurar claves e identificadores unívocos sin colisiones
export const ensureUniqueIds = <T extends { id?: string; dni?: string; empresa?: string }>(items: T[], prefix = 'RECORD'): T[] => {
  if (!Array.isArray(items)) return [];
  const seen = new Set<string>();
  return items.map((item, idx) => {
    let id = item.id !== undefined && item.id !== null && String(item.id).trim() !== ''
      ? String(item.id).trim()
      : (item.dni !== undefined && item.dni !== null && String(item.dni).trim() !== '' ? String(item.dni).trim() : '');
    
    if (!id || seen.has(id)) {
      const emp = item.empresa ? `-${item.empresa}` : '';
      id = id ? `${id}${emp}-${idx}` : `${prefix}-${Date.now()}-${idx}`;
    }
    seen.add(id);
    return {
      ...item,
      id
    };
  });
};

// Helper para normalizar y sanitizar registros de trabajadores provenientes de Sheets o inputs
export const sanitizeTrabajador = (raw: any): TrabajadorRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `TRAB-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      dni: '',
      apellidosNombres: '',
      empresa: 'PERPOL',
      condicion: 'Activo',
      sexo: 'M',
      fechaIngreso: '',
      fechaNacimiento: '',
      puesto: '',
      area: '',
      telefono: '',
      correo: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }
  const dniStr = raw.dni !== undefined && raw.dni !== null ? String(raw.dni).trim() : '';
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : (dniStr ? `TRAB-${dniStr}` : `TRAB-${Date.now()}-${Math.floor(Math.random() * 1000)}`);

  return {
    ...raw,
    id: idStr,
    dni: dniStr,
    apellidosNombres: raw.apellidosNombres !== undefined && raw.apellidosNombres !== null ? String(raw.apellidosNombres).trim() : '',
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    condicion: (raw.condicion as 'Activo' | 'Inactivo' | 'Cesado') || 'Activo',
    sexo: (raw.sexo as 'M' | 'F') || 'M',
    fechaIngreso: raw.fechaIngreso ? String(raw.fechaIngreso).slice(0, 10) : '',
    fechaNacimiento: raw.fechaNacimiento ? String(raw.fechaNacimiento).slice(0, 10) : '',
    puesto: raw.puesto !== undefined && raw.puesto !== null ? String(raw.puesto).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    telefono: raw.telefono !== undefined && raw.telefono !== null ? String(raw.telefono).trim() : '',
    correo: raw.correo !== undefined && raw.correo !== null ? String(raw.correo).trim() : '',
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para convertir a array de strings limpios sin elementos vacíos
const toCleanStringArray = (val: any): string[] => {
  if (Array.isArray(val)) return val.map((x) => String(x).trim()).filter(Boolean);
  if (typeof val === 'string' && val.trim()) {
    try {
      const parsed = JSON.parse(val);
      if (Array.isArray(parsed)) return parsed.map((x) => String(x).trim()).filter(Boolean);
      if (typeof parsed === 'string' && parsed.trim()) return [parsed.trim()];
    } catch {
      return val.split(',').map((x) => x.trim()).filter(Boolean);
    }
  }
  return [];
};

// Helper para limpiar strings opcionales evitando strings vacíos ("") que causen descargas dobles en <img> o <link>
const toCleanStringOrUndefined = (val: any): string | undefined => {
  if (val === undefined || val === null) return undefined;
  const s = String(val).trim();
  return s.length > 0 ? s : undefined;
};

// Helper para sanitizar Accidentes e Incidentes (Módulo 1)
export const sanitizeAccidente = (raw: any): AccidenteRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `ACC-${Date.now()}`,
      codigoCaso: `ACC-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      hora: '08:00',
      trabajadorDni: '',
      trabajadorNombre: '',
      cargo: '',
      area: '',
      turno: 'Mañana',
      lugarExacto: '',
      responsableArea: '',
      tipoEvento: 'Incidente',
      danoMaterial: 'NO',
      necesidadAtencion: 'NO',
      descripcion: '',
      partesCuerpoAfectadas: [],
      mecanismoEvento: [],
      agenteEvento: [],
      lesionReferida: [],
      estadoCaso: 'Abierto',
      diasDescanso: 0,
      createdAt: new Date().toISOString()
    };
  }
  const codCaso = raw.codigoCaso !== undefined && raw.codigoCaso !== null && String(raw.codigoCaso).trim() !== ''
    ? String(raw.codigoCaso).trim()
    : (raw.id ? String(raw.id).trim() : `ACC-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codCaso;

  return {
    ...raw,
    id: idStr,
    codigoCaso: codCaso,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    hora: raw.hora !== undefined && raw.hora !== null ? String(raw.hora).trim() : '08:00',
    trabajadorDni: raw.trabajadorDni !== undefined && raw.trabajadorDni !== null ? String(raw.trabajadorDni).trim() : '',
    trabajadorNombre: raw.trabajadorNombre !== undefined && raw.trabajadorNombre !== null ? String(raw.trabajadorNombre).trim() : '',
    cargo: raw.cargo !== undefined && raw.cargo !== null ? String(raw.cargo).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    lugarExacto: raw.lugarExacto !== undefined && raw.lugarExacto !== null ? String(raw.lugarExacto).trim() : '',
    responsableArea: raw.responsableArea !== undefined && raw.responsableArea !== null ? String(raw.responsableArea).trim() : '',
    tipoEvento: raw.tipoEvento || 'Incidente',
    danoMaterial: raw.danoMaterial === 'SI' ? 'SI' : 'NO',
    detalleDano: toCleanStringOrUndefined(raw.detalleDano),
    necesidadAtencion: raw.necesidadAtencion === 'SI' ? 'SI' : 'NO',
    descripcion: raw.descripcion !== undefined && raw.descripcion !== null ? String(raw.descripcion).trim() : '',
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    causaInmediata: toCleanStringOrUndefined(raw.causaInmediata),

    // 4 Listas de selección múltiple con campos "Otros"
    partesCuerpoAfectadas: toCleanStringArray(raw.partesCuerpoAfectadas),
    partesCuerpoOtros: toCleanStringOrUndefined(raw.partesCuerpoOtros),
    mecanismoEvento: toCleanStringArray(raw.mecanismoEvento),
    mecanismoEventoOtros: toCleanStringOrUndefined(raw.mecanismoEventoOtros),
    agenteEvento: toCleanStringArray(raw.agenteEvento),
    agenteEventoOtros: toCleanStringOrUndefined(raw.agenteEventoOtros),
    lesionReferida: toCleanStringArray(raw.lesionReferida),
    lesionReferidaOtros: toCleanStringOrUndefined(raw.lesionReferidaOtros),

    estadoCaso: raw.estadoCaso || 'Abierto',
    diasDescanso:
      Number(raw.diasDescanso) ||
      Number(raw.diasDescansoMedico) ||
      Number(raw['Días Descanso']) ||
      Number(raw['Días Descanso Médico']) ||
      Number(raw['Dias Descanso']) ||
      Number(raw['Dias Descanso Medico']) ||
      Number(raw.diasPerdidos) ||
      0,
    medidasCorrectivas: raw.medidasCorrectivas !== undefined && raw.medidasCorrectivas !== null ? String(raw.medidasCorrectivas).trim() : undefined,
    responsableSeguimiento: raw.responsableSeguimiento !== undefined && raw.responsableSeguimiento !== null ? String(raw.responsableSeguimiento).trim() : undefined,
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    conclusionesInvestigacion: raw.conclusionesInvestigacion !== undefined && raw.conclusionesInvestigacion !== null ? String(raw.conclusionesInvestigacion).trim() : undefined,
    origenAtencionBotiquinId: raw.origenAtencionBotiquinId !== undefined && raw.origenAtencionBotiquinId !== null ? String(raw.origenAtencionBotiquinId).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Atenciones Médicas (Módulo 2: Independiente)
export const sanitizeAtencionMedica = (raw: any): AtencionMedicaRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `ATN-${Date.now()}`,
      idAtencion: `ATN-${Date.now()}`,
      empresa: 'PERPOL',
      trabajadorDni: '',
      trabajadorNombre: '',
      lugarAtencion: 'Tópico de Planta',
      fechaAtencion: new Date().toISOString().slice(0, 10),
      diagnostico: '',
      generaDescanso: 'NO',
      diasDescanso: 0,
      estado: 'Cerrado',
      createdAt: new Date().toISOString()
    };
  }

  const idAtn = raw.idAtencion || raw.id || `ATN-${Date.now()}`;
  return {
    ...raw,
    id: idAtn,
    idAtencion: idAtn,
    idAccidente: raw.idAccidente ? String(raw.idAccidente).trim() : undefined,
    codigoAccidente: raw.codigoAccidente ? String(raw.codigoAccidente).trim() : undefined,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    trabajadorDni: raw.trabajadorDni ? String(raw.trabajadorDni).trim() : '',
    trabajadorNombre: raw.trabajadorNombre ? String(raw.trabajadorNombre).trim() : '',
    puesto: raw.puesto ? String(raw.puesto).trim() : '',
    area: raw.area ? String(raw.area).trim() : '',
    lugarEspecifico: toCleanStringOrUndefined(raw.lugarEspecifico ?? raw.lugarAccidente ?? raw.lugarExacto ?? raw['Lugar Específico'] ?? raw['Lugar']),
    turno: raw.turno ? String(raw.turno).trim() : 'Mañana',
    lugarAtencion: raw.lugarAtencion ? String(raw.lugarAtencion).trim() : 'Tópico de Planta',
    fechaAtencion: raw.fechaAtencion ? String(raw.fechaAtencion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    horaAtencion: raw.horaAtencion ? String(raw.horaAtencion).trim() : '09:00',
    diagnostico: raw.diagnostico ? String(raw.diagnostico).trim() : '',
    generaDescanso: raw.generaDescanso === 'SI' ? 'SI' : 'NO',
    fechaInicioDescanso: raw.fechaInicioDescanso ? String(raw.fechaInicioDescanso).slice(0, 10) : undefined,
    fechaFinDescanso: raw.fechaFinDescanso ? String(raw.fechaFinDescanso).slice(0, 10) : undefined,
    diasDescanso: Number(raw.diasDescanso) || 0,
    proximaCita: raw.proximaCita ? String(raw.proximaCita).slice(0, 10) : undefined,
    estado: raw.estado || 'En seguimiento',
    medicoTratante: raw.medicoTratante ? String(raw.medicoTratante).trim() : undefined,
    observaciones: raw.observaciones ? String(raw.observaciones).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Inspecciones SST
export const sanitizeInspeccion = (raw: any): InspeccionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `INSP-${Date.now()}`,
      codigoInspeccion: `INSP-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      area: '',
      responsableInspeccion: '',
      hallazgo: '',
      potencialGravedad: 2,
      prioridad: 'Media',
      tipo: 'Condición insegura',
      evidenciasIniciales: [],
      evidenciasCorreccion: [],
      estado: 'Pendiente',
      fechaCompromiso: new Date().toISOString().slice(0, 10),
      createdAt: new Date().toISOString()
    };
  }
  const codInsp = raw.codigoInspeccion !== undefined && raw.codigoInspeccion !== null && String(raw.codigoInspeccion).trim() !== ''
    ? String(raw.codigoInspeccion).trim()
    : (raw.id ? String(raw.id).trim() : `INSP-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codInsp;

  return {
    ...raw,
    id: idStr,
    codigoInspeccion: codInsp,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    lugarEspecifico: toCleanStringOrUndefined(raw.lugarEspecifico ?? raw.lugarExacto ?? raw.lugar ?? raw['Lugar Específico'] ?? raw['Lugar']),
    responsableInspeccion: raw.responsableInspeccion !== undefined && raw.responsableInspeccion !== null ? String(raw.responsableInspeccion).trim() : '',
    hallazgo: raw.hallazgo !== undefined && raw.hallazgo !== null ? String(raw.hallazgo).trim() : '',
    potencialGravedad: (Number(raw.potencialGravedad) as 1 | 2 | 3 | 4) || 2,
    prioridad: raw.prioridad || 'Media',
    tipo: raw.tipo || 'Condición insegura',
    evidenciasIniciales: toCleanStringArray(raw.evidenciasIniciales),
    evidenciasCorreccion: toCleanStringArray(raw.evidenciasCorreccion),
    estado: raw.estado || 'Pendiente',
    responsableLevantamiento: toCleanStringOrUndefined(raw.responsableLevantamiento),
    accionCorrectiva: toCleanStringOrUndefined(raw.accionCorrectiva),
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : new Date().toISOString().slice(0, 10),
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    fechaLevantamiento: raw.fechaLevantamiento ? String(raw.fechaLevantamiento).slice(0, 10) : undefined,
    atencionesPrimerosAuxilios: toCleanStringArray(raw.atencionesPrimerosAuxilios),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Consumos de Botiquín
export const sanitizeConsumoBotiquin = (raw: any): ConsumoBotiquinRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `BOT-${Date.now()}`,
      codigoAtencion: `BOT-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      tipoAtencion: 'Incidente',
      personaAtendida: '',
      dniPersona: '',
      puesto: '',
      area: '',
      turno: 'Mañana',
      lesionesSintomas: '',
      procedimientoAplicado: '',
      elementosConsumidos: [],
      atendidoPor: '',
      createdAt: new Date().toISOString()
    };
  }
  const codAtenc = raw.codigoAtencion !== undefined && raw.codigoAtencion !== null && String(raw.codigoAtencion).trim() !== ''
    ? String(raw.codigoAtencion).trim()
    : (raw.id ? String(raw.id).trim() : `BOT-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codAtenc;

  let elems = raw.elementosConsumidos;
  if (typeof elems === 'string') {
    try { elems = JSON.parse(elems); } catch { elems = []; }
  }
  if (!Array.isArray(elems)) elems = [];

  const cleanElements = elems.map((el: any) => ({
    item: el?.item !== undefined && el?.item !== null ? String(el.item).trim() : '',
    cantidad: Number(el?.cantidad) || 1,
    unidad: el?.unidad !== undefined && el?.unidad !== null ? String(el.unidad).trim() : 'Unidades'
  }));

  return {
    ...raw,
    id: idStr,
    codigoAtencion: codAtenc,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    hora: raw.hora !== undefined && raw.hora !== null ? String(raw.hora).trim() : '08:00',
    tipoAtencion: raw.tipoAtencion || 'Incidente',
    personaAtendida: raw.personaAtendida !== undefined && raw.personaAtendida !== null ? String(raw.personaAtendida).trim() : '',
    dniPersona: raw.dniPersona !== undefined && raw.dniPersona !== null ? String(raw.dniPersona).trim() : '',
    puesto: raw.puesto !== undefined && raw.puesto !== null ? String(raw.puesto).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    lugarEspecifico: toCleanStringOrUndefined(raw.lugarEspecifico ?? raw.lugarExacto ?? raw.lugar ?? raw['Lugar Específico'] ?? raw['Lugar']),
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    lesionesSintomas: raw.lesionesSintomas !== undefined && raw.lesionesSintomas !== null ? String(raw.lesionesSintomas).trim() : '',
    procedimientoAplicado: raw.procedimientoAplicado !== undefined && raw.procedimientoAplicado !== null ? String(raw.procedimientoAplicado).trim() : '',
    elementosConsumidos: cleanElements,
    inspeccionVinculadaId: raw.inspeccionVinculadaId !== undefined && raw.inspeccionVinculadaId !== null ? String(raw.inspeccionVinculadaId).trim() : undefined,
    inspeccionVinculadaCodigo: raw.inspeccionVinculadaCodigo !== undefined && raw.inspeccionVinculadaCodigo !== null ? String(raw.inspeccionVinculadaCodigo).trim() : undefined,
    inspeccionVinculadaDetalle: raw.inspeccionVinculadaDetalle !== undefined && raw.inspeccionVinculadaDetalle !== null ? String(raw.inspeccionVinculadaDetalle).trim() : undefined,
    atendidoPor: raw.atendidoPor !== undefined && raw.atendidoPor !== null ? String(raw.atendidoPor).trim() : '',
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    transferidoAccidentes: Boolean(raw.transferidoAccidentes),
    estadoValidacion: raw.estadoValidacion || 'Pendiente',
    casoAccidenteId: raw.casoAccidenteId !== undefined && raw.casoAccidenteId !== null ? String(raw.casoAccidenteId).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Investigaciones de Accidentes
export const sanitizeInvestigacion = (raw: any): InvestigacionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `INV-${Date.now()}`,
      codigoInvestigacion: `INV-${Date.now()}`,
      accidenteId: '',
      empresa: 'PERPOL',
      fechaInvestigacion: new Date().toISOString().slice(0, 10),
      fechaAccidente: new Date().toISOString().slice(0, 10),
      horaAccidente: '08:00',
      turno: 'Mañana',
      area: '',
      lugarExacto: '',
      diasDescanso: 0,
      datosTrabajador: {
        nombre: '',
        dni: '',
        edad: 0,
        genero: 'M',
        puesto: '',
        area: '',
        fechaIngreso: '',
        antiguedadPuesto: ''
      },
      descripcionCircunstancias: '',
      tipoContacto: '',
      agenteCausante: '',
      causasInmediatas: { actosSubestandar: [], condicionesSubestandar: [] },
      causasBasicas: { factoresPersonales: [], factoresTrabajo: [] },
      causaRaizMetodo: '5 Porqués',
      analisisCausaRaiz: '',
      conclusionCausaRaiz: '',
      medidasCorrectivas: [],
      investigadores: [],
      porcentajeAvance: 0,
      estado: 'Borrador',
      createdAt: new Date().toISOString()
    };
  }
  const codInv = raw.codigoInvestigacion !== undefined && raw.codigoInvestigacion !== null && String(raw.codigoInvestigacion).trim() !== ''
    ? String(raw.codigoInvestigacion).trim()
    : (raw.id ? String(raw.id).trim() : `INV-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codInv;

  let trab = raw.datosTrabajador;
  if (typeof trab === 'string') {
    try { trab = JSON.parse(trab); } catch { trab = {}; }
  }
  trab = trab || {};

  let cInm = raw.causasInmediatas;
  if (typeof cInm === 'string') {
    try { cInm = JSON.parse(cInm); } catch { cInm = {}; }
  }
  let cBas = raw.causasBasicas;
  if (typeof cBas === 'string') {
    try { cBas = JSON.parse(cBas); } catch { cBas = {}; }
  }
  let medidas = raw.medidasCorrectivas;
  if (typeof medidas === 'string') {
    try { medidas = JSON.parse(medidas); } catch { medidas = []; }
  }
  let invs = raw.investigadores;
  if (typeof invs === 'string') {
    try { invs = JSON.parse(invs); } catch { invs = []; }
  }

  return {
    ...raw,
    id: idStr,
    codigoInvestigacion: codInv,
    accidenteId: raw.accidenteId !== undefined && raw.accidenteId !== null ? String(raw.accidenteId).trim() : '',
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fechaInvestigacion: raw.fechaInvestigacion ? String(raw.fechaInvestigacion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    fechaAccidente: raw.fechaAccidente ? String(raw.fechaAccidente).slice(0, 10) : new Date().toISOString().slice(0, 10),
    horaAccidente: raw.horaAccidente !== undefined && raw.horaAccidente !== null ? String(raw.horaAccidente).trim() : '08:00',
    horaInicioLaboral: toCleanStringOrUndefined(raw.horaInicioLaboral),
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    lugarExacto: raw.lugarExacto !== undefined && raw.lugarExacto !== null ? String(raw.lugarExacto).trim() : '',
    diasDescanso:
      Number(raw.diasDescanso) ||
      Number(raw.diasDescansoMedico) ||
      Number(raw['Días Descanso']) ||
      Number(raw['Días Descanso Médico']) ||
      Number(raw['Dias Descanso']) ||
      Number(raw['Dias Descanso Medico']) ||
      Number(raw.diasPerdidos) ||
      0,
    numTrabajadoresAfectados: Number(raw.numTrabajadoresAfectados) || 1,
    responsableArea: toCleanStringOrUndefined(raw.responsableArea),
    partesCuerpoAfectadas: Array.isArray(raw.partesCuerpoAfectadas) ? raw.partesCuerpoAfectadas.map(String) : [],
    datosTrabajador: {
      nombre: trab.nombre !== undefined && trab.nombre !== null ? String(trab.nombre).trim() : '',
      dni: trab.dni !== undefined && trab.dni !== null ? String(trab.dni).trim() : '',
      edad: Number(trab.edad) || 0,
      genero: (trab.genero as 'M' | 'F') || 'M',
      puesto: trab.puesto !== undefined && trab.puesto !== null ? String(trab.puesto).trim() : '',
      area: trab.area !== undefined && trab.area !== null ? String(trab.area).trim() : '',
      fechaIngreso: trab.fechaIngreso ? String(trab.fechaIngreso).slice(0, 10) : '',
      antiguedadPuesto: trab.antiguedadPuesto !== undefined && trab.antiguedadPuesto !== null ? String(trab.antiguedadPuesto).trim() : ''
    },
    descripcionCircunstancias: raw.descripcionCircunstancias !== undefined && raw.descripcionCircunstancias !== null ? String(raw.descripcionCircunstancias).trim() : '',
    testigos: raw.testigos !== undefined && raw.testigos !== null ? String(raw.testigos).trim() : undefined,
    tipoContacto: raw.tipoContacto !== undefined && raw.tipoContacto !== null ? String(raw.tipoContacto).trim() : '',
    agenteCausante: raw.agenteCausante !== undefined && raw.agenteCausante !== null ? String(raw.agenteCausante).trim() : '',
    causasInmediatas: {
      actosSubestandar: Array.isArray(cInm?.actosSubestandar) ? cInm.actosSubestandar.map(String) : [],
      condicionesSubestandar: Array.isArray(cInm?.condicionesSubestandar) ? cInm.condicionesSubestandar.map(String) : []
    },
    causasBasicas: {
      factoresPersonales: Array.isArray(cBas?.factoresPersonales) ? cBas.factoresPersonales.map(String) : [],
      factoresTrabajo: Array.isArray(cBas?.factoresTrabajo) ? cBas.factoresTrabajo.map(String) : []
    },
    causaRaizMetodo: raw.causaRaizMetodo === 'Ishikawa' ? 'Ishikawa' : '5 Porqués',
    analisisCausaRaiz: raw.analisisCausaRaiz !== undefined && raw.analisisCausaRaiz !== null ? String(raw.analisisCausaRaiz).trim() : '',
    conclusionCausaRaiz: raw.conclusionCausaRaiz !== undefined && raw.conclusionCausaRaiz !== null ? String(raw.conclusionCausaRaiz).trim() : '',
    medidasCorrectivas: Array.isArray(medidas) ? medidas.map((m: any) => ({
      ...m,
      id: m?.id ? String(m.id).trim() : `MED-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      descripcion: m?.descripcion !== undefined && m?.descripcion !== null ? String(m.descripcion).trim() : '',
      tipoAccion: m?.tipoAccion || 'Control Administrativo',
      responsable: m?.responsable !== undefined && m?.responsable !== null ? String(m.responsable).trim() : '',
      plazo: m?.plazo ? String(m.plazo).slice(0, 10) : '',
      estado: m?.estado || 'Pendiente',
      evidenciaUrl: m?.evidenciaUrl !== undefined && m?.evidenciaUrl !== null ? String(m.evidenciaUrl).trim() : undefined,
      fechaVerificacion: m?.fechaVerificacion ? String(m.fechaVerificacion).slice(0, 10) : undefined,
      verificador: m?.verificador !== undefined && m?.verificador !== null ? String(m.verificador).trim() : undefined
    })) : [],
    investigadores: Array.isArray(invs) ? invs.map((i: any) => ({
      ...i,
      nombre: i?.nombre !== undefined && i?.nombre !== null ? String(i.nombre).trim() : '',
      cargo: i?.cargo !== undefined && i?.cargo !== null ? String(i.cargo).trim() : '',
      rol: i?.rol || 'Investigador Principal',
      firmaUrl: toCleanStringOrUndefined(i?.firmaUrl),
      firmaDriveId: toCleanStringOrUndefined(i?.firmaDriveId),
      fechaFirma: i?.fechaFirma ? String(i.fechaFirma).slice(0, 10) : undefined
    })) : [],
    porcentajeAvance: Number(raw.porcentajeAvance) || 0,
    estado: raw.estado || 'Borrador',
    closureErrors: Array.isArray(raw.closureErrors) ? raw.closureErrors.map(String) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Simulación de Costos
export const sanitizeSimulacionCostos = (raw: any): SimulacionCostosRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `SIM-${Date.now()}`,
      codigoSimulacion: `SIM-${Date.now()}`,
      empresa: 'PERPOL',
      fechaSimulacion: new Date().toISOString().slice(0, 10),
      descripcionEvento: '',
      area: '',
      probabilidadOcurrencia: 1,
      consecuenciaPersonas: 1,
      consecuenciaActivos: 1,
      consecuenciaOperacion: 1,
      nivelRiesgoCalculado: 1,
      esHiPo: false,
      diasSimulados: 1,
      remuneracionDiaria: 50,
      costoRemuneracionSimulada: 50,
      trabajadoresAfectadosParalizacion: 0,
      horasParalizadas: 0,
      costoHoraHombre: 15,
      costoMaquinariaDanos: 0,
      otrosCostosParalizacion: 0,
      costoParalizacionTotal: 0,
      costosDirectos: { atencionEmergencia: 0, gastosClinicos: 0, subsidioDiasPerdidos: 0, reparacionEquipos: 0, medicamentos: 0 },
      costosIndirectos: { paralizacionPlanta: 0, horasHombreInvestigacion: 0, reemplazoPersonal: 0, multasSanciones: 0, perdidaProductividad: 0 },
      costoTotalDirecto: 0,
      costoTotalIndirecto: 0,
      costoTotalEstimado: 0,
      costoRealIncurrido: 0,
      brechaCosto: 0,
      createdAt: new Date().toISOString()
    };
  }
  const codSim = raw.codigoSimulacion !== undefined && raw.codigoSimulacion !== null && String(raw.codigoSimulacion).trim() !== ''
    ? String(raw.codigoSimulacion).trim()
    : (raw.id ? String(raw.id).trim() : `SIM-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codSim;

  let cd = raw.costosDirectos;
  if (typeof cd === 'string') {
    try { cd = JSON.parse(cd); } catch { cd = {}; }
  }
  cd = cd || {};
  let ci = raw.costosIndirectos;
  if (typeof ci === 'string') {
    try { ci = JSON.parse(ci); } catch { ci = {}; }
  }
  ci = ci || {};

  return {
    ...raw,
    id: idStr,
    codigoSimulacion: codSim,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fechaSimulacion: raw.fechaSimulacion ? String(raw.fechaSimulacion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    incidenteId: raw.incidenteId !== undefined && raw.incidenteId !== null ? String(raw.incidenteId).trim() : undefined,
    codigoCasoIncidente: raw.codigoCasoIncidente !== undefined && raw.codigoCasoIncidente !== null ? String(raw.codigoCasoIncidente).trim() : undefined,
    inspeccionId: raw.inspeccionId !== undefined && raw.inspeccionId !== null ? String(raw.inspeccionId).trim() : undefined,
    inspeccionPuntaje: Number(raw.inspeccionPuntaje) || undefined,
    inspeccionDetalle: raw.inspeccionDetalle !== undefined && raw.inspeccionDetalle !== null ? String(raw.inspeccionDetalle).trim() : undefined,
    descripcionEvento: raw.descripcionEvento !== undefined && raw.descripcionEvento !== null ? String(raw.descripcionEvento).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    lugarEspecifico: toCleanStringOrUndefined(raw.lugarEspecifico ?? raw.lugarExacto ?? raw.lugar ?? raw['Lugar Específico'] ?? raw['Lugar']),
    probabilidadOcurrencia: Number(raw.probabilidadOcurrencia) || 1,
    consecuenciaPersonas: Number(raw.consecuenciaPersonas) || 1,
    consecuenciaActivos: Number(raw.consecuenciaActivos) || 1,
    consecuenciaOperacion: Number(raw.consecuenciaOperacion) || 1,
    nivelRiesgoCalculado: Number(raw.nivelRiesgoCalculado) || 1,
    esHiPo: Boolean(raw.esHiPo),
    diasSimulados: Number(raw.diasSimulados) || 0,
    remuneracionDiaria: Number(raw.remuneracionDiaria) || 0,
    costoRemuneracionSimulada: Number(raw.costoRemuneracionSimulada) || 0,
    trabajadoresAfectadosParalizacion: Number(raw.trabajadoresAfectadosParalizacion) || 0,
    horasParalizadas: Number(raw.horasParalizadas) || 0,
    costoHoraHombre: Number(raw.costoHoraHombre) || 0,
    costoMaquinariaDanos: Number(raw.costoMaquinariaDanos) || 0,
    otrosCostosParalizacion: Number(raw.otrosCostosParalizacion) || 0,
    costoParalizacionTotal: Number(raw.costoParalizacionTotal) || 0,
    costosDirectos: {
      atencionEmergencia: Number(cd.atencionEmergencia) || 0,
      gastosClinicos: Number(cd.gastosClinicos) || 0,
      subsidioDiasPerdidos: Number(cd.subsidioDiasPerdidos) || 0,
      reparacionEquipos: Number(cd.reparacionEquipos) || 0,
      medicamentos: Number(cd.medicamentos) || 0
    },
    costosIndirectos: {
      paralizacionPlanta: Number(ci.paralizacionPlanta) || 0,
      horasHombreInvestigacion: Number(ci.horasHombreInvestigacion) || 0,
      reemplazoPersonal: Number(ci.reemplazoPersonal) || 0,
      multasSanciones: Number(ci.multasSanciones) || 0,
      perdidaProductividad: Number(ci.perdidaProductividad) || 0
    },
    costoTotalDirecto: Number(raw.costoTotalDirecto) || 0,
    costoTotalIndirecto: Number(raw.costoTotalIndirecto) || 0,
    costoTotalEstimado: Number(raw.costoTotalEstimado) || 0,
    costoRealIncurrido: Number(raw.costoRealIncurrido) || 0,
    brechaCosto: Number(raw.brechaCosto) || 0,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Actos y Condiciones Inseguras (Módulo 3)
export const sanitizeActoCondicion = (raw: any): ActoCondicionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `AC-${Date.now()}`,
      codigoReporte: `AC-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      reportadoPor: '',
      clasificacion: 'Acto Inseguro',
      categoriaCodigo: 'CAT-01',
      categoriaNombre: 'General',
      potencialGravedad: 2,
      prioridad: 'Media',
      descripcion: '',
      estado: 'Pendiente',
      createdAt: new Date().toISOString()
    };
  }

  // Código de Reporte / Registro (admite codigoReporte, codigoRegistro, codigo, id, nroReporte, etc.)
  const rawCode =
    raw.codigoReporte ??
    raw.codigoRegistro ??
    raw.codigo ??
    raw.id ??
    raw.nroReporte ??
    raw['Código de Registro'] ??
    raw['Código Reporte'] ??
    raw['Código'] ??
    raw['Codigo'];
  const codRep =
    rawCode !== undefined && rawCode !== null && String(rawCode).trim() !== ''
      ? String(rawCode).trim()
      : `AC-${Date.now()}`;
  const idStr =
    raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
      ? String(raw.id).trim()
      : codRep;

  // Empresa (reconoce PERPOL, TR3, TR3 ALIMENTOS, PERPOL IDEAS, minúsculas o mayúsculas)
  const rawEmp = String(raw.empresa ?? raw.Empresa ?? raw['Compañía'] ?? raw['Sede'] ?? '').toUpperCase();
  const empresaVal: 'PERPOL' | 'TR3' = rawEmp.includes('TR3') ? 'TR3' : 'PERPOL';

  // Fecha (YYYY-MM-DD)
  const rawFecha = raw.fecha ?? raw.Fecha ?? raw.fechaReporte ?? raw['Fecha del Reporte'] ?? raw['Fecha de Reporte'];
  const fechaStr = rawFecha ? String(rawFecha).slice(0, 10) : new Date().toISOString().slice(0, 10);

  // Clasificación / Tipo
  const rawClasif = String(
    raw.clasificacion ??
    raw.Clasificación ??
    raw.tipoReporte ??
    raw.tipo ??
    raw.Tipo ??
    raw['Tipo de Reporte'] ??
    ''
  ).trim();
  const clasificacionVal: 'Acto Inseguro' | 'Condición Insegura' =
    rawClasif.toLowerCase().includes('condici') ? 'Condición Insegura' : 'Acto Inseguro';

  // Área
  const rawArea = toCleanStringOrUndefined(raw.areaActo ?? raw.areaCondicion ?? raw.area ?? raw.Area ?? raw['Área'] ?? raw['Area']);
  const areaActoVal = toCleanStringOrUndefined(raw.areaActo ?? rawArea);
  const areaCondicionVal = toCleanStringOrUndefined(raw.areaCondicion ?? rawArea);

  // Trabajador Observado
  const trabajadorNombre = toCleanStringOrUndefined(
    raw.trabajadorObservadoNombre ??
    raw.trabajadorObservado ??
    raw.trabajador ??
    raw.colaborador ??
    raw['Trabajador Observado'] ??
    raw['Trabajador']
  );

  // Lugar específico
  const lugarVal = toCleanStringOrUndefined(
    raw.lugarEspecifico ??
    raw.lugarExacto ??
    raw.lugar ??
    raw.ubicacion ??
    raw['Lugar Específico'] ??
    raw['Lugar']
  );

  // Categoría
  const rawCatCod =
    toCleanStringOrUndefined(
      raw.categoriaCodigo ??
      raw.categoriaId ??
      raw.codigoCategoria ??
      raw.cat_id ??
      raw['Código de Categoría']
    ) || 'CAT-01';
  const rawCatNom =
    toCleanStringOrUndefined(
      raw.categoriaNombre ??
      raw.categoria ??
      raw['Categoría']
    );
  const foundCat = CATALOGO_CATEGORIAS_RIESGO.find((c) => c.codigo === rawCatCod);
  const finalCatNom = foundCat ? foundCat.nombre : (rawCatNom || 'General');

  // Potencial de Gravedad y Prioridad
  const pgNum = Number(raw.potencialGravedad ?? raw.pg ?? raw['Potencial Gravedad']) || 2;
  const pgVal = (pgNum >= 1 && pgNum <= 4 ? pgNum : 2) as 1 | 2 | 3 | 4;
  const prioridadVal = raw.prioridad ?? raw.Prioridad ?? raw.nivelRiesgo ?? 'Media';

  // Descripción
  const descVal =
    toCleanStringOrUndefined(raw.descripcion ?? raw.Descripcion ?? raw['Descripción'] ?? raw.detalle ?? '') || '';

  // Estado
  const rawEstado = String(raw.estado ?? raw.Estado ?? '').trim();
  const estadoVal: 'Pendiente' | 'En proceso' | 'Cerrado' =
    rawEstado.toLowerCase() === 'cerrado' || rawEstado.toLowerCase() === 'subsanado'
      ? 'Cerrado'
      : rawEstado.toLowerCase().includes('proceso')
      ? 'En proceso'
      : 'Pendiente';

  // Reportado por
  const reportadoVal =
    toCleanStringOrUndefined(raw.reportadoPor ?? raw.reportado_por ?? raw['Reportado Por'] ?? raw.reporta) || '';

  return {
    ...raw,
    id: idStr,
    codigoReporte: codRep,
    empresa: empresaVal,
    fecha: fechaStr,
    reportadoPor: reportadoVal,
    clasificacion: clasificacionVal,
    categoriaCodigo: rawCatCod,
    categoriaNombre: finalCatNom,
    potencialGravedad: pgVal,
    prioridad: prioridadVal,
    descripcion: descVal,
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl ?? raw.foto ?? raw.evidencia),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    tipoPersonal: raw.tipoPersonal || undefined,
    empresaPersonal: toCleanStringOrUndefined(raw.empresaPersonal),
    trabajadorObservadoDni: toCleanStringOrUndefined(raw.trabajadorObservadoDni ?? raw.dni),
    trabajadorObservadoNombre: trabajadorNombre,
    cargoObservado: toCleanStringOrUndefined(raw.cargoObservado ?? raw.cargo ?? raw.puesto),
    areaActo: areaActoVal,
    turnoActo: raw.turnoActo || undefined,
    areaCondicion: areaCondicionVal,
    lugarEspecifico: lugarVal,
    estado: estadoVal,
    medidaCorrectiva: toCleanStringOrUndefined(raw.medidaCorrectiva ?? raw['Medida Correctiva'] ?? raw.accionCorrectiva),
    responsableSeguimiento: toCleanStringOrUndefined(raw.responsableSeguimiento ?? raw.responsable ?? raw['Responsable']),
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    fotoCierreUrl: toCleanStringOrUndefined(raw.fotoCierreUrl),
    fotoCierreDriveId: toCleanStringOrUndefined(raw.fotoCierreDriveId),
    observacionCierre: toCleanStringOrUndefined(raw.observacionCierre),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Programa Anual SST (Módulo 7)
export const sanitizeProgramaAnual = (raw: any): ProgramaAnualRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `PROG-${Date.now()}`,
      anio: new Date().getFullYear(),
      numeroItem: 1,
      empresa: 'PERPOL',
      objetivoGeneral: '',
      actividad: '',
      tipoActividad: 'Regular',
      responsable: '',
      presupuestoEstimado: 0,
      metaPorcentaje: 100,
      indicadorFormula: '',
      programacionMeses: Array(12).fill(false),
      ejecucionMeses: Array(12).fill(false),
      estado: 'Programado',
      avanceCalculado: 0,
      createdAt: new Date().toISOString()
    };
  }
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : `PROG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  let prog = raw.programacionMeses;
  if (typeof prog === 'string') {
    try { prog = JSON.parse(prog); } catch { prog = []; }
  }
  let ejec = raw.ejecucionMeses;
  if (typeof ejec === 'string') {
    try { ejec = JSON.parse(ejec); } catch { ejec = []; }
  }

  const cleanProg = Array.isArray(prog) && prog.length === 12 ? prog.map(Boolean) : Array(12).fill(false);
  const cleanEjec = Array.isArray(ejec) && ejec.length === 12 ? ejec.map(Boolean) : Array(12).fill(false);

  return {
    ...raw,
    id: idStr,
    anio: Number(raw.anio) || new Date().getFullYear(),
    numeroItem: Number(raw.numeroItem) || 1,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    objetivoGeneral: raw.objetivoGeneral !== undefined && raw.objetivoGeneral !== null ? String(raw.objetivoGeneral).trim() : '',
    objetivoEspecifico: raw.objetivoEspecifico !== undefined && raw.objetivoEspecifico !== null ? String(raw.objetivoEspecifico).trim() : undefined,
    actividad: raw.actividad !== undefined && raw.actividad !== null ? String(raw.actividad).trim() : '',
    tipoActividad: raw.tipoActividad === 'A Demanda' ? 'A Demanda' : 'Regular',
    responsable: raw.responsable !== undefined && raw.responsable !== null ? String(raw.responsable).trim() : '',
    presupuestoEstimado: Number(raw.presupuestoEstimado) || 0,
    metaPorcentaje: Number(raw.metaPorcentaje) || 100,
    indicadorFormula: raw.indicadorFormula !== undefined && raw.indicadorFormula !== null ? String(raw.indicadorFormula).trim() : '',
    programacionMeses: cleanProg,
    ejecucionMeses: cleanEjec,
    estado: raw.estado || 'Programado',
    avanceCalculado: Number(raw.avanceCalculado) || 0,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Resumen Mensual y Horas-Hombre (HH) (Módulo 7)
export const sanitizeResumenHH = (raw: any): ResumenMensualHH => {
  const yr = new Date().getFullYear();
  if (!raw || typeof raw !== 'object') {
    return {
      id: `${yr}-01`,
      empresa: 'PERPOL',
      anio: yr,
      mes: 1,
      trabajadoresPerpol: 0,
      hhPerpol: 0,
      trabajadoresTr3: 0,
      hhTr3: 0,
      totalTrabajadores: 0,
      totalHH: 0,
      createdAt: new Date().toISOString()
    };
  }
  const anio = Number(raw.anio) || yr;
  const mes = Math.max(1, Math.min(12, Number(raw.mes) || 1));
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : `${anio}-${mes < 10 ? '0' + mes : mes}`;

  const tPerpol = Number(raw.trabajadoresPerpol) || 0;
  const hPerpol = Number(raw.hhPerpol) || 0;
  const tTr3 = Number(raw.trabajadoresTr3) || 0;
  const hTr3 = Number(raw.hhTr3) || 0;

  return {
    ...raw,
    id: idStr,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    anio,
    mes,
    trabajadoresPerpol: tPerpol,
    hhPerpol: hPerpol,
    trabajadoresTr3: tTr3,
    hhTr3: hTr3,
    totalTrabajadores: Number(raw.totalTrabajadores) || (tPerpol + tTr3),
    totalHH: Number(raw.totalHH) || (hPerpol + hTr3),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

interface AppState {
  // Filtro de empresa activa
  empresaActiva: EmpresaId;
  setEmpresaActiva: (empresa: EmpresaId) => void;

  // Base global de Trabajadores (fuente de datos para autocompletado en toda la app)
  trabajadores: TrabajadorRecord[];
  setTrabajadores: (trabajadores: TrabajadorRecord[]) => void;
  upsertTrabajador: (trabajador: TrabajadorRecord) => void;
  batchUpsertTrabajadores: (trabajadores: TrabajadorRecord[]) => void;
  removeTrabajador: (idOrDni: string) => void;
  getTrabajadoresActivos: (empresa?: EmpresaId) => TrabajadorRecord[];

  // Inspecciones SST (Módulo 2 - fuente para vinculación y seguimiento)
  inspecciones: InspeccionRecord[];
  setInspecciones: (inspecciones: InspeccionRecord[]) => void;
  upsertInspeccion: (inspeccion: InspeccionRecord) => void;
  batchUpsertInspecciones: (inspecciones: InspeccionRecord[]) => void;
  removeInspeccion: (idOrCodigo: string) => void;
  vincularAtencionAInspeccion: (inspeccionId: string, atencionResumen: string) => void;

  // Consumo de Botiquín y Tópico (Módulo 4)
  consumosBotiquin: ConsumoBotiquinRecord[];
  setConsumosBotiquin: (consumos: ConsumoBotiquinRecord[]) => void;
  upsertConsumoBotiquin: (consumo: ConsumoBotiquinRecord) => void;
  batchUpsertConsumosBotiquin: (consumos: ConsumoBotiquinRecord[]) => void;
  removeConsumoBotiquin: (id: string) => void;
  marcarAtencionTransferida: (id: string, casoAccidenteId?: string) => void;
  descartarAtencionTransferencia: (id: string) => void;

  // Accidentes e Incidentes (Módulo 1)
  accidentes: AccidenteRecord[];
  setAccidentes: (accidentes: AccidenteRecord[]) => void;
  upsertAccidente: (accidente: AccidenteRecord) => void;
  batchUpsertAccidentes: (accidentes: AccidenteRecord[]) => void;
  removeAccidente: (id: string) => void;

  // Atenciones Médicas (Módulo 2 - Independizado)
  atencionesMedicas: AtencionMedicaRecord[];
  setAtencionesMedicas: (atenciones: AtencionMedicaRecord[]) => void;
  upsertAtencionMedica: (atencion: AtencionMedicaRecord) => void;
  batchUpsertAtencionesMedicas: (atenciones: AtencionMedicaRecord[]) => void;
  removeAtencionMedica: (id: string) => void;

  // Resumen del Programa Anual (para alimentar Estadísticas SST)
  programaResumen: ProgramaResumenAnual | null;
  setProgramaResumen: (resumen: ProgramaResumenAnual) => void;

  // Investigaciones de Accidentes (Módulo 10)
  investigaciones: InvestigacionRecord[];
  setInvestigaciones: (investigaciones: InvestigacionRecord[]) => void;
  upsertInvestigacion: (investigacion: InvestigacionRecord) => void;
  batchUpsertInvestigaciones: (investigaciones: InvestigacionRecord[]) => void;
  removeInvestigacion: (id: string) => void;

  // Simulación de Costos de Incidentes (Módulo 9)
  simulacionesCostos: SimulacionCostosRecord[];
  setSimulacionesCostos: (simulaciones: SimulacionCostosRecord[]) => void;
  upsertSimulacionCostos: (simulacion: SimulacionCostosRecord) => void;
  batchUpsertSimulacionesCostos: (simulaciones: SimulacionCostosRecord[]) => void;
  removeSimulacionCostos: (id: string) => void;

  // Actos y Condiciones Inseguras (Módulo 3)
  actosCondiciones: ActoCondicionRecord[];
  setActosCondiciones: (actosCondiciones: ActoCondicionRecord[]) => void;
  upsertActoCondicion: (acto: ActoCondicionRecord) => void;
  batchUpsertActosCondiciones: (newActos: ActoCondicionRecord[]) => void;
  removeActoCondicion: (idOrCodigo: string) => void;

  // Resumen Mensual y Horas-Hombre (HH) (Módulo 7)
  horasHombre: ResumenMensualHH[];
  setHorasHombre: (horasHombre: ResumenMensualHH[]) => void;
  upsertHorasHombre: (record: ResumenMensualHH) => void;
  batchUpsertHorasHombre: (records: ResumenMensualHH[]) => void;
  removeHorasHombre: (idOrMesAnio: string) => void;

  // Metas e Indicadores SST (Módulo 8)
  metasIndicadores: MetaIndicadoresSST;
  setMetasIndicadores: (metas: MetaIndicadoresSST) => void;
  estadisticasDashboard: EstadisticasDashboardData | null;
  setEstadisticasDashboard: (data: EstadisticasDashboardData | null) => void;

  // Configuración de Google Apps Script Web App
  gasWebAppUrl: string;
  setGasWebAppUrl: (url: string) => void;
  driveFolderId: string;
  setDriveFolderId: (folderId: string) => void;
  spreadsheetId: string;
  setSpreadsheetId: (sheetId: string) => void;
  isBackendConnected: boolean;
  setIsBackendConnected: (status: boolean) => void;

  // Estado de sincronización en tiempo real con Google Sheets (Requerimiento 1)
  lastSyncSheetsTime: string | null;
  isSyncingWithSheets: boolean;
  totalSincronizadosSheets: number;
  setLastSyncSheetsTime: (time: string | null) => void;
  setIsSyncingWithSheets: (status: boolean) => void;
  setTotalSincronizadosSheets: (count: number) => void;
  cargarDatosDesdeSheets: (datos: any) => void;

  // Estado de navegación UI
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;

  // Notificaciones y alertas
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id' | 'timestamp'>) => void;
  removeToast: (id: string) => void;

  // Estado de sincronización optimista
  pendingSyncCount: number;
  incrementSync: () => void;
  decrementSync: () => void;

  // Apariencia y Colores de la Marca
  themeColor: ThemeColor;
  customBrandHex: string;
  themeBackground: ThemeBackground;
  setThemeColor: (color: ThemeColor) => void;
  setCustomBrandHex: (hex: string) => void;
  setThemeBackground: (bg: ThemeBackground) => void;
  resetTheme: () => void;

  // Reiniciar contadores y vaciar registros transaccionales (para reiniciar correlativos en 0001)
  resetearContadoresModulos: () => void;
}

// Función de saneamiento: Elimina cualquier zona local oculta o caché residual
export function limpiarAlmacenamientoLocalOculto(): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('ssoma_tab_') || key.startsWith('ssoma_local_') || key.startsWith('ssoma_cache_'))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach((k) => localStorage.removeItem(k));

    // Limpiar entidades de negocio de ssoma-app-storage si existían de versiones anteriores
    const raw = localStorage.getItem('ssoma-app-storage');
    const DEFAULT_GAS_ENDPOINT = 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.state) {
        if (!parsed.state.gasWebAppUrl || typeof parsed.state.gasWebAppUrl !== 'string' || !parsed.state.gasWebAppUrl.startsWith('http') || !parsed.state.gasWebAppUrl.includes('/exec')) {
          parsed.state.gasWebAppUrl = DEFAULT_GAS_ENDPOINT;
        }
        delete parsed.state.trabajadores;
        delete parsed.state.accidentes;
        delete parsed.state.atencionesMedicas;
        delete parsed.state.inspecciones;
        delete parsed.state.consumosBotiquin;
        delete parsed.state.investigaciones;
        delete parsed.state.simulacionesCostos;
        delete parsed.state.contratistas;
        delete parsed.state.actosCondiciones;
        delete parsed.state.horasHombre;
        delete parsed.state.metasIndicadores;
        delete parsed.state.programaResumen;
        localStorage.setItem('ssoma-app-storage', JSON.stringify(parsed));
      }
    }

    // Asegurar que ssoma_gas_webapp_url nunca esté vacío y tenga la URL permanente
    const directUrl = localStorage.getItem('ssoma_gas_webapp_url');
    if (!directUrl || !directUrl.startsWith('http') || !directUrl.includes('/exec')) {
      localStorage.setItem('ssoma_gas_webapp_url', DEFAULT_GAS_ENDPOINT);
    }
  } catch {
    // Almacenamiento local restringido o inaccesible silencioso
  }
}

// Ejecutar limpieza preventiva de zona local oculta de inmediato
limpiarAlmacenamientoLocalOculto();

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      empresaActiva: 'CONSOLIDADO',
      setEmpresaActiva: (empresa) => set({ empresaActiva: empresa }),

      // Trabajadores (Carga directa desde Google Sheets)
      trabajadores: [],
      setTrabajadores: (trabajadores) => set({ trabajadores: ensureUniqueIds((trabajadores || []).map(sanitizeTrabajador), 'TRAB') }),
      upsertTrabajador: (trabajador) => {
        const clean = sanitizeTrabajador(trabajador);
        set((state) => {
          const index = state.trabajadores.findIndex(
            (t) => String(t.id) === clean.id || String(t.dni) === clean.dni
          );
          if (index >= 0) {
            const updated = [...state.trabajadores];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { trabajadores: updated };
          }
          return { trabajadores: [clean, ...state.trabajadores] };
        });
      },
      batchUpsertTrabajadores: (newTrabajadores) => {
        const cleanedItems = (newTrabajadores || []).map(sanitizeTrabajador);
        set((state) => {
          const list = [...state.trabajadores];
          cleanedItems.forEach((item) => {
            const idx = list.findIndex((t) => String(t.id) === item.id || String(t.dni) === item.dni);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { trabajadores: list };
        });
      },
      removeTrabajador: (idOrDni) => {
        const target = String(idOrDni ?? '').trim();
        set((state) => ({
          trabajadores: state.trabajadores.filter((t) => String(t.id || '').trim() !== target && String(t.dni || '').trim() !== target)
        }));
      },
      getTrabajadoresActivos: (empresa) => {
        const emp = empresa || get().empresaActiva;
        return (get().trabajadores || []).filter((t) => {
          const matchCondicion = t.condicion === 'Activo';
          if (!matchCondicion) return false;
          if (emp === 'CONSOLIDADO') return true;
          return t.empresa === emp;
        });
      },

      // Inspecciones SST (Carga directa desde Google Sheets)
      inspecciones: [],
      setInspecciones: (inspecciones) => set({ inspecciones: (inspecciones || []).map(sanitizeInspeccion) }),
      upsertInspeccion: (inspeccion) => {
        const clean = sanitizeInspeccion(inspeccion);
        set((state) => {
          const index = state.inspecciones.findIndex((i) => String(i.id) === clean.id || String(i.codigoInspeccion) === clean.codigoInspeccion);
          if (index >= 0) {
            const updated = [...state.inspecciones];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { inspecciones: updated };
          }
          return { inspecciones: [clean, ...state.inspecciones] };
        });
      },
      batchUpsertInspecciones: (newInspecciones) => {
        const cleaned = (newInspecciones || []).map(sanitizeInspeccion);
        set((state) => {
          const list = [...state.inspecciones];
          cleaned.forEach((item) => {
            const idx = list.findIndex((i) => String(i.id) === item.id || String(i.codigoInspeccion) === item.codigoInspeccion);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { inspecciones: list };
        });
      },
      removeInspeccion: (idOrCodigo) => {
        const target = String(idOrCodigo ?? '').trim();
        set((state) => ({
          inspecciones: (state.inspecciones || []).filter(
            (i) => String(i.id || '').trim() !== target && String(i.codigoInspeccion || '').trim() !== target
          )
        }));
      },
      vincularAtencionAInspeccion: (inspeccionId, atencionResumen) => {
        set((state) => {
          const index = state.inspecciones.findIndex((i) => String(i.id) === String(inspeccionId) || String(i.codigoInspeccion) === String(inspeccionId));
          if (index >= 0) {
            const updated = [...state.inspecciones];
            const currentLinks = updated[index].atencionesPrimerosAuxilios || [];
            if (!currentLinks.includes(atencionResumen)) {
              updated[index] = {
                ...updated[index],
                atencionesPrimerosAuxilios: [...currentLinks, atencionResumen],
                updatedAt: new Date().toISOString()
              };
            }
            return { inspecciones: updated };
          }
          return {};
        });
      },

      // Consumos Botiquín (Carga directa desde Google Sheets)
      consumosBotiquin: [],
      setConsumosBotiquin: (consumosBotiquin) => set({ consumosBotiquin: (consumosBotiquin || []).map(sanitizeConsumoBotiquin) }),
      upsertConsumoBotiquin: (consumo) => {
        const clean = sanitizeConsumoBotiquin(consumo);
        set((state) => {
          const index = state.consumosBotiquin.findIndex(
            (c) => String(c.id) === clean.id || String(c.codigoAtencion) === clean.codigoAtencion
          );
          if (index >= 0) {
            const updated = [...state.consumosBotiquin];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { consumosBotiquin: updated };
          }
          return { consumosBotiquin: [clean, ...state.consumosBotiquin] };
        });
      },
      batchUpsertConsumosBotiquin: (newConsumos) => {
        const cleaned = (newConsumos || []).map(sanitizeConsumoBotiquin);
        set((state) => {
          const list = [...state.consumosBotiquin];
          cleaned.forEach((item) => {
            const idx = list.findIndex((c) => String(c.id) === item.id || String(c.codigoAtencion) === item.codigoAtencion);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { consumosBotiquin: list };
        });
      },
      removeConsumoBotiquin: (id) => {
        const target = String(id ?? '').trim();
        set((state) => ({
          consumosBotiquin: state.consumosBotiquin.filter((c) => String(c.id).trim() !== target && String(c.codigoAtencion).trim() !== target)
        }));
      },
      marcarAtencionTransferida: (id, casoAccidenteId) => {
        const target = String(id ?? '').trim();
        set((state) => {
          const index = state.consumosBotiquin.findIndex((c) => String(c.id).trim() === target || String(c.codigoAtencion).trim() === target);
          if (index >= 0) {
            const updated = [...state.consumosBotiquin];
            updated[index] = {
              ...updated[index],
              transferidoAccidentes: true,
              estadoValidacion: 'Validado',
              casoAccidenteId: casoAccidenteId || updated[index].casoAccidenteId,
              updatedAt: new Date().toISOString()
            };
            return { consumosBotiquin: updated };
          }
          return {};
        });
      },
      descartarAtencionTransferencia: (id) => {
        const target = String(id ?? '').trim();
        set((state) => {
          const index = state.consumosBotiquin.findIndex((c) => String(c.id).trim() === target || String(c.codigoAtencion).trim() === target);
          if (index >= 0) {
            const updated = [...state.consumosBotiquin];
            updated[index] = {
              ...updated[index],
              transferidoAccidentes: false,
              estadoValidacion: 'Descartado',
              updatedAt: new Date().toISOString()
            };
            return { consumosBotiquin: updated };
          }
          return {};
        });
      },

      // Accidentes (Carga directa desde Google Sheets)
      accidentes: [],
      setAccidentes: (accidentes) => set({ accidentes: (accidentes || []).map(sanitizeAccidente) }),
      upsertAccidente: (accidente) => {
        const clean = sanitizeAccidente(accidente);
        set((state) => {
          const index = state.accidentes.findIndex(
            (a) => String(a.id) === clean.id || String(a.codigoCaso) === clean.codigoCaso
          );
          if (index >= 0) {
            const updated = [...state.accidentes];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { accidentes: updated };
          }
          return { accidentes: [clean, ...state.accidentes] };
        });
      },
      batchUpsertAccidentes: (newAccidentes) => {
        const cleaned = (newAccidentes || []).map(sanitizeAccidente);
        set((state) => {
          const list = [...state.accidentes];
          cleaned.forEach((item) => {
            const idx = list.findIndex((a) => String(a.id) === item.id || String(a.codigoCaso) === item.codigoCaso);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { accidentes: list };
        });
      },
      removeAccidente: (id) => {
        const target = String(id ?? '').trim();
        set((state) => ({
          accidentes: state.accidentes.filter((a) => String(a.id).trim() !== target && String(a.codigoCaso).trim() !== target)
        }));
      },

      // Atenciones Médicas (Módulo 2 - Carga directa desde Google Sheets)
      atencionesMedicas: [],
      setAtencionesMedicas: (atenciones) => set({ atencionesMedicas: (atenciones || []).map(sanitizeAtencionMedica) }),
      upsertAtencionMedica: (atencion) => {
        const clean = sanitizeAtencionMedica(atencion);
        set((state) => {
          const index = state.atencionesMedicas.findIndex(
            (m) => String(m.id) === clean.id || String(m.idAtencion) === clean.idAtencion
          );
          if (index >= 0) {
            const updated = [...state.atencionesMedicas];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { atencionesMedicas: updated };
          }
          return { atencionesMedicas: [clean, ...state.atencionesMedicas] };
        });
      },
      batchUpsertAtencionesMedicas: (newAtenciones) => {
        const cleaned = (newAtenciones || []).map(sanitizeAtencionMedica);
        set((state) => {
          const list = [...state.atencionesMedicas];
          cleaned.forEach((item) => {
            const idx = list.findIndex((m) => String(m.id) === item.id || String(m.idAtencion) === item.idAtencion);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { atencionesMedicas: list };
        });
      },
      removeAtencionMedica: (id) => {
        const target = String(id ?? '').trim();
        set((state) => ({
          atencionesMedicas: state.atencionesMedicas.filter((m) => String(m.id).trim() !== target && String(m.idAtencion).trim() !== target)
        }));
      },

      // Resumen Programa Anual
      programaResumen: null,
      setProgramaResumen: (programaResumen) => set({ programaResumen }),

      // Investigaciones de Accidentes (Módulo 10 - Carga directa desde Google Sheets)
      investigaciones: [],
      setInvestigaciones: (investigaciones) => set({ investigaciones: (investigaciones || []).map(sanitizeInvestigacion) }),
      upsertInvestigacion: (investigacion) => {
        const clean = sanitizeInvestigacion(investigacion);
        set((state) => {
          const index = state.investigaciones.findIndex(
            (inv) => String(inv.id) === clean.id || String(inv.codigoInvestigacion) === clean.codigoInvestigacion
          );
          if (index >= 0) {
            const updated = [...state.investigaciones];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { investigaciones: updated };
          }
          return { investigaciones: [clean, ...state.investigaciones] };
        });
      },
      batchUpsertInvestigaciones: (newInvs) => {
        const cleaned = (newInvs || []).map(sanitizeInvestigacion);
        set((state) => {
          const list = [...state.investigaciones];
          cleaned.forEach((item) => {
            const idx = list.findIndex((i) => String(i.id) === item.id || String(i.codigoInvestigacion) === item.codigoInvestigacion);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { investigaciones: list };
        });
      },
      removeInvestigacion: (id) => {
        const target = String(id ?? '').trim();
        set((state) => ({
          investigaciones: state.investigaciones.filter((inv) => String(inv.id).trim() !== target && String(inv.codigoInvestigacion).trim() !== target)
        }));
      },

      // Simulación de Costos de Incidentes (Módulo 9 - Carga directa desde Google Sheets)
      simulacionesCostos: [],
      setSimulacionesCostos: (simulacionesCostos) => set({ simulacionesCostos: (simulacionesCostos || []).map(sanitizeSimulacionCostos) }),
      upsertSimulacionCostos: (simulacion) => {
        const clean = sanitizeSimulacionCostos(simulacion);
        set((state) => {
          const index = state.simulacionesCostos.findIndex(
            (s) => String(s.id) === clean.id || String(s.codigoSimulacion) === clean.codigoSimulacion
          );
          if (index >= 0) {
            const updated = [...state.simulacionesCostos];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { simulacionesCostos: updated };
          }
          return { simulacionesCostos: [clean, ...state.simulacionesCostos] };
        });
      },
      batchUpsertSimulacionesCostos: (newSims) => {
        const cleaned = (newSims || []).map(sanitizeSimulacionCostos);
        set((state) => {
          const list = [...state.simulacionesCostos];
          cleaned.forEach((item) => {
            const idx = list.findIndex((s) => String(s.id) === item.id || String(s.codigoSimulacion) === item.codigoSimulacion);
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { simulacionesCostos: list };
        });
      },
      removeSimulacionCostos: (id) => {
        const target = String(id ?? '').trim();
        set((state) => ({
          simulacionesCostos: state.simulacionesCostos.filter((s) => String(s.id).trim() !== target && String(s.codigoSimulacion).trim() !== target)
        }));
      },

      // Actos y Condiciones Inseguras (Módulo 3 - Carga directa desde Google Sheets)
      actosCondiciones: [],
      setActosCondiciones: (actosCondiciones) => set({ actosCondiciones: (actosCondiciones || []).map(sanitizeActoCondicion) }),
      upsertActoCondicion: (acto) => {
        const clean = sanitizeActoCondicion(acto);
        set((state) => {
          const index = state.actosCondiciones.findIndex(
            (a) => String(a.id) === clean.id || String(a.codigoReporte) === clean.codigoReporte
          );
          if (index >= 0) {
            const updated = [...state.actosCondiciones];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return { actosCondiciones: updated };
          }
          return { actosCondiciones: [clean, ...state.actosCondiciones] };
        });
      },
      batchUpsertActosCondiciones: (newActos) => {
        const cleaned = (newActos || []).map(sanitizeActoCondicion);
        set((state) => {
          const list = [...state.actosCondiciones];
          cleaned.forEach((item) => {
            const idx = list.findIndex(
              (a) => String(a.id) === item.id || String(a.codigoReporte) === item.codigoReporte
            );
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.unshift(item);
            }
          });
          return { actosCondiciones: list };
        });
      },
      removeActoCondicion: (idOrCodigo) => {
        const target = String(idOrCodigo ?? '').trim();
        set((state) => ({
          actosCondiciones: state.actosCondiciones.filter(
            (a) => String(a.id).trim() !== target && String(a.codigoReporte || '').trim() !== target
          )
        }));
      },

      // Resumen Mensual y Horas-Hombre (HH) (Módulo 7 - Carga directa desde Google Sheets)
      horasHombre: [],
      setHorasHombre: (horasHombre) =>
        set({ horasHombre: (horasHombre || []).map(sanitizeResumenHH) }),
      upsertHorasHombre: (record) => {
        const clean = sanitizeResumenHH(record);
        set((state) => {
          const index = state.horasHombre.findIndex(
            (h) => String(h.id) === clean.id || (h.anio === clean.anio && h.mes === clean.mes)
          );
          if (index >= 0) {
            const updated = [...state.horasHombre];
            updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
            return {
              horasHombre: updated.sort((a, b) =>
                a.anio !== b.anio ? a.anio - b.anio : a.mes - b.mes
              )
            };
          }
          return {
            horasHombre: [...state.horasHombre, clean].sort((a, b) =>
              a.anio !== b.anio ? a.anio - b.anio : a.mes - b.mes
            )
          };
        });
      },
      batchUpsertHorasHombre: (records) => {
        const cleaned = (records || []).map(sanitizeResumenHH);
        set((state) => {
          const list = [...state.horasHombre];
          cleaned.forEach((item) => {
            const idx = list.findIndex(
              (h) => String(h.id) === item.id || (h.anio === item.anio && h.mes === item.mes)
            );
            if (idx >= 0) {
              list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
            } else {
              list.push(item);
            }
          });
          return {
            horasHombre: list.sort((a, b) =>
              a.anio !== b.anio ? a.anio - b.anio : a.mes - b.mes
            )
          };
        });
      },
      removeHorasHombre: (idOrMesAnio) => {
        const target = String(idOrMesAnio ?? '').trim();
        set((state) => ({
          horasHombre: state.horasHombre.filter((h) => String(h.id).trim() !== target)
        }));
      },

      // Metas e Indicadores SST (Módulo 8)
      metasIndicadores: DEFAULT_METAS_INDICADORES,
      setMetasIndicadores: (metasIndicadores) => set({ metasIndicadores }),
      estadisticasDashboard: null,
      setEstadisticasDashboard: (estadisticasDashboard) => set({ estadisticasDashboard }),

      // GAS Web App URL Permanente
      gasWebAppUrl: (() => {
        try {
          const direct = localStorage.getItem('ssoma_gas_webapp_url');
          if (direct && direct.trim() && direct.includes('/exec')) return direct.trim();
        } catch {}
        const envUrl = ((import.meta as unknown as { env?: { VITE_GAS_API_URL?: string } })?.env?.VITE_GAS_API_URL) || '';
        if (envUrl && envUrl.trim() && envUrl.includes('/exec')) return envUrl.trim();
        return 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';
      })(),
      setGasWebAppUrl: (url) => {
        const trimmed = (url && url.trim().length > 0 && url.includes('/exec'))
          ? url.trim()
          : 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';
        try {
          localStorage.setItem('ssoma_gas_webapp_url', trimmed);
        } catch {}
        set({ gasWebAppUrl: trimmed });
      },
      driveFolderId: (() => {
        try {
          const direct = localStorage.getItem('ssoma_drive_folder_id');
          if (direct && direct.trim()) return direct.trim();
        } catch {}
        return '';
      })(),
      setDriveFolderId: (driveFolderId) => {
        const trimmed = driveFolderId.trim();
        try {
          if (trimmed) {
            localStorage.setItem('ssoma_drive_folder_id', trimmed);
          } else {
            localStorage.removeItem('ssoma_drive_folder_id');
          }
        } catch {}
        set({ driveFolderId: trimmed });
      },
      spreadsheetId: '',
      setSpreadsheetId: (spreadsheetId) => set({ spreadsheetId: spreadsheetId.trim() }),
      isBackendConnected: (() => {
        try {
          const val = localStorage.getItem('ssoma_backend_connected');
          if (val === 'false') return false;
          return true; // Predeterminado a conectado para la URL permanente oficial
        } catch {
          return true;
        }
      })(),
      setIsBackendConnected: (isBackendConnected) => {
        try {
          localStorage.setItem('ssoma_backend_connected', String(isBackendConnected));
        } catch {}
        set({ isBackendConnected });
      },

      // Requerimiento 1: Sincronización en tiempo real desde Google Sheets
      lastSyncSheetsTime: null,
      isSyncingWithSheets: false,
      totalSincronizadosSheets: 0,
      setLastSyncSheetsTime: (lastSyncSheetsTime) => set({ lastSyncSheetsTime }),
      setIsSyncingWithSheets: (isSyncingWithSheets) => set({ isSyncingWithSheets }),
      setTotalSincronizadosSheets: (totalSincronizadosSheets) => set({ totalSincronizadosSheets }),
      cargarDatosDesdeSheets: (payload: any) => {
        const data = payload?.data || payload;
        if (!data || typeof data !== 'object') return;

        set(() => {
          const next: Partial<AppState> = {
            isBackendConnected: true,
            lastSyncSheetsTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            isSyncingWithSheets: false
          };

          let total = 0;

          if (Array.isArray(data.trabajadores)) {
            next.trabajadores = ensureUniqueIds(data.trabajadores.map(sanitizeTrabajador), 'TRAB');
            total += data.trabajadores.length;
          }
          if (Array.isArray(data.accidentes)) {
            next.accidentes = ensureUniqueIds(data.accidentes.map(sanitizeAccidente), 'ACC');
            total += data.accidentes.length;
          }
          if (Array.isArray(data.atencionesMedicas)) {
            next.atencionesMedicas = ensureUniqueIds(data.atencionesMedicas.map(sanitizeAtencionMedica), 'ATN');
            total += data.atencionesMedicas.length;
          }
          if (Array.isArray(data.inspecciones)) {
            next.inspecciones = ensureUniqueIds(data.inspecciones.map(sanitizeInspeccion), 'INSP');
            total += data.inspecciones.length;
          }
          if (Array.isArray(data.atencionesBotiquin)) {
            next.consumosBotiquin = ensureUniqueIds(data.atencionesBotiquin.map(sanitizeConsumoBotiquin), 'BOT');
            total += data.atencionesBotiquin.length;
          } else if (Array.isArray(data.consumosBotiquin)) {
            next.consumosBotiquin = ensureUniqueIds(data.consumosBotiquin.map(sanitizeConsumoBotiquin), 'BOT');
            total += data.consumosBotiquin.length;
          }
          if (Array.isArray(data.investigaciones)) {
            next.investigaciones = ensureUniqueIds(data.investigaciones.map(sanitizeInvestigacion), 'INV');
            total += data.investigaciones.length;
          }
          if (Array.isArray(data.simulacionesCostos)) {
            next.simulacionesCostos = ensureUniqueIds(data.simulacionesCostos.map(sanitizeSimulacionCostos), 'SIM');
            total += data.simulacionesCostos.length;
          }
          const rawActos =
            data.actosCondiciones ||
            data.actos_condiciones ||
            data.actos ||
            data.actosYCondiciones ||
            data.SSOMA_ActosCondiciones ||
            data.SSOMA_Actos_Condiciones;
          if (Array.isArray(rawActos)) {
            next.actosCondiciones = ensureUniqueIds(rawActos.map(sanitizeActoCondicion), 'ACT');
            total += rawActos.length;
          }
          if (Array.isArray(data.horasHombre)) {
            next.horasHombre = ensureUniqueIds(data.horasHombre.map(sanitizeResumenHH), 'HH');
            total += data.horasHombre.length;
          } else if (Array.isArray(data.resumenHH)) {
            next.horasHombre = ensureUniqueIds(data.resumenHH.map(sanitizeResumenHH), 'HH');
            total += data.resumenHH.length;
          }
          if (data.metasSST && typeof data.metasSST === 'object' && !Array.isArray(data.metasSST)) {
            next.metasIndicadores = data.metasSST;
          }
          if (Array.isArray(data.programaAnual)) {
            total += data.programaAnual.length;
          }

          next.totalSincronizadosSheets = total;
          return next;
        });
      },

      // UI
      sidebarOpen: true,
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),

      // Toasts
      toasts: [],
      addToast: (toast) => {
        const id = Math.random().toString(36).substring(2, 9);
        const newToast: ToastMessage = { ...toast, id, timestamp: Date.now() };
        set((state) => ({ toasts: [...state.toasts.slice(-4), newToast] }));
        setTimeout(() => {
          set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
        }, 4500);
      },
      removeToast: (id) =>
        set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),

      // Sync counter
      pendingSyncCount: 0,
      incrementSync: () => set((state) => ({ pendingSyncCount: state.pendingSyncCount + 1 })),
      decrementSync: () =>
        set((state) => ({ pendingSyncCount: Math.max(0, state.pendingSyncCount - 1) })),

      // Apariencia y Colores de la Marca
      themeColor: 'corporate',
      customBrandHex: '#263B5E',
      themeBackground: 'light',
      setThemeColor: (color) => {
        set({ themeColor: color });
        applyTheme(color, get().customBrandHex, get().themeBackground);
      },
      setCustomBrandHex: (hex) => {
        set({ customBrandHex: hex, themeColor: 'custom' });
        applyTheme('custom', hex, get().themeBackground);
      },
      setThemeBackground: (themeBackground) => {
        set({ themeBackground });
        applyTheme(get().themeColor, get().customBrandHex, themeBackground);
      },
      resetTheme: () => {
        set({ themeColor: 'corporate', customBrandHex: '#263B5E', themeBackground: 'light' });
        applyTheme('corporate', '#263B5E', 'light');
      },

      // Reinicio de contadores y registros de módulos para comenzar desde 0001
      resetearContadoresModulos: () => {
        set({
          accidentes: [],
          actosCondiciones: [],
          inspecciones: [],
          investigaciones: [],
          atencionesMedicas: [],
          consumosBotiquin: [],
          simulacionesCostos: [],
          programaResumen: null
        });
      }
    }),
    {
      name: 'ssoma-app-storage',
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.themeBackground = 'light';
          if (!state.themeColor || state.themeColor === 'emerald') {
            state.themeColor = 'corporate';
            state.customBrandHex = '#263B5E';
          }
          applyTheme(state.themeColor || 'corporate', state.customBrandHex || '#263B5E', 'light');

          // Si la URL guardada en localStorage estuviera vacía o no fuera válida, restaurar la URL oficial permanente
          if (!state.gasWebAppUrl || state.gasWebAppUrl.trim().length === 0 || !state.gasWebAppUrl.includes('/exec')) {
            state.gasWebAppUrl = 'https://script.google.com/macros/s/AKfycby9w5US4caD8wspGgpS8avcHEdb7LmC8FM7-DSQwtYhrLorwO0Vwu7C0Gnma6mHa2RH3g/exec';
          }
        }
      },
      // Exclusivamente se persisten configuraciones de conexión y preferencias de interfaz
      // NUNCA se guardan registros de negocio en almacenamiento local (sin zona local oculta)
      partialize: (state) => ({
        empresaActiva: state.empresaActiva,
        gasWebAppUrl: state.gasWebAppUrl,
        driveFolderId: state.driveFolderId,
        spreadsheetId: state.spreadsheetId,
        isBackendConnected: state.isBackendConnected,
        sidebarOpen: state.sidebarOpen,
        themeColor: state.themeColor,
        customBrandHex: state.customBrandHex,
        themeBackground: state.themeBackground
      })
    }
  )
);
