/**
 * useDataStore: Store central de registros de negocio SSOMA.
 * Mantiene en memoria de sesión: Trabajadores, Accidentes, Atenciones Médicas,
 * Inspecciones, Botiquín, Investigaciones, Costos, Actos/Condiciones, Horas-Hombre y Metas.
 * Evita persistencia desfasada en disco (sin almacenamiento residual local).
 */
import { create } from 'zustand';
import { EmpresaId } from '../types';
import {
  TrabajadorRecord,
  ProgramaResumenAnual,
  ConsumoBotiquinRecord,
  AccidenteRecord,
  InspeccionRecord,
  InvestigacionRecord,
  SimulacionCostosRecord,
  ActoCondicionRecord,
  ProgramaAnualRecord,
  ResumenMensualHH,
  MetaIndicadoresSST,
  EstadisticasDashboardData,
  AtencionMedicaRecord
} from '../types/modules';
import {
  DEFAULT_METAS_INDICADORES,
  ensureUniqueIds,
  sanitizeTrabajador,
  sanitizeAccidente,
  sanitizeAtencionMedica,
  sanitizeInspeccion,
  sanitizeConsumoBotiquin,
  sanitizeInvestigacion,
  sanitizeSimulacionCostos,
  sanitizeActoCondicion,
  sanitizeProgramaAnual,
  sanitizeHorasHombre
} from './sanitizers';

export interface DataState {
  // Base global de Trabajadores
  trabajadores: TrabajadorRecord[];
  setTrabajadores: (trabajadores: TrabajadorRecord[]) => void;
  upsertTrabajador: (trabajador: TrabajadorRecord) => void;
  batchUpsertTrabajadores: (trabajadores: TrabajadorRecord[]) => void;
  removeTrabajador: (idOrDni: string) => void;
  getTrabajadoresActivos: (empresa?: EmpresaId) => TrabajadorRecord[];

  // Inspecciones SST
  inspecciones: InspeccionRecord[];
  setInspecciones: (inspecciones: InspeccionRecord[]) => void;
  upsertInspeccion: (inspeccion: InspeccionRecord) => void;
  batchUpsertInspecciones: (inspecciones: InspeccionRecord[]) => void;
  removeInspeccion: (idOrCodigo: string) => void;
  vincularAtencionAInspeccion: (inspeccionId: string, atencionResumen: string) => void;

  // Consumo de Botiquín
  consumosBotiquin: ConsumoBotiquinRecord[];
  setConsumosBotiquin: (consumos: ConsumoBotiquinRecord[]) => void;
  upsertConsumoBotiquin: (consumo: ConsumoBotiquinRecord) => void;
  batchUpsertConsumosBotiquin: (consumos: ConsumoBotiquinRecord[]) => void;
  removeConsumoBotiquin: (id: string) => void;
  marcarAtencionTransferida: (id: string, casoAccidenteId?: string) => void;
  descartarAtencionTransferencia: (id: string) => void;

  // Accidentes e Incidentes
  accidentes: AccidenteRecord[];
  setAccidentes: (accidentes: AccidenteRecord[]) => void;
  upsertAccidente: (accidente: AccidenteRecord) => void;
  batchUpsertAccidentes: (accidentes: AccidenteRecord[]) => void;
  removeAccidente: (id: string) => void;

  // Atenciones Médicas
  atencionesMedicas: AtencionMedicaRecord[];
  setAtencionesMedicas: (atenciones: AtencionMedicaRecord[]) => void;
  upsertAtencionMedica: (atencion: AtencionMedicaRecord) => void;
  batchUpsertAtencionesMedicas: (atenciones: AtencionMedicaRecord[]) => void;
  removeAtencionMedica: (id: string) => void;

  // Resumen del Programa Anual
  programaResumen: ProgramaResumenAnual | null;
  setProgramaResumen: (resumen: ProgramaResumenAnual) => void;

  // Investigaciones de Accidentes
  investigaciones: InvestigacionRecord[];
  setInvestigaciones: (investigaciones: InvestigacionRecord[]) => void;
  upsertInvestigacion: (investigacion: InvestigacionRecord) => void;
  batchUpsertInvestigaciones: (investigaciones: InvestigacionRecord[]) => void;
  removeInvestigacion: (id: string) => void;

  // Simulación de Costos de Incidentes
  simulacionesCostos: SimulacionCostosRecord[];
  setSimulacionesCostos: (simulaciones: SimulacionCostosRecord[]) => void;
  upsertSimulacionCostos: (simulacion: SimulacionCostosRecord) => void;
  batchUpsertSimulacionesCostos: (simulaciones: SimulacionCostosRecord[]) => void;
  removeSimulacionCostos: (id: string) => void;

  // Actos y Condiciones Inseguras
  actosCondiciones: ActoCondicionRecord[];
  setActosCondiciones: (actosCondiciones: ActoCondicionRecord[]) => void;
  upsertActoCondicion: (acto: ActoCondicionRecord) => void;
  batchUpsertActosCondiciones: (newActos: ActoCondicionRecord[]) => void;
  removeActoCondicion: (idOrCodigo: string) => void;

  // Horas-Hombre (HH)
  horasHombre: ResumenMensualHH[];
  setHorasHombre: (horasHombre: ResumenMensualHH[]) => void;
  upsertHorasHombre: (record: ResumenMensualHH) => void;
  batchUpsertHorasHombre: (records: ResumenMensualHH[]) => void;
  removeHorasHombre: (idOrMesAnio: string) => void;

  // Metas e Indicadores SST
  metasIndicadores: MetaIndicadoresSST;
  setMetasIndicadores: (metas: MetaIndicadoresSST) => void;
  estadisticasDashboard: EstadisticasDashboardData | null;
  setEstadisticasDashboard: (data: EstadisticasDashboardData | null) => void;

  // Cargar datos completos desde Sheets
  cargarDatosDesdeSheets: (datos: any) => void;
}

export const useDataStore = create<DataState>((set, get) => ({
  // Trabajadores
  trabajadores: [],
  setTrabajadores: (trabajadores) =>
    set({ trabajadores: ensureUniqueIds((trabajadores || []).map(sanitizeTrabajador), 'TRAB') }),
  upsertTrabajador: (trabajador) => {
    const clean = sanitizeTrabajador(trabajador);
    set((state) => {
      const index = state.trabajadores.findIndex(
        (t) => String(t.id) === clean.id || String(t.dni) === clean.dni
      );
      if (index >= 0) {
        const updated = [...state.trabajadores];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { trabajadores: updated };
      }
      return { trabajadores: [clean, ...state.trabajadores] };
    });
  },
  batchUpsertTrabajadores: (newTrabajadores) => {
    const cleanedItems = (newTrabajadores || []).map(sanitizeTrabajador);
    set((state) => {
      const list = [...state.trabajadores];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex((t) => String(t.id) === item.id || String(t.dni) === item.dni);
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { trabajadores: list };
    });
  },
  removeTrabajador: (idOrDni) => {
    const target = String(idOrDni ?? '').trim();
    set((state) => ({
      trabajadores: state.trabajadores.filter(
        (t) => String(t.id || '').trim() !== target && String(t.dni || '').trim() !== target
      )
    }));
  },
  getTrabajadoresActivos: (empresa) => {
    return (get().trabajadores || []).filter((t) => {
      const matchCondicion = t.condicion === 'Activo';
      if (!matchCondicion) return false;
      if (!empresa || empresa === 'CONSOLIDADO') return true;
      return t.empresa === empresa;
    });
  },

  // Inspecciones
  inspecciones: [],
  setInspecciones: (inspecciones) =>
    set({ inspecciones: ensureUniqueIds((inspecciones || []).map(sanitizeInspeccion), 'INSP') }),
  upsertInspeccion: (inspeccion) => {
    const clean = sanitizeInspeccion(inspeccion);
    set((state) => {
      const index = state.inspecciones.findIndex(
        (i) => String(i.id) === clean.id || String(i.codigoInspeccion) === clean.codigoInspeccion
      );
      if (index >= 0) {
        const updated = [...state.inspecciones];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { inspecciones: updated };
      }
      return { inspecciones: [clean, ...state.inspecciones] };
    });
  },
  batchUpsertInspecciones: (newInspecciones) => {
    const cleanedItems = (newInspecciones || []).map(sanitizeInspeccion);
    set((state) => {
      const list = [...state.inspecciones];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (i) => String(i.id) === item.id || String(i.codigoInspeccion) === item.codigoInspeccion
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { inspecciones: list };
    });
  },
  removeInspeccion: (idOrCodigo) => {
    const target = String(idOrCodigo ?? '').trim();
    set((state) => ({
      inspecciones: state.inspecciones.filter(
        (i) =>
          String(i.id || '').trim() !== target &&
          String(i.codigoInspeccion || '').trim() !== target
      )
    }));
  },
  vincularAtencionAInspeccion: (inspeccionId, atencionResumen) => {
    set((state) => ({
      inspecciones: state.inspecciones.map((insp) => {
        if (
          String(insp.id) === String(inspeccionId) ||
          String(insp.codigoInspeccion) === String(inspeccionId)
        ) {
          const actuales = Array.isArray(insp.atencionesPrimerosAuxilios)
            ? insp.atencionesPrimerosAuxilios
            : [];
          if (!actuales.includes(atencionResumen)) {
            return {
              ...insp,
              atencionesPrimerosAuxilios: [...actuales, atencionResumen],
              updatedAt: new Date().toISOString()
            };
          }
        }
        return insp;
      })
    }));
  },

  // Botiquín
  consumosBotiquin: [],
  setConsumosBotiquin: (consumos) =>
    set({ consumosBotiquin: ensureUniqueIds((consumos || []).map(sanitizeConsumoBotiquin), 'BOT') }),
  upsertConsumoBotiquin: (consumo) => {
    const clean = sanitizeConsumoBotiquin(consumo);
    set((state) => {
      const index = state.consumosBotiquin.findIndex(
        (c) => String(c.id) === clean.id || String(c.codigoAtencion) === clean.codigoAtencion
      );
      if (index >= 0) {
        const updated = [...state.consumosBotiquin];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { consumosBotiquin: updated };
      }
      return { consumosBotiquin: [clean, ...state.consumosBotiquin] };
    });
  },
  batchUpsertConsumosBotiquin: (newConsumos) => {
    const cleanedItems = (newConsumos || []).map(sanitizeConsumoBotiquin);
    set((state) => {
      const list = [...state.consumosBotiquin];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (c) => String(c.id) === item.id || String(c.codigoAtencion) === item.codigoAtencion
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { consumosBotiquin: list };
    });
  },
  removeConsumoBotiquin: (id) =>
    set((state) => ({
      consumosBotiquin: state.consumosBotiquin.filter((c) => String(c.id) !== String(id))
    })),
  marcarAtencionTransferida: (id, casoAccidenteId) => {
    set((state) => ({
      consumosBotiquin: state.consumosBotiquin.map((c) =>
        String(c.id) === String(id)
          ? {
              ...c,
              transferidoAccidentes: true,
              estadoValidacion: 'Transferido',
              casoAccidenteId,
              updatedAt: new Date().toISOString()
            }
          : c
      )
    }));
  },
  descartarAtencionTransferencia: (id) => {
    set((state) => ({
      consumosBotiquin: state.consumosBotiquin.map((c) =>
        String(c.id) === String(id)
          ? {
              ...c,
              estadoValidacion: 'Descartado',
              updatedAt: new Date().toISOString()
            }
          : c
      )
    }));
  },

  // Accidentes
  accidentes: [],
  setAccidentes: (accidentes) =>
    set({ accidentes: ensureUniqueIds((accidentes || []).map(sanitizeAccidente), 'ACC') }),
  upsertAccidente: (accidente) => {
    const clean = sanitizeAccidente(accidente);
    set((state) => {
      const index = state.accidentes.findIndex(
        (a) => String(a.id) === clean.id || String(a.codigoCaso) === clean.codigoCaso
      );
      if (index >= 0) {
        const updated = [...state.accidentes];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { accidentes: updated };
      }
      return { accidentes: [clean, ...state.accidentes] };
    });
  },
  batchUpsertAccidentes: (newAccidentes) => {
    const cleanedItems = (newAccidentes || []).map(sanitizeAccidente);
    set((state) => {
      const list = [...state.accidentes];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (a) => String(a.id) === item.id || String(a.codigoCaso) === item.codigoCaso
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { accidentes: list };
    });
  },
  removeAccidente: (id) =>
    set((state) => ({
      accidentes: state.accidentes.filter(
        (a) => String(a.id) !== String(id) && String(a.codigoCaso) !== String(id)
      )
    })),

  // Atenciones Médicas
  atencionesMedicas: [],
  setAtencionesMedicas: (atenciones) =>
    set({ atencionesMedicas: ensureUniqueIds((atenciones || []).map(sanitizeAtencionMedica), 'ATN') }),
  upsertAtencionMedica: (atencion) => {
    const clean = sanitizeAtencionMedica(atencion);
    set((state) => {
      const index = state.atencionesMedicas.findIndex(
        (a) => String(a.id) === clean.id || String(a.idAtencion) === clean.idAtencion
      );
      if (index >= 0) {
        const updated = [...state.atencionesMedicas];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { atencionesMedicas: updated };
      }
      return { atencionesMedicas: [clean, ...state.atencionesMedicas] };
    });
  },
  batchUpsertAtencionesMedicas: (newAtenciones) => {
    const cleanedItems = (newAtenciones || []).map(sanitizeAtencionMedica);
    set((state) => {
      const list = [...state.atencionesMedicas];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (a) => String(a.id) === item.id || String(a.idAtencion) === item.idAtencion
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { atencionesMedicas: list };
    });
  },
  removeAtencionMedica: (id) =>
    set((state) => ({
      atencionesMedicas: state.atencionesMedicas.filter(
        (a) => String(a.id) !== String(id) && String(a.idAtencion) !== String(id)
      )
    })),

  // Resumen Programa
  programaResumen: null,
  setProgramaResumen: (resumen) => set({ programaResumen: resumen }),

  // Investigaciones
  investigaciones: [],
  setInvestigaciones: (investigaciones) =>
    set({ investigaciones: ensureUniqueIds((investigaciones || []).map(sanitizeInvestigacion), 'INV') }),
  upsertInvestigacion: (investigacion) => {
    const clean = sanitizeInvestigacion(investigacion);
    set((state) => {
      const index = state.investigaciones.findIndex(
        (i) =>
          String(i.id) === clean.id || String(i.codigoInvestigacion) === clean.codigoInvestigacion
      );
      if (index >= 0) {
        const updated = [...state.investigaciones];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { investigaciones: updated };
      }
      return { investigaciones: [clean, ...state.investigaciones] };
    });
  },
  batchUpsertInvestigaciones: (newInvestigaciones) => {
    const cleanedItems = (newInvestigaciones || []).map(sanitizeInvestigacion);
    set((state) => {
      const list = [...state.investigaciones];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (i) =>
            String(i.id) === item.id || String(i.codigoInvestigacion) === item.codigoInvestigacion
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { investigaciones: list };
    });
  },
  removeInvestigacion: (id) =>
    set((state) => ({
      investigaciones: state.investigaciones.filter(
        (i) =>
          String(i.id) !== String(id) && String(i.codigoInvestigacion) !== String(id)
      )
    })),

  // Simulación Costos
  simulacionesCostos: [],
  setSimulacionesCostos: (simulaciones) =>
    set({
      simulacionesCostos: ensureUniqueIds(
        (simulaciones || []).map(sanitizeSimulacionCostos),
        'SIM'
      )
    }),
  upsertSimulacionCostos: (simulacion) => {
    const clean = sanitizeSimulacionCostos(simulacion);
    set((state) => {
      const index = state.simulacionesCostos.findIndex(
        (s) =>
          String(s.id) === clean.id || String(s.codigoSimulacion) === clean.codigoSimulacion
      );
      if (index >= 0) {
        const updated = [...state.simulacionesCostos];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { simulacionesCostos: updated };
      }
      return { simulacionesCostos: [clean, ...state.simulacionesCostos] };
    });
  },
  batchUpsertSimulacionesCostos: (newSimulaciones) => {
    const cleanedItems = (newSimulaciones || []).map(sanitizeSimulacionCostos);
    set((state) => {
      const list = [...state.simulacionesCostos];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (s) =>
            String(s.id) === item.id || String(s.codigoSimulacion) === item.codigoSimulacion
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { simulacionesCostos: list };
    });
  },
  removeSimulacionCostos: (id) =>
    set((state) => ({
      simulacionesCostos: state.simulacionesCostos.filter(
        (s) =>
          String(s.id) !== String(id) && String(s.codigoSimulacion) !== String(id)
      )
    })),

  // Actos y Condiciones
  actosCondiciones: [],
  setActosCondiciones: (actosCondiciones) =>
    set({
      actosCondiciones: ensureUniqueIds(
        (actosCondiciones || []).map(sanitizeActoCondicion),
        'AC'
      )
    }),
  upsertActoCondicion: (acto) => {
    const clean = sanitizeActoCondicion(acto);
    set((state) => {
      const index = state.actosCondiciones.findIndex(
        (a) =>
          String(a.id) === clean.id || String(a.codigoReporte) === clean.codigoReporte
      );
      if (index >= 0) {
        const updated = [...state.actosCondiciones];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { actosCondiciones: updated };
      }
      return { actosCondiciones: [clean, ...state.actosCondiciones] };
    });
  },
  batchUpsertActosCondiciones: (newActos) => {
    const cleanedItems = (newActos || []).map(sanitizeActoCondicion);
    set((state) => {
      const list = [...state.actosCondiciones];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (a) =>
            String(a.id) === item.id || String(a.codigoReporte) === item.codigoReporte
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { actosCondiciones: list };
    });
  },
  removeActoCondicion: (idOrCodigo) => {
    const target = String(idOrCodigo ?? '').trim();
    set((state) => ({
      actosCondiciones: state.actosCondiciones.filter(
        (a) =>
          String(a.id || '').trim() !== target &&
          String(a.codigoReporte || '').trim() !== target
      )
    }));
  },

  // Horas-Hombre
  horasHombre: [],
  setHorasHombre: (horasHombre) =>
    set({
      horasHombre: ensureUniqueIds(
        (horasHombre || []).map(sanitizeHorasHombre),
        'HH'
      )
    }),
  upsertHorasHombre: (record) => {
    const clean = sanitizeHorasHombre(record);
    set((state) => {
      const index = state.horasHombre.findIndex(
        (h) =>
          String(h.id) === clean.id ||
          (h.anio === clean.anio &&
            h.mes === clean.mes &&
            (h.empresa === clean.empresa || !clean.empresa))
      );
      if (index >= 0) {
        const updated = [...state.horasHombre];
        updated[index] = { ...updated[index], ...clean, updatedAt: new Date().toISOString() };
        return { horasHombre: updated };
      }
      return { horasHombre: [clean, ...state.horasHombre] };
    });
  },
  batchUpsertHorasHombre: (records) => {
    const cleanedItems = (records || []).map(sanitizeHorasHombre);
    set((state) => {
      const list = [...state.horasHombre];
      cleanedItems.forEach((item) => {
        const idx = list.findIndex(
          (h) =>
            String(h.id) === item.id ||
            (h.anio === item.anio &&
              h.mes === item.mes &&
              (h.empresa === item.empresa || !item.empresa))
        );
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...item, updatedAt: new Date().toISOString() };
        } else {
          list.unshift(item);
        }
      });
      return { horasHombre: list };
    });
  },
  removeHorasHombre: (idOrMesAnio) => {
    const target = String(idOrMesAnio ?? '').trim();
    set((state) => ({
      horasHombre: state.horasHombre.filter((h) => String(h.id || '').trim() !== target)
    }));
  },

  // Metas e Indicadores
  metasIndicadores: DEFAULT_METAS_INDICADORES,
  setMetasIndicadores: (metas) => set({ metasIndicadores: metas }),
  estadisticasDashboard: null,
  setEstadisticasDashboard: (data) => set({ estadisticasDashboard: data }),

  // Carga masiva directa de Sheets
  cargarDatosDesdeSheets: (datos) => {
    if (!datos || typeof datos !== 'object') return;
    set((state) => {
      const updates: Partial<DataState> = {};

      if (Array.isArray(datos.trabajadores)) {
        updates.trabajadores = ensureUniqueIds(datos.trabajadores.map(sanitizeTrabajador), 'TRAB');
      }
      if (Array.isArray(datos.accidentes)) {
        updates.accidentes = ensureUniqueIds(datos.accidentes.map(sanitizeAccidente), 'ACC');
      }
      if (Array.isArray(datos.atencionesMedicas)) {
        updates.atencionesMedicas = ensureUniqueIds(
          datos.atencionesMedicas.map(sanitizeAtencionMedica),
          'ATN'
        );
      }
      if (Array.isArray(datos.inspecciones)) {
        updates.inspecciones = ensureUniqueIds(datos.inspecciones.map(sanitizeInspeccion), 'INSP');
      }
      if (Array.isArray(datos.consumosBotiquin)) {
        updates.consumosBotiquin = ensureUniqueIds(
          datos.consumosBotiquin.map(sanitizeConsumoBotiquin),
          'BOT'
        );
      }
      if (Array.isArray(datos.investigaciones)) {
        updates.investigaciones = ensureUniqueIds(
          datos.investigaciones.map(sanitizeInvestigacion),
          'INV'
        );
      }
      if (Array.isArray(datos.simulacionesCostos)) {
        updates.simulacionesCostos = ensureUniqueIds(
          datos.simulacionesCostos.map(sanitizeSimulacionCostos),
          'SIM'
        );
      }
      if (Array.isArray(datos.actosCondiciones)) {
        updates.actosCondiciones = ensureUniqueIds(
          datos.actosCondiciones.map(sanitizeActoCondicion),
          'AC'
        );
      }
      if (Array.isArray(datos.horasHombre)) {
        updates.horasHombre = ensureUniqueIds(
          datos.horasHombre.map(sanitizeHorasHombre),
          'HH'
        );
      }
      if (datos.programaResumen) {
        updates.programaResumen = datos.programaResumen;
      }
      if (datos.metasIndicadores) {
        updates.metasIndicadores = datos.metasIndicadores;
      }

      return {
        ...state,
        ...updates
      };
    });
  }
}));
