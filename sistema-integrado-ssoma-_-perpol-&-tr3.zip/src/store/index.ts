/**
 * Barrel file for Zustand stores and sanitizers.
 * Exports domain-specific stores:
 * - useAppStore: Empresa activa, sidebar, theme
 * - useDataStore: Entidades de negocio (accidentes, inspecciones, etc.)
 * - useUIStore: Toasts y pendingSyncCount
 * - useGoogleSheetsStore: Configuración GAS y estado de sincronización Sheets
 * Also re-exports unified useAppStore for backwards compatibility.
 */

export * from './sanitizers';
export * from './useAppStore';
export * from './useDataStore';
export * from './useUIStore';
export * from './useGoogleSheetsStore';
export { useAppStore as useUnifiedStore } from './appStore';
