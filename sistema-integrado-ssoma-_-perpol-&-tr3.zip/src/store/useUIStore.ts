/**
 * useUIStore: Store para notificaciones Toast y estado visual de sincronización optimista.
 */
import { create } from 'zustand';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  timestamp: number;
}

export interface UIState {
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id' | 'timestamp'>) => void;
  removeToast: (id: string) => void;

  pendingSyncCount: number;
  incrementSync: () => void;
  decrementSync: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  toasts: [],
  addToast: (toast) => {
    const id = `toast-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newToast: ToastMessage = {
      ...toast,
      id,
      timestamp: Date.now()
    };
    set((state) => ({ toasts: [...state.toasts, newToast] }));
    setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    }, 4000);
  },
  removeToast: (id) =>
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),

  pendingSyncCount: 0,
  incrementSync: () => set((state) => ({ pendingSyncCount: state.pendingSyncCount + 1 })),
  decrementSync: () =>
    set((state) => ({ pendingSyncCount: Math.max(0, state.pendingSyncCount - 1) }))
}));
