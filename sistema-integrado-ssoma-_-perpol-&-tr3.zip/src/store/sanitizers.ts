/**
 * Slices y funciones auxiliares para normalización y sanitización de datos SSOMA.
 * Permite garantizar la integridad de identificadores y campos obligatorios
 * provenientes de Google Sheets, formularios o importaciones masivas.
 */
import {
  TrabajadorRecord,
  ConsumoBotiquinRecord,
  AccidenteRecord,
  InspeccionRecord,
  InvestigacionRecord,
  SimulacionCostosRecord,
  ActoCondicionRecord,
  ProgramaAnualRecord,
  ResumenMensualHH,
  MetaIndicadoresSST,
  AtencionMedicaRecord
} from '../types/modules';
import { CATALOGO_CATEGORIAS_RIESGO } from '../utils/ssomaCatalogs';

// Metas Anuales SST por defecto (Módulo 8)
export const DEFAULT_METAS_INDICADORES: MetaIndicadoresSST = {
  empresa: 'CONSOLIDADO',
  periodoAnio: 2026,
  metaIF: 2.5,
  metaIS: 25.0,
  metaIA: 0.06,
  metaCumplimientoPrograma: 90.0,
  metaInspeccionesSubsanadas: 85.0
};

// Helper universal para asegurar claves e identificadores unívocos sin colisiones
export const ensureUniqueIds = <T extends { id?: string; dni?: string; empresa?: string }>(items: T[], prefix = 'RECORD'): T[] => {
  if (!Array.isArray(items)) return [];
  const seen = new Set<string>();
  return items.map((item, idx) => {
    let id = item.id !== undefined && item.id !== null && String(item.id).trim() !== ''
      ? String(item.id).trim()
      : (item.dni !== undefined && item.dni !== null && String(item.dni).trim() !== '' ? String(item.dni).trim() : '');
    
    if (!id || seen.has(id)) {
      const emp = item.empresa ? `-${item.empresa}` : '';
      id = id ? `${id}${emp}-${idx}` : `${prefix}-${Date.now()}-${idx}`;
    }
    seen.add(id);
    return {
      ...item,
      id
    };
  });
};

// Helper para convertir a array de strings limpios sin elementos vacíos
export const toCleanStringArray = (val: any): string[] => {
  if (Array.isArray(val)) return val.map((x) => String(x).trim()).filter(Boolean);
  if (typeof val === 'string' && val.trim()) {
    try {
      const parsed = JSON.parse(val);
      if (Array.isArray(parsed)) return parsed.map((x) => String(x).trim()).filter(Boolean);
      if (typeof parsed === 'string' && parsed.trim()) return [parsed.trim()];
    } catch {
      return val.split(',').map((x) => x.trim()).filter(Boolean);
    }
  }
  return [];
};

// Helper para limpiar strings opcionales evitando strings vacíos ("") que causen descargas dobles
export const toCleanStringOrUndefined = (val: any): string | undefined => {
  if (val === undefined || val === null) return undefined;
  const s = String(val).trim();
  return s.length > 0 ? s : undefined;
};

// Helper para normalizar y sanitizar registros de trabajadores provenientes de Sheets o inputs
export const sanitizeTrabajador = (raw: any): TrabajadorRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `TRAB-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      dni: '',
      apellidosNombres: '',
      empresa: 'PERPOL',
      condicion: 'Activo',
      sexo: 'M',
      fechaIngreso: '',
      fechaNacimiento: '',
      puesto: '',
      area: '',
      telefono: '',
      correo: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }
  const dniStr = raw.dni !== undefined && raw.dni !== null ? String(raw.dni).trim() : '';
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : (dniStr ? `TRAB-${dniStr}` : `TRAB-${Date.now()}-${Math.floor(Math.random() * 1000)}`);

  return {
    ...raw,
    id: idStr,
    dni: dniStr,
    apellidosNombres: raw.apellidosNombres !== undefined && raw.apellidosNombres !== null ? String(raw.apellidosNombres).trim() : '',
    empresa: String(raw.empresa || '').toUpperCase().includes('TR3') ? 'TR3' : 'PERPOL',
    condicion: (raw.condicion as 'Activo' | 'Inactivo' | 'Cesado') || 'Activo',
    sexo: (raw.sexo as 'M' | 'F') || 'M',
    fechaIngreso: raw.fechaIngreso ? String(raw.fechaIngreso).slice(0, 10) : '',
    fechaNacimiento: raw.fechaNacimiento ? String(raw.fechaNacimiento).slice(0, 10) : '',
    puesto: raw.puesto !== undefined && raw.puesto !== null ? String(raw.puesto).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    telefono: raw.telefono !== undefined && raw.telefono !== null ? String(raw.telefono).trim() : '',
    correo: raw.correo !== undefined && raw.correo !== null ? String(raw.correo).trim() : '',
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Accidentes e Incidentes (Módulo 1)
export const sanitizeAccidente = (raw: any): AccidenteRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `ACC-${Date.now()}`,
      codigoCaso: `ACC-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      hora: '08:00',
      trabajadorDni: '',
      trabajadorNombre: '',
      cargo: '',
      area: '',
      turno: 'Mañana',
      lugarExacto: '',
      responsableArea: '',
      tipoEvento: 'Incidente',
      danoMaterial: 'NO',
      necesidadAtencion: 'NO',
      descripcion: '',
      partesCuerpoAfectadas: [],
      mecanismoEvento: [],
      agenteEvento: [],
      lesionReferida: [],
      estadoCaso: 'Abierto',
      diasDescanso: 0,
      createdAt: new Date().toISOString()
    };
  }
  const codCaso = raw.codigoCaso !== undefined && raw.codigoCaso !== null && String(raw.codigoCaso).trim() !== ''
    ? String(raw.codigoCaso).trim()
    : (raw.id ? String(raw.id).trim() : `ACC-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codCaso;

  return {
    ...raw,
    id: idStr,
    codigoCaso: codCaso,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    hora: raw.hora !== undefined && raw.hora !== null ? String(raw.hora).trim() : '08:00',
    trabajadorDni: raw.trabajadorDni !== undefined && raw.trabajadorDni !== null ? String(raw.trabajadorDni).trim() : '',
    trabajadorNombre: raw.trabajadorNombre !== undefined && raw.trabajadorNombre !== null ? String(raw.trabajadorNombre).trim() : '',
    cargo: raw.cargo !== undefined && raw.cargo !== null ? String(raw.cargo).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    lugarExacto: raw.lugarExacto !== undefined && raw.lugarExacto !== null ? String(raw.lugarExacto).trim() : '',
    responsableArea: raw.responsableArea !== undefined && raw.responsableArea !== null ? String(raw.responsableArea).trim() : '',
    tipoEvento: raw.tipoEvento || 'Incidente',
    danoMaterial: raw.danoMaterial === 'SI' ? 'SI' : 'NO',
    detalleDano: toCleanStringOrUndefined(raw.detalleDano),
    necesidadAtencion: raw.necesidadAtencion === 'SI' ? 'SI' : 'NO',
    descripcion: raw.descripcion !== undefined && raw.descripcion !== null ? String(raw.descripcion).trim() : '',
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    causaInmediata: toCleanStringOrUndefined(raw.causaInmediata),
    partesCuerpoAfectadas: toCleanStringArray(raw.partesCuerpoAfectadas),
    partesCuerpoOtros: toCleanStringOrUndefined(raw.partesCuerpoOtros),
    mecanismoEvento: toCleanStringArray(raw.mecanismoEvento),
    mecanismoEventoOtros: toCleanStringOrUndefined(raw.mecanismoEventoOtros),
    agenteEvento: toCleanStringArray(raw.agenteEvento),
    agenteEventoOtros: toCleanStringOrUndefined(raw.agenteEventoOtros),
    lesionReferida: toCleanStringArray(raw.lesionReferida),
    lesionReferidaOtros: toCleanStringOrUndefined(raw.lesionReferidaOtros),
    estadoCaso: raw.estadoCaso || 'Abierto',
    diasDescanso:
      Number(raw.diasDescanso) ||
      Number(raw.diasDescansoMedico) ||
      Number(raw['Días Descanso']) ||
      Number(raw['Días Descanso Médico']) ||
      Number(raw['Dias Descanso']) ||
      Number(raw['Dias Descanso Medico']) ||
      Number(raw.diasPerdidos) ||
      0,
    medidasCorrectivas: raw.medidasCorrectivas !== undefined && raw.medidasCorrectivas !== null ? String(raw.medidasCorrectivas).trim() : undefined,
    responsableSeguimiento: raw.responsableSeguimiento !== undefined && raw.responsableSeguimiento !== null ? String(raw.responsableSeguimiento).trim() : undefined,
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    conclusionesInvestigacion: raw.conclusionesInvestigacion !== undefined && raw.conclusionesInvestigacion !== null ? String(raw.conclusionesInvestigacion).trim() : undefined,
    origenAtencionBotiquinId: raw.origenAtencionBotiquinId !== undefined && raw.origenAtencionBotiquinId !== null ? String(raw.origenAtencionBotiquinId).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Atenciones Médicas (Módulo 2)
export const sanitizeAtencionMedica = (raw: any): AtencionMedicaRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `ATN-${Date.now()}`,
      idAtencion: `ATN-${Date.now()}`,
      empresa: 'PERPOL',
      trabajadorDni: '',
      trabajadorNombre: '',
      lugarAtencion: 'Tópico de Planta',
      fechaAtencion: new Date().toISOString().slice(0, 10),
      diagnostico: '',
      generaDescanso: 'NO',
      diasDescanso: 0,
      estado: 'Cerrado',
      createdAt: new Date().toISOString()
    };
  }

  const idAtn = raw.idAtencion || raw.id || `ATN-${Date.now()}`;
  return {
    ...raw,
    id: idAtn,
    idAtencion: idAtn,
    idAccidente: raw.idAccidente ? String(raw.idAccidente).trim() : undefined,
    codigoAccidente: raw.codigoAccidente ? String(raw.codigoAccidente).trim() : undefined,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    trabajadorDni: raw.trabajadorDni ? String(raw.trabajadorDni).trim() : '',
    trabajadorNombre: raw.trabajadorNombre ? String(raw.trabajadorNombre).trim() : '',
    puesto: raw.puesto ? String(raw.puesto).trim() : '',
    area: raw.area ? String(raw.area).trim() : '',
    turno: raw.turno ? String(raw.turno).trim() : 'Mañana',
    lugarAtencion: raw.lugarAtencion ? String(raw.lugarAtencion).trim() : 'Tópico de Planta',
    fechaAtencion: raw.fechaAtencion ? String(raw.fechaAtencion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    horaAtencion: raw.horaAtencion ? String(raw.horaAtencion).trim() : '09:00',
    diagnostico: raw.diagnostico ? String(raw.diagnostico).trim() : '',
    generaDescanso: raw.generaDescanso === 'SI' ? 'SI' : 'NO',
    fechaInicioDescanso: raw.fechaInicioDescanso ? String(raw.fechaInicioDescanso).slice(0, 10) : undefined,
    fechaFinDescanso: raw.fechaFinDescanso ? String(raw.fechaFinDescanso).slice(0, 10) : undefined,
    diasDescanso: Number(raw.diasDescanso) || 0,
    proximaCita: raw.proximaCita ? String(raw.proximaCita).slice(0, 10) : undefined,
    estado: raw.estado || 'En seguimiento',
    medicoTratante: raw.medicoTratante ? String(raw.medicoTratante).trim() : undefined,
    observaciones: raw.observaciones ? String(raw.observaciones).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Inspecciones SST
export const sanitizeInspeccion = (raw: any): InspeccionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `INSP-${Date.now()}`,
      codigoInspeccion: `INSP-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      area: '',
      responsableInspeccion: '',
      hallazgo: '',
      potencialGravedad: 2,
      prioridad: 'Media',
      tipo: 'Condición insegura',
      evidenciasIniciales: [],
      evidenciasCorreccion: [],
      estado: 'Pendiente',
      fechaCompromiso: new Date().toISOString().slice(0, 10),
      createdAt: new Date().toISOString()
    };
  }
  const codInsp = raw.codigoInspeccion !== undefined && raw.codigoInspeccion !== null && String(raw.codigoInspeccion).trim() !== ''
    ? String(raw.codigoInspeccion).trim()
    : (raw.id ? String(raw.id).trim() : `INSP-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codInsp;

  return {
    ...raw,
    id: idStr,
    codigoInspeccion: codInsp,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    responsableInspeccion: raw.responsableInspeccion !== undefined && raw.responsableInspeccion !== null ? String(raw.responsableInspeccion).trim() : '',
    hallazgo: raw.hallazgo !== undefined && raw.hallazgo !== null ? String(raw.hallazgo).trim() : '',
    potencialGravedad: (Number(raw.potencialGravedad) as 1 | 2 | 3 | 4) || 2,
    prioridad: raw.prioridad || 'Media',
    tipo: raw.tipo || 'Condición insegura',
    evidenciasIniciales: toCleanStringArray(raw.evidenciasIniciales),
    evidenciasCorreccion: toCleanStringArray(raw.evidenciasCorreccion),
    estado: raw.estado || 'Pendiente',
    responsableLevantamiento: toCleanStringOrUndefined(raw.responsableLevantamiento),
    accionCorrectiva: toCleanStringOrUndefined(raw.accionCorrectiva),
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : new Date().toISOString().slice(0, 10),
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    fechaLevantamiento: raw.fechaLevantamiento ? String(raw.fechaLevantamiento).slice(0, 10) : undefined,
    atencionesPrimerosAuxilios: toCleanStringArray(raw.atencionesPrimerosAuxilios),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Consumos de Botiquín
export const sanitizeConsumoBotiquin = (raw: any): ConsumoBotiquinRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `BOT-${Date.now()}`,
      codigoAtencion: `BOT-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      tipoAtencion: 'Incidente',
      personaAtendida: '',
      dniPersona: '',
      puesto: '',
      area: '',
      turno: 'Mañana',
      lesionesSintomas: '',
      procedimientoAplicado: '',
      elementosConsumidos: [],
      atendidoPor: '',
      createdAt: new Date().toISOString()
    };
  }
  const codAtenc = raw.codigoAtencion !== undefined && raw.codigoAtencion !== null && String(raw.codigoAtencion).trim() !== ''
    ? String(raw.codigoAtencion).trim()
    : (raw.id ? String(raw.id).trim() : `BOT-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codAtenc;

  let elems = raw.elementosConsumidos;
  if (typeof elems === 'string') {
    try { elems = JSON.parse(elems); } catch { elems = []; }
  }
  if (!Array.isArray(elems)) elems = [];

  const cleanElements = elems.map((el: any) => ({
    item: el?.item !== undefined && el?.item !== null ? String(el.item).trim() : '',
    cantidad: Number(el?.cantidad) || 1,
    unidad: el?.unidad !== undefined && el?.unidad !== null ? String(el.unidad).trim() : 'Unidades'
  }));

  return {
    ...raw,
    id: idStr,
    codigoAtencion: codAtenc,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fecha: raw.fecha ? String(raw.fecha).slice(0, 10) : new Date().toISOString().slice(0, 10),
    hora: raw.hora !== undefined && raw.hora !== null ? String(raw.hora).trim() : '08:00',
    tipoAtencion: raw.tipoAtencion || 'Incidente',
    personaAtendida: raw.personaAtendida !== undefined && raw.personaAtendida !== null ? String(raw.personaAtendida).trim() : '',
    dniPersona: raw.dniPersona !== undefined && raw.dniPersona !== null ? String(raw.dniPersona).trim() : '',
    puesto: raw.puesto !== undefined && raw.puesto !== null ? String(raw.puesto).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    lesionesSintomas: raw.lesionesSintomas !== undefined && raw.lesionesSintomas !== null ? String(raw.lesionesSintomas).trim() : '',
    procedimientoAplicado: raw.procedimientoAplicado !== undefined && raw.procedimientoAplicado !== null ? String(raw.procedimientoAplicado).trim() : '',
    elementosConsumidos: cleanElements,
    inspeccionVinculadaId: raw.inspeccionVinculadaId !== undefined && raw.inspeccionVinculadaId !== null ? String(raw.inspeccionVinculadaId).trim() : undefined,
    inspeccionVinculadaCodigo: raw.inspeccionVinculadaCodigo !== undefined && raw.inspeccionVinculadaCodigo !== null ? String(raw.inspeccionVinculadaCodigo).trim() : undefined,
    inspeccionVinculadaDetalle: raw.inspeccionVinculadaDetalle !== undefined && raw.inspeccionVinculadaDetalle !== null ? String(raw.inspeccionVinculadaDetalle).trim() : undefined,
    atendidoPor: raw.atendidoPor !== undefined && raw.atendidoPor !== null ? String(raw.atendidoPor).trim() : '',
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    transferidoAccidentes: Boolean(raw.transferidoAccidentes),
    estadoValidacion: raw.estadoValidacion || 'Pendiente',
    casoAccidenteId: raw.casoAccidenteId !== undefined && raw.casoAccidenteId !== null ? String(raw.casoAccidenteId).trim() : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Investigaciones de Accidentes
export const sanitizeInvestigacion = (raw: any): InvestigacionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `INV-${Date.now()}`,
      codigoInvestigacion: `INV-${Date.now()}`,
      accidenteId: '',
      empresa: 'PERPOL',
      fechaInvestigacion: new Date().toISOString().slice(0, 10),
      fechaAccidente: new Date().toISOString().slice(0, 10),
      horaAccidente: '08:00',
      turno: 'Mañana',
      area: '',
      lugarExacto: '',
      diasDescanso: 0,
      datosTrabajador: {
        nombre: '',
        dni: '',
        edad: 0,
        genero: 'M',
        puesto: '',
        area: '',
        fechaIngreso: '',
        antiguedadPuesto: ''
      },
      descripcionCircunstancias: '',
      tipoContacto: '',
      agenteCausante: '',
      causasInmediatas: { actosSubestandar: [], condicionesSubestandar: [] },
      causasBasicas: { factoresPersonales: [], factoresTrabajo: [] },
      causaRaizMetodo: '5 Porqués',
      analisisCausaRaiz: '',
      conclusionCausaRaiz: '',
      medidasCorrectivas: [],
      investigadores: [],
      porcentajeAvance: 0,
      estado: 'Borrador',
      createdAt: new Date().toISOString()
    };
  }
  const codInv = raw.codigoInvestigacion !== undefined && raw.codigoInvestigacion !== null && String(raw.codigoInvestigacion).trim() !== ''
    ? String(raw.codigoInvestigacion).trim()
    : (raw.id ? String(raw.id).trim() : `INV-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codInv;

  let trab = raw.datosTrabajador;
  if (typeof trab === 'string') {
    try { trab = JSON.parse(trab); } catch { trab = {}; }
  }
  trab = trab || {};

  let cInm = raw.causasInmediatas;
  if (typeof cInm === 'string') {
    try { cInm = JSON.parse(cInm); } catch { cInm = {}; }
  }
  cInm = cInm || {};

  let cBas = raw.causasBasicas;
  if (typeof cBas === 'string') {
    try { cBas = JSON.parse(cBas); } catch { cBas = {}; }
  }
  cBas = cBas || {};

  let medidas = raw.medidasCorrectivas;
  if (typeof medidas === 'string') {
    try { medidas = JSON.parse(medidas); } catch { medidas = []; }
  }

  let invs = raw.investigadores;
  if (typeof invs === 'string') {
    try { invs = JSON.parse(invs); } catch { invs = []; }
  }

  return {
    ...raw,
    id: idStr,
    codigoInvestigacion: codInv,
    accidenteId: raw.accidenteId !== undefined && raw.accidenteId !== null ? String(raw.accidenteId).trim() : '',
    codigoAccidente: raw.codigoAccidente !== undefined && raw.codigoAccidente !== null ? String(raw.codigoAccidente).trim() : undefined,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fechaInvestigacion: raw.fechaInvestigacion ? String(raw.fechaInvestigacion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    fechaAccidente: raw.fechaAccidente ? String(raw.fechaAccidente).slice(0, 10) : new Date().toISOString().slice(0, 10),
    horaAccidente: raw.horaAccidente !== undefined && raw.horaAccidente !== null ? String(raw.horaAccidente).trim() : '08:00',
    turno: raw.turno !== undefined && raw.turno !== null ? String(raw.turno).trim() : 'Mañana',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    lugarExacto: raw.lugarExacto !== undefined && raw.lugarExacto !== null ? String(raw.lugarExacto).trim() : '',
    diasDescanso: Number(raw.diasDescanso) || 0,
    datosTrabajador: {
      nombre: trab.nombre !== undefined && trab.nombre !== null ? String(trab.nombre).trim() : '',
      dni: trab.dni !== undefined && trab.dni !== null ? String(trab.dni).trim() : '',
      edad: Number(trab.edad) || 0,
      genero: trab.genero === 'F' ? 'F' : 'M',
      puesto: trab.puesto !== undefined && trab.puesto !== null ? String(trab.puesto).trim() : '',
      area: trab.area !== undefined && trab.area !== null ? String(trab.area).trim() : '',
      fechaIngreso: trab.fechaIngreso ? String(trab.fechaIngreso).slice(0, 10) : '',
      antiguedadPuesto: trab.antiguedadPuesto !== undefined && trab.antiguedadPuesto !== null ? String(trab.antiguedadPuesto).trim() : ''
    },
    descripcionCircunstancias: raw.descripcionCircunstancias !== undefined && raw.descripcionCircunstancias !== null ? String(raw.descripcionCircunstancias).trim() : '',
    testigos: raw.testigos !== undefined && raw.testigos !== null ? String(raw.testigos).trim() : undefined,
    tipoContacto: raw.tipoContacto !== undefined && raw.tipoContacto !== null ? String(raw.tipoContacto).trim() : '',
    agenteCausante: raw.agenteCausante !== undefined && raw.agenteCausante !== null ? String(raw.agenteCausante).trim() : '',
    causasInmediatas: {
      actosSubestandar: Array.isArray(cInm?.actosSubestandar) ? cInm.actosSubestandar.map(String) : [],
      condicionesSubestandar: Array.isArray(cInm?.condicionesSubestandar) ? cInm.condicionesSubestandar.map(String) : []
    },
    causasBasicas: {
      factoresPersonales: Array.isArray(cBas?.factoresPersonales) ? cBas.factoresPersonales.map(String) : [],
      factoresTrabajo: Array.isArray(cBas?.factoresTrabajo) ? cBas.factoresTrabajo.map(String) : []
    },
    causaRaizMetodo: raw.causaRaizMetodo === 'Ishikawa' ? 'Ishikawa' : '5 Porqués',
    analisisCausaRaiz: raw.analisisCausaRaiz !== undefined && raw.analisisCausaRaiz !== null ? String(raw.analisisCausaRaiz).trim() : '',
    conclusionCausaRaiz: raw.conclusionCausaRaiz !== undefined && raw.conclusionCausaRaiz !== null ? String(raw.conclusionCausaRaiz).trim() : '',
    medidasCorrectivas: Array.isArray(medidas) ? medidas.map((m: any) => ({
      ...m,
      id: m?.id ? String(m.id).trim() : `MED-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      descripcion: m?.descripcion !== undefined && m?.descripcion !== null ? String(m.descripcion).trim() : '',
      tipoAccion: m?.tipoAccion || 'Control Administrativo',
      responsable: m?.responsable !== undefined && m?.responsable !== null ? String(m.responsable).trim() : '',
      plazo: m?.plazo ? String(m.plazo).slice(0, 10) : '',
      estado: m?.estado || 'Pendiente',
      evidenciaUrl: m?.evidenciaUrl !== undefined && m?.evidenciaUrl !== null ? String(m.evidenciaUrl).trim() : undefined,
      fechaVerificacion: m?.fechaVerificacion ? String(m.fechaVerificacion).slice(0, 10) : undefined,
      verificador: m?.verificador !== undefined && m?.verificador !== null ? String(m.verificador).trim() : undefined
    })) : [],
    investigadores: Array.isArray(invs) ? invs.map((i: any) => ({
      ...i,
      nombre: i?.nombre !== undefined && i?.nombre !== null ? String(i.nombre).trim() : '',
      cargo: i?.cargo !== undefined && i?.cargo !== null ? String(i.cargo).trim() : '',
      rol: i?.rol || 'Investigador Principal',
      firmaUrl: toCleanStringOrUndefined(i?.firmaUrl),
      firmaDriveId: toCleanStringOrUndefined(i?.firmaDriveId),
      fechaFirma: i?.fechaFirma ? String(i.fechaFirma).slice(0, 10) : undefined
    })) : [],
    porcentajeAvance: Number(raw.porcentajeAvance) || 0,
    estado: raw.estado || 'Borrador',
    closureErrors: Array.isArray(raw.closureErrors) ? raw.closureErrors.map(String) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Simulación de Costos
export const sanitizeSimulacionCostos = (raw: any): SimulacionCostosRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `SIM-${Date.now()}`,
      codigoSimulacion: `SIM-${Date.now()}`,
      empresa: 'PERPOL',
      fechaSimulacion: new Date().toISOString().slice(0, 10),
      descripcionEvento: '',
      area: '',
      probabilidadOcurrencia: 1,
      consecuenciaPersonas: 1,
      consecuenciaActivos: 1,
      consecuenciaOperacion: 1,
      nivelRiesgoCalculado: 1,
      esHiPo: false,
      diasSimulados: 1,
      remuneracionDiaria: 50,
      costoRemuneracionSimulada: 50,
      trabajadoresAfectadosParalizacion: 0,
      horasParalizadas: 0,
      costoHoraHombre: 15,
      costoMaquinariaDanos: 0,
      otrosCostosParalizacion: 0,
      costoParalizacionTotal: 0,
      costosDirectos: { atencionEmergencia: 0, gastosClinicos: 0, subsidioDiasPerdidos: 0, reparacionEquipos: 0, medicamentos: 0 },
      costosIndirectos: { paralizacionPlanta: 0, horasHombreInvestigacion: 0, reemplazoPersonal: 0, multasSanciones: 0, perdidaProductividad: 0 },
      costoTotalDirecto: 0,
      costoTotalIndirecto: 0,
      costoTotalEstimado: 0,
      costoRealIncurrido: 0,
      brechaCosto: 0,
      createdAt: new Date().toISOString()
    };
  }
  const codSim = raw.codigoSimulacion !== undefined && raw.codigoSimulacion !== null && String(raw.codigoSimulacion).trim() !== ''
    ? String(raw.codigoSimulacion).trim()
    : (raw.id ? String(raw.id).trim() : `SIM-${Date.now()}`);
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : codSim;

  let cd = raw.costosDirectos;
  if (typeof cd === 'string') {
    try { cd = JSON.parse(cd); } catch { cd = {}; }
  }
  cd = cd || {};
  let ci = raw.costosIndirectos;
  if (typeof ci === 'string') {
    try { ci = JSON.parse(ci); } catch { ci = {}; }
  }
  ci = ci || {};

  return {
    ...raw,
    id: idStr,
    codigoSimulacion: codSim,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    fechaSimulacion: raw.fechaSimulacion ? String(raw.fechaSimulacion).slice(0, 10) : new Date().toISOString().slice(0, 10),
    incidenteId: raw.incidenteId !== undefined && raw.incidenteId !== null ? String(raw.incidenteId).trim() : undefined,
    codigoCasoIncidente: raw.codigoCasoIncidente !== undefined && raw.codigoCasoIncidente !== null ? String(raw.codigoCasoIncidente).trim() : undefined,
    inspeccionId: raw.inspeccionId !== undefined && raw.inspeccionId !== null ? String(raw.inspeccionId).trim() : undefined,
    inspeccionPuntaje: Number(raw.inspeccionPuntaje) || undefined,
    inspeccionDetalle: raw.inspeccionDetalle !== undefined && raw.inspeccionDetalle !== null ? String(raw.inspeccionDetalle).trim() : undefined,
    descripcionEvento: raw.descripcionEvento !== undefined && raw.descripcionEvento !== null ? String(raw.descripcionEvento).trim() : '',
    area: raw.area !== undefined && raw.area !== null ? String(raw.area).trim() : '',
    probabilidadOcurrencia: Number(raw.probabilidadOcurrencia) || 1,
    consecuenciaPersonas: Number(raw.consecuenciaPersonas) || 1,
    consecuenciaActivos: Number(raw.consecuenciaActivos) || 1,
    consecuenciaOperacion: Number(raw.consecuenciaOperacion) || 1,
    nivelRiesgoCalculado: Number(raw.nivelRiesgoCalculado) || 1,
    esHiPo: Boolean(raw.esHiPo),
    diasSimulados: Number(raw.diasSimulados) || 0,
    remuneracionDiaria: Number(raw.remuneracionDiaria) || 0,
    costoRemuneracionSimulada: Number(raw.costoRemuneracionSimulada) || 0,
    trabajadoresAfectadosParalizacion: Number(raw.trabajadoresAfectadosParalizacion) || 0,
    horasParalizadas: Number(raw.horasParalizadas) || 0,
    costoHoraHombre: Number(raw.costoHoraHombre) || 0,
    costoMaquinariaDanos: Number(raw.costoMaquinariaDanos) || 0,
    otrosCostosParalizacion: Number(raw.otrosCostosParalizacion) || 0,
    costoParalizacionTotal: Number(raw.costoParalizacionTotal) || 0,
    costosDirectos: {
      atencionEmergencia: Number(cd.atencionEmergencia) || 0,
      gastosClinicos: Number(cd.gastosClinicos) || 0,
      subsidioDiasPerdidos: Number(cd.subsidioDiasPerdidos) || 0,
      reparacionEquipos: Number(cd.reparacionEquipos) || 0,
      medicamentos: Number(cd.medicamentos) || 0
    },
    costosIndirectos: {
      paralizacionPlanta: Number(ci.paralizacionPlanta) || 0,
      horasHombreInvestigacion: Number(ci.horasHombreInvestigacion) || 0,
      reemplazoPersonal: Number(ci.reemplazoPersonal) || 0,
      multasSanciones: Number(ci.multasSanciones) || 0,
      perdidaProductividad: Number(ci.perdidaProductividad) || 0
    },
    costoTotalDirecto: Number(raw.costoTotalDirecto) || 0,
    costoTotalIndirecto: Number(raw.costoTotalIndirecto) || 0,
    costoTotalEstimado: Number(raw.costoTotalEstimado) || 0,
    costoRealIncurrido: Number(raw.costoRealIncurrido) || 0,
    brechaCosto: Number(raw.brechaCosto) || 0,
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Actos y Condiciones Inseguras (Módulo 3)
export const sanitizeActoCondicion = (raw: any): ActoCondicionRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `AC-${Date.now()}`,
      codigoReporte: `AC-${Date.now()}`,
      empresa: 'PERPOL',
      fecha: new Date().toISOString().slice(0, 10),
      reportadoPor: '',
      clasificacion: 'Acto Inseguro',
      categoriaCodigo: 'CAT-01',
      categoriaNombre: 'General',
      potencialGravedad: 2,
      prioridad: 'Media',
      descripcion: '',
      estado: 'Pendiente',
      createdAt: new Date().toISOString()
    };
  }

  const rawCode =
    raw.codigoReporte ??
    raw.codigoRegistro ??
    raw.codigo ??
    raw.id ??
    raw.nroReporte ??
    raw['Código de Registro'] ??
    raw['Código Reporte'] ??
    raw['Código'] ??
    raw['Codigo'];
  const codRep =
    rawCode !== undefined && rawCode !== null && String(rawCode).trim() !== ''
      ? String(rawCode).trim()
      : `AC-${Date.now()}`;
  const idStr =
    raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
      ? String(raw.id).trim()
      : codRep;

  const rawEmp = String(raw.empresa ?? raw.Empresa ?? raw['Compañía'] ?? raw['Sede'] ?? '').toUpperCase();
  const empresaVal: 'PERPOL' | 'TR3' = rawEmp.includes('TR3') ? 'TR3' : 'PERPOL';

  const rawFecha = raw.fecha ?? raw.Fecha ?? raw.fechaReporte ?? raw['Fecha del Reporte'] ?? raw['Fecha de Reporte'];
  const fechaStr = rawFecha ? String(rawFecha).slice(0, 10) : new Date().toISOString().slice(0, 10);

  const rawClasif = String(
    raw.clasificacion ??
    raw.Clasificación ??
    raw.tipoReporte ??
    raw.tipo ??
    raw.Tipo ??
    raw['Tipo de Reporte'] ??
    ''
  ).trim();
  const clasificacionVal: 'Acto Inseguro' | 'Condición Insegura' =
    rawClasif.toLowerCase().includes('condici') ? 'Condición Insegura' : 'Acto Inseguro';

  const rawArea = toCleanStringOrUndefined(raw.areaActo ?? raw.areaCondicion ?? raw.area ?? raw.Area ?? raw['Área'] ?? raw['Area']);
  const areaActoVal = toCleanStringOrUndefined(raw.areaActo ?? rawArea);
  const areaCondicionVal = toCleanStringOrUndefined(raw.areaCondicion ?? rawArea);

  const trabajadorNombre = toCleanStringOrUndefined(
    raw.trabajadorObservadoNombre ??
    raw.trabajadorObservado ??
    raw.trabajador ??
    raw.colaborador ??
    raw['Trabajador Observado'] ??
    raw['Trabajador']
  );

  const lugarVal = toCleanStringOrUndefined(
    raw.lugarEspecifico ??
    raw.lugarExacto ??
    raw.lugar ??
    raw.ubicacion ??
    raw['Lugar Específico'] ??
    raw['Lugar']
  );

  const rawCatCod =
    toCleanStringOrUndefined(
      raw.categoriaCodigo ??
      raw.categoriaId ??
      raw.codigoCategoria ??
      raw.cat_id ??
      raw['Código de Categoría']
    ) || 'CAT-01';
  const rawCatNom =
    toCleanStringOrUndefined(
      raw.categoriaNombre ??
      raw.categoria ??
      raw['Categoría']
    );
  const foundCat = CATALOGO_CATEGORIAS_RIESGO.find((c) => c.codigo === rawCatCod);
  const finalCatNom = foundCat ? foundCat.nombre : (rawCatNom || 'General');

  const pgNum = Number(raw.potencialGravedad ?? raw.pg ?? raw['Potencial Gravedad']) || 2;
  const pgVal = (pgNum >= 1 && pgNum <= 4 ? pgNum : 2) as 1 | 2 | 3 | 4;
  const prioridadVal = raw.prioridad ?? raw.Prioridad ?? raw.nivelRiesgo ?? 'Media';

  const descVal =
    toCleanStringOrUndefined(raw.descripcion ?? raw.Descripcion ?? raw['Descripción'] ?? raw.detalle ?? '') || '';

  const rawEstado = String(raw.estado ?? raw.Estado ?? '').trim();
  const estadoVal: 'Pendiente' | 'En proceso' | 'Cerrado' =
    rawEstado.toLowerCase() === 'cerrado' || rawEstado.toLowerCase() === 'subsanado'
      ? 'Cerrado'
      : rawEstado.toLowerCase().includes('proceso')
      ? 'En proceso'
      : 'Pendiente';

  const reportadoVal =
    toCleanStringOrUndefined(raw.reportadoPor ?? raw.reportado_por ?? raw['Reportado Por'] ?? raw.reporta) || '';

  return {
    ...raw,
    id: idStr,
    codigoReporte: codRep,
    empresa: empresaVal,
    fecha: fechaStr,
    reportadoPor: reportadoVal,
    clasificacion: clasificacionVal,
    categoriaCodigo: rawCatCod,
    categoriaNombre: finalCatNom,
    potencialGravedad: pgVal,
    prioridad: prioridadVal,
    descripcion: descVal,
    fotoUrl: toCleanStringOrUndefined(raw.fotoUrl ?? raw.foto ?? raw.evidencia),
    fotoDriveId: toCleanStringOrUndefined(raw.fotoDriveId),
    tipoPersonal: raw.tipoPersonal || undefined,
    empresaPersonal: toCleanStringOrUndefined(raw.empresaPersonal),
    trabajadorObservadoDni: toCleanStringOrUndefined(raw.trabajadorObservadoDni ?? raw.dni),
    trabajadorObservadoNombre: trabajadorNombre,
    cargoObservado: toCleanStringOrUndefined(raw.cargoObservado ?? raw.cargo ?? raw.puesto),
    areaActo: areaActoVal,
    turnoActo: raw.turnoActo || undefined,
    areaCondicion: areaCondicionVal,
    lugarEspecifico: lugarVal,
    estado: estadoVal,
    medidaCorrectiva: toCleanStringOrUndefined(raw.medidaCorrectiva ?? raw['Medida Correctiva'] ?? raw.accionCorrectiva),
    responsableSeguimiento: toCleanStringOrUndefined(raw.responsableSeguimiento ?? raw.responsable ?? raw['Responsable']),
    fechaCompromiso: raw.fechaCompromiso ? String(raw.fechaCompromiso).slice(0, 10) : undefined,
    fechaCierre: raw.fechaCierre ? String(raw.fechaCierre).slice(0, 10) : undefined,
    fotoCierreUrl: toCleanStringOrUndefined(raw.fotoCierreUrl),
    fotoCierreDriveId: toCleanStringOrUndefined(raw.fotoCierreDriveId),
    observacionCierre: toCleanStringOrUndefined(raw.observacionCierre),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Programa Anual SST (Módulo 7)
export const sanitizeProgramaAnual = (raw: any): ProgramaAnualRecord => {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `PROG-${Date.now()}`,
      anio: new Date().getFullYear(),
      numeroItem: 1,
      empresa: 'PERPOL',
      objetivoGeneral: '',
      actividad: '',
      tipoActividad: 'Regular',
      responsable: '',
      presupuestoEstimado: 0,
      metaPorcentaje: 100,
      indicadorFormula: '',
      programacionMeses: Array(12).fill(false),
      ejecucionMeses: Array(12).fill(false),
      estado: 'Programado',
      avanceCalculado: 0,
      createdAt: new Date().toISOString()
    };
  }
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : `PROG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  let prog = raw.programacionMeses;
  if (typeof prog === 'string') {
    try { prog = JSON.parse(prog); } catch { prog = []; }
  }
  let ejec = raw.ejecucionMeses;
  if (typeof ejec === 'string') {
    try { ejec = JSON.parse(ejec); } catch { ejec = []; }
  }

  const cleanProg = Array.isArray(prog) && prog.length === 12 ? prog.map(Boolean) : Array(12).fill(false);
  const cleanEjec = Array.isArray(ejec) && ejec.length === 12 ? ejec.map(Boolean) : Array(12).fill(false);

  return {
    ...raw,
    id: idStr,
    anio: Number(raw.anio) || new Date().getFullYear(),
    numeroItem: Number(raw.numeroItem) || 1,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    objetivoGeneral: raw.objetivoGeneral !== undefined && raw.objetivoGeneral !== null ? String(raw.objetivoGeneral).trim() : '',
    actividad: raw.actividad !== undefined && raw.actividad !== null ? String(raw.actividad).trim() : '',
    tipoActividad: raw.tipoActividad || 'Regular',
    responsable: raw.responsable !== undefined && raw.responsable !== null ? String(raw.responsable).trim() : '',
    presupuestoEstimado: Number(raw.presupuestoEstimado) || 0,
    metaPorcentaje: Number(raw.metaPorcentaje) || 100,
    indicadorFormula: raw.indicadorFormula !== undefined && raw.indicadorFormula !== null ? String(raw.indicadorFormula).trim() : '',
    programacionMeses: cleanProg,
    ejecucionMeses: cleanEjec,
    estado: raw.estado || 'Programado',
    avanceCalculado: Number(raw.avanceCalculado) || 0,
    observaciones: toCleanStringOrUndefined(raw.observaciones),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};

// Helper para sanitizar Resumen Mensual de Horas-Hombre (HH)
export const sanitizeHorasHombre = (raw: any): ResumenMensualHH => {
  const yr = new Date().getFullYear();
  if (!raw || typeof raw !== 'object') {
    return {
      id: `${yr}-01`,
      empresa: 'PERPOL',
      anio: yr,
      mes: 1,
      trabajadoresPerpol: 0,
      hhPerpol: 0,
      trabajadoresTr3: 0,
      hhTr3: 0,
      totalTrabajadores: 0,
      totalHH: 0,
      createdAt: new Date().toISOString()
    };
  }
  const anio = Number(raw.anio) || yr;
  const mes = Math.max(1, Math.min(12, Number(raw.mes) || 1));
  const idStr = raw.id !== undefined && raw.id !== null && String(raw.id).trim() !== ''
    ? String(raw.id).trim()
    : `${anio}-${mes < 10 ? '0' + mes : mes}`;

  const tPerpol = Number(raw.trabajadoresPerpol) || 0;
  const hPerpol = Number(raw.hhPerpol) || 0;
  const tTr3 = Number(raw.trabajadoresTr3) || 0;
  const hTr3 = Number(raw.hhTr3) || 0;

  return {
    ...raw,
    id: idStr,
    empresa: raw.empresa === 'TR3' ? 'TR3' : 'PERPOL',
    anio,
    mes,
    trabajadoresPerpol: tPerpol,
    hhPerpol: hPerpol,
    trabajadoresTr3: tTr3,
    hhTr3: hTr3,
    totalTrabajadores: Number(raw.totalTrabajadores) || (tPerpol + tTr3),
    totalHH: Number(raw.totalHH) || (hPerpol + hTr3),
    createdAt: raw.createdAt ? String(raw.createdAt) : new Date().toISOString(),
    updatedAt: raw.updatedAt ? String(raw.updatedAt) : new Date().toISOString()
  };
};
