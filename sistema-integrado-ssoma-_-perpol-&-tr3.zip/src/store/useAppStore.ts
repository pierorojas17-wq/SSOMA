/**
 * useAppStore: Store de configuración general de la aplicación,
 * contexto de empresa activa, preferencias de interfaz y apariencia.
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { EmpresaId } from '../types';
import { ThemeColor, ThemeBackground } from '../types/theme';
import { applyTheme } from '../utils/themeUtils';

export interface AppPreferencesState {
  // Filtro de empresa activa
  empresaActiva: EmpresaId;
  setEmpresaActiva: (empresa: EmpresaId) => void;

  // Estado de navegación de la interfaz
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;

  // Apariencia y Colores de la Marca
  themeColor: ThemeColor;
  customBrandHex: string;
  themeBackground: ThemeBackground;
  setThemeColor: (color: ThemeColor) => void;
  setCustomBrandHex: (hex: string) => void;
  setThemeBackground: (bg: ThemeBackground) => void;
  resetTheme: () => void;
}

export const useAppStore = create<AppPreferencesState>()(
  persist(
    (set, get) => ({
      empresaActiva: 'CONSOLIDADO',
      setEmpresaActiva: (empresa) => set({ empresaActiva: empresa }),

      sidebarOpen: true,
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),

      themeColor: 'corporate',
      customBrandHex: '#263B5E',
      themeBackground: 'light',
      setThemeColor: (color) => {
        set({ themeColor: color });
        applyTheme(color, get().customBrandHex, get().themeBackground);
      },
      setCustomBrandHex: (hex) => {
        set({ customBrandHex: hex, themeColor: 'custom' });
        applyTheme('custom', hex, get().themeBackground);
      },
      setThemeBackground: (themeBackground) => {
        set({ themeBackground });
        applyTheme(get().themeColor, get().customBrandHex, themeBackground);
      },
      resetTheme: () => {
        set({ themeColor: 'corporate', customBrandHex: '#263B5E', themeBackground: 'light' });
        applyTheme('corporate', '#263B5E', 'light');
      }
    }),
    {
      name: 'ssoma-app-preferences',
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.themeBackground = 'light';
          if (!state.themeColor || state.themeColor === 'emerald') {
            state.themeColor = 'corporate';
            state.customBrandHex = '#263B5E';
          }
          applyTheme(state.themeColor || 'corporate', state.customBrandHex || '#263B5E', 'light');
        }
      }
    }
  )
);
