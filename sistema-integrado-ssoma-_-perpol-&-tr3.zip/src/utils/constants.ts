/**
 * Constantes globales del Sistema Integrado SSOMA
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 */

export const APP_NAME = 'Sistema Integrado SSOMA';
export const APP_VERSION = '2.0.0';

export const COLORES_MARCA = {
  navy: '#263B5E',
  blue: '#3F72AF',
  teal: '#5AB9A8',
  tealDark: '#489E90',
  amber: '#F2B84B',
  danger: '#D9534F',
  surface: '#FFFFFF',
  appBg: '#F4F6F8'
} as const;

export const MESES_ANIO = [
  { numero: 1, nombre: 'Enero', corto: 'Ene' },
  { numero: 2, nombre: 'Febrero', corto: 'Feb' },
  { numero: 3, nombre: 'Marzo', corto: 'Mar' },
  { numero: 4, nombre: 'Abril', corto: 'Abr' },
  { numero: 5, nombre: 'Mayo', corto: 'May' },
  { numero: 6, nombre: 'Junio', corto: 'Jun' },
  { numero: 7, nombre: 'Julio', corto: 'Jul' },
  { numero: 8, nombre: 'Agosto', corto: 'Ago' },
  { numero: 9, nombre: 'Setiembre', corto: 'Set' },
  { numero: 10, nombre: 'Octubre', corto: 'Oct' },
  { numero: 11, nombre: 'Noviembre', corto: 'Nov' },
  { numero: 12, nombre: 'Diciembre', corto: 'Dic' }
] as const;

export const TURNOS_TRABAJO = ['Mañana', 'Tarde', 'Noche', 'Rotativo'] as const;

export const ESTADOS_CASO = ['Abierto', 'En investigación', 'Con medidas correctivas', 'Cerrado'] as const;
