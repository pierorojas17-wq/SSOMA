/**
 * Re-exportación de utilidades de exportación para compatibilidad
 */
import { exportToExcel } from './export/excelUtils';
import { exportToPdf, PdfExportOptions } from './export/pdfUtils';
import { exportToCsv } from './export/csvUtils';

export * from './export';

export class ExportUtils {
  public static exportToExcel = exportToExcel;
  public static exportToPdf = exportToPdf;
  public static exportToCsv = exportToCsv;
  public static printElement(_elementId: string, _title?: string) {
    window.print();
  }
}
