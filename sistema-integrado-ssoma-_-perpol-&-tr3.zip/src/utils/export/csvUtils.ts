import Papa from 'papaparse';

export function exportToCsv<T extends Record<string, unknown>>(
  data: T[],
  fileName: string
): void {
  if (!data || data.length === 0) {
    throw new Error('No hay registros para exportar a CSV.');
  }

  const csv = Papa.unparse(data);
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName.replace(/\.csv$/i, '')}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
