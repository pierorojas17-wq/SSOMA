import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { EMPRESAS, EmpresaId } from '../../types';

export interface PdfExportOptions {
  title: string;
  subtitle?: string;
  empresa: EmpresaId;
  fileName: string;
  headers: string[];
  rows: (string | number)[][];
  columnWidths?: number[];
  orientation?: 'portrait' | 'landscape';
}

export function exportToPdf(options: PdfExportOptions): void {
  const orientation = options.orientation || 'landscape';
  const doc = new jsPDF({
    orientation,
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // 1. Franja superior verde corporativo SSOMA
  doc.setFillColor(31, 157, 85);
  doc.rect(0, 0, pageWidth, 18, 'F');

  // Título en la franja
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('SISTEMA INTEGRADO DE GESTIÓN SSOMA', 14, 11);

  const empresaInfo =
    options.empresa === 'CONSOLIDADO' ? null : EMPRESAS[options.empresa as 'PERPOL' | 'TR3'];
  const empresaText = empresaInfo
    ? `${empresaInfo.razonSocial} | RUC: ${empresaInfo.ruc}`
    : 'PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C. (CONSOLIDADO)';

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(empresaText, pageWidth - 14, 11, { align: 'right' });

  // 2. Título del Documento
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(options.title, 14, 28);

  if (options.subtitle) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(options.subtitle, 14, 34);
  }

  const fechaEmision = new Date().toLocaleString('es-PE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Fecha de emisión: ${fechaEmision}`, pageWidth - 14, 28, { align: 'right' });

  // 3. Tabla generada con autoTable
  autoTable(doc, {
    startY: options.subtitle ? 38 : 34,
    head: [options.headers],
    body: options.rows,
    theme: 'grid',
    headStyles: {
      fillColor: [31, 157, 85],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center'
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 2,
      textColor: [30, 41, 59],
      overflow: 'linebreak'
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252]
    },
    margin: { top: 20, right: 14, bottom: 20, left: 14 },
    didDrawPage: (data) => {
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      const str = `Página ${data.pageNumber} de ${doc.getNumberOfPages()}`;
      doc.text(str, pageWidth / 2, pageHeight - 8, { align: 'center' });
      doc.text(
        'Documento controlado - Ley N° 29783 de Seguridad y Salud en el Trabajo',
        14,
        pageHeight - 8
      );
    }
  });

  const cleanFileName = `${options.fileName.replace(/\.pdf$/i, '')}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(cleanFileName);
}
