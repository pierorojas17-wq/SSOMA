/**
 * Utilidad de compresión y optimización de imágenes en el cliente
 * Emplea OffscreenCanvas / createImageBitmap cuando está disponible
 * con fallback a HTMLCanvasElement clásico.
 */

export interface CompressImageOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number; // 0.1 a 1.0 (default 0.8)
  format?: 'image/jpeg' | 'image/webp' | 'image/png';
}

/**
 * Comprime un archivo o Blob de imagen y retorna un nuevo Blob optimizado
 */
export async function compressImage(
  source: File | Blob | string,
  options: CompressImageOptions = {}
): Promise<Blob> {
  const {
    maxWidth = 1200,
    maxHeight = 1200,
    quality = 0.8,
    format = 'image/jpeg'
  } = options;

  let imgBitmap: ImageBitmap | HTMLImageElement;
  let originalWidth = 0;
  let originalHeight = 0;

  if (typeof source === 'string') {
    // Es un dataURL o URL
    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('Error al cargar la imagen'));
      img.src = source;
    });
    imgBitmap = img;
    originalWidth = img.width;
    originalHeight = img.height;
  } else if (typeof window !== 'undefined' && 'createImageBitmap' in window) {
    try {
      imgBitmap = await createImageBitmap(source);
      originalWidth = imgBitmap.width;
      originalHeight = imgBitmap.height;
    } catch {
      // Fallback a HTMLImageElement
      const url = URL.createObjectURL(source);
      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('Error al decodificar la imagen'));
        img.src = url;
      });
      URL.revokeObjectURL(url);
      imgBitmap = img;
      originalWidth = img.width;
      originalHeight = img.height;
    }
  } else {
    const url = URL.createObjectURL(source);
    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('Error al decodificar imagen'));
      img.src = url;
    });
    URL.revokeObjectURL(url);
    imgBitmap = img;
    originalWidth = img.width;
    originalHeight = img.height;
  }

  // Calcular dimensiones manteniendo la relación de aspecto
  let targetWidth = originalWidth;
  let targetHeight = originalHeight;

  if (targetWidth > maxWidth || targetHeight > maxHeight) {
    const ratio = Math.min(maxWidth / targetWidth, maxHeight / targetHeight);
    targetWidth = Math.round(targetWidth * ratio);
    targetHeight = Math.round(targetHeight * ratio);
  }

  // Renderizado con OffscreenCanvas si está soportado
  if (typeof OffscreenCanvas !== 'undefined') {
    const offscreen = new OffscreenCanvas(targetWidth, targetHeight);
    const ctx = offscreen.getContext('2d');
    if (ctx) {
      if (format === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
      }
      ctx.drawImage(imgBitmap, 0, 0, targetWidth, targetHeight);
      return await offscreen.convertToBlob({ type: format, quality });
    }
  }

  // Fallback con canvas del DOM
  return new Promise<Blob>((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      reject(new Error('No se pudo inicializar el contexto 2D de canvas'));
      return;
    }

    if (format === 'image/jpeg') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetWidth, targetHeight);
    }

    ctx.drawImage(imgBitmap, 0, 0, targetWidth, targetHeight);

    canvas.toBlob(
      (blob) => {
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error('Error al convertir canvas a Blob'));
        }
      },
      format,
      quality
    );
  });
}

/**
 * Convierte un Blob o File a Data URL (base64)
 */
export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Error al leer el archivo en base64'));
    reader.readAsDataURL(blob);
  });
}
