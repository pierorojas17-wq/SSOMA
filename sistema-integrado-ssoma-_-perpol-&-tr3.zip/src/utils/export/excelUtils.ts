import * as XLSX from 'xlsx';

export function exportToExcel<T extends Record<string, unknown>>(
  data: T[],
  fileName: string,
  sheetName = 'Datos_SSOMA'
): void {
  if (!data || data.length === 0) {
    throw new Error('No hay registros para exportar a Excel.');
  }

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.substring(0, 31));

  const keys = Object.keys(data[0] || {});
  worksheet['!cols'] = keys.map((key) => {
    const maxLength = Math.max(
      key.length,
      ...data.map((row) => String(row[key] ?? '').length)
    );
    return { wch: Math.min(Math.max(maxLength + 3, 12), 40) };
  });

  const cleanFileName = `${fileName.replace(/\.xlsx$/i, '')}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, cleanFileName);
}
