/**
 * Esquemas de Importación para los 10 Módulos del Sistema SSOMA
 * Define campos obligatorios, alias para auto-mapeo inteligente, tipos de datos,
 * validadores normativos (RUC, DNI, fechas) y filas de ejemplo para plantillas Excel.
 */

export interface FieldSchema {
  key: string;
  label: string;
  required: boolean;
  type: 'string' | 'number' | 'date' | 'boolean' | 'enum';
  enumValues?: string[];
  aliases: string[];
  preserveZeros?: boolean; // Para DNI, RUC y Teléfonos
  description?: string;
}

export interface ModuleImportSchema {
  moduleId: string;
  moduleName: string;
  sheetName: string;
  primaryKey: string;
  fields: FieldSchema[];
  sampleRow: Record<string, unknown>;
  requiresMasterValidation?: boolean;
  masterValidationField?: string;
  masterValidationMessage?: string;
}

export const MODULE_IMPORT_SCHEMAS: Record<string, ModuleImportSchema> = {
  // 1. Accidentes de Trabajo y Seguimiento
  accidentes: {
    moduleId: 'accidentes',
    moduleName: 'Módulo 1: Accidentes e Incidentes',
    sheetName: 'SSOMA_Accidentes',
    primaryKey: 'codigoCaso',
    fields: [
      {
        key: 'codigoCaso',
        label: 'Código de Caso',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_caso', 'cod_caso', 'caso', 'id_caso', 'nro_caso'],
        description: 'Formato sugerido ACC-YYYY-XXXX'
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'razon_social', 'compania', 'cia']
      },
      {
        key: 'fecha',
        label: 'Fecha del Evento',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_accidente', 'fecha_evento', 'fec_accidente']
      },
      {
        key: 'hora',
        label: 'Hora del Evento',
        required: false,
        type: 'string',
        aliases: ['hora', 'hora_accidente', 'hora_evento']
      },
      {
        key: 'trabajadorDni',
        label: 'DNI del Trabajador',
        required: true,
        type: 'string',
        preserveZeros: true,
        aliases: ['dni', 'trabajador_dni', 'doc_identidad', 'documento', 'cedula']
      },
      {
        key: 'trabajadorNombre',
        label: 'Apellidos y Nombres',
        required: true,
        type: 'string',
        aliases: ['nombre', 'trabajador', 'trabajador_nombre', 'apellidos_nombres', 'colaborador']
      },
      {
        key: 'cargo',
        label: 'Cargo / Puesto',
        required: false,
        type: 'string',
        aliases: ['cargo', 'puesto', 'ocupacion', 'posicion']
      },
      {
        key: 'area',
        label: 'Área de Ocurrencia',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'departamento', 'zona']
      },
      {
        key: 'turno',
        label: 'Turno',
        required: false,
        type: 'enum',
        enumValues: ['Mañana', 'Tarde', 'Noche'],
        aliases: ['turno', 'jornada', 'horario']
      },
      {
        key: 'lugarExacto',
        label: 'Lugar Específico',
        required: false,
        type: 'string',
        aliases: ['lugar', 'lugar_exacto', 'ubicacion', 'sitio']
      },
      {
        key: 'tipoEvento',
        label: 'Clasificación del Evento',
        required: true,
        type: 'enum',
        enumValues: ['Incidente potencial', 'Incidente', 'Accidente leve', 'Accidente incapacitante', 'Accidente mortal'],
        aliases: ['tipo_evento', 'clasificacion', 'tipo_accidente', 'gravedad']
      },
      {
        key: 'danoMaterial',
        label: '¿Hubo Daño Material?',
        required: false,
        type: 'enum',
        enumValues: ['SI', 'NO'],
        aliases: ['dano_material', 'dano', 'danos_materiales']
      },
      {
        key: 'necesidadAtencion',
        label: '¿Requirió Atención Médica?',
        required: false,
        type: 'enum',
        enumValues: ['SI', 'NO'],
        aliases: ['necesidad_atencion', 'atencion_medica', 'topico']
      },
      {
        key: 'descripcion',
        label: 'Descripción de los Hechos',
        required: true,
        type: 'string',
        aliases: ['descripcion', 'hechos', 'detalle', 'circunstancias']
      },
      {
        key: 'partesCuerpoAfectadas',
        label: 'Partes del Cuerpo Afectadas',
        required: false,
        type: 'string',
        aliases: ['partes_cuerpo', 'partes_afectadas', 'cuerpo_afectado', 'parte_cuerpo']
      },
      {
        key: 'mecanismoEvento',
        label: 'Tipo / Mecanismo del Evento',
        required: false,
        type: 'string',
        aliases: ['mecanismo', 'mecanismo_evento', 'forma_accidente', 'tipo_mecanismo']
      },
      {
        key: 'agenteEvento',
        label: 'Fuente o Agente del Evento',
        required: false,
        type: 'string',
        aliases: ['agente', 'fuente', 'agente_evento', 'fuente_evento']
      },
      {
        key: 'lesionReferida',
        label: 'Lesión o Afectación a la Salud',
        required: false,
        type: 'string',
        aliases: ['lesion', 'lesion_referida', 'tipo_lesion', 'afectacion']
      },
      {
        key: 'estadoCaso',
        label: 'Estado del Caso',
        required: false,
        type: 'enum',
        enumValues: ['Abierto', 'En investigación', 'Con medidas correctivas', 'Cerrado'],
        aliases: ['estado', 'estado_caso', 'status']
      }
    ],
    sampleRow: {
      codigoCaso: 'ACC-2026-0001',
      empresa: 'PERPOL',
      fecha: '2026-02-10',
      hora: '10:30',
      trabajadorDni: '45892134',
      trabajadorNombre: 'Mendoza Ruiz, Carlos Alberto',
      cargo: 'Operario de Envasado',
      area: 'Línea de Envasado L-2',
      turno: 'Mañana',
      lugarExacto: 'Faja transportadora central',
      tipoEvento: 'Accidente leve',
      danoMaterial: 'NO',
      necesidadAtencion: 'SI',
      partesCuerpoAfectadas: 'Dedos, Mano',
      mecanismoEvento: 'Cortes',
      agenteEvento: 'Metales, Herramienta manual',
      lesionReferida: 'Laceración',
      descripcion: 'Corte superficial en dedo índice derecho al manipular guía metálica.',
      estadoCaso: 'Cerrado'
    }
  },

  // 2. Atenciones Médicas y Primeros Auxilios
  atencionesMedicas: {
    moduleId: 'atencionesMedicas',
    moduleName: 'Módulo 2: Atenciones Médicas',
    sheetName: 'SSOMA_AtencionesMedicas',
    primaryKey: 'idAtencion',
    fields: [
      {
        key: 'idAtencion',
        label: 'ID de Atención',
        required: true,
        type: 'string',
        aliases: ['id_atencion', 'codigo_atencion', 'codigo', 'cod_atencion', 'nro_atencion'],
        description: 'Formato sugerido ATN-YYYY-XXXX'
      },
      {
        key: 'codigoAccidente',
        label: 'ID Accidente Vinculado',
        required: false,
        type: 'string',
        aliases: ['codigo_accidente', 'id_accidente', 'accidente', 'caso_sst', 'caso_accidente']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'razon_social', 'compania', 'cia']
      },
      {
        key: 'fechaAtencion',
        label: 'Fecha de Atención',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_atencion', 'fec_atencion']
      },
      {
        key: 'horaAtencion',
        label: 'Hora de Atención',
        required: false,
        type: 'string',
        aliases: ['hora', 'hora_atencion']
      },
      {
        key: 'trabajadorDni',
        label: 'DNI / C.E. del Trabajador',
        required: true,
        type: 'string',
        preserveZeros: true,
        aliases: ['dni', 'trabajador_dni', 'doc_identidad', 'documento', 'ce', 'c.e.']
      },
      {
        key: 'trabajadorNombre',
        label: 'Apellidos y Nombres',
        required: true,
        type: 'string',
        aliases: ['nombre', 'trabajador', 'trabajador_nombre', 'apellidos_nombres', 'colaborador']
      },
      {
        key: 'puesto',
        label: 'Puesto / Cargo',
        required: false,
        type: 'string',
        aliases: ['cargo', 'puesto', 'ocupacion', 'posicion']
      },
      {
        key: 'area',
        label: 'Área de Trabajo',
        required: false,
        type: 'string',
        aliases: ['area', 'seccion', 'departamento', 'zona']
      },
      {
        key: 'turno',
        label: 'Turno',
        required: false,
        type: 'enum',
        enumValues: ['Mañana', 'Tarde', 'Noche'],
        aliases: ['turno', 'jornada', 'horario']
      },
      {
        key: 'lugarAtencion',
        label: 'Lugar de Atención',
        required: true,
        type: 'string',
        aliases: ['lugar', 'lugar_atencion', 'topico', 'clinica', 'centro_medico']
      },
      {
        key: 'diagnostico',
        label: 'Diagnóstico / Descripción Médica',
        required: true,
        type: 'string',
        aliases: ['diagnostico', 'descripcion', 'tratamiento', 'diagnostico_medico']
      },
      {
        key: 'generaDescanso',
        label: '¿Genera Descanso Médico?',
        required: false,
        type: 'enum',
        enumValues: ['SI', 'NO'],
        aliases: ['genera_descanso', 'descanso', 'descanso_medico']
      },
      {
        key: 'fechaInicioDescanso',
        label: 'Inicio de Descanso',
        required: false,
        type: 'date',
        aliases: ['inicio_descanso', 'fecha_inicio_descanso', 'desde']
      },
      {
        key: 'fechaFinDescanso',
        label: 'Fin de Descanso',
        required: false,
        type: 'date',
        aliases: ['fin_descanso', 'fecha_fin_descanso', 'hasta']
      },
      {
        key: 'diasDescanso',
        label: 'Días de Descanso',
        required: false,
        type: 'number',
        aliases: ['dias_descanso', 'dias', 'dias_dm']
      },
      {
        key: 'proximaCita',
        label: 'Próxima Cita / Control',
        required: false,
        type: 'date',
        aliases: ['proxima_cita', 'cita', 'control']
      },
      {
        key: 'estado',
        label: 'Estado de la Atención',
        required: false,
        type: 'enum',
        enumValues: ['En seguimiento', 'Alta / reincorporado', 'Cerrado'],
        aliases: ['estado', 'status', 'condicion']
      },
      {
        key: 'medicoTratante',
        label: 'Médico / Profesional Tratante',
        required: false,
        type: 'string',
        aliases: ['medico', 'medico_tratante', 'profesional']
      },
      {
        key: 'observaciones',
        label: 'Observaciones',
        required: false,
        type: 'string',
        aliases: ['observaciones', 'notas']
      }
    ],
    sampleRow: {
      idAtencion: 'ATN-2026-0001',
      codigoAccidente: 'ACC-2026-0001',
      empresa: 'PERPOL',
      fechaAtencion: '2026-02-10',
      horaAtencion: '10:45',
      trabajadorDni: '45892134',
      trabajadorNombre: 'Mendoza Ruiz, Carlos Alberto',
      puesto: 'Operario de Envasado',
      area: 'Línea de Envasado L-2',
      turno: 'Mañana',
      lugarAtencion: 'Tópico de Planta',
      diagnostico: 'Corte superficial en dedo índice. Curación, desinfección y vendaje compresivo.',
      generaDescanso: 'NO',
      fechaInicioDescanso: '',
      fechaFinDescanso: '',
      diasDescanso: 0,
      proximaCita: '2026-02-12',
      estado: 'Alta / reincorporado',
      medicoTratante: 'Lic. Ocupacional SSOMA',
      observaciones: 'Apto para labores con guantes de nitrilo reforzado.'
    }
  },

  // 3. Inspecciones SST
  inspecciones: {
    moduleId: 'inspecciones',
    moduleName: 'Módulo 2: Inspecciones SST',
    sheetName: 'SSOMA_Inspecciones',
    primaryKey: 'codigoInspeccion',
    fields: [
      {
        key: 'codigoInspeccion',
        label: 'Código de Inspección',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_inspeccion', 'cod_inspeccion', 'nro_inspeccion']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'fecha',
        label: 'Fecha de Inspección',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_inspeccion', 'fec_inspeccion']
      },
      {
        key: 'area',
        label: 'Área Inspeccionada',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'zona', 'lugar']
      },
      {
        key: 'responsableInspeccion',
        label: 'Inspector Responsable',
        required: true,
        type: 'string',
        aliases: ['responsable', 'inspector', 'responsable_inspeccion', 'auditor']
      },
      {
        key: 'hallazgo',
        label: 'Descripción del Hallazgo',
        required: true,
        type: 'string',
        aliases: ['hallazgo', 'descripcion', 'observacion', 'condicion_detectada']
      },
      {
        key: 'potencialGravedad',
        label: 'Potencial de Gravedad (1 a 4)',
        required: true,
        type: 'number',
        aliases: ['potencial_gravedad', 'pg', 'p.g.', 'gravedad', 'nivel_gravedad']
      },
      {
        key: 'tipo',
        label: 'Tipo de Hallazgo',
        required: false,
        type: 'enum',
        enumValues: ['Condición insegura', 'Acto inseguro', 'Observación', 'No conformidad', 'Buena práctica'],
        aliases: ['tipo', 'tipo_hallazgo', 'clasificacion']
      },
      {
        key: 'fechaCompromiso',
        label: 'Fecha de Compromiso',
        required: true,
        type: 'date',
        aliases: ['fecha_compromiso', 'compromiso', 'plazo', 'fecha_limite']
      },
      {
        key: 'responsableLevantamiento',
        label: 'Responsable de Levantamiento',
        required: false,
        type: 'string',
        aliases: ['responsable_levantamiento', 'responsable_accion', 'asignado_a']
      },
      {
        key: 'accionCorrectiva',
        label: 'Acción Correctiva Propuesta',
        required: false,
        type: 'string',
        aliases: ['accion_correctiva', 'medida_correctiva', 'plan_accion', 'solucion']
      },
      {
        key: 'estado',
        label: 'Estado de Levantamiento',
        required: false,
        type: 'enum',
        enumValues: ['Pendiente', 'En proceso', 'Subsanado', 'Vencido'],
        aliases: ['estado', 'status', 'situacion']
      }
    ],
    sampleRow: {
      codigoInspeccion: 'INSP-2026-0001',
      empresa: 'PERPOL',
      fecha: '2026-01-15',
      area: 'Planta de Procesos',
      responsableInspeccion: 'Ing. Supervisor SSOMA',
      hallazgo: 'Cables de alimentación de bomba centrífuga sin canaleta de protección.',
      potencialGravedad: 3,
      tipo: 'Condición insegura',
      fechaCompromiso: '2026-01-22',
      responsableLevantamiento: 'Jefe de Mantenimiento',
      accionCorrectiva: 'Instalación de tubería conduit metálica y rotulado de voltaje.',
      estado: 'Subsanado'
    }
  },

  // 3. Actos y Condiciones Inseguras
  'actos-condiciones': {
    moduleId: 'actos-condiciones',
    moduleName: 'Módulo 3: Actos y Condiciones Inseguras',
    sheetName: 'SSOMA_ActosCondiciones',
    primaryKey: 'codigoRegistro',
    fields: [
      {
        key: 'codigoRegistro',
        label: 'Código de Registro',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_registro', 'cod_registro', 'id_registro', 'nro_reporte']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'clasificacion',
        label: 'Clasificación',
        required: true,
        type: 'enum',
        enumValues: ['Acto Inseguro', 'Condición Insegura'],
        aliases: ['clasificacion', 'tipo', 'clase']
      },
      {
        key: 'fecha',
        label: 'Fecha del Reporte',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_reporte', 'fec_reporte']
      },
      {
        key: 'area',
        label: 'Área',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'zona']
      },
      {
        key: 'lugarExacto',
        label: 'Lugar Específico',
        required: false,
        type: 'string',
        aliases: ['lugar', 'lugar_exacto', 'ubicacion']
      },
      {
        key: 'trabajadorObservado',
        label: 'Trabajador Observado (Si es Acto)',
        required: false,
        type: 'string',
        aliases: ['trabajador_observado', 'observado', 'infractor', 'colaborador']
      },
      {
        key: 'categoriaId',
        label: 'Código de Categoría (CAT-01 a CAT-12)',
        required: true,
        type: 'string',
        aliases: ['categoria', 'categoria_id', 'cat_id', 'codigo_categoria']
      },
      {
        key: 'descripcion',
        label: 'Descripción Detallada',
        required: true,
        type: 'string',
        aliases: ['descripcion', 'detalle', 'reporte', 'observacion']
      },
      {
        key: 'potencialGravedad',
        label: 'Potencial de Gravedad (1 a 4)',
        required: true,
        type: 'number',
        aliases: ['potencial_gravedad', 'pg', 'p.g.', 'gravedad']
      },
      {
        key: 'medidaCorrectiva',
        label: 'Medida Correctiva',
        required: false,
        type: 'string',
        aliases: ['medida_correctiva', 'accion_correctiva', 'solucion']
      },
      {
        key: 'responsableSeguimiento',
        label: 'Responsable de Seguimiento',
        required: false,
        type: 'string',
        aliases: ['responsable', 'responsable_seguimiento', 'asignado']
      },
      {
        key: 'estado',
        label: 'Estado',
        required: false,
        type: 'enum',
        enumValues: ['Abierto', 'En proceso', 'Cerrado'],
        aliases: ['estado', 'status', 'situacion']
      }
    ],
    sampleRow: {
      codigoRegistro: 'AC-2026-0001',
      empresa: 'PERPOL',
      clasificacion: 'Acto Inseguro',
      fecha: '2026-01-20',
      area: 'Almacén de Materia Prima',
      lugarExacto: 'Zona de estantería pesada',
      trabajadorObservado: 'Pérez Vargas, Juan José',
      categoriaId: 'CAT-01',
      descripcion: 'Operador manipulando montacargas sin cinturón de seguridad abrochado.',
      potencialGravedad: 3,
      medidaCorrectiva: 'Reentrenamiento y amonestación preventiva según RIT.',
      responsableSeguimiento: 'Jefe de Almacén',
      estado: 'Cerrado'
    }
  },

  // 4. Consumo de Botiquín y Tópico
  botiquin: {
    moduleId: 'botiquin',
    moduleName: 'Módulo 4: Consumo de Botiquín',
    sheetName: 'SSOMA_Botiquin',
    primaryKey: 'codigoAtencion',
    fields: [
      {
        key: 'codigoAtencion',
        label: 'Código de Atención',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_atencion', 'cod_atencion', 'id_atencion', 'nro_atencion']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'fecha',
        label: 'Fecha de Atención',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_atencion', 'fec_atencion']
      },
      {
        key: 'hora',
        label: 'Hora de Atención',
        required: false,
        type: 'string',
        aliases: ['hora', 'hora_atencion']
      },
      {
        key: 'personaAtendida',
        label: 'Persona Atendida',
        required: true,
        type: 'string',
        aliases: ['persona', 'persona_atendida', 'paciente', 'colaborador', 'trabajador']
      },
      {
        key: 'dniPersona',
        label: 'DNI / Documento',
        required: true,
        type: 'string',
        preserveZeros: true,
        aliases: ['dni', 'dni_persona', 'documento', 'doc_identidad']
      },
      {
        key: 'puesto',
        label: 'Puesto de Trabajo',
        required: false,
        type: 'string',
        aliases: ['puesto', 'cargo', 'ocupacion']
      },
      {
        key: 'area',
        label: 'Área',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'departamento']
      },
      {
        key: 'tipoAtencion',
        label: 'Tipo de Atención Médica',
        required: true,
        type: 'enum',
        enumValues: ['Incidente', 'Accidente', 'Enfermedad común'],
        aliases: ['tipo_atencion', 'tipo_evento', 'diagnostico_inicial', 'motivo']
      },
      {
        key: 'lesionesSintomas',
        label: 'Lesiones o Síntomas',
        required: true,
        type: 'string',
        aliases: ['lesiones', 'sintomas', 'lesiones_sintomas', 'diagnostico']
      },
      {
        key: 'procedimiento',
        label: 'Procedimiento Aplicado',
        required: false,
        type: 'string',
        aliases: ['procedimiento', 'tratamiento', 'accion_tomada', 'cura']
      }
    ],
    sampleRow: {
      codigoAtencion: 'BOT-2026-0001',
      empresa: 'PERPOL',
      fecha: '2026-01-18',
      hora: '09:15',
      personaAtendida: 'Fernández Quispe, Luis Enrique',
      dniPersona: '47201934',
      puesto: 'Técnico de Mantenimiento',
      area: 'Mantenimiento Mecánico',
      tipoAtencion: 'Accidente',
      lesionesSintomas: 'Excoriación leve en antebrazo derecho por roce con chapa metálica.',
      procedimiento: 'Limpieza con clorhexidina al 2%, desinfección y colocación de apósito estéril.'
    }
  },

  // 6. Base de Trabajadores y Horas-Hombre
  trabajadores: {
    moduleId: 'trabajadores',
    moduleName: 'Módulo 6: Base de Trabajadores',
    sheetName: 'SSOMA_Trabajadores',
    primaryKey: 'dni',
    fields: [
      {
        key: 'dni',
        label: 'DNI / C.E.',
        required: true,
        type: 'string',
        preserveZeros: true,
        aliases: [
          'dni', 'c.e.', 'ce', 'dni / c.e.', 'dni/c.e.', 'dni / ce', 'dni_ce',
          'carne_extranjeria', 'carne_de_extranjeria', 'documento', 'doc_identidad',
          'num_doc', 'codigo', 'cedula'
        ]
      },
      {
        key: 'apellidosNombres',
        label: 'Apellidos y Nombres Completos',
        required: true,
        type: 'string',
        aliases: ['nombres', 'apellidos_nombres', 'trabajador', 'colaborador', 'nombre_completo']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede', 'cia']
      },
      {
        key: 'condicion',
        label: 'Condición Laboral',
        required: true,
        type: 'enum',
        enumValues: ['Activo', 'Inactivo', 'Cesado'],
        aliases: ['condicion', 'estado', 'status', 'situacion']
      },
      {
        key: 'sexo',
        label: 'Sexo (M / F)',
        required: false,
        type: 'enum',
        enumValues: ['M', 'F'],
        aliases: ['sexo', 'genero']
      },
      {
        key: 'fechaIngreso',
        label: 'Fecha de Ingreso',
        required: true,
        type: 'date',
        aliases: ['fecha_ingreso', 'fec_ingreso', 'ingreso', 'alta']
      },
      {
        key: 'fechaNacimiento',
        label: 'Fecha de Nacimiento',
        required: false,
        type: 'date',
        aliases: ['fecha_nacimiento', 'fec_nacimiento', 'nacimiento']
      },
      {
        key: 'puesto',
        label: 'Puesto de Trabajo',
        required: true,
        type: 'string',
        aliases: ['puesto', 'cargo', 'ocupacion', 'posicion']
      },
      {
        key: 'area',
        label: 'Área / Departamento',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'departamento', 'gerencia']
      },
      {
        key: 'telefono',
        label: 'Teléfono / Móvil',
        required: false,
        type: 'string',
        preserveZeros: true,
        aliases: ['telefono', 'celular', 'movil']
      },
      {
        key: 'correo',
        label: 'Correo Electrónico',
        required: false,
        type: 'string',
        aliases: ['correo', 'email', 'correo_corporativo']
      }
    ],
    sampleRow: {
      dni: '09876543',
      apellidosNombres: 'Alvarado Benítez, Manuel Alejandro',
      empresa: 'PERPOL',
      condicion: 'Activo',
      sexo: 'M',
      fechaIngreso: '2021-03-15',
      fechaNacimiento: '1988-06-22',
      puesto: 'Operario de Producción',
      area: 'Producción Quesos',
      telefono: '987654321',
      correo: 'malvarado@perpol.com.pe'
    }
  },

  // 7. Horas-Hombre (HH)
  horasHombre: {
    moduleId: 'horas-hombre',
    moduleName: 'Módulo 7: Horas-Hombre (HH)',
    sheetName: 'SSOMA_HorasHombre',
    primaryKey: 'id',
    fields: [
      {
        key: 'anio',
        label: 'Año (ej: 2026)',
        required: true,
        type: 'number',
        aliases: ['anio', 'año', 'year', 'periodo']
      },
      {
        key: 'mes',
        label: 'Mes (1 al 12)',
        required: true,
        type: 'number',
        aliases: ['mes', 'month', 'numero_mes']
      },
      {
        key: 'trabajadoresPerpol',
        label: 'N° Trabajadores PERPOL',
        required: true,
        type: 'number',
        aliases: ['trabajadores_perpol', 'personal_perpol', 'colaboradores_perpol']
      },
      {
        key: 'hhPerpol',
        label: 'Horas-Hombre (HH) PERPOL',
        required: true,
        type: 'number',
        aliases: ['hh_perpol', 'horas_perpol', 'hh_perpol_ideas']
      },
      {
        key: 'trabajadoresTr3',
        label: 'N° Trabajadores TR3',
        required: true,
        type: 'number',
        aliases: ['trabajadores_tr3', 'personal_tr3', 'colaboradores_tr3']
      },
      {
        key: 'hhTr3',
        label: 'Horas-Hombre (HH) TR3',
        required: true,
        type: 'number',
        aliases: ['hh_tr3', 'horas_tr3', 'hh_tr3_alimentos']
      }
    ],
    sampleRow: {
      anio: 2026,
      mes: 3,
      trabajadoresPerpol: 90,
      hhPerpol: 16200,
      trabajadoresTr3: 70,
      hhTr3: 12600
    }
  },

  // 7. Programa Anual SST
  'programa-anual': {
    moduleId: 'programa-anual',
    moduleName: 'Módulo 7: Programa Anual SST',
    sheetName: 'SSOMA_ProgramaAnual',
    primaryKey: 'numeroItem',
    fields: [
      {
        key: 'numeroItem',
        label: 'Número de Ítem',
        required: true,
        type: 'number',
        aliases: ['item', 'numero_item', 'nro_item', 'id', 'num']
      },
      {
        key: 'anio',
        label: 'Año del Programa',
        required: true,
        type: 'number',
        aliases: ['anio', 'ano', 'periodo', 'gestion']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'objetivoGeneral',
        label: 'Objetivo General',
        required: true,
        type: 'string',
        aliases: ['objetivo_general', 'objetivo', 'meta_estrategica']
      },
      {
        key: 'actividad',
        label: 'Actividad Específica',
        required: true,
        type: 'string',
        aliases: ['actividad', 'tarea', 'descripcion_actividad', 'accion']
      },
      {
        key: 'tipoActividad',
        label: 'Tipo de Actividad',
        required: false,
        type: 'enum',
        enumValues: ['Regular', 'A Demanda'],
        aliases: ['tipo', 'tipo_actividad', 'modalidad']
      },
      {
        key: 'responsable',
        label: 'Responsable de Ejecución',
        required: true,
        type: 'string',
        aliases: ['responsable', 'lider', 'asignado']
      },
      {
        key: 'metaPorcentaje',
        label: 'Meta Anual (%)',
        required: false,
        type: 'number',
        aliases: ['meta', 'meta_porcentaje', 'meta_%', 'porcentaje_meta']
      }
    ],
    sampleRow: {
      numeroItem: 1,
      anio: 2026,
      empresa: 'PERPOL',
      objetivoGeneral: 'Fortalecer la cultura preventiva y competencias en SST',
      actividad: 'Capacitación en Identificación de Peligros, Evaluación de Riesgos y Medidas de Control (IPERC)',
      tipoActividad: 'Regular',
      responsable: 'Supervisor SSOMA',
      metaPorcentaje: 100
    }
  },

  // 8. Estadísticas SST (Metas)
  estadisticas: {
    moduleId: 'estadisticas',
    moduleName: 'Módulo 8: Metas Anuales SST',
    sheetName: 'SSOMA_MetasSST',
    primaryKey: 'periodoAnio',
    fields: [
      {
        key: 'periodoAnio',
        label: 'Año de Gestión',
        required: true,
        type: 'number',
        aliases: ['anio', 'periodo', 'periodo_anio', 'gestion']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3', 'CONSOLIDADO'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'metaIF',
        label: 'Meta Índice de Frecuencia (IF)',
        required: true,
        type: 'number',
        aliases: ['meta_if', 'metaif', 'limite_if']
      },
      {
        key: 'metaIS',
        label: 'Meta Índice de Severidad (IS)',
        required: true,
        type: 'number',
        aliases: ['meta_is', 'metais', 'limite_is']
      },
      {
        key: 'metaIA',
        label: 'Meta Índice de Accidentabilidad (IA)',
        required: true,
        type: 'number',
        aliases: ['meta_ia', 'metaia', 'limite_ia']
      },
      {
        key: 'metaCumplimientoPrograma',
        label: 'Meta Cumplimiento Programa (%)',
        required: false,
        type: 'number',
        aliases: ['meta_cumplimiento', 'meta_programa', 'meta_prog']
      },
      {
        key: 'metaInspeccionesSubsanadas',
        label: 'Meta Subsanación Inspecciones (%)',
        required: false,
        type: 'number',
        aliases: ['meta_inspecciones', 'meta_subsanacion']
      }
    ],
    sampleRow: {
      periodoAnio: 2026,
      empresa: 'PERPOL',
      metaIF: 5.0,
      metaIS: 50.0,
      metaIA: 0.25,
      metaCumplimientoPrograma: 90,
      metaInspeccionesSubsanadas: 85
    }
  },

  // 9. Simulación de Costos de Incidentes
  'simulacion-costos': {
    moduleId: 'simulacion-costos',
    moduleName: 'Módulo 9: Simulación de Costos',
    sheetName: 'sst_simulacion_costos_incidentes',
    primaryKey: 'codigoSimulacion',
    fields: [
      {
        key: 'codigoSimulacion',
        label: 'Código de Simulación',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_simulacion', 'cod_simulacion', 'id_simulacion']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'fechaSimulacion',
        label: 'Fecha de Simulación',
        required: true,
        type: 'date',
        aliases: ['fecha', 'fecha_simulacion', 'fec_simulacion']
      },
      {
        key: 'area',
        label: 'Área',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'zona']
      },
      {
        key: 'descripcionEvento',
        label: 'Descripción del Escenario',
        required: true,
        type: 'string',
        aliases: ['descripcion', 'descripcion_evento', 'escenario', 'evento']
      },
      {
        key: 'probabilidadOcurrencia',
        label: 'Probabilidad (1 a 5)',
        required: true,
        type: 'number',
        aliases: ['probabilidad', 'prob', 'probabilidad_ocurrencia']
      },
      {
        key: 'consecuenciaPersonas',
        label: 'Consecuencia en Personas (1 a 5)',
        required: true,
        type: 'number',
        aliases: ['consecuencia_personas', 'personas', 'dano_personas']
      },
      {
        key: 'diasSimulados',
        label: 'Días de Descanso Simulados',
        required: false,
        type: 'number',
        aliases: ['dias_simulados', 'dias', 'descanso_simulado']
      },
      {
        key: 'remuneracionDiaria',
        label: 'Remuneración Diaria Promedio (S/)',
        required: false,
        type: 'number',
        aliases: ['remuneracion', 'remuneracion_diaria', 'sueldo_diario']
      },
      {
        key: 'costoRealIncurrido',
        label: 'Costo Real Incurrido (S/)',
        required: false,
        type: 'number',
        aliases: ['costo_real', 'costo_real_incurrido', 'gasto_real']
      }
    ],
    sampleRow: {
      codigoSimulacion: 'SIM-2026-0001',
      empresa: 'PERPOL',
      fechaSimulacion: '2026-02-15',
      area: 'Planta de Procesos',
      descripcionEvento: 'Caída de nivel por fuga de vapor sin válvula de purga.',
      probabilidadOcurrencia: 4,
      consecuenciaPersonas: 4,
      diasSimulados: 45,
      remuneracionDiaria: 85,
      costoRealIncurrido: 350
    }
  },

  // 10. Investigación de Accidentes e Incidentes
  investigacion: {
    moduleId: 'investigacion',
    moduleName: 'Módulo 10: Investigación de Accidentes',
    sheetName: 'SSOMA_Investigaciones',
    primaryKey: 'codigoInvestigacion',
    requiresMasterValidation: true,
    masterValidationField: 'accidenteId',
    masterValidationMessage: 'El ID de Accidente (accidenteId) debe existir previamente en el Módulo 1 para no crear investigaciones huérfanas.',
    fields: [
      {
        key: 'codigoInvestigacion',
        label: 'Código de Investigación',
        required: true,
        type: 'string',
        aliases: ['codigo', 'codigo_investigacion', 'cod_investigacion', 'id_investigacion']
      },
      {
        key: 'accidenteId',
        label: 'ID de Caso Accidente (ACC-...)',
        required: true,
        type: 'string',
        aliases: ['accidente_id', 'caso_id', 'codigo_caso', 'accidente', 'id_accidente']
      },
      {
        key: 'empresa',
        label: 'Empresa',
        required: true,
        type: 'enum',
        enumValues: ['PERPOL', 'TR3'],
        aliases: ['empresa', 'compania', 'sede']
      },
      {
        key: 'fechaInvestigacion',
        label: 'Fecha de Investigación',
        required: true,
        type: 'date',
        aliases: ['fecha_investigacion', 'fec_investigacion']
      },
      {
        key: 'fechaAccidente',
        label: 'Fecha del Accidente',
        required: true,
        type: 'date',
        aliases: ['fecha_accidente', 'fec_accidente']
      },
      {
        key: 'area',
        label: 'Área',
        required: true,
        type: 'string',
        aliases: ['area', 'seccion', 'zona']
      },
      {
        key: 'tipoContacto',
        label: 'Tipo de Contacto Normativo',
        required: true,
        type: 'string',
        aliases: ['tipo_contacto', 'contacto', 'forma_accidente']
      },
      {
        key: 'agenteCausante',
        label: 'Agente Causante',
        required: true,
        type: 'string',
        aliases: ['agente', 'agente_causante', 'objeto_lesion']
      },
      {
        key: 'causaRaizMetodo',
        label: 'Método Causa Raíz',
        required: false,
        type: 'enum',
        enumValues: ['5 Porqués', 'Ishikawa'],
        aliases: ['metodo', 'causa_raiz_metodo', 'metodologia']
      },
      {
        key: 'analisisCausaRaiz',
        label: 'Análisis de Causa Raíz',
        required: false,
        type: 'string',
        aliases: ['analisis', 'analisis_causa_raiz', 'porques']
      },
      {
        key: 'conclusionCausaRaiz',
        label: 'Conclusión Causal',
        required: false,
        type: 'string',
        aliases: ['conclusion', 'conclusion_causa_raiz', 'causa_raiz']
      },
      {
        key: 'estado',
        label: 'Estado de Investigación',
        required: false,
        type: 'enum',
        enumValues: ['Borrador', 'En revisión', 'En revision', 'Cerrada'],
        aliases: ['estado', 'status', 'situacion']
      }
    ],
    sampleRow: {
      codigoInvestigacion: 'INV-2026-0001',
      accidenteId: 'ACC-2026-0001',
      empresa: 'PERPOL',
      fechaInvestigacion: '2026-02-12',
      fechaAccidente: '2026-02-10',
      area: 'Línea de Envasado L-2',
      tipoContacto: 'Golpeado por',
      agenteCausante: 'Guía metálica de faja transportadora',
      causaRaizMetodo: '5 Porqués',
      analisisCausaRaiz: '1. ¿Por qué ocurrió? Operario rozó guía metálica suelta. 2. ¿Por qué estaba suelta? Falta de perno de anclaje tras cambio de formato.',
      conclusionCausaRaiz: 'Falta de procedimiento estandarizado de verificación pre-operativa tras cambios de formato.',
      estado: 'Cerrada'
    }
  }
};
