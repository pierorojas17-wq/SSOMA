import * as XLSX from 'xlsx';
export * from './csvImporter';
export * from './excelImporter';
export * from './validator';

export function downloadTemplate(
  headers: string[],
  fileName: string,
  sampleRow?: Record<string, unknown>,
  sheetTitle = 'Plantilla_SSOMA'
): void {
  const wsData: (string | number | boolean | null)[][] = [headers];

  if (sampleRow) {
    const row = headers.map((h) => {
      const val = sampleRow[h];
      if (typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean') {
        return val;
      }
      return val ? String(val) : '';
    });
    wsData.push(row);
  }

  const ws = XLSX.utils.aoa_to_sheet(wsData);
  ws['!cols'] = headers.map(() => ({ wch: 24 }));

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetTitle.substring(0, 31));
  XLSX.writeFile(wb, `${fileName}_Plantilla.xlsx`);
}
