import Papa from 'papaparse';

export interface ParseResult<T = Record<string, unknown>> {
  headers: string[];
  rows: T[];
  totalRows: number;
  fileName: string;
  sheetName?: string;
}

export function parseCsv(file: File): Promise<ParseResult> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: 'greedy',
      dynamicTyping: false,
      complete: (results) => {
        const rawHeaders = (results.meta.fields || []).map((h) => h.trim());
        const cleanHeaders = rawHeaders.filter((h) => h.length > 0);

        const rows = (results.data as Record<string, unknown>[]).filter((row) =>
          Object.values(row).some((val) => val !== null && val !== undefined && String(val).trim() !== '')
        );

        resolve({
          headers: cleanHeaders,
          rows,
          totalRows: rows.length,
          fileName: file.name,
          sheetName: 'CSV'
        });
      },
      error: (err) => reject(new Error('Error al procesar CSV con PapaParse: ' + err.message))
    });
  });
}
