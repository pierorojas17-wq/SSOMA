/**
 * Validaciones comunes de importación de datos
 */

export function validateRequiredHeaders(headers: string[], required: string[]): { valid: boolean; missing: string[] } {
  const normalizedHeaders = headers.map(h => h.trim().toLowerCase());
  const missing = required.filter(req => !normalizedHeaders.includes(req.toLowerCase()));
  return {
    valid: missing.length === 0,
    missing
  };
}

export function chunkArray<T>(items: T[], chunkSize = 50): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    chunks.push(items.slice(i, i + chunkSize));
  }
  return chunks;
}
