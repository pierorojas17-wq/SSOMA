import * as XLSX from 'xlsx';
import { ParseResult } from './csvImporter';

export interface SpreadsheetInfo {
  sheetNames: string[];
  selectedSheet: string;
  isExcel: boolean;
  fileName: string;
  fileSize: number;
}

export function inspectFile(file: File): Promise<SpreadsheetInfo> {
  const extension = file.name.split('.').pop()?.toLowerCase();
  const isExcel = extension === 'xlsx' || extension === 'xls';

  if (!isExcel && extension !== 'csv') {
    throw new Error(
      'Formato no compatible. Por favor cargue un archivo con extensión .xlsx, .xls o .csv'
    );
  }

  if (!isExcel) {
    return Promise.resolve({
      sheetNames: ['CSV'],
      selectedSheet: 'CSV',
      isExcel: false,
      fileName: file.name,
      fileSize: file.size
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array', bookSheets: true });
        const sheetNames = workbook.SheetNames || [];

        if (sheetNames.length === 0) {
          throw new Error('El archivo Excel no contiene ninguna hoja de cálculo.');
        }

        resolve({
          sheetNames,
          selectedSheet: sheetNames[0],
          isExcel: true,
          fileName: file.name,
          fileSize: file.size
        });
      } catch (err) {
        reject(new Error('No se pudo inspeccionar el archivo Excel: ' + (err instanceof Error ? err.message : String(err))));
      }
    };
    reader.onerror = () => reject(new Error('Error de lectura en el archivo.'));
    reader.readAsArrayBuffer(file);
  });
}

export function parseExcelSheet(file: File, targetSheetName?: string): Promise<ParseResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, {
          type: 'array',
          cellDates: true,
          cellText: true
        });

        const sheetToRead = targetSheetName && workbook.Sheets[targetSheetName]
          ? targetSheetName
          : workbook.SheetNames[0];

        if (!sheetToRead || !workbook.Sheets[sheetToRead]) {
          throw new Error(`La hoja de cálculo '${targetSheetName || 'predeterminada'}' no existe en el archivo.`);
        }

        const worksheet = workbook.Sheets[sheetToRead];

        const rawJson = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, {
          defval: '',
          raw: false
        });

        if (rawJson.length === 0) {
          resolve({
            headers: [],
            rows: [],
            totalRows: 0,
            fileName: file.name,
            sheetName: sheetToRead
          });
          return;
        }

        const rawHeaders = Object.keys(rawJson[0]).map((h) => h.trim());
        const cleanHeaders = rawHeaders.filter((h) => h.length > 0);

        resolve({
          headers: cleanHeaders,
          rows: rawJson,
          totalRows: rawJson.length,
          fileName: file.name,
          sheetName: sheetToRead
        });
      } catch (err: unknown) {
        reject(new Error('Error al leer hoja Excel: ' + (err instanceof Error ? err.message : String(err))));
      }
    };

    reader.onerror = () => reject(new Error('No se pudo leer el archivo seleccionado.'));
    reader.readAsArrayBuffer(file);
  });
}
