import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAntiCacheUrl,
  getCorsSafeAntiCacheHeaders,
  applyAntiCacheToPayload,
  SERVER_ANTI_CACHE_HEADERS
} from '../antiCache';

describe('Anti-Caché Compatible con CORS Suite', () => {
  describe('buildAntiCacheUrl', () => {
    it('debe agregar parámetros de timestamp y nonce a una URL limpia', () => {
      const url = 'https://script.google.com/macros/s/ABC/exec';
      const antiCacheUrl = buildAntiCacheUrl(url);

      assert.ok(antiCacheUrl.startsWith(url + '?_t='));
      assert.ok(antiCacheUrl.includes('&_cb='));

      const urlObj = new URL(antiCacheUrl);
      const timestamp = urlObj.searchParams.get('_t');
      const nonce = urlObj.searchParams.get('_cb');

      assert.ok(timestamp !== null && !isNaN(Number(timestamp)));
      assert.ok(nonce !== null && nonce.length > 0);
    });

    it('debe respetar y concatenar con & si la URL ya posee parámetros existentes', () => {
      const url = 'https://script.google.com/macros/s/ABC/exec?action=sync&module=accidentes';
      const antiCacheUrl = buildAntiCacheUrl(url);

      assert.ok(antiCacheUrl.startsWith(url + '&_t='));
      assert.ok(antiCacheUrl.includes('&_cb='));

      const urlObj = new URL(antiCacheUrl);
      assert.equal(urlObj.searchParams.get('action'), 'sync');
      assert.equal(urlObj.searchParams.get('module'), 'accidentes');
      assert.ok(urlObj.searchParams.get('_t') !== null);
      assert.ok(urlObj.searchParams.get('_cb') !== null);
    });

    it('debe preservar el fragmento de hash (#) al final de la URL', () => {
      const url = '/api/gas#tab-preview';
      const antiCacheUrl = buildAntiCacheUrl(url);

      assert.ok(antiCacheUrl.startsWith('/api/gas?_t='));
      assert.ok(antiCacheUrl.endsWith('#tab-preview'));
    });

    it('genera marcas de tiempo o nonces únicos en llamadas consecutivas', () => {
      const url = '/api/gas';
      const url1 = buildAntiCacheUrl(url);
      const url2 = buildAntiCacheUrl(url);

      assert.notEqual(url1, url2);
    });
  });

  describe('getCorsSafeAntiCacheHeaders', () => {
    it('NUNCA debe incluir Cache-Control, Pragma o Expires cuando isDirectCors es true', () => {
      // Direct CORS a Google Apps Script: no debe disparar OPTIONS preflight
      const headers = getCorsSafeAntiCacheHeaders(true);

      assert.equal(headers['Cache-Control'], undefined);
      assert.equal(headers['Pragma'], undefined);
      assert.equal(headers['Expires'], undefined);
      assert.equal(headers['Content-Type'], 'text/plain;charset=utf-8');
    });

    it('debe incluir cabeceras completas Anti-Caché cuando isDirectCors es false (Proxy/Same-origin)', () => {
      const headers = getCorsSafeAntiCacheHeaders(false);

      assert.equal(headers['Content-Type'], 'application/json');
      assert.ok(headers['Cache-Control']?.includes('no-store'));
      assert.ok(headers['Cache-Control']?.includes('no-cache'));
      assert.equal(headers['Pragma'], 'no-cache');
      assert.equal(headers['Expires'], '0');
    });
  });

  describe('applyAntiCacheToPayload', () => {
    it('debe inyectar _timestamp y _nonce en el payload sin mutar el objeto original', () => {
      const originalPayload = { action: 'guardarRegistro', tabla: 'accidentes' };
      const antiCachePayload = applyAntiCacheToPayload(originalPayload);

      assert.equal(antiCachePayload.action, 'guardarRegistro');
      assert.equal(antiCachePayload.tabla, 'accidentes');
      assert.ok(typeof antiCachePayload._timestamp === 'number');
      assert.ok(typeof antiCachePayload._nonce === 'string');

      // Inmutabilidad
      assert.equal((originalPayload as any)._timestamp, undefined);
    });
  });

  describe('SERVER_ANTI_CACHE_HEADERS', () => {
    it('debe contener directivas estrictas para respuestas del servidor Express', () => {
      assert.ok(SERVER_ANTI_CACHE_HEADERS['Cache-Control']?.includes('no-store'));
      assert.ok(SERVER_ANTI_CACHE_HEADERS['Cache-Control']?.includes('no-cache'));
      assert.ok(SERVER_ANTI_CACHE_HEADERS['Cache-Control']?.includes('must-revalidate'));
      assert.equal(SERVER_ANTI_CACHE_HEADERS['Pragma'], 'no-cache');
      assert.equal(SERVER_ANTI_CACHE_HEADERS['Expires'], '0');
      assert.equal(SERVER_ANTI_CACHE_HEADERS['Surrogate-Control'], 'no-store');
    });
  });
});
