/**
 * Re-exportación de utilidades de importación masiva para compatibilidad
 */
import { inspectFile, parseExcelSheet, SpreadsheetInfo } from './import/excelImporter';
import { parseCsv, ParseResult } from './import/csvImporter';
import { downloadTemplate, chunkArray } from './import';

export * from './import';

export class BulkDataImporter {
  public static inspectFile = inspectFile;
  public static parseFileSheet(file: File, sheetName?: string): Promise<ParseResult> {
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (extension === 'csv') {
      return parseCsv(file);
    } else if (extension === 'xlsx' || extension === 'xls') {
      return parseExcelSheet(file, sheetName);
    } else {
      throw new Error('Formato de archivo no compatible (.xlsx, .xls o .csv)');
    }
  }
  public static downloadTemplate = downloadTemplate;
  public static chunkArray = chunkArray;
}
