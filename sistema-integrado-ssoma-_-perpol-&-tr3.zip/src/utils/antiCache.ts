/**
 * Utilidades de Anti-Caché 100% compatibles con CORS
 *
 * CRÍTICO PARA INTEGRACIONES CON GOOGLE APPS SCRIPT (GAS):
 * - En llamadas cross-origin directas a GAS (script.google.com), agregar cabeceras
 *   como 'Cache-Control' o 'Pragma' dispara una petición preflight HTTP OPTIONS.
 * - Google Apps Script NO soporta OPTIONS preflight y falla con error CORS en el navegador.
 * - Esta utilidad implementa la estrategia de Anti-Caché de doble nivel:
 *   1. Anti-Caché por Query Params (Timestamp + Nonce): Totalmente seguro para CORS,
 *      no dispara preflight OPTIONS y garantiza que ni el navegador ni CDNs intermedias
 *      sirvan respuestas cacheadas o redirecciones 302 obsoletas.
 *   2. Anti-Caché en Payload: Inyecta metadatos temporales únicos en el cuerpo POST.
 *   3. Cabeceras estrictas Anti-Caché solo cuando se navega a través de Same-Origin/Proxy.
 */

/**
 * Añade parámetros de consulta anti-caché (_t y _cb) a cualquier URL.
 * Funciona de forma transparente tanto con URLs relativas (/api/gas)
 * como con URLs absolutas (https://script.google.com/...).
 * 
 * NUNCA DISPARA PREFLIGHT CORS porque no altera las cabeceras HTTP de la petición.
 */
export function buildAntiCacheUrl(url: string, paramPrefix: string = '_t'): string {
  if (!url || typeof url !== 'string') return url;

  const timestamp = Date.now();
  const nonce = Math.random().toString(36).substring(2, 9);
  const cacheQuery = `${paramPrefix}=${timestamp}&_cb=${nonce}`;

  const hashIndex = url.indexOf('#');
  let baseUrl = url;
  let hashPart = '';

  if (hashIndex !== -1) {
    baseUrl = url.substring(0, hashIndex);
    hashPart = url.substring(hashIndex);
  }

  const separator = baseUrl.includes('?') ? '&' : '?';
  return `${baseUrl}${separator}${cacheQuery}${hashPart}`;
}

/**
 * Retorna las cabeceras HTTP adecuadas respetando las reglas de CORS.
 *
 * @param isDirectCors - Si es true (petición directa al script de Google sin proxy),
 *                       NO debe incluir 'Cache-Control' ni 'Pragma' para evitar
 *                       el preflight OPTIONS que Google Apps Script rechaza.
 *                       Si es false (petición local o al proxy Express),
 *                       retorna el set completo de directivas anti-caché.
 */
export function getCorsSafeAntiCacheHeaders(isDirectCors: boolean = false): Record<string, string> {
  if (isDirectCors) {
    // Solo cabeceras seguras (CORS Safelisted Headers)
    // El anti-caché en este caso se garantiza vía URL query params y payload.
    return {
      'Content-Type': 'text/plain;charset=utf-8'
    };
  }

  // Para el proxy /api/gas o endpoints internos
  return {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
    'Pragma': 'no-cache',
    'Expires': '0'
  };
}

/**
 * Inyecta una marca de tiempo y un identificador aleatorio en el payload
 * para forzar que el cuerpo de la petición sea único, previniendo caché
 * a nivel de proxy o HTTP POST caching en navegadores que lo soporten.
 */
export function applyAntiCacheToPayload<T extends object>(payload: T): T & {
  _timestamp: number;
  _nonce: string;
} {
  return {
    ...payload,
    _timestamp: Date.now(),
    _nonce: Math.random().toString(36).substring(2, 9)
  };
}

/**
 * Cabeceras estándar que el servidor Express debe enviar en respuestas HTTP
 * para forzar a los clientes y proxies a no almacenar en caché las respuestas.
 */
export const SERVER_ANTI_CACHE_HEADERS: Record<string, string> = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
  'Pragma': 'no-cache',
  'Expires': '0',
  'Surrogate-Control': 'no-store'
};
