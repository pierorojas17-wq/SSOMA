/**
 * Pruebas unitarias para Seguridad (PINs) y Validación en tiempo de ejecución (Zod).
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PIN_CONFIG, isValidAdminPin, isValidSyncPin } from '../../../config/secrets';
import {
  validateTrabajador,
  validateAccidente,
  validateHorasHombre,
  TrabajadorSchema
} from '../schemas';

describe('7.1 Seguridad y Autorización de Códigos PIN', () => {
  it('debe tener configurado el PIN por defecto o desde entorno', () => {
    assert.ok(PIN_CONFIG.ADMIN);
    assert.ok(PIN_CONFIG.SYNC);
    assert.strictEqual(typeof PIN_CONFIG.ADMIN, 'string');
    assert.strictEqual(typeof PIN_CONFIG.SYNC, 'string');
  });

  it('debe validar exitosamente el PIN administrativo correcto', () => {
    assert.strictEqual(isValidAdminPin(PIN_CONFIG.ADMIN), true);
    assert.strictEqual(isValidAdminPin('999999'), false);
    assert.strictEqual(isValidAdminPin(''), false);
    assert.strictEqual(isValidAdminPin(null), false);
  });

  it('debe validar exitosamente el PIN de sincronización', () => {
    assert.strictEqual(isValidSyncPin(PIN_CONFIG.SYNC), true);
    assert.strictEqual(isValidSyncPin('0000'), false);
    assert.strictEqual(isValidSyncPin(undefined), false);
  });
});

describe('7.3 Validación Robusta con Esquemas Zod', () => {
  it('debe validar un trabajador con datos conformes', () => {
    const validWorker = {
      dni: '12345678',
      apellidosNombres: 'Pérez Gómez, Juan Carlos',
      empresa: 'PERPOL',
      area: 'Planta de Operaciones',
      puesto: 'Operador de Montacargas',
      correo: 'juan.perez@empresa.com',
      telefono: '987654321',
      estado: 'Activo'
    };

    const result = validateTrabajador(validWorker);
    assert.strictEqual(result.success, true);
    if (result.success) {
      assert.strictEqual(result.data.dni, '12345678');
      assert.strictEqual(result.data.empresa, 'PERPOL');
    }
  });

  it('debe rechazar DNI con longitud menor a 8 o caracteres no numéricos', () => {
    const invalidWorker = {
      dni: '12345', // 5 dígitos
      apellidosNombres: 'Ana Torres',
      empresa: 'TR3',
      area: 'Almacén',
      puesto: 'Asistente'
    };

    const result = validateTrabajador(invalidWorker);
    assert.strictEqual(result.success, false);
    if (!result.success) {
      assert.ok(result.errors.dni, 'Debe haber un error en el campo DNI');
    }
  });

  it('debe rechazar correo electrónico con sintaxis inválida', () => {
    const invalidEmailWorker = {
      dni: '87654321',
      apellidosNombres: 'Carlos Santana',
      empresa: 'PERPOL',
      area: 'Mantenimiento',
      puesto: 'Técnico',
      correo: 'correo-sin-arroba'
    };

    const result = validateTrabajador(invalidEmailWorker);
    assert.strictEqual(result.success, false);
    if (!result.success) {
      assert.ok(result.errors.correo, 'Debe haber un error en el campo correo');
    }
  });

  it('debe validar horas-hombre trabajadas con formato de mes AAAA-MM', () => {
    const validHHT = {
      empresa: 'PERPOL',
      mes: '2026-03',
      horasHombreTrabajadas: 24500,
      numTrabajadores: 110
    };

    const result = validateHorasHombre(validHHT);
    assert.strictEqual(result.success, true);

    const invalidMesHHT = {
      empresa: 'PERPOL',
      mes: '03-2026', // Formato invertido
      horasHombreTrabajadas: 100,
      numTrabajadores: 5
    };
    const invalidResult = validateHorasHombre(invalidMesHHT);
    assert.strictEqual(invalidResult.success, false);
  });
});
