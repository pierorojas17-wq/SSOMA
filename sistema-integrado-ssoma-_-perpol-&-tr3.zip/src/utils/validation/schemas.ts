import { z } from 'zod';

/**
 * Esquemas de validación en tiempo de ejecución con Zod
 * para el Sistema Integrado SSOMA (Seguridad, Salud Ocupacional y Medio Ambiente).
 * Garantiza integridad de datos ante entradas manuales, importaciones y APIs externas.
 */

// 1. Trabajador Schema
export const TrabajadorSchema = z.object({
  id: z.string().optional(),
  dni: z.string()
    .regex(/^\d{8}$/, 'DNI debe ser exactamente 8 dígitos')
    .or(z.string().regex(/^[a-zA-Z0-9]{9,12}$/, 'Carnet de extranjería o pasaporte debe tener entre 9 y 12 caracteres')),
  apellidosNombres: z.string().min(3, 'Nombre completo debe tener al menos 3 caracteres').max(120, 'Nombre excede límite'),
  empresa: z.enum(['PERPOL', 'TR3']).or(z.string().min(1, 'Empresa es requerida')),
  sede: z.string().optional().default('Principal'),
  area: z.string().min(1, 'El área de trabajo es requerida'),
  puesto: z.string().min(1, 'El puesto de trabajo es requerido'),
  correo: z.string().email('Formato de correo electrónico inválido').optional().or(z.literal('')),
  telefono: z.string().regex(/^\d{7,9}$/, 'El teléfono debe contener entre 7 y 9 dígitos numéricos').optional().or(z.literal('')),
  tipoContrato: z.string().optional().default('Plazo Fijo'),
  fechaIngreso: z.string().optional().default(''),
  fechaNacimiento: z.string().optional().default(''),
  genero: z.enum(['M', 'F', 'Otro']).optional().default('M'),
  estado: z.enum(['Activo', 'Cesado', 'Licencia']).default('Activo')
});

export type TrabajadorFormData = z.infer<typeof TrabajadorSchema>;

// 2. Accidente / Incidente Schema
export const AccidenteSchema = z.object({
  id: z.string().optional(),
  codigoCaso: z.string().min(1, 'El código de caso es obligatorio'),
  fecha: z.string().min(4, 'Fecha inválida'),
  hora: z.string().optional().default(''),
  empresa: z.string().min(1, 'La empresa es requerida'),
  sede: z.string().optional().default(''),
  area: z.string().min(1, 'El área es requerida'),
  lugarExacto: z.string().optional().default(''),
  tipoEvento: z.enum(['Accidente Leve', 'Accidente Incapacitante', 'Accidente Mortal', 'Incidente Peligroso', 'Incidente']),
  clasificacion: z.string().optional().default(''),
  potencialDanio: z.enum(['Bajo', 'Medio', 'Alto', 'Crítico']).optional().default('Bajo'),
  trabajadorDni: z.string().regex(/^\d{8}$/, 'DNI debe constar de 8 dígitos numéricos').or(z.literal('')),
  trabajadorNombre: z.string().min(1, 'Nombre del trabajador es requerido'),
  puestoTrabajo: z.string().optional().default(''),
  tipoContrato: z.string().optional().default(''),
  edad: z.number().nonnegative().optional().default(0),
  antiguedadPuesto: z.string().optional().default(''),
  parteCuerpoAfectada: z.string().optional().default(''),
  naturalezaLesion: z.string().optional().default(''),
  agenteCausante: z.string().optional().default(''),
  descripcionHechos: z.string().min(5, 'La descripción de los hechos debe tener al menos 5 caracteres'),
  diasPerdidos: z.number().min(0).default(0),
  diasCargados: z.number().min(0).default(0),
  estadoCaso: z.enum(['Abierto', 'En Investigación', 'Cerrado', 'Pendiente Validación']).default('Abierto'),
  costoDirectoEstimado: z.number().min(0).default(0),
  costoIndirectoEstimado: z.number().min(0).default(0),
  medidasCorrectivas: z.string().optional().default(''),
  responsableInvestigacion: z.string().optional().default(''),
  fechaCierre: z.string().optional().default('')
});

export type AccidenteFormData = z.infer<typeof AccidenteSchema>;

// 3. Atención Médica / Botiquín Schema
export const AtencionMedicaSchema = z.object({
  id: z.string().optional(),
  codigo: z.string().min(1, 'El código es obligatorio'),
  fecha: z.string().min(4, 'Fecha inválida'),
  hora: z.string().optional().default(''),
  empresa: z.string().min(1, 'La empresa es requerida'),
  sede: z.string().optional().default(''),
  trabajadorDni: z.string().regex(/^\d{8}$/, 'DNI debe tener 8 dígitos').or(z.literal('')),
  trabajadorNombre: z.string().min(1, 'El nombre es obligatorio'),
  area: z.string().min(1, 'El área es requerida'),
  puesto: z.string().optional().default(''),
  motivoConsulta: z.enum(['Accidente de Trabajo', 'Enfermedad Común', 'Evaluación Preventiva', 'Primeros Auxilios', 'Curación', 'Otro']),
  sintomasDiagnostico: z.string().min(3, 'Diagnóstico o síntomas requeridos'),
  tratamientoBrindado: z.string().min(2, 'Tratamiento brindado requerido'),
  medicamentosInsumos: z.string().optional().default(''),
  requiereDescanso: z.boolean().default(false),
  diasDescanso: z.number().min(0).default(0),
  derivadoA: z.string().optional().default(''),
  atendidoPor: z.string().min(1, 'Profesional de salud requerido'),
  observaciones: z.string().optional().default(''),
  estado: z.enum(['Atendido', 'En Observación', 'Derivado', 'Alta']).default('Atendido')
});

export type AtencionMedicaFormData = z.infer<typeof AtencionMedicaSchema>;

// 4. Investigación de Accidente Schema
export const InvestigacionSchema = z.object({
  id: z.string().optional(),
  codigoInvestigacion: z.string().min(1, 'Código de investigación obligatorio'),
  codigoCasoAccidente: z.string().min(1, 'Caso de accidente vinculado requerido'),
  fechaInvestigacion: z.string().min(4, 'Fecha de investigación requerida'),
  liderInvestigador: z.string().min(1, 'Líder investigador requerido'),
  equipoInvestigador: z.string().optional().default(''),
  metodologia: z.enum(['5 Porqués', 'Ishikawa / Causa-Efecto', 'Árbol de Causas', 'ICAM', 'SCAT']).default('5 Porqués'),
  actosInseguros: z.string().optional().default(''),
  condicionesInseguras: z.string().optional().default(''),
  factoresPersonales: z.string().optional().default(''),
  factoresTrabajo: z.string().optional().default(''),
  causasInmediatas: z.string().optional().default(''),
  causasBasicas: z.string().optional().default(''),
  faltaControl: z.string().optional().default(''),
  conclusiones: z.string().min(5, 'Conclusiones mínimas requeridas'),
  planAccion: z.string().min(5, 'Plan de acción requerido'),
  estado: z.enum(['Borrador', 'En Revisión', 'Aprobado', 'Implementado']).default('Borrador')
});

export type InvestigacionFormData = z.infer<typeof InvestigacionSchema>;

// 5. Inspección Schema
export const InspeccionSchema = z.object({
  id: z.string().optional(),
  codigo: z.string().min(1, 'Código de inspección requerido'),
  fecha: z.string().min(4, 'Fecha requerida'),
  empresa: z.string().min(1, 'Empresa requerida'),
  sede: z.string().optional().default(''),
  area: z.string().min(1, 'Área requerida'),
  tipoInspeccion: z.enum(['Planeada', 'No Planeada', 'EPP', 'Extintores', 'Orden y Limpieza', 'Botiquines', 'Herramientas', 'Ergonómica']),
  inspectorNombre: z.string().min(1, 'Nombre del inspector requerido'),
  hallazgos: z.string().optional().default(''),
  nivelRiesgo: z.enum(['Bajo', 'Medio', 'Alto', 'Crítico']).default('Bajo'),
  estado: z.enum(['Abierto', 'En Proceso', 'Cerrado']).default('Abierto'),
  porcentajeCumplimiento: z.number().min(0).max(100).default(100)
});

export type InspeccionFormData = z.infer<typeof InspeccionSchema>;

// 6. Actos y Condiciones Inseguras Schema
export const ActoCondicionSchema = z.object({
  id: z.string().optional(),
  codigo: z.string().min(1, 'Código requerido'),
  empresa: z.string().min(1, 'Empresa requerida'),
  sede: z.string().optional().default(''),
  area: z.string().min(1, 'Área requerida'),
  fecha: z.string().min(4, 'Fecha requerida'),
  tipoRegistro: z.enum(['Acto Inseguro', 'Condición Insegura']),
  clasificacionRiesgo: z.enum(['Bajo', 'Medio', 'Alto', 'Crítico']).default('Medio'),
  descripcion: z.string().min(4, 'Descripción del hallazgo requerida'),
  reportadoPor: z.string().optional().default(''),
  responsableCorreccion: z.string().optional().default(''),
  medidaInmediata: z.string().optional().default(''),
  estado: z.enum(['Abierto', 'En Proceso', 'Cerrado']).default('Abierto')
});

export type ActoCondicionFormData = z.infer<typeof ActoCondicionSchema>;

// 7. Horas-Hombre Trabajadas (HHT) Schema
export const HorasHombreSchema = z.object({
  id: z.string().optional(),
  empresa: z.enum(['PERPOL', 'TR3']).or(z.string().min(1)),
  mes: z.string().regex(/^\d{4}-\d{2}$/, 'Formato de mes debe ser AAAA-MM'),
  horasHombreTrabajadas: z.number().min(0, 'Las horas trabajadas deben ser mayores o iguales a 0'),
  numTrabajadores: z.number().min(0, 'El número de trabajadores debe ser mayor o igual a 0'),
  diasTrabajadosMes: z.number().min(0).max(31).optional().default(30),
  observaciones: z.string().optional().default('')
});

export type HorasHombreFormData = z.infer<typeof HorasHombreSchema>;

// 8. Simulación de Costos Schema
export const SimulacionCostosSchema = z.object({
  id: z.string().optional(),
  codigo: z.string().min(1, 'Código requerido'),
  empresa: z.string().min(1, 'Empresa requerida'),
  fecha: z.string().min(4, 'Fecha requerida'),
  descripcionEscenario: z.string().min(3, 'Descripción de escenario requerida'),
  probabilidadOcurrencia: z.number().min(0).max(100).default(10),
  costoDirectoTotal: z.number().min(0).default(0),
  costoIndirectoTotal: z.number().min(0).default(0),
  costoTotalEstimado: z.number().min(0).default(0),
  ahorroEstimadoPrevencion: z.number().min(0).default(0),
  retornoInversionROI: z.number().default(0)
});

export type SimulacionCostosFormData = z.infer<typeof SimulacionCostosSchema>;

/**
 * Función genérica y segura para validar datos con un esquema Zod.
 */
export function validateWithSchema<T>(
  schema: z.ZodSchema<T>,
  data: unknown
): { success: true; data: T } | { success: false; errors: Record<string, string> } {
  const result = schema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  const errors: Record<string, string> = {};
  result.error.issues.forEach((issue) => {
    const path = issue.path.join('.');
    errors[path] = issue.message;
  });
  return { success: false, errors };
}

/**
 * Validadores funcionales rápidos con tipado estricto
 */
export const validateTrabajador = (data: unknown) => validateWithSchema(TrabajadorSchema, data);
export const validateAccidente = (data: unknown) => validateWithSchema(AccidenteSchema, data);
export const validateAtencionMedica = (data: unknown) => validateWithSchema(AtencionMedicaSchema, data);
export const validateInvestigacion = (data: unknown) => validateWithSchema(InvestigacionSchema, data);
export const validateInspeccion = (data: unknown) => validateWithSchema(InspeccionSchema, data);
export const validateActoCondicion = (data: unknown) => validateWithSchema(ActoCondicionSchema, data);
export const validateHorasHombre = (data: unknown) => validateWithSchema(HorasHombreSchema, data);
export const validateSimulacionCostos = (data: unknown) => validateWithSchema(SimulacionCostosSchema, data);
