/**
 * Utilidades para formateo de fechas
 */

export function formatDate(isoOrDateString?: string | null, fallback = '-'): string {
  if (!isoOrDateString) return fallback;
  try {
    const clean = String(isoOrDateString).slice(0, 10);
    const parts = clean.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    const d = new Date(isoOrDateString);
    if (isNaN(d.getTime())) return fallback;
    return d.toLocaleDateString('es-PE', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch {
    return fallback;
  }
}

export function formatDateTime(isoOrDateString?: string | null, fallback = '-'): string {
  if (!isoOrDateString) return fallback;
  try {
    const d = new Date(isoOrDateString);
    if (isNaN(d.getTime())) return fallback;
    return d.toLocaleString('es-PE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return fallback;
  }
}

export function getTodayDateString(): string {
  return new Date().toISOString().slice(0, 10);
}
