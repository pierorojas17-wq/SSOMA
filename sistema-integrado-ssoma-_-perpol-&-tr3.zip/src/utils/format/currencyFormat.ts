/**
 * Utilidades para formateo de moneda (Soles PEN / Dólares USD)
 */

export function formatCurrencyPEN(amount?: number | null, decimals = 2): string {
  const val = Number(amount) || 0;
  return `S/ ${val.toLocaleString('es-PE', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}`;
}

export function formatCurrencyUSD(amount?: number | null, decimals = 2): string {
  const val = Number(amount) || 0;
  return `$ ${val.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}`;
}
