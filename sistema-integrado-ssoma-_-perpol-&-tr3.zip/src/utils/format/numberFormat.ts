/**
 * Utilidades para formateo de números y porcentajes
 */

export function formatNumber(val?: number | null, decimals = 0): string {
  const num = Number(val) || 0;
  return num.toLocaleString('es-PE', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  });
}

export function formatPercent(val?: number | null, decimals = 1): string {
  const num = Number(val) || 0;
  return `${num.toFixed(decimals)}%`;
}
