/**
 * Utilidades para procesamiento, normalización y visualización robusta de imágenes de Google Drive
 */

export interface DriveImageSources {
  fileId: string | null;
  primaryUrl: string;
  secondaryUrl: string;
  tertiaryUrl: string;
  directWebUrl: string | null;
  isDrive: boolean;
}

/**
 * Extrae de forma segura el ID de archivo de Google Drive a partir de cualquier formato de URL o ID directo
 */
export function extractDriveFileId(urlOrId?: string | null): string | null {
  if (!urlOrId || typeof urlOrId !== 'string') return null;
  const trimmed = urlOrId.trim();
  if (!trimmed) return null;

  // Data URLs en Base64 no son de Drive
  if (trimmed.startsWith('data:image/')) return null;

  // Patrón 1: /d/FILE_ID
  const dMatch = trimmed.match(/\/d\/([a-zA-Z0-9_-]{20,})/);
  if (dMatch && dMatch[1]) return dMatch[1];

  // Patrón 2: id=FILE_ID o open?id=FILE_ID
  const idMatch = trimmed.match(/[?&]id=([a-zA-Z0-9_-]{20,})/);
  if (idMatch && idMatch[1]) return idMatch[1];

  // Patrón 3: file/d/FILE_ID
  const fileMatch = trimmed.match(/file\/d\/([a-zA-Z0-9_-]{20,})/);
  if (fileMatch && fileMatch[1]) return fileMatch[1];

  // Patrón 4: Si ya es un ID directo de Drive (alfanumérico largo sin slashes ni protocolos)
  if (/^[a-zA-Z0-9_-]{25,}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

/**
 * Normaliza cualquier URL o ID de Google Drive a enlaces compatibles con incrustación en <img>
 */
export function getDriveImageSources(urlOrId?: string | null, fallbackDriveId?: string | null): DriveImageSources {
  let clean = (urlOrId || '').trim();
  if (clean.startsWith('public/assets/')) {
    clean = `/${clean.replace(/^public\//, '')}`;
  }

  const fileId = extractDriveFileId(clean) || extractDriveFileId(fallbackDriveId);

  if (fileId) {
    return {
      fileId,
      // CDN directo de Google UserContent (no bloquea hotlink y no redirige a HTML)
      primaryUrl: `https://lh3.googleusercontent.com/d/${fileId}`,
      // Servicio de miniaturas en alta resolución de Google Drive
      secondaryUrl: `https://drive.google.com/thumbnail?id=${fileId}&sz=w1200`,
      // Endpoint de exportación de vista directa
      tertiaryUrl: `https://drive.google.com/uc?export=view&id=${fileId}`,
      // Enlace para abrir la vista nativa de Drive en pestaña nueva
      directWebUrl: `https://drive.google.com/file/d/${fileId}/view`,
      isDrive: true
    };
  }

  // Si es Data URL u otra URL web ordinaria
  return {
    fileId: null,
    primaryUrl: clean,
    secondaryUrl: clean,
    tertiaryUrl: clean,
    directWebUrl: clean.startsWith('http') ? clean : null,
    isDrive: false
  };
}
