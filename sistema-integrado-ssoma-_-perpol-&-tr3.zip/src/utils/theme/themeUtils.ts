import { ThemeColor, ThemeBackground, THEME_OPTIONS } from '../../types/theme';

export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const cleanHex = hex.replace('#', '').trim();
  if (cleanHex.length === 3) {
    return {
      r: parseInt(cleanHex[0] + cleanHex[0], 16),
      g: parseInt(cleanHex[1] + cleanHex[1], 16),
      b: parseInt(cleanHex[2] + cleanHex[2], 16)
    };
  }
  if (cleanHex.length === 6) {
    return {
      r: parseInt(cleanHex.substring(0, 2), 16),
      g: parseInt(cleanHex.substring(2, 4), 16),
      b: parseInt(cleanHex.substring(4, 6), 16)
    };
  }
  return null;
}

export function applyTheme(
  color: ThemeColor,
  customHex?: string,
  background: ThemeBackground = 'light'
) {
  const root = document.documentElement;

  let primaryHex = '#263B5E';
  if (color === 'custom' && customHex && /^#[0-9A-Fa-f]{6}$/.test(customHex)) {
    primaryHex = customHex;
  } else if (color !== 'custom' && THEME_OPTIONS[color]) {
    primaryHex = THEME_OPTIONS[color].hex;
  }

  const rgb = hexToRgb(primaryHex) || { r: 38, g: 59, b: 94 };

  root.style.setProperty('--color-brand-primary', primaryHex);
  root.style.setProperty('--color-brand-rgb', `${rgb.r}, ${rgb.g}, ${rgb.b}`);
  root.style.setProperty('--color-brand-light', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.12)`);
  root.style.setProperty('--color-brand-border', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.35)`);
  root.style.setProperty('--color-brand-hover', color === 'corporate' ? '#3F72AF' : `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.85)`);

  root.setAttribute('data-theme-color', color);
  root.setAttribute('data-theme-bg', background);

  const body = document.body;
  body.classList.remove('theme-bg-slate', 'theme-bg-midnight', 'theme-bg-navy', 'theme-bg-light');
  body.classList.add(`theme-bg-${background}`);
}

export function getThemeClasses(color: ThemeColor) {
  if (color === 'custom') {
    return {
      bg: 'bg-[#263B5E]',
      bgHover: 'hover:bg-[#3F72AF]',
      text: 'text-[#263B5E]',
      border: 'border-[#263B5E]',
      bgLight: 'bg-[#F4F6F8]',
      borderLight: 'border-[#E5E9EF]'
    };
  }
  const option = THEME_OPTIONS[color] || THEME_OPTIONS.corporate;
  return {
    bg: option.bgClass,
    bgHover: option.bgHoverClass,
    text: option.textClass,
    border: option.borderClass,
    bgLight: option.bgLightClass,
    borderLight: option.borderLightClass
  };
}
