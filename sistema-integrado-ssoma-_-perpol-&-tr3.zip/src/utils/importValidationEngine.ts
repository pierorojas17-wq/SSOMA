/**
 * Motor de Validación y Gestor de Lotes en el Cliente (Frontend)
 * Ejecuta validaciones exhaustivas fila por fila:
 * - Campos obligatorios y tipos de datos
 * - Validación normativa de RUC (identificando PERPOL y TR3)
 * - Preservación de ceros a la izquierda en DNI (8 dígitos), RUC (11 dígitos) y teléfonos
 * - Detección de claves duplicadas dentro del mismo archivo
 * - Validación relacional con registros maestros para prevenir registros huérfanos
 * - Transmisor secuencial por lotes para evitar timeouts en Google Apps Script
 */

import { ModuleImportSchema } from './moduleImportSchemas';
import { GasApiClient } from '../services/api';
import { GasApiResponse } from '../types';

export interface RowValidationError {
  rowNumber: number;
  field: string;
  fieldLabel: string;
  value: unknown;
  message: string;
  isCritical: boolean;
}

export interface ValidationSummary {
  totalRows: number;
  validRowsCount: number;
  warningRowsCount: number;
  criticalRowsCount: number;
  duplicateKeysCount: number;
  transformedRows: Record<string, unknown>[];
  errors: RowValidationError[];
  isValidForImport: boolean;
}

export interface BatchProgress {
  currentBatch: number;
  totalBatches: number;
  percent: number;
  processedRows: number;
  totalRows: number;
  status: 'idle' | 'transmitting' | 'success' | 'error';
  message: string;
}

export interface BatchImportResult {
  success: boolean;
  totalSubmitted: number;
  createdCount: number;
  updatedCount: number;
  skippedCount: number;
  rejectedCount: number;
  errors: string[];
  executionTimeMs: number;
}

export class ImportValidationEngine {
  /**
   * Valida un RUC peruano (11 dígitos, comienza con 10 o 20) y verifica si corresponde a PERPOL o TR3
   */
  public static validateRuc(rucRaw: unknown): {
    isValid: boolean;
    cleanRuc: string;
    empresaDetectada?: 'PERPOL' | 'TR3';
    error?: string;
  } {
    if (rucRaw === null || rucRaw === undefined || String(rucRaw).trim() === '') {
      return { isValid: false, cleanRuc: '', error: 'RUC vacío' };
    }

    let clean = String(rucRaw).trim().replace(/\D/g, '');

    // Si tiene menos de 11 dígitos por pérdida de ceros, rellenar a la izquierda
    if (clean.length > 0 && clean.length < 11) {
      clean = clean.padStart(11, '0');
    }

    if (clean.length !== 11) {
      return {
        isValid: false,
        cleanRuc: clean,
        error: `El RUC debe tener exactamente 11 dígitos numéricos (actual: ${clean.length})`
      };
    }

    if (!clean.startsWith('10') && !clean.startsWith('20') && !clean.startsWith('15') && !clean.startsWith('17')) {
      return {
        isValid: false,
        cleanRuc: clean,
        error: `El RUC '${clean}' no tiene un prefijo válido de SUNAT (debe iniciar con 10 o 20)`
      };
    }

    // Identificar si corresponde a las razones sociales de la empresa
    let empresaDetectada: 'PERPOL' | 'TR3' | undefined;
    if (clean === '20392729977') {
      empresaDetectada = 'PERPOL';
    } else if (clean === '20550842891') {
      empresaDetectada = 'TR3';
    }

    return { isValid: true, cleanRuc: clean, empresaDetectada };
  }

  /**
   * Normaliza documento de identidad peruano:
   * - DNI: 8 dígitos numéricos
   * - C.E. (Carné de Extranjería): cuando lleva más dígitos/caracteres (hasta 12 caracteres máx)
   */
  public static normalizeDni(dniRaw: unknown): { isValid: boolean; cleanDni: string; error?: string; tipoDoc?: 'DNI' | 'C.E.' } {
    if (dniRaw === null || dniRaw === undefined || String(dniRaw).trim() === '') {
      return { isValid: false, cleanDni: '', error: 'DNI / C.E. vacío' };
    }

    let clean = String(dniRaw).trim().toUpperCase().replace(/[^a-zA-Z0-9]/g, '');

    // Rellenar ceros iniciales si fue importado como número entero de DNI (ej: 9876543 -> 09876543)
    if (/^\d+$/.test(clean) && clean.length > 0 && clean.length < 8) {
      clean = clean.padStart(8, '0');
    }

    // DNI: exactamente 8 dígitos numéricos
    if (/^\d{8}$/.test(clean)) {
      return { isValid: true, cleanDni: clean, tipoDoc: 'DNI' };
    }

    // C.E. (Carné de Extranjería): cuando tiene más de 8 caracteres y máximo 12
    if (clean.length > 8 && clean.length <= 12) {
      return { isValid: true, cleanDni: clean, tipoDoc: 'C.E.' };
    }

    if (clean.length > 12) {
      return {
        isValid: false,
        cleanDni: clean,
        error: `El C.E. (Carné de Extranjería) debe tener como máximo 12 caracteres (actual: ${clean.length} caracteres)`
      };
    }

    return {
      isValid: false,
      cleanDni: clean,
      error: `Documento inválido '${clean}'. DNI requiere 8 dígitos y C.E. hasta 12 caracteres.`
    };
  }

  /**
   * Normaliza teléfonos peruanos preservando formato
   */
  public static normalizeTelefono(telRaw: unknown): string {
    if (!telRaw) return '';
    const clean = String(telRaw).trim().replace(/[^\d+]/g, '');
    if (clean.length === 8 && !clean.startsWith('9')) {
      return clean.padStart(9, '9');
    }
    return clean;
  }

  /**
   * Sugiere automáticamente la correspondencia entre encabezados del archivo y campos esperados
   */
  public static autoSuggestMapping(
    fileHeaders: string[],
    schema: ModuleImportSchema
  ): Record<string, string> {
    const mapping: Record<string, string> = {};

    schema.fields.forEach((field) => {
      // 1. Coincidencia exacta con la clave
      let match = fileHeaders.find(
        (h) => h.toLowerCase().trim() === field.key.toLowerCase().trim()
      );

      // 2. Coincidencia exacta con la etiqueta legible
      if (!match) {
        match = fileHeaders.find(
          (h) => h.toLowerCase().trim() === field.label.toLowerCase().trim()
        );
      }

      // 3. Coincidencia con lista de alias
      if (!match) {
        match = fileHeaders.find((h) => {
          const cleanH = h
            .toLowerCase()
            .trim()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]/g, '_');
          return field.aliases.some((alias) => {
            const cleanAlias = alias
              .toLowerCase()
              .trim()
              .normalize('NFD')
              .replace(/[\u0300-\u036f]/g, '')
              .replace(/[^a-z0-9]/g, '_');
            return cleanH === cleanAlias || cleanH.includes(cleanAlias) || cleanAlias.includes(cleanH);
          });
        });
      }

      if (match) {
        mapping[field.key] = match;
      }
    });

    return mapping;
  }

  /**
   * Evalúa fila por fila el archivo importado aplicando todas las reglas de negocio
   */
  public static validateRows(
    rawRows: Record<string, unknown>[],
    columnMapping: Record<string, string>, // targetField -> fileHeader
    schema: ModuleImportSchema,
    masterRecords?: {
      accidentesIds?: Set<string>;
      trabajadoresDnis?: Set<string>;
      inspeccionesIds?: Set<string>;
    }
  ): ValidationSummary {
    const errors: RowValidationError[] = [];
    const transformedRows: Record<string, unknown>[] = [];
    const seenPrimaryKeys = new Map<string, number>(); // primaryKeyVal -> firstRowNumber
    let duplicateKeysCount = 0;

    rawRows.forEach((row, index) => {
      const rowNumber = index + 2; // +1 por 1-based, +1 por encabezados
      const transformedItem: Record<string, unknown> = {};
      let hasRowCriticalError = false;

      // Mapear cada campo del esquema
      schema.fields.forEach((field) => {
        const fileColumnName = columnMapping[field.key];
        let val = fileColumnName ? row[fileColumnName] : undefined;

        // Limpiar strings
        if (typeof val === 'string') {
          val = val.trim();
        }

        // Validación de campo obligatorio
        if (field.required && (val === undefined || val === null || val === '')) {
          errors.push({
            rowNumber,
            field: field.key,
            fieldLabel: field.label,
            value: val,
            message: `El campo obligatorio '${field.label}' está vacío`,
            isCritical: true
          });
          hasRowCriticalError = true;
          return;
        }

        // Si no es obligatorio y está vacío, asignar valor por defecto
        if (val === undefined || val === null || val === '') {
          transformedItem[field.key] = field.type === 'number' ? 0 : '';
          return;
        }

        // Normalizaciones específicas
        if (field.key === 'dni' || field.key === 'trabajadorDni' || field.key === 'dniPersona') {
          const { isValid, cleanDni, error } = this.normalizeDni(val);
          if (!isValid && field.required) {
            errors.push({
              rowNumber,
              field: field.key,
              fieldLabel: field.label,
              value: val,
              message: error || 'DNI inválido',
              isCritical: true
            });
            hasRowCriticalError = true;
          }
          val = cleanDni;
        } else if (field.key === 'ruc') {
          const { isValid, cleanRuc, error } = this.validateRuc(val);
          if (!isValid) {
            errors.push({
              rowNumber,
              field: field.key,
              fieldLabel: field.label,
              value: val,
              message: error || 'RUC inválido',
              isCritical: true
            });
            hasRowCriticalError = true;
          }
          val = cleanRuc;
        } else if (field.key === 'telefono') {
          val = this.normalizeTelefono(val);
        } else if (field.type === 'number') {
          const num = Number(val);
          if (isNaN(num)) {
            errors.push({
              rowNumber,
              field: field.key,
              fieldLabel: field.label,
              value: val,
              message: `El valor '${val}' en '${field.label}' no es un número válido`,
              isCritical: field.required
            });
            if (field.required) hasRowCriticalError = true;
            val = 0;
          } else {
            val = num;
          }
        } else if (field.type === 'enum' && field.enumValues) {
          const strVal = String(val).trim();
          // Comparación insensible a mayúsculas
          const matchEnum = field.enumValues.find(
            (e) => e.toLowerCase() === strVal.toLowerCase()
          );
          if (!matchEnum) {
            errors.push({
              rowNumber,
              field: field.key,
              fieldLabel: field.label,
              value: val,
              message: `El valor '${strVal}' en '${field.label}' no es válido. Opciones permitidas: ${field.enumValues.join(', ')}`,
              isCritical: field.required
            });
            if (field.required) hasRowCriticalError = true;
          } else {
            val = matchEnum;
          }
        }

        transformedItem[field.key] = val;
      });

      // Asegurar campo 'id'
      const pkField = schema.primaryKey;
      const pkVal = transformedItem[pkField] ? String(transformedItem[pkField]).trim() : '';

      if (!transformedItem.id) {
        transformedItem.id = pkVal || `IMPORT-${Date.now()}-${rowNumber}`;
      }

      // Detección de claves duplicadas dentro del mismo archivo
      if (pkVal) {
        if (seenPrimaryKeys.has(pkVal)) {
          const originalRow = seenPrimaryKeys.get(pkVal)!;
          duplicateKeysCount++;
          errors.push({
            rowNumber,
            field: pkField,
            fieldLabel: schema.fields.find((f) => f.key === pkField)?.label || pkField,
            value: pkVal,
            message: `Clave duplicada '${pkVal}'. Ya fue registrada en la fila ${originalRow} de este archivo.`,
            isCritical: true
          });
          hasRowCriticalError = true;
        } else {
          seenPrimaryKeys.set(pkVal, rowNumber);
        }
      }

      // Validación relacional con maestros (evitar registros huérfanos)
      if (schema.requiresMasterValidation && schema.masterValidationField) {
        const masterVal = String(transformedItem[schema.masterValidationField] || '').trim();
        if (schema.moduleId === 'investigacion' && masterRecords?.accidentesIds && masterRecords.accidentesIds.size > 0) {
          if (!masterRecords.accidentesIds.has(masterVal)) {
            errors.push({
              rowNumber,
              field: schema.masterValidationField,
              fieldLabel: 'Caso de Accidente Vinculado',
              value: masterVal,
              message: `Error de integridad referencial: El caso de accidente '${masterVal}' no existe en el Módulo 1 (Accidentes). Se exige un ID maestro válido para no crear investigaciones huérfanas.`,
              isCritical: true
            });
            hasRowCriticalError = true;
          }
        }
      }

      // Validación relacional específica de Actos y Condiciones
      if (schema.moduleId === 'actos-condiciones') {
        const catId = String(transformedItem.categoriaId || '').trim().toUpperCase();
        const validCats = [
          'CAT-01', 'CAT-02', 'CAT-03', 'CAT-04', 'CAT-05', 'CAT-06',
          'CAT-07', 'CAT-08', 'CAT-09', 'CAT-10', 'CAT-11', 'CAT-12'
        ];
        if (catId && !validCats.includes(catId)) {
          errors.push({
            rowNumber,
            field: 'categoriaId',
            fieldLabel: 'Categoría de Riesgo',
            value: catId,
            message: `Categoría inválida '${catId}'. Debe pertenecer al catálogo normativo de 12 categorías (CAT-01 a CAT-12).`,
            isCritical: true
          });
          hasRowCriticalError = true;
        }
      }

      // Campos de auditoría
      if (!transformedItem.createdAt) {
        transformedItem.createdAt = new Date().toISOString();
      }
      transformedItem.updatedAt = new Date().toISOString();
      transformedItem.__rowNumber = rowNumber;
      transformedItem.__hasError = hasRowCriticalError;

      transformedRows.push(transformedItem);
    });

    const criticalErrors = errors.filter((e) => e.isCritical);
    const warningErrors = errors.filter((e) => !e.isCritical);
    const validRowsCount = transformedRows.filter((r) => !r.__hasError).length;

    return {
      totalRows: rawRows.length,
      validRowsCount,
      warningRowsCount: warningErrors.length,
      criticalRowsCount: criticalErrors.length,
      duplicateKeysCount,
      transformedRows,
      errors,
      isValidForImport: validRowsCount > 0
    };
  }

  /**
   * Gestor de Lotes (Batch Manager): Envía los registros limpios en fragmentos secuenciales
   */
  public static async executeBatchImport(
    rowsToImport: Record<string, unknown>[],
    schema: ModuleImportSchema,
    mode: 'upsert' | 'insertar' | 'actualizar',
    empresa: string,
    onProgress?: (progress: BatchProgress) => void,
    chunkSize = 50
  ): Promise<BatchImportResult> {
    const startTime = performance.now();
    const cleanRows = rowsToImport.map((r) => {
      const copy = { ...r };
      delete copy.__rowNumber;
      delete copy.__hasError;
      return copy;
    });

    // Dividir en lotes
    const chunks: Record<string, unknown>[][] = [];
    for (let i = 0; i < cleanRows.length; i += chunkSize) {
      chunks.push(cleanRows.slice(i, i + chunkSize));
    }

    const totalBatches = chunks.length;
    let createdCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;
    let rejectedCount = 0;
    const errors: string[] = [];

    for (let batchIdx = 0; batchIdx < totalBatches; batchIdx++) {
      const currentBatch = batchIdx + 1;
      const batchData = chunks[batchIdx];
      const processedCount = (batchIdx * chunkSize) + batchData.length;
      const percent = Math.round((processedCount / cleanRows.length) * 100);

      if (onProgress) {
        onProgress({
          currentBatch,
          totalBatches,
          percent,
          processedRows: processedCount,
          totalRows: cleanRows.length,
          status: 'transmitting',
          message: `Transmitiendo lote ${currentBatch} de ${totalBatches} (${batchData.length} registros)...`
        });
      }

      try {
        const response: GasApiResponse = await GasApiClient.sendRequest({
          action: 'batchImport',
          sheetName: schema.sheetName,
          empresa: empresa as any,
          rows: batchData,
          mode,
          primaryKey: schema.primaryKey,
          batchIndex: currentBatch,
          totalBatches
        });

        if (response.success) {
          createdCount += response.created ?? batchData.length;
          updatedCount += response.updated ?? 0;
          skippedCount += response.skipped ?? 0;
          rejectedCount += response.rejected ?? 0;
          if (response.errors && response.errors.length > 0) {
            errors.push(...response.errors);
          }
        } else {
          rejectedCount += batchData.length;
          errors.push(`Error en lote ${currentBatch}: ${response.error || 'Fallo desconocido'}`);
        }
      } catch (err: unknown) {
        rejectedCount += batchData.length;
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(`Fallo de red en lote ${currentBatch}: ${msg}`);
      }
    }

    const executionTimeMs = Math.round(performance.now() - startTime);

    if (onProgress) {
      onProgress({
        currentBatch: totalBatches,
        totalBatches,
        percent: 100,
        processedRows: cleanRows.length,
        totalRows: cleanRows.length,
        status: errors.length > 0 && createdCount + updatedCount === 0 ? 'error' : 'success',
        message: 'Importación por lotes finalizada.'
      });
    }

    return {
      success: createdCount + updatedCount > 0,
      totalSubmitted: cleanRows.length,
      createdCount,
      updatedCount,
      skippedCount,
      rejectedCount,
      errors,
      executionTimeMs
    };
  }
}
