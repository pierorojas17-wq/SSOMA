/**
 * Catálogos estandarizados y algoritmos normativos de SSOMA
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 */

export interface CategoriaRiesgoDef {
  codigo: string;
  nombre: string;
  descripcion: string;
  pgSugerido: 1 | 2 | 3 | 4;
}

/**
 * Catálogo duro de 12 categorías de riesgo (CAT-01 a CAT-12)
 * Especificado en el análisis técnico del Sistema Integrado SSOMA.
 */
export const CATALOGO_CATEGORIAS_RIESGO: CategoriaRiesgoDef[] = [
  {
    codigo: 'CAT-01',
    nombre: 'Prevención y Protección contra Incendios y Emergencias',
    descripcion: 'Extintores, gabinetes, rociadores, rutas de escape y brigadas',
    pgSugerido: 3
  },
  {
    codigo: 'CAT-02',
    nombre: 'Sustancias Químicas Peligrosas: Manipulación, Almacenamiento y Exposición',
    descripcion: 'Sustancias corrosivas, reactivos CIP, amoníaco y hojas SDS',
    pgSugerido: 3
  },
  {
    codigo: 'CAT-03',
    nombre: 'Seguridad de Máquinas, Equipos y Herramientas',
    descripcion: 'Protecciones mecánicas, paradas de emergencia, engranajes y fajas',
    pgSugerido: 3
  },
  {
    codigo: 'CAT-04',
    nombre: 'Caídas a Distinto Nivel: Escaleras, Plataformas, Aberturas y Protección contra Caídas',
    descripcion: 'Escaleras, andamios, arneses, líneas de vida y barandas',
    pgSugerido: 4
  },
  {
    codigo: 'CAT-05',
    nombre: 'Espacios Confinados: Acceso, Permanencia y Rescate',
    descripcion: 'Tanques de fermentación, silos, cisternas y pozos de bombeo',
    pgSugerido: 4
  },
  {
    codigo: 'CAT-06',
    nombre: 'Riesgos Eléctricos y Control de Energías Peligrosas',
    descripcion: 'Tableros, cableado, candados LOTO, tarjetas y puesta a tierra',
    pgSugerido: 4
  },
  {
    codigo: 'CAT-07',
    nombre: 'Ergonomía, Posturas de Trabajo y Manipulación Manual de Cargas',
    descripcion: 'Levantamiento de sacos, posturas forzadas, movimientos repetitivos',
    pgSugerido: 2
  },
  {
    codigo: 'CAT-08',
    nombre: 'Condiciones Locativas, Orden, Limpieza y Almacenamiento',
    descripcion: 'Pasillos despejados, pisos resbaladizos, apilamiento seguro',
    pgSugerido: 1
  },
  {
    codigo: 'CAT-09',
    nombre: 'Equipos de Protección Personal (EPP): Disponibilidad, Uso y Estado',
    descripcion: 'Cascos, botas dieléctricas, lentes, tapones, guantes y respiradores',
    pgSugerido: 2
  },
  {
    codigo: 'CAT-10',
    nombre: 'Seguridad Vial Interna, Vehículos y Equipos de Transporte',
    descripcion: 'Velocidad, alarmas de retroceso, señalización y cruces peatonales',
    pgSugerido: 3
  },
  {
    codigo: 'CAT-11',
    nombre: 'Procedimientos, Permisos y Controles de Trabajo Seguro (PETS / ATS)',
    descripcion: 'Omisión de permisos, desvío de estándares y falta de autorización',
    pgSugerido: 2
  },
  {
    codigo: 'CAT-12',
    nombre: 'Agentes Físicos y Condiciones Ambientales de Trabajo',
    descripcion: 'Cámaras frigoríficas, calor en calderas, iluminación deficiente',
    pgSugerido: 2
  }
];

/**
 * Catálogo oficial de Áreas de Trabajo del Sistema Integrado SSOMA
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 */
export const AREAS_EMPRESA = [
  'Procesos',
  'Laboratorio',
  'Almacén Químicos',
  'Dosimetría',
  'Etiquetado',
  'Postres',
  'Oficina Ventas',
  'Áreas comunes',
  'Oficina Gerencia',
  'Oficina Contabilidad',
  'Oficina RRHH',
  'Oficina Marketing',
  'Plataforma de equipos de refrigeración',
  'Cisternas',
  'Recepción de leche',
  'Recepción de Insumos/envases',
  'Sala de compresores',
  'Mantenimiento',
  'Contenedor',
  'Almacén de secos',
  'SSOMA',
  'Vigilancia',
  'Caldero',
  'Sub Estación',
  'Envasado',
  'Cámara de frio',
  'Despacho',
  'Oficina de Calidad',
  'Oficina de Producción'
];

export const AREAS_TRABAJO = AREAS_EMPRESA;

/**
 * Catálogo oficial de Lugares Físicos Específicos para incidentes, actos y condiciones inseguras.
 * Incorpora 'Escalera de acceso' y 'Pasadizo' junto a la infraestructura física detallada de planta.
 */
export const LUGARES_ESPECIFICOS = [
  'Escalera de acceso',
  'Pasadizo',
  'Caldero',
  'Sala de compresores',
  'Sub Estación',
  'Plataforma de equipos de refrigeración',
  'Sala de Chillers',
  'Grupo electrógeno',
  'Cisternas',
  'Cisterna de agua helada',
  'Cisterna de agua caliente',
  'Cisterna de agua de re-uso',
  'Cisterna de agua blanda',
  'Cisterna de agua de red',
  'Tanque de 15 mil',
  'Envasado',
  'Envasadora Lineal 6 pistones',
  'Envasadora Lineal 4 pistones',
  'Envasadora Rotativa',
  'Envasadora de botellas',
  'Maquina enchaquetadora',
  'Tinas de incubación',
  'Camara de incubación',
  'Camara de congelado',
  'Camara de conservación',
  'Oficina Camara de frio',
  'Camara de Producto Terminado 1',
  'Camara de Producto Terminado 2',
  'Camara de Golpe de frio',
  'Cámara de frio',
  'Procesos',
  'Sala de mezclas',
  'Laboratorio',
  'Almacén Químicos',
  'Dosimetría',
  'Etiquetado',
  'Postres',
  'Recepción de leche',
  'Recepción de Insumos/envases',
  'Almacén de secos',
  'Almacén de envases',
  'Almacén SSOMA',
  'Almacén Marketing',
  'Almacén de Saneamiento',
  'Almacén de Transito',
  'Contenedor',
  'Contenedor Riffer',
  'Contenedor de Almacén seco',
  'Taller de Mantenimiento',
  'Almacén de Mantenimiento',
  'Oficina de Mantenimiento',
  'Mantenimiento',
  'Despacho',
  'Vigilancia',
  'Caseta de vigilancia',
  'Cochera',
  'Comedor',
  'SSHH Varones',
  'SSHH Mujeres',
  'Vestuario Varones',
  'Vestuario Mujeres',
  'Áreas comunes',
  'Oficina Gerencia',
  'Oficina Contabilidad',
  'Oficina RRHH',
  'Oficina Marketing',
  'Oficina Ventas',
  'Oficina de Calidad',
  'Oficina de Producción',
  'Sala de Reuniones',
  'SSOMA'
];

/**
 * Conversión oficial de Potencial de Gravedad (P.G.) a Prioridad
 * P.G. 1 -> Baja
 * P.G. 2 -> Media
 * P.G. 3 -> Alta
 * P.G. 4 -> Inmediata (Crítico)
 */
export function pgToPrioridad(pg: 1 | 2 | 3 | 4): 'Baja' | 'Media' | 'Alta' | 'Inmediata' {
  switch (pg) {
    case 1:
      return 'Baja';
    case 2:
      return 'Media';
    case 3:
      return 'Alta';
    case 4:
      return 'Inmediata';
    default:
      return 'Media';
  }
}

/**
 * Plazo estándar sugerido en días según P.G.
 */
export function pgToDiasPlazo(pg: 1 | 2 | 3 | 4): number {
  switch (pg) {
    case 1:
      return 30; // 30 días
    case 2:
      return 15; // 10 días
    case 3:
      return 3;  // 72 horas
    case 4:
      return 1;  // 24 horas / Inmediato
    default:
      return 15;
  }
}

export interface DelayInfo {
  overdue: boolean;
  days: number;
  text: string;
}

/**
 * ALGORITMO CRÍTICO: getDelayInfo
 * Regla estricta del sistema original:
 * Compara la fecha de compromiso con la fecha de cierre (o la fecha actual si está abierto)
 * utilizando fechas UTC sin hora.
 * Solo debe marcarse como atrasado (overdue: true) cuando la diferencia es mayor que 1 día.
 * Un día de diferencia (diffDays <= 1) debe mostrarse dentro del plazo o con contador 0.
 */
export function getDelayInfo(fechaCompromisoStr: string, fechaCierreStr?: string): DelayInfo {
  if (!fechaCompromisoStr) {
    return { overdue: false, days: 0, text: 'Sin fecha' };
  }

  // Parsear fecha de compromiso en UTC (YYYY-MM-DD)
  const compParts = fechaCompromisoStr.split('-').map(Number);
  if (compParts.length < 3 || isNaN(compParts[0]) || isNaN(compParts[1]) || isNaN(compParts[2])) {
    return { overdue: false, days: 0, text: 'Fecha inválida' };
  }
  const compUtc = Date.UTC(compParts[0], compParts[1] - 1, compParts[2]);

  let refUtc: number;
  if (fechaCierreStr) {
    const cierreParts = fechaCierreStr.split('-').map(Number);
    if (cierreParts.length >= 3 && !isNaN(cierreParts[0])) {
      refUtc = Date.UTC(cierreParts[0], cierreParts[1] - 1, cierreParts[2]);
    } else {
      const now = new Date();
      refUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
    }
  } else {
    const now = new Date();
    refUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  }

  const msPerDay = 1000 * 60 * 60 * 24;
  const diffDays = Math.round((refUtc - compUtc) / msPerDay);

  // Regla estricta:
  // Solo se marca overdue: true cuando diffDays > 1.
  // 1 día de diferencia o menos se considera dentro del plazo (days: 0).
  if (diffDays > 1) {
    return {
      overdue: true,
      days: diffDays,
      text: `${diffDays} días de retraso`
    };
  } else if (diffDays === 1) {
    return {
      overdue: false,
      days: 0,
      text: 'Plazo límite (1 día)'
    };
  } else if (diffDays === 0) {
    return {
      overdue: false,
      days: 0,
      text: 'Vence hoy'
    };
  } else {
    const restantes = Math.abs(diffDays);
    return {
      overdue: false,
      days: 0,
      text: `${restantes} días restantes`
    };
  }
}

/**
 * Catálogo estandarizado de insumos médicos para Botiquines y Primeros Auxilios
 */
export interface InsumoBotiquinItem {
  nombre: string;
  unidad: string;
  categoria: 'Material de curación' | 'Antiséptico' | 'Medicamento básico' | 'Instrumental y EPP';
}

export const CATALOGO_INSUMOS_BOTIQUIN: InsumoBotiquinItem[] = [
  { nombre: 'Gasa estéril fraccionada (10x10 cm)', unidad: 'Sobres', categoria: 'Material de curación' },
  { nombre: 'Venda elástica 3 pulgadas', unidad: 'Unidades', categoria: 'Material de curación' },
  { nombre: 'Venda elástica 4 pulgadas', unidad: 'Unidades', categoria: 'Material de curación' },
  { nombre: 'Venda elástica 6 pulgadas', unidad: 'Unidades', categoria: 'Material de curación' },
  { nombre: 'Esparadrapo antialérgico microporoso', unidad: 'Rollos', categoria: 'Material de curación' },
  { nombre: 'Apósitos / Curitas adhesivas estándar', unidad: 'Unidades', categoria: 'Material de curación' },
  { nombre: 'Algodón hidrófilo 100g', unidad: 'Paquetes', categoria: 'Material de curación' },
  { nombre: 'Alcohol etílico al 70% (250 ml)', unidad: 'Frascos', categoria: 'Antiséptico' },
  { nombre: 'Agua oxigenada 10 volúmenes (120 ml)', unidad: 'Frascos', categoria: 'Antiséptico' },
  { nombre: 'Povidona Yodada / Solución antiséptica', unidad: 'Frascos', categoria: 'Antiséptico' },
  { nombre: 'Cloruro de sodio al 0.9% (Suero fisiológico para lavado)', unidad: 'Frascos', categoria: 'Antiséptico' },
  { nombre: 'Paracetamol 500 mg (analgésico / antipirético)', unidad: 'Tabletas', categoria: 'Medicamento básico' },
  { nombre: 'Ibuprofeno 400 mg (antiinflamatorio)', unidad: 'Tabletas', categoria: 'Medicamento básico' },
  { nombre: 'Sal de rehidratación oral (sobre)', unidad: 'Sobres', categoria: 'Medicamento básico' },
  { nombre: 'Sulfadiazina de plata en crema (quemaduras leves)', unidad: 'Tubos', categoria: 'Medicamento básico' },
  { nombre: 'Guantes de látex / nitrilo desechables', unidad: 'Pares', categoria: 'Instrumental y EPP' },
  { nombre: 'Tijera de trauma punta roma', unidad: 'Unidades', categoria: 'Instrumental y EPP' },
  { nombre: 'Pinza anatómica metálica', unidad: 'Unidades', categoria: 'Instrumental y EPP' },
  { nombre: 'Termómetro digital infrarrojo / axilar', unidad: 'Unidades', categoria: 'Instrumental y EPP' }
];

/**
 * Catálogo de Causas Inmediatas (Normativa G.050 / DS 005-2012-TR)
 */
export const CAUSAS_INMEDIATAS_ACTOS = [
  'Operar equipos sin autorización',
  'No advertir o no señalizar el peligro',
  'Operar a velocidad inadecuada',
  'Desactivar dispositivos de seguridad o protecciones mecánicas',
  'Uso de equipo o herramienta defectuosa',
  'Uso indebido o no uso de Equipos de Protección Personal (EPP)',
  'Cargar o manipular peso de manera incorrecta / sobreesfuerzo',
  'Posición o postura inadecuada para la tarea',
  'Realizar mantenimiento a equipos en movimiento o energizados',
  'Distracción, bromas o falta de atención',
  'Consumo de sustancias que alteran la conducta',
  'Violación de Procedimiento Escrito de Trabajo Seguro (PETS)'
];

export const CAUSAS_INMEDIATAS_CONDICIONES = [
  'Protecciones y defensas mecánicas inadecuadas o ausentes',
  'Equipos de Protección Personal defectuosos o inadecuados',
  'Herramientas, equipos o materiales defectuosos',
  'Espacio de trabajo restringido o congestionado',
  'Sistemas de advertencia o señalización insuficientes',
  'Peligros de incendio o explosión latentes',
  'Falta de orden, limpieza o pasillos obstaculizados',
  'Pisos resbalosos, desniveles o baches en tránsito',
  'Condiciones ambientales peligrosas (ruido, calor, iluminación deficiente)',
  'Ventilación deficiente o presencia de vapores / polvos',
  'Cables eléctricos expuestos o instalaciones sin aterramiento'
];

export const TURNOS_TRABAJO = ['Mañana', 'Tarde', 'Noche'] as const;

/**
 * Catálogos Específicos para Módulo 10: Investigación de Accidentes e Incidentes
 * (Modelo Causal Frank Bird / D.S. 005-2012-TR / RM 050-2013-TR)
 */
export const CATALOGO_TIPOS_CONTACTO = [
  'Golpeado contra (corriendo hacia o tropezando con objetos estacionarios o filosos)',
  'Golpeado por (objeto en movimiento, caída de materiales, proyectil o carga suspendida)',
  'Caída a un mismo nivel (resbalón, tropiezo en piso llano)',
  'Caída a diferente nivel (desde altura, andamio, escalera, plataforma o desnivel)',
  'Atrapado en (puntos de pellizco, engranajes, fajas transportadoras o mordazas)',
  'Atrapado sobre o entre (partes fijas y en movimiento, derrumbe o volcamiento de carga)',
  'Contacto con energía eléctrica (baja tensión, arco eléctrico, electrocución)',
  'Contacto con temperaturas extremas (superficies calientes, vapor, frío en cámaras)',
  'Contacto con sustancias químicas peligrosas (inhalación, absorción cutánea, salpicadura)',
  'Sobreesfuerzo o sobretensión física (levantamiento, empuje o tracción manual de carga)'
] as const;

export const CATALOGO_ACTOS_SUBESTANDAR = [
  'Operar equipos o maquinaria sin debida autorización',
  'No advertir peligros, señalizar o bloquear el área de trabajo',
  'Operar a velocidad inadecuada o con exceso de confianza',
  'Desactivar o anular dispositivos de seguridad, paradas o guardas',
  'Usar herramientas, equipos o accesorios defectuosos o hechizos',
  'No usar los Equipos de Protección Personal (EPP) obligatorios',
  'Usar el EPP de forma incorrecta o en condiciones deterioradas',
  'Cargar, levantar o manipular peso de manera inadecuada (sobreesfuerzo)',
  'Adoptar posturas ergonómicas forzadas o peligrosas para la tarea',
  'Dar mantenimiento o limpieza a equipos en movimiento o energizados',
  'Realizar bromas, juegos o distracciones durante la jornada de trabajo',
  'Consumo de medicamentos no autorizados, alcohol o sustancias psicoactivas',
  'Violar o desviar el Procedimiento Escrito de Trabajo Seguro (PETS)',
  'Intentar ganar tiempo saltándose pasos críticos de seguridad',
  'Trabajar bajo condiciones ambientales adversas sin permiso especial'
] as const;

export const CATALOGO_CONDICIONES_SUBESTANDAR = [
  'Protecciones, guardas o defensas mecánicas ausentes o inadecuadas',
  'Equipos de Protección Personal (EPP) defectuosos, desgastados o inadecuados',
  'Herramientas manuales, eléctricas o equipos con fallas mecánicas',
  'Espacio de trabajo congestionado, restringido o sin zonas de escape',
  'Sistemas de advertencia, señalización o alarmas sonoras/visuales insuficientes',
  'Peligros latentes de incendio, fugas de vapor o conatos de explosión',
  'Falta de orden, aseo o pasillos y accesos peatonales obstaculizados',
  'Pisos resbalosos, desniveles, zanjas sin cubrir o baches en tránsito',
  'Iluminación deficiente, excesivo deslumbramiento o sombras en la zona',
  'Ventilación deficiente, acumulación de vapores, gases tóxicos o polvos',
  'Ruido excesivo continuo que interfiere con la comunicación de alerta',
  'Temperatura ambiental extrema (calor en calderas / frío en cámaras frigoríficas)',
  'Instalaciones eléctricas expuestas, sin aterramiento o cables pelados',
  'Apilamiento inestable o almacenamiento de materiales sobrecargados',
  'Estructuras, plataformas, barandas o andamios inestables o corroídos'
] as const;

export const CATALOGO_FACTORES_PERSONALES = [
  'Capacidad física / fisiológica inadecuada (visión, fuerza, peso o alergias)',
  'Capacidad mental / psicológica inadecuada (estrés agudo, lentitud de reflejos)',
  'Tensión física o fisiológica (fatiga, falta de descanso, sobrecarga laboral)',
  'Tensión mental o psicológica (preocupaciones personales, presión emocional)',
  'Falta de conocimiento (inducción incompleta, desconocimiento del peligro)',
  'Falta de habilidad o entrenamiento práctico insuficiente en la tarea',
  'Motivación deficiente (ahorro de esfuerzo, actitud permisiva, frustración)'
] as const;

export const CATALOGO_FACTORES_TRABAJO = [
  'Liderazgo y/o supervisión deficiente (falta de inspección, tolerancia de desvíos)',
  'Ingeniería inadecuada (diseño deficiente del puesto, máquina o proceso)',
  'Adquisición de materiales y equipos inadecuados o sin especificación SST',
  'Mantenimiento preventivo y correctivo deficiente o inexistente',
  'Estándares de trabajo (PETS / ATS) deficientes, obsoletos o no difundidos',
  'Uso y desgaste normal excesivo sin plan de reposición oportuna',
  'Abuso o uso incorrecto intencional de herramientas e instalaciones',
  'Comunicación deficiente entre turnos o cuadrillas de trabajo'
] as const;

/**
 * Listas normativas de selección múltiple obligatorias para Módulo 1: Accidentes de Trabajo
 */
export const PARTES_CUERPO_AFECTADAS = [
  'Cabeza',
  'Ojos',
  'Tronco',
  'Brazo',
  'Mano',
  'Dedos',
  'Pierna',
  'Pie',
  'Otros'
] as const;

export const MECANISMOS_EVENTO = [
  'Golpes',
  'Caídas',
  'Cortes',
  'Quemaduras',
  'Atrapamientos',
  'Atropellamientos',
  'Sobre esfuerzo',
  'Intoxicación',
  'Otros'
] as const;

export const FUENTES_AGENTES_EVENTO = [
  'Calor',
  'Químicos',
  'Metales',
  'Eléctricos',
  'Vidrio',
  'Escaleras',
  'Madera',
  'Herramienta manual',
  'Otros'
] as const;

export const LESIONES_REFERIDAS = [
  'Amputación',
  'Pérdida de visión',
  'Quemadura',
  'Electrocución',
  'Raspadura',
  'Laceración',
  'Fractura',
  'Luxación',
  'Contusión',
  'Envenenamiento',
  'Lesiones múltiples',
  'Muerte',
  'Otros'
] as const;

