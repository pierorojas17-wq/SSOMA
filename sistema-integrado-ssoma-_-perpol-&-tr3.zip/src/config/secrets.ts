/**
 * Configuración centralizada de seguridad, credenciales y PINs SSOMA.
 * Permite configuración por variables de entorno (.env) manteniendo
 * valores por defecto para entornos locales o demostraciones.
 */

const getEnvVar = (key: string, defaultValue: string): string => {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
    return String(import.meta.env[key]).trim();
  }
  if (typeof process !== 'undefined' && process.env && process.env[key]) {
    return String(process.env[key]).trim();
  }
  return defaultValue;
};

export const PIN_CONFIG = {
  ADMIN: getEnvVar('VITE_ADMIN_PIN', '2295'),
  SYNC: getEnvVar('VITE_SYNC_PIN', '2295')
} as const;

/**
 * Validador de PIN para autorización de módulos administrativos y configuración.
 */
export const isValidAdminPin = (inputPin?: string | null): boolean => {
  if (!inputPin) return false;
  return inputPin.trim() === PIN_CONFIG.ADMIN;
};

/**
 * Validador de PIN para sincronización forzada o re-sincronización con Google Sheets.
 */
export const isValidSyncPin = (inputPin?: string | null): boolean => {
  if (!inputPin) return false;
  return inputPin.trim() === PIN_CONFIG.SYNC;
};
