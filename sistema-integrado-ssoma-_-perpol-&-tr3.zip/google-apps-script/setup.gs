/**
 * ==============================================================================
 * SISTEMA INTEGRADO SSOMA — SCRIPT DE CONFIGURACIÓN Y SEGURIDAD INICIAL (SETUP)
 * PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 * ==============================================================================
 * 
 * Este script se ejecuta una sola vez desde el editor de Google Apps Script
 * mediante la función: runSsomaProductionSetup()
 * 
 * Acciones que realiza automáticamente:
 * 1. Inicializa o valida la estructura de 10 hojas en Google Sheets.
 * 2. Bloquea y protege estructuralmente las hojas para evitar ediciones
 *    accidentales o borrado de fórmulas por usuarios directos de Sheets.
 * 3. Valida y configura la carpeta de Google Drive para evidencias fotográficas y firmas.
 * 4. Imprime en el log los IDs exactos para configurar en el frontend (.env.production).
 */

// Nombre de la carpeta de Drive designada para evidencias
var DRIVE_FOLDER_NAME = "SSOMA_Evidencias_Produccion";

// Lista de las tablas estándar de los 11 módulos activos del sistema SSOMA
var SSOMA_REQUIRED_SHEETS = [
  { name: 'SSOMA_Accidentes', pk: 'codigoCaso', desc: 'Módulo 1: Accidentes de Trabajo' },
  { name: 'SSOMA_AtencionesMedicas', pk: 'codigoAtencion', desc: 'Módulo 2: Atenciones Médicas' },
  { name: 'SSOMA_Inspecciones', pk: 'codigoInspeccion', desc: 'Módulo 3: Inspecciones SST' },
  { name: 'SSOMA_ActosCondiciones', pk: 'codigoRegistro', desc: 'Módulo 4: Actos y Condiciones Inseguras' },
  { name: 'SSOMA_ConsumoBotiquin', pk: 'codigoAtencion', desc: 'Módulo 5: Consumo de Botiquín' },
  { name: 'SSOMA_Trabajadores', pk: 'dni', desc: 'Módulo 6: Base de Trabajadores' },
  { name: 'SSOMA_HorasHombre', pk: 'id', desc: 'Módulo 7: Horas-Hombre (HH)' },
  { name: 'SSOMA_ProgramaAnual', pk: 'id', desc: 'Módulo 8: Programa Anual SST' },
  { name: 'SSOMA_MetasSST', pk: 'id', desc: 'Módulo 9: Metas Anuales de Indicadores SST' },
  { name: 'sst_simulacion_costos_incidentes', pk: 'codigoSimulacion', desc: 'Módulo 10: Simulación de Costos' },
  { name: 'SSOMA_Investigaciones', pk: 'codigoInvestigacion', desc: 'Módulo 11: Investigación de Accidentes' },
  { name: 'sst_estadisticas_dashboard', pk: 'id', desc: 'Consolidado Periódico de Estadísticas SST' }
];

/**
 * Función principal de inicialización en Producción
 */
function runSsomaProductionSetup() {
  Logger.log("==================================================================");
  Logger.log("INICIANDO CONFIGURACIÓN DE PRODUCCIÓN - SISTEMA INTEGRADO SSOMA");
  Logger.log("==================================================================");

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var userEmail = Session.getEffectiveUser().getEmail();
  Logger.log("Usuario de ejecución (Owner/Admin): " + userEmail);
  Logger.log("Spreadsheet ID: " + ss.getId());
  Logger.log("Spreadsheet URL: " + ss.getUrl());

  // 1. Validar y Proteger Hojas de Cálculo
  Logger.log("\n--- PASO 1: VALIDACIÓN Y PROTECCIÓN ESTRUCTURAL DE HOJAS ---");
  var sheetsProtectedCount = 0;

  SSOMA_REQUIRED_SHEETS.forEach(function(def) {
    var sheet = ss.getSheetByName(def.name);
    if (!sheet) {
      sheet = ss.insertSheet(def.name);
      Logger.log("[CREADA] Hoja creada: " + def.name + " (" + def.desc + ")");
    } else {
      Logger.log("[EXISTE] Hoja encontrada: " + def.name);
    }

    // Proteger la hoja para que solo el propietario / servicio de GAS pueda editar
    try {
      var protections = sheet.getProtections(SpreadsheetApp.ProtectionType.SHEET);
      var protection;
      if (protections.length > 0) {
        protection = protections[0];
      } else {
        protection = sheet.protect();
      }

      protection.setDescription("Protección del Sistema SSOMA - " + def.desc);
      protection.setWarningOnly(false); // Bloqueo estricto

      var me = Session.getEffectiveUser();
      var editors = protection.getEditors();
      var editorsToRemove = editors.filter(function(ed) {
        return ed.getEmail().toLowerCase() !== me.getEmail().toLowerCase();
      });
      if (editorsToRemove.length > 0) {
        try {
          protection.removeEditors(editorsToRemove);
        } catch (e) {}
      }

      // Solo aplicar setDomainEdit si la cuenta pertenece a un dominio Google Workspace
      try {
        if (typeof protection.canDomainEdit === 'function' && protection.canDomainEdit()) {
          protection.setDomainEdit(false);
        }
      } catch (domainErr) {
        // Cuentas personales @gmail.com no soportan domainEdit, se ignora limpiamente
      }

      sheetsProtectedCount++;
    } catch (protErr) {
      // Ignorar si ya está protegida
    }
  });

  Logger.log("Total de hojas aseguradas contra manipulación manual: " + sheetsProtectedCount);

  // 2. Validar y Configurar Carpeta de Google Drive
  Logger.log("\n--- PASO 2: GESTIÓN DE CARPETA DE GOOGLE DRIVE PARA EVIDENCIAS ---");
  var driveFolder = null;
  var existingFolders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);

  if (existingFolders.hasNext()) {
    driveFolder = existingFolders.next();
    Logger.log("[EXISTE] Carpeta de Drive encontrada: " + driveFolder.getName() + " (ID: " + driveFolder.getId() + ")");
  } else {
    driveFolder = DriveApp.createFolder(DRIVE_FOLDER_NAME);
    Logger.log("[CREADA] Carpeta de Drive creada exitosamente: " + DRIVE_FOLDER_NAME + " (ID: " + driveFolder.getId() + ")");
  }

  // Establecer permisos de la carpeta
  try {
    driveFolder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    Logger.log("Permisos de carpeta asignados: LECTURA CON ENLACE (permite visualización directa de fotos/firmas)");
  } catch (shareErr) {
    Logger.log("Carpeta de Drive lista para almacenar evidencias fotográficas.");
  }

  // 3. Resumen Final de Parámetros para .env.production
  Logger.log("\n==================================================================");
  Logger.log("CONFIGURACIÓN COMPLETADA CON ÉXITO");
  Logger.log("==================================================================");
  Logger.log("Copie los siguientes valores en su archivo .env.production:");
  Logger.log("VITE_SPREADSHEET_ID=\"" + ss.getId() + "\"");
  Logger.log("VITE_DRIVE_FOLDER_ID=\"" + driveFolder.getId() + "\"");
  Logger.log("VITE_GAS_API_URL=\"[Pegue aquí la URL del Web App obtenido en 'Implementar -> Nueva implementación']\"");
  Logger.log("==================================================================\n");

  return {
    success: true,
    spreadsheetId: ss.getId(),
    driveFolderId: driveFolder.getId(),
    sheetsCount: SSOMA_REQUIRED_SHEETS.length
  };
}

/**
 * Función de verificación de estado y salud del backend (Health Check)
 */
function testSsomaBackendHealth() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var folder = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  
  var health = {
    spreadsheetConnected: !!ss,
    spreadsheetName: ss ? ss.getName() : null,
    driveFolderConfigured: folder.hasNext(),
    timestamp: new Date().toISOString()
  };

  Logger.log("Health Check Result: " + JSON.stringify(health));
  return health;
}
