/**
 * ==============================================================================
 * SISTEMA INTEGRADO SSOMA - BACKEND GOOGLE APPS SCRIPT (Code.gs)
 * Empresas: PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.
 * ==============================================================================
 *
 * INSTRUCCIONES DE DESPLIEGUE EN GOOGLE WORKSPACE:
 * 1. Abre Google Sheets (o crea una nueva hoja de cálculo para el Sistema SSOMA).
 * 2. Ve a Extensiones > Apps Script.
 * 3. Pega este código completo en 'Code.gs'.
 * 4. Haz clic en "Implementar" (Deploy) > "Nueva implementación" (New deployment).
 * 5. Tipo: "Aplicación web" (Web app).
 * 6. Ejecutar como: "Yo" (Tu cuenta de Google con acceso a Sheets y Drive).
 * 7. Quién tiene acceso: "Cualquier usuario" (Anyone).
 * 8. Copia la URL de la aplicación web generada (termina en /exec) y pégala en
 *    la configuración de la aplicación web frontend.
 */

// Configuración predeterminada de carpetas y hojas
var CONFIG = {
  DEFAULT_FOLDER_NAME: 'SSOMA_Evidencias_PERPOL_TR3',
  DEFAULT_SHEET_NAME: 'SSOMA_General'
};

/**
 * Función principal para probar la ejecución directa desde el editor de Apps Script (Botón "Ejecutar")
 */
function ejecutarPruebaDelSistema() {
  Logger.log('==================================================');
  Logger.log('INICIANDO PRUEBA DEL SISTEMA INTEGRADO SSOMA');
  Logger.log('==================================================');
  var resultado = obtenerDatos();
  Logger.log('Estado de conexión: ' + (resultado.success ? 'CONEXIÓN EXITOSA' : 'FALLO'));
  Logger.log('Total registros encontrados en Google Sheets: ' + (resultado.totalRegistros || 0));
  if (resultado.data) {
    Object.keys(resultado.data).forEach(function(k) {
      var cant = Array.isArray(resultado.data[k]) ? resultado.data[k].length : 0;
      Logger.log('  - ' + k + ': ' + cant + ' registros');
    });
  }
  Logger.log('==================================================');
  Logger.log('PRUEBA FINALIZADA SIN ERRORES');
  Logger.log('==================================================');
  return resultado;
}

/**
 * Punto de entrada GET (Servicio HTML para Web App e interfaz web, o JSON para API de verificación)
 */
function doGet(e) {
  e = e || { parameter: {} };
  // 1. Si se solicita formato JSON explícito mediante parámetro ?api=json
  if (e && e.parameter && e.parameter.api === 'json') {
    return createJsonResponse({
      success: true,
      message: 'Backend SSOMA activo (PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.)',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    });
  }

  // 2. Renderizar la interfaz web HTML (Index.html) en Google Apps Script
  try {
    return HtmlService.createHtmlOutputFromFile('Index')
      .setTitle('Sistema Integrado SSOMA | PERPOL & TR3')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    // Si no se incluyó Index.html en el proyecto Apps Script, retornar JSON informativo
    var responseData = {
      success: true,
      message: 'Backend SSOMA activo (PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.)',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    };
    return createJsonResponse(responseData);
  }
}

/**
 * Punto de entrada POST obligatorio para la comunicación con el Frontend
 * Procesa el cuerpo JSON en e.postData.contents y redirige mediante router interno.
 */
function doPost(e) {
  try {
    // Si se ejecuta manualmente desde el editor de Apps Script sin parámetros HTTP
    if (!e || !e.postData || !e.postData.contents) {
      Logger.log('Aviso: doPost ejecutado manualmente desde el editor de Apps Script. Ejecutando verificación...');
      var testData = obtenerDatos();
      Logger.log('Verificación finalizada con éxito: ' + (testData.totalRegistros || 0) + ' registros encontrados.');
      return createJsonResponse({
        success: true,
        message: 'Verificación ejecutada correctamente desde el editor de Apps Script.',
        totalRegistros: testData.totalRegistros,
        timestamp: new Date().toISOString()
      });
    }

    var payload = JSON.parse(e.postData.contents);
    var action = payload.action || 'ping';

    // Enrutador interno para controladores especializados
    switch (action) {
      // --- CARGA AUTOMÁTICA DE DATOS DESDE GOOGLE SHEETS (REQUERIMIENTO 1) ---
      case 'obtenerDatos':
      case 'getInitialData':
        return createJsonResponse(obtenerDatos(payload));

      case 'ping':
        return handlePing();

      case 'readRows':
        return handleReadRows(payload);

      case 'insertRow':
        return handleInsertRow(payload);

      case 'updateRow':
        return handleUpdateRow(payload);

      case 'deleteRow':
        return handleDeleteRow(payload);

      case 'batchInsert':
        return handleBatchInsert(payload);

      case 'uploadDriveFile':
        return handleUploadDriveFile(payload);

      // --- FASE 2: MÓDULO 6 TRABAJADORES Y HORAS HOMBRE ---
      case 'getTrabajadores':
      case 'saveTrabajador':
      case 'deleteTrabajador':
        return handleTrabajadoresCrud(payload);

      case 'getResumenHH':
      case 'saveResumenHH':
        return handleResumenHHCrud(payload);

      // --- FASE 2: MÓDULO 5 CONTRATISTAS ---
      case 'getContratistas':
      case 'saveContratista':
      case 'deleteContratista':
        return handleContratistasCrud(payload);

      // --- FASE 2: MÓDULO 7 PROGRAMA ANUAL SST ---
      case 'getProgramaAnual':
      case 'saveProgramaAnual':
      case 'deleteProgramaAnual':
      case 'saveProgramaResumen':
      case 'getProgramaResumen':
        return handleProgramaAnualCrud(payload);

      // --- FASE 3: MÓDULO 3 ACTOS Y CONDICIONES INSEGURAS ---
      case 'getActosCondiciones':
      case 'saveActoCondicion':
      case 'updateSeguimientoActoCondicion':
      case 'deleteActoCondicion':
        return handleActosCondicionesCrud(payload);

      // --- FASE 3: MÓDULO 2 INSPECCIONES SST ---
      case 'getInspecciones':
      case 'saveInspeccion':
      case 'updateSeguimientoInspeccion':
      case 'deleteInspeccion':
      case 'batchUploadDriveFiles':
        return handleInspeccionesCrud(payload);

      // --- FASE 4: MÓDULO 4 CONSUMO DE BOTIQUÍN ---
      case 'getConsumosBotiquin':
      case 'saveConsumoBotiquin':
      case 'deleteConsumoBotiquin':
        return handleBotiquinCrud(payload);

      // --- FASE 4: MÓDULO 1 ACCIDENTES DE TRABAJO Y SEGUIMIENTO ---
      case 'getAccidentes':
      case 'saveAccidente':
      case 'updateSeguimientoAccidente':
      case 'deleteAccidente':
      case 'transferirAtencionAAccidente':
        return handleAccidentesCrud(payload);

      // --- MÓDULO 2: ATENCIONES MÉDICAS Y PRIMEROS AUXILIOS ---
      case 'getAtencionesMedicas':
      case 'saveAtencionMedica':
      case 'deleteAtencionMedica':
        return handleAtencionesMedicasCrud(payload);

      // --- FASE 5 (PARTE 1): MÓDULO 10 INVESTIGACIÓN DE ACCIDENTES E INCIDENTES ---
      case 'getInvestigaciones':
      case 'saveInvestigacion':
      case 'persistDraft':
      case 'deleteInvestigacion':
        return handleInvestigacionesCrud(payload);

      // --- FASE 5 (PARTE 2): MÓDULO 9 SIMULACIÓN DE COSTOS DE INCIDENTES ---
      case 'getSimulacionesCostos':
      case 'saveSimulacionCostos':
      case 'deleteSimulacionCostos':
        return handleSimulacionCostosCrud(payload);

      // --- FASE 5 (PARTE 3): MÓDULO 8 ESTADÍSTICAS SST ---
      case 'getIndicatorTargets':
      case 'saveIndicatorTargets':
      case 'getEstadisticasSnapshot':
      case 'saveEstadisticasSnapshot':
        return handleEstadisticasCrud(payload);

      // --- FASE 6: IMPORTADOR GENÉRICO MASIVO POR LOTES (BATCH IMPORT) ---
      case 'handleBatchImport':
      case 'batchImport':
        return handleBatchImport(payload);

      default:
        return createJsonResponse({
          success: false,
          error: "Acción no reconocida en el backend: '" + action + "'",
          timestamp: new Date().toISOString()
        });
    }
  } catch (error) {
    return createJsonResponse({
      success: false,
      error: 'Error interno en Google Apps Script: ' + error.toString(),
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Genera la respuesta HTTP en formato JSON con cabeceras CORS
 */
function createJsonResponse(data) {
  var output = ContentService.createTextOutput(JSON.stringify(data));
  output.setMimeType(ContentService.MimeType.JSON);
  return output;
}

/**
 * Controlador de prueba de conexión
 */
function handlePing() {
  return createJsonResponse({
    success: true,
    message: 'Conexión exitosa con Google Apps Script y Google Sheets.',
    timestamp: new Date().toISOString()
  });
}

/**
 * Helper universal para normalizar valores leídos desde Google Sheets
 * Asegura que campos como DNI, ID, RUC, Teléfono y Códigos siempre sean Strings limpios
 */
function normalizeSheetValue(header, val) {
  if (val === null || val === undefined) return '';
  var h = String(header || '').toLowerCase().trim();
  
  // Si es fecha proveniente de Google Sheets (Date object)
  if (val instanceof Date) {
    try {
      return Utilities.formatDate(val, Session.getScriptTimeZone() || 'America/Lima', 'yyyy-MM-dd');
    } catch (e) {
      return val.toISOString().slice(0, 10);
    }
  }

  // Identificadores y campos de texto que nunca deben ser interpretados como números
  if (
    h.indexOf('dni') !== -1 ||
    h === 'id' ||
    h.indexOf('ruc') !== -1 ||
    h.indexOf('telefono') !== -1 ||
    h.indexOf('celular') !== -1 ||
    h.indexOf('codigo') !== -1 ||
    h.indexOf('ats') !== -1 ||
    h.indexOf('petar') !== -1 ||
    h.indexOf('puesto') !== -1 ||
    h.indexOf('area') !== -1 ||
    h.indexOf('nombre') !== -1
  ) {
    return String(val).trim();
  }

  // JSON objects / arrays serializados
  if (typeof val === 'string' && (val.charAt(0) === '[' || val.charAt(0) === '{')) {
    try {
      return JSON.parse(val);
    } catch (e) {}
  }

  return val;
}

/**
 * Convierte un encabezado con espacios, tildes o caracteres especiales en clave camelCase
 */
function toCamelCaseKey(str) {
  if (!str) return '';
  var clean = String(str)
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9\s_]/g, '');
  var words = clean.split(/[\s_]+/);
  if (words.length === 0) return '';
  var result = words[0].toLowerCase();
  for (var i = 1; i < words.length; i++) {
    var w = words[i];
    if (w.length > 0) {
      result += w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }
  }
  return result;
}

/**
 * ==============================================================================
 * REQUERIMIENTO 1: CARGA AUTOMÁTICA DE DATOS DESDE GOOGLE SHEETS
 * Invocada por google.script.run.obtenerDatos() o mediante action: 'obtenerDatos'
 * ==============================================================================
 */
function obtenerDatos(payload) {
  payload = payload || {};
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      var propId = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
      if (propId) {
        ss = SpreadsheetApp.openById(propId);
      }
    }

    // Catálogo de los 11 módulos activos del Sistema SSOMA (con nombres alternativos completos)
    var catalogos = [
      { key: 'trabajadores', sheetName: 'SSOMA_Trabajadores', altNames: ['Trabajadores', 'SSOMA_Trabajador', 'Personal'] },
      { key: 'accidentes', sheetName: 'SSOMA_Accidentes', altNames: ['Accidentes', 'SSOMA_Accidente', 'Incidentes'] },
      { key: 'atencionesMedicas', sheetName: 'SSOMA_AtencionesMedicas', altNames: ['SSOMA_Atenciones_Medicas', 'AtencionesMedicas', 'Atenciones Medicas', 'Topico'] },
      { key: 'inspecciones', sheetName: 'SSOMA_Inspecciones', altNames: ['Inspecciones', 'SSOMA_Inspeccion', 'Inspeccion'] },
      { key: 'actosCondiciones', sheetName: 'SSOMA_ActosCondiciones', altNames: ['SSOMA_Actos_Condiciones', 'ActosCondiciones', 'Actos_Condiciones', 'Actos y Condiciones', 'Actos y Condiciones Inseguras', 'SSOMA_Actos_y_Condiciones', 'SSOMA - Actos y Condiciones', 'Actos', 'Condiciones'] },
      { key: 'atencionesBotiquin', sheetName: 'SSOMA_Atenciones', altNames: ['SSOMA_ConsumoBotiquin', 'SSOMA_Botiquin', 'Atenciones', 'ConsumoBotiquin', 'Botiquin'] },
      { key: 'programaAnual', sheetName: 'SSOMA_Programa_Anual', altNames: ['SSOMA_ProgramaAnual', 'ProgramaAnual', 'Programa Anual'] },
      { key: 'investigaciones', sheetName: 'SSOMA_Investigaciones', altNames: ['Investigaciones', 'SSOMA_Investigacion', 'Investigacion'] },
      { key: 'simulacionesCostos', sheetName: 'SSOMA_Simulacion_Costos', altNames: ['sst_simulacion_costos_incidentes', 'SimulacionCostos', 'Costos'] },
      { key: 'horasHombre', sheetName: 'SSOMA_HorasHombre', altNames: ['SSOMA_Resumen_HH', 'HorasHombre', 'Horas Hombre', 'ResumenHH'] },
      { key: 'metasSST', sheetName: 'SSOMA_MetasSST', altNames: ['MetasSST', 'Metas'] }
    ];

    var consolidado = {};
    var conteoTotal = 0;

    catalogos.forEach(function(cat) {
      try {
        // Búsqueda inteligente de hoja (exacta y flexible)
        var sheet = findSheet(ss, cat.sheetName, cat.altNames);
        if (!sheet) {
          consolidado[cat.key] = [];
          return;
        }

        var lastRow = sheet.getLastRow();
        var lastCol = sheet.getLastColumn();

        if (lastRow <= 1 || lastCol === 0) {
          consolidado[cat.key] = [];
          return;
        }

        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var rawData = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();

        var rows = rawData.map(function(row) {
          var item = {};
          headers.forEach(function(header, idx) {
            var rawHeader = String(header || '').trim();
            if (!rawHeader) return;
            var val = normalizeSheetValue(rawHeader, row[idx]);
            item[rawHeader] = val;

            // Generar clave normalizada en camelCase si no existe
            var cleanKey = toCamelCaseKey(rawHeader);
            if (cleanKey && item[cleanKey] === undefined) {
              item[cleanKey] = val;
            }
          });

          // Estandarización de claves para Actos y Condiciones
          if (cat.key === 'actosCondiciones') {
            if (!item.codigoReporte) {
              item.codigoReporte = item.codigoRegistro || item.codigo || item.nroReporte || item.id || '';
            }
            if (!item.codigoRegistro) {
              item.codigoRegistro = item.codigoReporte;
            }
            if (!item.id) {
              item.id = item.codigoReporte;
            }
            if (!item.clasificacion) {
              item.clasificacion = item.tipoReporte || item.tipo || 'Acto Inseguro';
            }
            if (!item.tipoReporte) {
              item.tipoReporte = item.clasificacion;
            }
            if (!item.categoriaCodigo) {
              item.categoriaCodigo = item.categoriaId || item.codigoCategoria || 'CAT-01';
            }
            if (!item.categoriaNombre && item.categoria) {
              item.categoriaNombre = item.categoria;
            }
            if (!item.areaActo && (item.area || item.areaCondicion)) {
              item.areaActo = item.area || item.areaCondicion;
            }
            if (!item.areaCondicion && (item.area || item.areaActo)) {
              item.areaCondicion = item.area || item.areaActo;
            }
            if (!item.trabajadorObservadoNombre && item.trabajadorObservado) {
              item.trabajadorObservadoNombre = item.trabajadorObservado;
            }
            if (!item.lugarEspecifico && (item.lugarExacto || item.lugar)) {
              item.lugarEspecifico = item.lugarExacto || item.lugar;
            }
          }

          return item;
        });

        // Filtrado opcional si se solicita por empresa específica (insensible a formato 'PERPOL IDEAS' o 'TR3 ALIMENTOS')
        if (payload.empresa && payload.empresa !== 'CONSOLIDADO') {
          rows = rows.filter(function(r) {
            var emp = String(r.empresa || r.Empresa || '').toUpperCase().trim();
            if (payload.empresa === 'TR3') {
              return emp.indexOf('TR3') !== -1;
            }
            if (payload.empresa === 'PERPOL') {
              return emp.indexOf('PERPOL') !== -1 || emp === '';
            }
            return emp === payload.empresa;
          });
        }

        consolidado[cat.key] = rows;
        conteoTotal += rows.length;
      } catch (errCat) {
        consolidado[cat.key] = [];
      }
    });

    return {
      success: true,
      data: consolidado,
      totalRegistros: conteoTotal,
      empresa: payload.empresa || 'CONSOLIDADO',
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    return {
      success: false,
      error: 'Error en obtenerDatos(): ' + error.toString(),
      data: {},
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * ==============================================================================
 * CONTROLADORES DE PERSISTENCIA EN GOOGLE SHEETS
 * ==============================================================================
 */

/**
 * Lee registros de una pestaña específica de Google Sheets
 */
function handleReadRows(payload) {
  var sheetName = payload.sheetName || CONFIG.DEFAULT_SHEET_NAME;
  var sheet = getOrCreateSheet(sheetName);
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();

  if (lastRow <= 1 || lastCol === 0) {
    return createJsonResponse({
      success: true,
      data: [],
      affectedRows: 0,
      timestamp: new Date().toISOString()
    });
  }

  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var rawData = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();

  var rows = rawData.map(function(row) {
    var item = {};
    headers.forEach(function(header, idx) {
      item[header] = normalizeSheetValue(header, row[idx]);
    });
    return item;
  });

  // Filtrado opcional por empresa ('PERPOL' o 'TR3')
  if (payload.empresa && payload.empresa !== 'CONSOLIDADO') {
    rows = rows.filter(function(r) {
      return r.empresa === payload.empresa;
    });
  }

  return createJsonResponse({
    success: true,
    data: rows,
    affectedRows: rows.length,
    timestamp: new Date().toISOString()
  });
}

/**
 * Inserta una nueva fila estructurada en Google Sheets
 */
function handleInsertRow(payload) {
  var sheetName = payload.sheetName || CONFIG.DEFAULT_SHEET_NAME;
  var record = payload.data || {};
  var sheet = getOrCreateSheet(sheetName);

  if (!record.id) {
    record.id = 'REC-' + new Date().getTime() + '-' + Math.floor(Math.random() * 1000);
  }
  if (!record.createdAt) {
    record.createdAt = new Date().toISOString();
  }

  var headers = ensureHeaders(sheet, Object.keys(record));
  var rowValues = headers.map(function(header) {
    var val = record[header];
    if (val === undefined || val === null) return '';
    if (typeof val === 'object') return JSON.stringify(val);
    return val;
  });

  sheet.appendRow(rowValues);

  return createJsonResponse({
    success: true,
    data: record,
    affectedRows: 1,
    message: 'Registro insertado correctamente en hoja ' + sheetName,
    timestamp: new Date().toISOString()
  });
}

/**
 * Detecta de forma inteligente el índice de la columna identificadora (ID, código, DNI, etc.)
 */
function findIdColumnIndex(headers) {
  if (!headers || !headers.length) return -1;
  var variants = [
    'id', 'ID', 'Id', '_id',
    'codigoReporte', 'codigoRegistro', 'codigo',
    'codigoInspeccion', 'codigoAccidente', 'codigoCapacitacion',
    'dni', 'numeroDocumento'
  ];
  for (var v = 0; v < variants.length; v++) {
    var idx = headers.indexOf(variants[v]);
    if (idx !== -1) return idx;
  }
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i]).toLowerCase().trim();
    if (h === 'id' || h === 'id_registro' || h === 'cod_registro' || h === 'codigo' || h === 'código') {
      return i;
    }
  }
  return -1;
}

/**
 * Actualiza un registro existente buscando por la columna 'id' o variantes de código
 */
function handleUpdateRow(payload) {
  var sheetName = payload.sheetName || CONFIG.DEFAULT_SHEET_NAME;
  var record = payload.data || {};
  var targetId = payload.id || record.id || record.codigoReporte || record.codigoRegistro;
  var sheet = getOrCreateSheet(sheetName);

  if (!targetId) {
    return createJsonResponse({
      success: false,
      error: 'Se requiere el parámetro ID para actualizar el registro.',
      timestamp: new Date().toISOString()
    });
  }

  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow <= 1) {
    return createJsonResponse({
      success: false,
      error: 'La hoja no contiene registros para actualizar.',
      timestamp: new Date().toISOString()
    });
  }

  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var idColIdx = findIdColumnIndex(headers);
  if (idColIdx === -1) {
    return createJsonResponse({
      success: false,
      error: "Columna identificadora no encontrada en la hoja " + sheetName,
      timestamp: new Date().toISOString()
    });
  }

  var idValues = sheet.getRange(2, idColIdx + 1, lastRow - 1, 1).getValues();
  var rowIndex = -1;

  for (var i = 0; i < idValues.length; i++) {
    var cellVal = String(idValues[i][0]).trim();
    if (
      cellVal &&
      (cellVal === String(targetId).trim() ||
        (record.id && cellVal === String(record.id).trim()) ||
        (record.codigoReporte && cellVal === String(record.codigoReporte).trim()) ||
        (record.codigoRegistro && cellVal === String(record.codigoRegistro).trim()))
    ) {
      rowIndex = i + 2; // +2 por encabezados y base 1
      break;
    }
  }

  if (rowIndex === -1) {
    return createJsonResponse({
      success: false,
      error: 'No se encontró registro con ID: ' + targetId,
      timestamp: new Date().toISOString()
    });
  }

  // Asegurar que todas las claves del registro existan en encabezados
  headers = ensureHeaders(sheet, Object.keys(record));
  record.updatedAt = new Date().toISOString();

  var updatedRow = headers.map(function(header) {
    var val = record[header];
    if (val === undefined || val === null) return '';
    if (typeof val === 'object') return JSON.stringify(val);
    return val;
  });

  sheet.getRange(rowIndex, 1, 1, updatedRow.length).setValues([updatedRow]);

  return createJsonResponse({
    success: true,
    data: record,
    affectedRows: 1,
    message: 'Registro ' + targetId + ' actualizado exitosamente.',
    timestamp: new Date().toISOString()
  });
}

/**
 * Elimina una fila buscando por la columna 'id' o variantes
 */
function handleDeleteRow(payload) {
  var sheetName = payload.sheetName || CONFIG.DEFAULT_SHEET_NAME;
  var targetId = payload.id;
  var sheet = getOrCreateSheet(sheetName);

  if (!targetId) {
    return createJsonResponse({
      success: false,
      error: 'Se requiere ID para eliminar el registro.',
      timestamp: new Date().toISOString()
    });
  }

  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow <= 1) {
    return createJsonResponse({
      success: false,
      error: 'La hoja no contiene registros.',
      timestamp: new Date().toISOString()
    });
  }

  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var idColIdx = findIdColumnIndex(headers);
  if (idColIdx === -1) {
    return createJsonResponse({
      success: false,
      error: "Columna identificadora no encontrada en la hoja " + sheetName,
      timestamp: new Date().toISOString()
    });
  }

  var idValues = sheet.getRange(2, idColIdx + 1, lastRow - 1, 1).getValues();
  for (var i = 0; i < idValues.length; i++) {
    var cellVal = String(idValues[i][0]).trim();
    if (cellVal && (cellVal === String(targetId).trim() || cellVal.indexOf(String(targetId).trim()) !== -1)) {
      sheet.deleteRow(i + 2);
      return createJsonResponse({
        success: true,
        affectedRows: 1,
        message: 'Registro ' + targetId + ' eliminado correctamente.',
        timestamp: new Date().toISOString()
      });
    }
  }

  return createJsonResponse({
    success: false,
    error: 'Registro no encontrado para eliminar con ID: ' + targetId,
    timestamp: new Date().toISOString()
  });
}

/**
 * Inserción masiva por lotes (Optimizado para importaciones SheetJS/PapaParse desde frontend)
 */
function handleBatchInsert(payload) {
  var sheetName = payload.sheetName || CONFIG.DEFAULT_SHEET_NAME;
  var items = Array.isArray(payload.data) ? payload.data : [];
  if (items.length === 0) {
    return createJsonResponse({
      success: true,
      affectedRows: 0,
      message: 'No se enviaron registros en el lote.',
      timestamp: new Date().toISOString()
    });
  }

  var sheet = getOrCreateSheet(sheetName);

  // Recolectar todas las posibles cabeceras
  var allKeysSet = {};
  items.forEach(function(item) {
    Object.keys(item).forEach(function(k) {
      allKeysSet[k] = true;
    });
  });

  var headers = ensureHeaders(sheet, Object.keys(allKeysSet));

  var rowsToInsert = items.map(function(item) {
    if (!item.id) {
      item.id = 'REC-' + new Date().getTime() + '-' + Math.floor(Math.random() * 10000);
    }
    if (!item.createdAt) {
      item.createdAt = new Date().toISOString();
    }
    return headers.map(function(h) {
      var val = item[h];
      if (val === undefined || val === null) return '';
      if (typeof val === 'object') return JSON.stringify(val);
      return val;
    });
  });

  var startRow = sheet.getLastRow() + 1;
  sheet.getRange(startRow, 1, rowsToInsert.length, headers.length).setValues(rowsToInsert);

  return createJsonResponse({
    success: true,
    affectedRows: rowsToInsert.length,
    message: 'Se insertaron ' + rowsToInsert.length + ' registros exitosamente en ' + sheetName,
    timestamp: new Date().toISOString()
  });
}

/**
 * ==============================================================================
 * GESTIÓN CRÍTICA DE EVIDENCIAS Y FIRMAS EN GOOGLE DRIVE
 * ==============================================================================
 * Transforma el string Base64 en archivo físico (Blob), lo guarda en Google Drive
 * y retorna exclusivamente la URL o ID, garantizando que NUNCA se escriba Base64
 * en las celdas de Google Sheets (evitando superar el límite de 50k caracteres).
 */
function handleUploadDriveFile(payload) {
  var fileData = payload.fileData;
  if (!fileData || !fileData.base64) {
    return createJsonResponse({
      success: false,
      error: 'No se suministró información del archivo (base64 requerido).',
      timestamp: new Date().toISOString()
    });
  }

  var base64Str = fileData.base64;
  // Eliminar prefijos Data URL si vienen incluidos
  if (base64Str.indexOf('base64,') > -1) {
    base64Str = base64Str.split('base64,')[1];
  }

  var mimeType = fileData.mimeType || 'image/jpeg';
  var fileName = fileData.fileName || ('ssoma_evidencia_' + new Date().getTime() + '.jpg');
  var targetFolderId = payload.driveFolderId;

  var folder;
  if (targetFolderId && targetFolderId.trim().length > 0) {
    try {
      folder = DriveApp.getFolderById(targetFolderId.trim());
    } catch (e) {
      folder = getOrCreateFolder(CONFIG.DEFAULT_FOLDER_NAME);
    }
  } else {
    folder = getOrCreateFolder(CONFIG.DEFAULT_FOLDER_NAME);
  }

  // Convertir Base64 a Blob físico
  var decodedBytes = Utilities.base64Decode(base64Str);
  var blob = Utilities.newBlob(decodedBytes, mimeType, fileName);

  // Crear archivo físico en Google Drive
  var file = folder.createFile(blob);
  
  // Establecer permisos de visualización pública con link para el dashboard
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (err) {
    // Si la organización restringe compartir fuera del dominio, continúa con permisos estándar
  }

  var fileId = file.getId();
  // URL directa de visualización compatible con incrustación web (sin bloqueo hotlink de Drive)
  var viewUrl = 'https://lh3.googleusercontent.com/d/' + fileId;
  var thumbnailUrl = 'https://drive.google.com/thumbnail?id=' + fileId + '&sz=w1200';
  var webUrl = 'https://drive.google.com/file/d/' + fileId + '/view';

  return createJsonResponse({
    success: true,
    fileId: fileId,
    fileUrl: viewUrl,
    thumbnailUrl: thumbnailUrl,
    webUrl: webUrl,
    fileName: fileName,
    folderName: folder.getName(),
    message: 'Archivo almacenado físicamente en Google Drive con éxito.',
    timestamp: new Date().toISOString()
  });
}

/**
 * ==============================================================================
 * UTILIDADES DE HOJA DE CÁLCULO Y GOOGLE DRIVE
 * ==============================================================================
 */

/**
 * Busca de forma segura una hoja por su nombre o alias sin modificar la estructura del spreadsheet.
 * Admite coincidencias exactas y flexibles (insensible a mayúsculas, tildes, espacios o guiones bajos).
 */
function findSheet(ss, sheetName, altNames) {
  if (!ss) return null;
  // 1. Búsqueda exacta directa
  var sheet = ss.getSheetByName(sheetName);
  if (sheet) return sheet;
  if (altNames && Array.isArray(altNames)) {
    for (var i = 0; i < altNames.length; i++) {
      sheet = ss.getSheetByName(altNames[i]);
      if (sheet) return sheet;
    }
  }

  // 2. Búsqueda flexible (insensible a mayúsculas, tildes, espacios y guiones)
  var allSheets = ss.getSheets();
  var normalize = function(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[\s_\-]/g, '');
  };

  var candidates = [sheetName].concat(altNames || []);
  var normalizedCandidates = candidates.map(normalize);

  for (var j = 0; j < allSheets.length; j++) {
    var curName = allSheets[j].getName();
    var curNorm = normalize(curName);
    if (normalizedCandidates.indexOf(curNorm) !== -1) {
      return allSheets[j];
    }
  }

  return null;
}

/**
 * Obtiene la hoja de cálculo activa o la pestaña requerida (con soporte para nombres alternativos)
 */
function getOrCreateSheet(sheetName, altNames) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) {
    var propId = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
    if (propId) {
      try {
        ss = SpreadsheetApp.openById(propId);
      } catch (e) {
        Logger.log('Error abriendo spreadsheet por SPREADSHEET_ID: ' + e);
      }
    }
  }
  if (!ss) {
    throw new Error('No se detectó una hoja de cálculo vinculada. Abre el contenedor Spreadsheet o usa SpreadsheetApp.openById().');
  }

  var sheet = findSheet(ss, sheetName, altNames);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  return sheet;
}

/**
 * Asegura que los encabezados existan en la fila 1 de la hoja
 */
function ensureHeaders(sheet, requiredKeys) {
  var lastCol = sheet.getLastColumn();
  var currentHeaders = [];

  if (lastCol > 0) {
    currentHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  }

  var updatedHeaders = currentHeaders.slice();

  // Asegurar que 'id' y 'createdAt' siempre estén al inicio
  if (updatedHeaders.indexOf('id') === -1) {
    updatedHeaders.unshift('id');
  }
  if (updatedHeaders.indexOf('createdAt') === -1) {
    updatedHeaders.splice(1, 0, 'createdAt');
  }

  requiredKeys.forEach(function(k) {
    if (updatedHeaders.indexOf(k) === -1) {
      updatedHeaders.push(k);
    }
  });

  // Si hay nuevas columnas, actualizar la fila 1
  if (updatedHeaders.length > currentHeaders.length || lastCol === 0) {
    sheet.getRange(1, 1, 1, updatedHeaders.length).setValues([updatedHeaders]);
    // Formato visual para cabeceras
    sheet.getRange(1, 1, 1, updatedHeaders.length)
      .setBackground('#1F9D55')
      .setFontColor('#FFFFFF')
      .setFontWeight('bold');
    sheet.setFrozenRows(1);
  }

  return updatedHeaders;
}

/**
 * Localiza o crea una carpeta en la raíz de Google Drive
 */
function getOrCreateFolder(folderName) {
  var folders = DriveApp.getFoldersByName(folderName);
  if (folders.hasNext()) {
    return folders.next();
  }
  return DriveApp.createFolder(folderName);
}

/**
 * ==============================================================================
 * CONTROLADORES FASE 2: MÓDULO 6 - TRABAJADORES Y HORAS HOMBRE
 * ==============================================================================
 */

/**
 * CRUD para Trabajadores individuales. Clave primaria lógica: DNI / Código
 */
function handleTrabajadoresCrud(payload) {
  var sheet = getOrCreateSheet('SSOMA_Trabajadores');
  var action = payload.action;

  if (action === 'getTrabajadores') {
    return handleReadRows({ sheetName: 'SSOMA_Trabajadores', empresa: payload.empresa });
  }

  if (action === 'saveTrabajador') {
    var item = payload.data || {};
    var dni = String(item.dni || item.id || '').trim();

    if (!dni) {
      return createJsonResponse({
        success: false,
        error: 'El campo DNI / C.E. es obligatorio para registrar un trabajador.',
        timestamp: new Date().toISOString()
      });
    }

    item.id = item.id || dni;
    item.dni = dni;

    // Buscar si ya existe por DNI o ID para actualizarlo y evitar duplicados
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var rowIndex = -1;

    if (lastRow > 1 && lastCol > 0) {
      var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
      var dniColIdx = headers.indexOf('dni');
      var idColIdx = headers.indexOf('id');
      var checkCol = dniColIdx >= 0 ? dniColIdx : idColIdx;

      if (checkCol >= 0) {
        var values = sheet.getRange(2, checkCol + 1, lastRow - 1, 1).getValues();
        for (var i = 0; i < values.length; i++) {
          if (String(values[i][0]).trim() === dni) {
            rowIndex = i + 2;
            break;
          }
        }
      }
    }

    if (rowIndex > 0) {
      // Actualizar registro existente
      return handleUpdateRow({
        sheetName: 'SSOMA_Trabajadores',
        id: item.id,
        data: item
      });
    } else {
      // Insertar nuevo registro
      return handleInsertRow({
        sheetName: 'SSOMA_Trabajadores',
        data: item
      });
    }
  }

  if (action === 'deleteTrabajador') {
    return handleDeleteRow({
      sheetName: 'SSOMA_Trabajadores',
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Trabajadores: ' + action });
}

/**
 * Resumen Mensual de Personal y Horas-Hombre (HH)
 * Clave compuesta obligatoria: Año-Mes (ej: "2026-09")
 */
function handleResumenHHCrud(payload) {
  var sheet = getOrCreateSheet('SSOMA_Resumen_HH');
  var action = payload.action;

  if (action === 'getResumenHH') {
    return handleReadRows({ sheetName: 'SSOMA_Resumen_HH' });
  }

  if (action === 'saveResumenHH') {
    var data = payload.data || {};
    var anio = parseInt(data.anio, 10);
    var mes = parseInt(data.mes, 10);

    if (!anio || !mes) {
      return createJsonResponse({
        success: false,
        error: 'Año y Mes son obligatorios para el resumen de Horas-Hombre.',
        timestamp: new Date().toISOString()
      });
    }

    // Clave compuesta única: Año-Mes
    var compositeKey = anio + '-' + (mes < 10 ? '0' + mes : mes);
    data.id = compositeKey;
    data.anio = anio;
    data.mes = mes;

    // Totales calculados automáticamente
    data.trabajadoresPerpol = Number(data.trabajadoresPerpol) || 0;
    data.hhPerpol = Number(data.hhPerpol) || 0;
    data.trabajadoresTr3 = Number(data.trabajadoresTr3) || 0;
    data.hhTr3 = Number(data.hhTr3) || 0;
    data.totalTrabajadores = data.trabajadoresPerpol + data.trabajadoresTr3;
    data.totalHH = data.hhPerpol + data.hhTr3;

    // Verificar si ya existe esa clave compuesta Año-Mes para actualizar
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var rowIndex = -1;

    if (lastRow > 1 && lastCol > 0) {
      var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
      var idIdx = headers.indexOf('id');
      if (idIdx >= 0) {
        var ids = sheet.getRange(2, idIdx + 1, lastRow - 1, 1).getValues();
        for (var j = 0; j < ids.length; j++) {
          if (String(ids[j][0]) === compositeKey) {
            rowIndex = j + 2;
            break;
          }
        }
      }
    }

    if (rowIndex > 0) {
      return handleUpdateRow({
        sheetName: 'SSOMA_Resumen_HH',
        id: compositeKey,
        data: data
      });
    } else {
      return handleInsertRow({
        sheetName: 'SSOMA_Resumen_HH',
        data: data
      });
    }
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Resumen HH' });
}

/**
 * ==============================================================================
 * CONTROLADORES FASE 2: MÓDULO 5 - CONTROL DE CONTRATISTAS
 * ==============================================================================
 */

/**
 * Controlador de Contratistas con subida física de evidencia en Google Drive
 */
function handleContratistasCrud(payload) {
  var sheet = getOrCreateSheet('SSOMA_Contratistas');
  var action = payload.action;

  if (action === 'getContratistas') {
    return handleReadRows({ sheetName: 'SSOMA_Contratistas', empresa: payload.empresa });
  }

  if (action === 'saveContratista') {
    var item = payload.data || {};

    // 1. Si viene archivo en Base64, subir a Google Drive físicamente primero
    if (payload.fileData && payload.fileData.base64) {
      var uploadRes = handleUploadDriveFile(payload);
      var uploadJson = JSON.parse(uploadRes.getContent());
      if (uploadJson.success) {
        item.evidenciaFotoUrl = uploadJson.fileUrl;
        item.evidenciaDriveId = uploadJson.fileId;
      }
    }

    // Asegurar que no quede ningún campo Base64 en el objeto a persistir
    delete item.base64;
    delete item.fotoBase64;

    if (!item.id) {
      item.id = 'CONT-' + new Date().getTime() + '-' + Math.floor(Math.random() * 1000);
    }

    // Buscar si existe para actualizar o insertar
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var exists = false;

    if (lastRow > 1 && lastCol > 0) {
      var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
      var idIdx = headers.indexOf('id');
      if (idIdx >= 0) {
        var ids = sheet.getRange(2, idIdx + 1, lastRow - 1, 1).getValues();
        for (var k = 0; k < ids.length; k++) {
          if (String(ids[k][0]) === String(item.id)) {
            exists = true;
            break;
          }
        }
      }
    }

    if (exists) {
      return handleUpdateRow({ sheetName: 'SSOMA_Contratistas', id: item.id, data: item });
    } else {
      return handleInsertRow({ sheetName: 'SSOMA_Contratistas', data: item });
    }
  }

  if (action === 'deleteContratista') {
    return handleDeleteRow({ sheetName: 'SSOMA_Contratistas', id: payload.id });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Contratistas' });
}

/**
 * ==============================================================================
 * CONTROLADORES FASE 2: MÓDULO 7 - PROGRAMA ANUAL SST (GANTT Y RESUMEN)
 * ==============================================================================
 */

/**
 * Guarda y recupera actividades con arrays de 12 meses y resumen estadístico precalculado
 */
function handleProgramaAnualCrud(payload) {
  var action = payload.action;

  if (action === 'getProgramaAnual') {
    return handleReadRows({
      sheetName: 'SSOMA_Programa_Anual',
      empresa: payload.empresa
    });
  }

  if (action === 'saveProgramaAnual') {
    var act = payload.data || {};
    if (!act.id) {
      act.id = 'PROG-' + (act.anio || new Date().getFullYear()) + '-' + new Date().getTime();
    }
    return handleUpdateOrInsert('SSOMA_Programa_Anual', act);
  }

  if (action === 'deleteProgramaAnual') {
    return handleDeleteRow({
      sheetName: 'SSOMA_Programa_Anual',
      id: payload.id
    });
  }

  // Persistencia del Resumen Anual consolidado con clave compuesta Año-Empresa
  if (action === 'saveProgramaResumen') {
    var resumen = payload.data || {};
    var clave = (resumen.anio || new Date().getFullYear()) + '-' + (resumen.empresa || 'CONSOLIDADO');
    resumen.id = clave;
    return handleUpdateOrInsert('SSOMA_Programa_Resumen', resumen);
  }

  if (action === 'getProgramaResumen') {
    return handleReadRows({
      sheetName: 'SSOMA_Programa_Resumen',
      empresa: payload.empresa
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Programa Anual' });
}

/**
 * Helper para actualizar registro si existe por ID o insertarlo
 */
function handleUpdateOrInsert(sheetName, item) {
  var sheet = getOrCreateSheet(sheetName);
  var targetId = item.id || item.codigoReporte || item.codigoRegistro;
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  var rowIndex = -1;

  if (lastRow > 1 && lastCol > 0) {
    var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var idColIdx = headers.indexOf('id');
    if (idColIdx < 0) idColIdx = headers.indexOf('codigoReporte');
    if (idColIdx < 0) idColIdx = headers.indexOf('codigoRegistro');
    if (idColIdx < 0) idColIdx = headers.indexOf('codigo');
    if (idColIdx >= 0) {
      var ids = sheet.getRange(2, idColIdx + 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        var rowVal = String(ids[i][0]).trim();
        if (
          rowVal &&
          (rowVal === String(targetId).trim() ||
            (item.id && rowVal === String(item.id).trim()) ||
            (item.codigoReporte && rowVal === String(item.codigoReporte).trim()) ||
            (item.codigoRegistro && rowVal === String(item.codigoRegistro).trim()))
        ) {
          rowIndex = i + 2;
          break;
        }
      }
    }
  }

  if (rowIndex > 0) {
    return handleUpdateRow({ sheetName: sheetName, id: targetId, data: item });
  } else {
    return handleInsertRow({ sheetName: sheetName, data: item });
  }
}

/**
 * ==============================================================================
 * CONTROLADORES FASE 3: MÓDULO 3 - ACTOS Y CONDICIONES INSEGURAS
 * ==============================================================================
 */

/**
 * Gestiona el registro y seguimiento de Actos y Condiciones Inseguras
 * Genera el número correlativo automático (AC-YYYY-XXXX) a partir del máximo registrado.
 */
function handleActosCondicionesCrud(payload) {
  var altNames = [
    'SSOMA_ActosCondiciones',
    'ActosCondiciones',
    'Actos_Condiciones',
    'Actos y Condiciones',
    'Actos y Condiciones Inseguras',
    'SSOMA_Actos_y_Condiciones',
    'SSOMA - Actos y Condiciones',
    'Actos'
  ];
  var sheet = getOrCreateSheet('SSOMA_Actos_Condiciones', altNames);
  var sheetName = sheet.getName();
  var action = payload.action;

  if (action === 'getActosCondiciones') {
    return handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
  }

  if (action === 'saveActoCondicion') {
    var item = payload.data || {};

    // Si viene archivo nuevo en Base64, subirlo a Google Drive
    if (payload.fileData && payload.fileData.base64) {
      var uploadRes = handleUploadDriveFile(payload);
      var uploadJson = JSON.parse(uploadRes.getContent());
      if (uploadJson.success) {
        if (payload.isCierre) {
          item.fotoCierreUrl = uploadJson.fileUrl;
          item.fotoCierreDriveId = uploadJson.fileId;
        } else {
          item.fotoUrl = uploadJson.fileUrl;
          item.fotoDriveId = uploadJson.fileId;
        }
      }
    }

    delete item.base64;

    // Generar correlativo automático si es nuevo
    if (!item.codigoReporte && !item.codigoRegistro) {
      var anioActual = new Date().getFullYear();
      var maxCorrelativo = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoReporte');
        if (codIdx < 0) codIdx = headers.indexOf('codigoRegistro');
        if (codIdx < 0) codIdx = headers.indexOf('codigo');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var codStr = String(codes[i][0]);
            // Formato esperado: AC-2026-0001
            var match = codStr.match(/AC-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxCorrelativo) maxCorrelativo = num;
            }
          }
        }
      }

      var nextNum = maxCorrelativo + 1;
      var paddedNum = ('0000' + nextNum).slice(-4);
      item.codigoReporte = 'AC-' + anioActual + '-' + paddedNum;
      item.codigoRegistro = item.codigoReporte;
    } else {
      if (!item.codigoReporte) item.codigoReporte = item.codigoRegistro;
      if (!item.codigoRegistro) item.codigoRegistro = item.codigoReporte;
    }

    if (!item.id) {
      item.id = item.codigoReporte || ('AC-' + new Date().getTime());
    }

    return handleUpdateOrInsert(sheetName, item);
  }

  // Actualización de seguimiento (plan de acción, estado, cierre) sin duplicar filas
  if (action === 'updateSeguimientoActoCondicion') {
    var segData = payload.data || {};
    var targetId = payload.id || segData.id || segData.codigoReporte || segData.codigoRegistro;

    if (!targetId) {
      return createJsonResponse({ success: false, error: 'ID requerido para actualizar seguimiento de Acto/Condición' });
    }

    // Si viene foto de cierre
    if (payload.fileData && payload.fileData.base64) {
      var uploadResCierre = handleUploadDriveFile(payload);
      var uploadJsonCierre = JSON.parse(uploadResCierre.getContent());
      if (uploadJsonCierre.success) {
        segData.fotoCierreUrl = uploadJsonCierre.fileUrl;
        segData.fotoCierreDriveId = uploadJsonCierre.fileId;
      }
    }

    return handleUpdateRow({
      sheetName: sheetName,
      id: targetId,
      data: segData
    });
  }

  if (action === 'deleteActoCondicion') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Actos y Condiciones' });
}

/**
 * ==============================================================================
 * CONTROLADORES FASE 3: MÓDULO 2 - INSPECCIONES SST
 * ==============================================================================
 */

/**
 * Gestiona Inspecciones SST con múltiples evidencias fotográficas y actualización de seguimiento
 */
function handleInspeccionesCrud(payload) {
  var sheetName = 'SSOMA_Inspecciones';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getInspecciones') {
    return handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
  }

  // Subida por lotes (batch) de fotos a Google Drive
  if (action === 'batchUploadDriveFiles') {
    var files = Array.isArray(payload.filesData) ? payload.filesData : [];
    var results = [];

    files.forEach(function(f) {
      var singlePayload = {
        action: 'uploadDriveFile',
        fileData: f,
        driveFolderId: payload.driveFolderId
      };
      var res = handleUploadDriveFile(singlePayload);
      try {
        var jsonRes = JSON.parse(res.getContent());
        if (jsonRes.success) {
          results.push({ fileUrl: jsonRes.fileUrl, fileId: jsonRes.fileId, fileName: jsonRes.fileName });
        }
      } catch (e) {
        // Ignorar fallo individual
      }
    });

    return createJsonResponse({
      success: true,
      data: results,
      totalUploaded: results.length,
      timestamp: new Date().toISOString()
    });
  }

  if (action === 'saveInspeccion') {
    var item = payload.data || {};

    // Serializar arrays de imágenes a formato JSON o texto delimitado para celdas de Sheets
    if (Array.isArray(item.evidenciasIniciales)) {
      item.evidenciasIniciales = JSON.stringify(item.evidenciasIniciales);
    }
    if (Array.isArray(item.evidenciasCorreccion)) {
      item.evidenciasCorreccion = JSON.stringify(item.evidenciasCorreccion);
    }
    if (Array.isArray(item.atencionesPrimerosAuxilios)) {
      item.atencionesPrimerosAuxilios = JSON.stringify(item.atencionesPrimerosAuxilios);
    }

    if (!item.codigoInspeccion) {
      var anio = new Date().getFullYear();
      var maxInsp = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoInspeccion');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/INSP-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxInsp) maxInsp = num;
            }
          }
        }
      }

      item.codigoInspeccion = 'INSP-' + anio + '-' + ('0000' + (maxInsp + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.codigoInspeccion;
    }

    return handleUpdateOrInsert(sheetName, item);
  }

  // Actualización de seguimiento: actualiza SOLO campos de levantamiento sin sobrescribir hallazgos
  if (action === 'updateSeguimientoInspeccion') {
    var targetId = payload.id || (payload.data && payload.data.id);
    if (!targetId) {
      return createJsonResponse({ success: false, error: 'ID requerido para actualizar seguimiento de inspección' });
    }

    var partialData = payload.data || {};
    if (Array.isArray(partialData.evidenciasCorreccion)) {
      partialData.evidenciasCorreccion = JSON.stringify(partialData.evidenciasCorreccion);
    }

    return handleUpdateRow({
      sheetName: sheetName,
      id: targetId,
      data: partialData
    });
  }

  if (action === 'deleteInspeccion') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Inspecciones SST' });
}

/**
 * ==============================================================================
 * FASE 4 (PARTE 1): CONTROLADOR DE CONSUMO DE BOTIQUÍN (MÓDULO 4)
 * Gestiona atenciones de primeros auxilios, insumos dispensados y
 * vinculación bidireccional automática con Inspecciones SST (Módulo 2).
 * ==============================================================================
 */
function handleBotiquinCrud(payload) {
  var sheetName = 'SSOMA_Botiquin';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getConsumosBotiquin') {
    var readRes = handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
    try {
      var content = JSON.parse(readRes.getContent());
      if (content.success && Array.isArray(content.data)) {
        content.data = content.data.map(function(row) {
          if (row.elementosConsumidos && typeof row.elementosConsumidos === 'string') {
            try {
              row.elementosConsumidos = JSON.parse(row.elementosConsumidos);
            } catch (e) {
              // Dejar como string
            }
          }
          return row;
        });
        return createJsonResponse(content);
      }
    } catch (e) {
      // Retornar respuesta cruda
    }
    return readRes;
  }

  if (action === 'saveConsumoBotiquin') {
    var item = payload.data || {};

    // Serializar elementos consumidos a JSON para almacenamiento en celda de Google Sheets
    if (Array.isArray(item.elementosConsumidos)) {
      item.elementosConsumidos = JSON.stringify(item.elementosConsumidos);
    }

    // Generar correlativo BOT-YYYY-XXXX si no se proporciona
    if (!item.codigoAtencion) {
      var anio = new Date().getFullYear();
      var maxBot = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoAtencion');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/BOT-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxBot) maxBot = num;
            }
          }
        }
      }

      item.codigoAtencion = 'BOT-' + anio + '-' + ('0000' + (maxBot + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.codigoAtencion;
    }

    // Estado inicial de validación para la bandeja de transferencia hacia Módulo 1
    if (item.tipoAtencion === 'Enfermedad común') {
      item.transferidoAccidentes = false;
      item.estadoValidacion = 'Descartado'; // Regla: Enfermedad común no genera eventos estadísticos SST
    } else {
      if (item.transferidoAccidentes === undefined) {
        item.transferidoAccidentes = false;
      }
      if (!item.estadoValidacion) {
        item.estadoValidacion = 'Pendiente';
      }
    }

    // Guardar o actualizar registro de atención médica
    var saveResult = handleUpdateOrInsert(sheetName, item);

    // =========================================================================
    // VINCULACIÓN BIDIRECCIONAL CON INSPECCIONES SST (MÓDULO 2)
    // Inserta el ID y un resumen breve de esta atención en el campo
    // 'atencionesPrimerosAuxilios' de la inspección seleccionada.
    // =========================================================================
    if (item.inspeccionVinculadaId) {
      try {
        var inspSheetName = 'SSOMA_Inspecciones';
        var inspSheet = getOrCreateSheet(inspSheetName);
        var inspLastRow = inspSheet.getLastRow();
        var inspLastCol = inspSheet.getLastColumn();

        if (inspLastRow > 1 && inspLastCol > 0) {
          var inspHeaders = inspSheet.getRange(1, 1, 1, inspLastCol).getValues()[0];
          var idCol = inspHeaders.indexOf('id');
          var codCol = inspHeaders.indexOf('codigoInspeccion');
          var atnCol = inspHeaders.indexOf('atencionesPrimerosAuxilios');

          // Crear columna si no existe aún
          if (atnCol === -1) {
            atnCol = inspLastCol;
            inspSheet.getRange(1, atnCol + 1).setValue('atencionesPrimerosAuxilios');
            inspHeaders.push('atencionesPrimerosAuxilios');
          }

          var targetRow = -1;
          for (var r = 2; r <= inspLastRow; r++) {
            var rowId = idCol >= 0 ? inspSheet.getRange(r, idCol + 1).getValue() : '';
            var rowCod = codCol >= 0 ? inspSheet.getRange(r, codCol + 1).getValue() : '';

            if (rowId === item.inspeccionVinculadaId || rowCod === item.inspeccionVinculadaId) {
              targetRow = r;
              break;
            }
          }

          if (targetRow > 1) {
            var currentAtnRaw = inspSheet.getRange(targetRow, atnCol + 1).getValue();
            var atnList = [];
            try {
              if (currentAtnRaw) {
                atnList = JSON.parse(currentAtnRaw);
                if (!Array.isArray(atnList)) atnList = [String(currentAtnRaw)];
              }
            } catch (ex) {
              atnList = String(currentAtnRaw).split('\n').filter(function(s) { return s.trim().length > 0; });
            }

            var atnSummary = item.codigoAtencion + ': ' + item.tipoAtencion + ' - ' + (item.personaAtendida || '') + ' (' + (item.lesionesSintomas || 'Primeros auxilios') + ')';
            
            // Verificar si ya existe en la lista
            var alreadyLinked = false;
            for (var k = 0; k < atnList.length; k++) {
              if (String(atnList[k]).indexOf(item.codigoAtencion) >= 0) {
                alreadyLinked = true;
                break;
              }
            }

            if (!alreadyLinked) {
              atnList.push(atnSummary);
              inspSheet.getRange(targetRow, atnCol + 1).setValue(JSON.stringify(atnList));
            }
          }
        }
      } catch (linkError) {
        // La vinculación falló de forma no crítica, registrar en log
        Logger.log('Error en vinculación bidireccional con inspección: ' + linkError.toString());
      }
    }

    return saveResult;
  }

  if (action === 'deleteConsumoBotiquin') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Módulo Botiquín' });
}

/**
 * ==============================================================================
 * FASE 4 (PARTE 2): CONTROLADOR DE ACCIDENTES E INCIDENTES (MÓDULO 1)
 * Gestiona el registro oficial de accidentes/incidentes, seguimiento,
 * días de descanso médico y recepción de transferencias desde Tópico.
 * ==============================================================================
 */
function handleAccidentesCrud(payload) {
  var sheetName = 'SSOMA_Accidentes';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getAccidentes') {
    return handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
  }

  if (action === 'saveAccidente') {
    var item = payload.data || {};

    // Generar correlativo ACC-YYYY-XXXX si no se proporciona
    if (!item.codigoCaso) {
      var anio = new Date().getFullYear();
      var maxAcc = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoCaso');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/ACC-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxAcc) maxAcc = num;
            }
          }
        }
      }

      item.codigoCaso = 'ACC-' + anio + '-' + ('0000' + (maxAcc + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.codigoCaso;
    }

    if (!item.estadoCaso) {
      item.estadoCaso = 'Abierto';
    }

    item.diasDescanso = Number(item.diasDescanso) || 0;

    var saveRes = handleUpdateOrInsert(sheetName, item);

    // Si este caso provino de una atención de botiquín, actualizar el registro de Botiquín
    if (item.origenAtencionBotiquinId) {
      try {
        var botSheetName = 'SSOMA_Botiquin';
        var botSheet = getOrCreateSheet(botSheetName);
        var botLastRow = botSheet.getLastRow();
        var botLastCol = botSheet.getLastColumn();

        if (botLastRow > 1 && botLastCol > 0) {
          var bHeaders = botSheet.getRange(1, 1, 1, botLastCol).getValues()[0];
          var bIdCol = bHeaders.indexOf('id');
          var bCodCol = bHeaders.indexOf('codigoAtencion');
          var bTransCol = bHeaders.indexOf('transferidoAccidentes');
          var bEstCol = bHeaders.indexOf('estadoValidacion');
          var bCasoCol = bHeaders.indexOf('casoAccidenteId');

          if (bTransCol === -1) {
            bTransCol = botLastCol;
            botSheet.getRange(1, bTransCol + 1).setValue('transferidoAccidentes');
          }
          if (bEstCol === -1) {
            bEstCol = botSheet.getLastColumn();
            botSheet.getRange(1, bEstCol + 1).setValue('estadoValidacion');
          }
          if (bCasoCol === -1) {
            bCasoCol = botSheet.getLastColumn();
            botSheet.getRange(1, bCasoCol + 1).setValue('casoAccidenteId');
          }

          for (var bRow = 2; bRow <= botLastRow; bRow++) {
            var bId = bIdCol >= 0 ? botSheet.getRange(bRow, bIdCol + 1).getValue() : '';
            var bCod = bCodCol >= 0 ? botSheet.getRange(bRow, bCodCol + 1).getValue() : '';

            if (bId === item.origenAtencionBotiquinId || bCod === item.origenAtencionBotiquinId) {
              botSheet.getRange(bRow, bTransCol + 1).setValue(true);
              botSheet.getRange(bRow, bEstCol + 1).setValue('Validado');
              botSheet.getRange(bRow, bCasoCol + 1).setValue(item.codigoCaso);
              break;
            }
          }
        }
      } catch (errBot) {
        Logger.log('Error actualizando botiquin tras crear accidente: ' + errBot.toString());
      }
    }

    return saveRes;
  }

  // Actualización de seguimiento (plan de acción, estado, descanso médico, fecha de cierre)
  if (action === 'updateSeguimientoAccidente') {
    var targetId = payload.id || (payload.data && payload.data.id);
    if (!targetId) {
      return createJsonResponse({ success: false, error: 'ID requerido para actualizar seguimiento de accidente' });
    }

    return handleUpdateRow({
      sheetName: sheetName,
      id: targetId,
      data: payload.data
    });
  }

  if (action === 'deleteAccidente') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  // Transferencia rápida de atención de botiquín hacia borrador de accidente
  if (action === 'transferirAtencionAAccidente') {
    var atencionId = payload.atencionId;
    if (!atencionId) {
      return createJsonResponse({ success: false, error: 'atencionId requerido para transferir' });
    }

    // Retorna confirmación; la UI procesa y guarda el caso oficial
    return createJsonResponse({
      success: true,
      message: 'Atención ' + atencionId + ' habilitada para generación de caso oficial en Módulo 1.',
      timestamp: new Date().toISOString()
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Accidentes de Trabajo' });
}

/**
 * ==============================================================================
 * MÓDULO 2: CONTROLADOR DE ATENCIONES MÉDICAS Y PRIMEROS AUXILIOS
 * Gestiona el registro independiente de atenciones clínicas, diagnóstico médico,
 * descansos laborales, citas de control y vinculación opcional con eventos SST.
 * ==============================================================================
 */
function handleAtencionesMedicasCrud(payload) {
  var sheetName = 'SSOMA_AtencionesMedicas';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getAtencionesMedicas') {
    return handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
  }

  if (action === 'saveAtencionMedica') {
    var item = payload.data || {};

    // Generar correlativo ATN-YYYY-XXXX si no se proporciona
    if (!item.idAtencion) {
      var anio = new Date().getFullYear();
      var maxAtn = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('idAtencion');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/ATN-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxAtn) maxAtn = num;
            }
          }
        }
      }

      item.idAtencion = 'ATN-' + anio + '-' + ('0000' + (maxAtn + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.idAtencion;
    }

    if (!item.estado) {
      item.estado = 'En seguimiento';
    }

    item.diasDescanso = Number(item.diasDescanso) || 0;

    return handleUpdateOrInsert(sheetName, item);
  }

  if (action === 'deleteAtencionMedica') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Atenciones Médicas' });
}

/**
 * ==============================================================================
 * FASE 5 (PARTE 1): CONTROLADOR DE INVESTIGACIÓN DE ACCIDENTES (MÓDULO 10)
 * Metodología de causa raíz (5 Porqués / Ishikawa), snapshots de caso y trabajador,
 * seguimiento de medidas correctivas y array de investigadores con firmas en Drive.
 * ==============================================================================
 */
function handleInvestigacionesCrud(payload) {
  var sheetName = 'SSOMA_Investigaciones';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getInvestigaciones') {
    var readRes = handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
    try {
      var content = JSON.parse(readRes.getContent());
      if (content.success && Array.isArray(content.data)) {
        content.data = content.data.map(function(row) {
          var jsonFields = ['datosTrabajador', 'causasInmediatas', 'causasBasicas', 'medidasCorrectivas', 'investigadores', 'closureErrors'];
          for (var i = 0; i < jsonFields.length; i++) {
            var f = jsonFields[i];
            if (row[f] && typeof row[f] === 'string') {
              try {
                row[f] = JSON.parse(row[f]);
              } catch (e) {
                // conservar valor original
              }
            }
          }
          return row;
        });
        return createJsonResponse(content);
      }
    } catch (e) {
      // Retornar lectura directa
    }
    return readRes;
  }

  if (action === 'saveInvestigacion' || action === 'persistDraft') {
    var item = payload.data || {};

    // Generar correlativo INV-YYYY-XXXX si no se proporciona
    if (!item.codigoInvestigacion) {
      var anio = new Date().getFullYear();
      var maxInv = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoInvestigacion');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/INV-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxInv) maxInv = num;
            }
          }
        }
      }

      item.codigoInvestigacion = 'INV-' + anio + '-' + ('0000' + (maxInv + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.codigoInvestigacion;
    }

    if (!item.estado) {
      item.estado = 'Borrador';
    }

    // Serializar campos complejos a JSON para almacenamiento en celdas de Sheets
    var jsonFieldsToSerialize = ['datosTrabajador', 'causasInmediatas', 'causasBasicas', 'medidasCorrectivas', 'investigadores', 'closureErrors'];
    for (var k = 0; k < jsonFieldsToSerialize.length; k++) {
      var fieldKey = jsonFieldsToSerialize[k];
      if (item[fieldKey] && typeof item[fieldKey] === 'object') {
        item[fieldKey] = JSON.stringify(item[fieldKey]);
      }
    }

    var saveRes = handleUpdateOrInsert(sheetName, item);

    // Si la investigación está vinculada a un accidente (ACC-...), actualizar el estado del caso en SSOMA_Accidentes
    if (item.accidenteId) {
      try {
        var accSheet = getOrCreateSheet('SSOMA_Accidentes');
        var accLastRow = accSheet.getLastRow();
        var accLastCol = accSheet.getLastColumn();

        if (accLastRow > 1 && accLastCol > 0) {
          var accHeaders = accSheet.getRange(1, 1, 1, accLastCol).getValues()[0];
          var accIdCol = accHeaders.indexOf('id');
          var accCodCol = accHeaders.indexOf('codigoCaso');
          var accEstCol = accHeaders.indexOf('estadoCaso');

          if (accEstCol >= 0) {
            for (var r = 2; r <= accLastRow; r++) {
              var aId = accIdCol >= 0 ? accSheet.getRange(r, accIdCol + 1).getValue() : '';
              var aCod = accCodCol >= 0 ? accSheet.getRange(r, accCodCol + 1).getValue() : '';

              if (aId === item.accidenteId || aCod === item.accidenteId) {
                var nuevoEstadoAccidente = item.estado === 'Cerrada' ? 'Cerrado' : 'En investigación';
                accSheet.getRange(r, accEstCol + 1).setValue(nuevoEstadoAccidente);
                break;
              }
            }
          }
        }
      } catch (errAcc) {
        Logger.log('Error actualizando estado en SSOMA_Accidentes: ' + errAcc.toString());
      }
    }

    return saveRes;
  }

  if (action === 'deleteInvestigacion') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Módulo de Investigación' });
}

/**
 * ==============================================================================
 * FASE 5 (PARTE 2): CONTROLADOR DE SIMULACIÓN DE COSTOS DE INCIDENTES (MÓDULO 9)
 * Tabla aislada para escenarios heurísticos y modelos económicos de pérdidas potenciales.
 * Garantiza que los días simulados y costos NO se sumen a las estadísticas reales.
 * ==============================================================================
 */
function handleSimulacionCostosCrud(payload) {
  var sheetName = 'sst_simulacion_costos_incidentes';
  var sheet = getOrCreateSheet(sheetName);
  var action = payload.action;

  if (action === 'getSimulacionesCostos') {
    var readRes = handleReadRows({ sheetName: sheetName, empresa: payload.empresa });
    try {
      var content = JSON.parse(readRes.getContent());
      if (content.success && Array.isArray(content.data)) {
        content.data = content.data.map(function(row) {
          if (row.costosDirectos && typeof row.costosDirectos === 'string') {
            try { row.costosDirectos = JSON.parse(row.costosDirectos); } catch (e) {}
          }
          if (row.costosIndirectos && typeof row.costosIndirectos === 'string') {
            try { row.costosIndirectos = JSON.parse(row.costosIndirectos); } catch (e) {}
          }
          return row;
        });
        return createJsonResponse(content);
      }
    } catch (e) {}
    return readRes;
  }

  if (action === 'saveSimulacionCostos') {
    var item = payload.data || {};

    if (!item.codigoSimulacion) {
      var anio = new Date().getFullYear();
      var maxSim = 0;
      var lastRow = sheet.getLastRow();
      var lastCol = sheet.getLastColumn();

      if (lastRow > 1 && lastCol > 0) {
        var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
        var codIdx = headers.indexOf('codigoSimulacion');
        if (codIdx >= 0) {
          var codes = sheet.getRange(2, codIdx + 1, lastRow - 1, 1).getValues();
          for (var i = 0; i < codes.length; i++) {
            var match = String(codes[i][0]).match(/SIM-\d{4}-(\d+)/);
            if (match && match[1]) {
              var num = parseInt(match[1], 10);
              if (num > maxSim) maxSim = num;
            }
          }
        }
      }

      item.codigoSimulacion = 'SIM-' + anio + '-' + ('0000' + (maxSim + 1)).slice(-4);
    }

    if (!item.id) {
      item.id = item.codigoSimulacion;
    }

    // Serializar objetos económicos a string JSON
    if (item.costosDirectos && typeof item.costosDirectos === 'object') {
      item.costosDirectos = JSON.stringify(item.costosDirectos);
    }
    if (item.costosIndirectos && typeof item.costosIndirectos === 'object') {
      item.costosIndirectos = JSON.stringify(item.costosIndirectos);
    }

    // Guardado exclusivo en sst_simulacion_costos_incidentes (nunca afecta estadísticas reales)
    return handleUpdateOrInsert(sheetName, item);
  }

  if (action === 'deleteSimulacionCostos') {
    return handleDeleteRow({
      sheetName: sheetName,
      id: payload.id
    });
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Simulación de Costos' });
}

/**
 * ==============================================================================
 * FASE 5 (PARTE 3): CONTROLADOR DE ESTADÍSTICAS SST (MÓDULO 8)
 * Gestión de metas anuales de indicadores (IF, IS, IA) y snapshots periódicos
 * consolidados en 'sst_estadisticas_dashboard' para optimizar tiempos de carga.
 * ==============================================================================
 */
function handleEstadisticasCrud(payload) {
  var action = payload.action;

  // Gestión de Metas Anuales de Indicadores
  if (action === 'getIndicatorTargets') {
    var metasSheet = getOrCreateSheet('SSOMA_MetasSST');
    return handleReadRows({ sheetName: 'SSOMA_MetasSST', empresa: payload.empresa });
  }

  if (action === 'saveIndicatorTargets') {
    var targets = payload.data || {};
    if (!targets.id) {
      targets.id = (targets.empresa || 'CONSOLIDADO') + '-' + (targets.periodoAnio || new Date().getFullYear());
    }
    return handleUpdateOrInsert('SSOMA_MetasSST', targets);
  }

  // Snapshots consolidados periódicos del Dashboard
  if (action === 'getEstadisticasSnapshot') {
    return handleReadRows({ sheetName: 'sst_estadisticas_dashboard', empresa: payload.empresa });
  }

  if (action === 'saveEstadisticasSnapshot') {
    var snapshot = payload.data || {};
    if (!snapshot.id) {
      snapshot.id = 'SNAP-' + (snapshot.empresa || 'CONSOLIDADO') + '-' + (snapshot.periodoAnio || new Date().getFullYear());
    }
    snapshot.fechaCalculoSnapshot = new Date().toISOString();

    if (snapshot.mensual && typeof snapshot.mensual === 'object') {
      snapshot.mensual = JSON.stringify(snapshot.mensual);
    }
    if (snapshot.metas && typeof snapshot.metas === 'object') {
      snapshot.metas = JSON.stringify(snapshot.metas);
    }

    return handleUpdateOrInsert('sst_estadisticas_dashboard', snapshot);
  }

  return createJsonResponse({ success: false, error: 'Acción no soportada en Estadísticas SST' });
}

/**
 * ==============================================================================
 * FASE 6: CONTROLADOR DE IMPORTACIÓN MASIVA POR LOTES (BATCH PROCESSING)
 * Diseñado para máxima velocidad mediante escrituras en bloque setValues()
 * Evita iteraciones celda por celda garantizando ejecución en < 2 segundos.
 * Soporta modos: 'upsert' (crear y actualizar), 'insertar' (solo nuevos),
 * 'actualizar' (solo existentes). Preserva campos vacíos como "sin cambios".
 * ==============================================================================
 */
function handleBatchImport(payload) {
  var sheetName = payload.sheetName || 'SSOMA_DEFAULT';
  var sheet = getOrCreateSheet(sheetName);
  var rows = Array.isArray(payload.rows) ? payload.rows : (Array.isArray(payload.data) ? payload.data : []);
  var mode = payload.mode || 'upsert';
  var primaryKey = payload.primaryKey || 'id';

  if (rows.length === 0) {
    return createJsonResponse({
      success: true,
      created: 0,
      updated: 0,
      skipped: 0,
      rejected: 0,
      message: 'No se recibieron filas para procesar',
      timestamp: new Date().toISOString()
    });
  }

  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  var headers = [];

  // Si la hoja no tiene encabezados, deducirlos de las claves de la primera fila
  if (lastRow === 0 || lastCol === 0) {
    var sampleKeys = Object.keys(rows[0] || {});
    // Asegurar que 'id' esté primero si existe
    headers = sampleKeys.filter(function(k) { return k !== '__rowNumber' && k !== '__hasError'; });
    if (headers.indexOf('id') === -1) headers.unshift('id');
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    lastRow = 1;
    lastCol = headers.length;
  } else {
    headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  }

  // Verificar si hay columnas nuevas en las filas entrantes para añadirlas al final
  var newColumnsFound = false;
  rows.forEach(function(row) {
    Object.keys(row).forEach(function(k) {
      if (k !== '__rowNumber' && k !== '__hasError' && headers.indexOf(k) === -1) {
        headers.push(k);
        newColumnsFound = true;
      }
    });
  });

  if (newColumnsFound) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    lastCol = headers.length;
  }

  var pkIndex = headers.indexOf(primaryKey);
  if (pkIndex === -1) pkIndex = headers.indexOf('id');

  // Mapa de clave primaria a índice de fila (1-based en Sheets)
  var pkRowMap = {};
  var allSheetValues = [];

  if (lastRow > 1) {
    allSheetValues = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
    for (var r = 0; r < allSheetValues.length; r++) {
      var currentPk = pkIndex >= 0 ? String(allSheetValues[r][pkIndex]).trim() : '';
      if (currentPk) {
        pkRowMap[currentPk] = r + 2; // fila real en hoja (fila 1 son headers)
      }
    }
  }

  var createdCount = 0;
  var updatedCount = 0;
  var skippedCount = 0;
  var rejectedCount = 0;
  var errors = [];
  var newRowsToAppend = [];
  var updatedRowsIndices = [];

  for (var i = 0; i < rows.length; i++) {
    var item = rows[i];
    if (!item || typeof item !== 'object') {
      rejectedCount++;
      continue;
    }

    var itemPk = String(item[primaryKey] || item.id || '').trim();
    var existingRowNumber = itemPk ? pkRowMap[itemPk] : undefined;

    if (existingRowNumber !== undefined) {
      // Registro existente encontrado en la hoja
      if (mode === 'insertar') {
        skippedCount++;
        continue;
      }

      // Modo 'actualizar' o 'upsert': actualizar preservando campos no provistos
      var rowIndexInArray = existingRowNumber - 2;
      var existingRowValues = allSheetValues[rowIndexInArray];

      headers.forEach(function(h, colIdx) {
        var newVal = item[h];
        // Respetar campos vacíos como "sin cambios" a menos que sea provisto explícitamente
        if (newVal !== undefined && newVal !== null && String(newVal).trim() !== '') {
          if (typeof newVal === 'object') {
            existingRowValues[colIdx] = JSON.stringify(newVal);
          } else {
            existingRowValues[colIdx] = newVal;
          }
        }
      });

      // Actualizar updatedAt
      var upIdx = headers.indexOf('updatedAt');
      if (upIdx >= 0) existingRowValues[upIdx] = new Date().toISOString();

      allSheetValues[rowIndexInArray] = existingRowValues;
      updatedRowsIndices.push(existingRowNumber);
      updatedCount++;
    } else {
      // Registro nuevo
      if (mode === 'actualizar') {
        skippedCount++;
        continue;
      }

      // Modo 'insertar' o 'upsert': crear nueva fila
      var newRowArr = headers.map(function(h) {
        var val = item[h];
        if (val === undefined || val === null) return '';
        if (typeof val === 'object') return JSON.stringify(val);
        return val;
      });

      newRowsToAppend.push(newRowArr);
      if (itemPk) {
        // Registrar en el mapa por si viene repetido en el mismo lote
        pkRowMap[itemPk] = lastRow + newRowsToAppend.length;
      }
      createdCount++;
    }
  }

  // Escritura atómica en bloque para nuevas filas: getRange().setValues()
  if (newRowsToAppend.length > 0) {
    sheet.getRange(lastRow + 1, 1, newRowsToAppend.length, headers.length).setValues(newRowsToAppend);
  }

  // Escritura de filas actualizadas: si hay varias, actualizar el bloque completo en memoria
  if (updatedCount > 0 && allSheetValues.length > 0) {
    sheet.getRange(2, 1, allSheetValues.length, headers.length).setValues(allSheetValues);
  }

  return createJsonResponse({
    success: true,
    created: createdCount,
    updated: updatedCount,
    skipped: skippedCount,
    rejected: rejectedCount,
    errors: errors,
    message: 'Lote de ' + rows.length + ' filas procesado exitosamente en ' + sheetName,
    timestamp: new Date().toISOString()
  });
}

