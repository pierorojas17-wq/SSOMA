# GUÍA DE ARQUITECTURA E INTEGRACIÓN
## Independización de “Accidentes de Trabajo” y Creación de “Atenciones Médicas”

Sistema Integrado SSOMA — PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.

---

### 1. OBJETIVO DEL SISTEMA
El sistema ha independizado la gestión en dos módulos especializados y autónomos:

* **Módulo 1: Accidentes de Trabajo (`/accidentes`)**
  * Limitado exclusivamente a los **Datos del evento SST**.
  * No almacena internamente arrays de atenciones ni campos médicos de diagnóstico o descanso.
  * Incorpora las 4 listas técnicas normativas de selección múltiple con habilitación dinámica de "Otros".
  * Incluye la pregunta indicadora `¿Requirió primeros auxilios o atención médica?` (SÍ / NO).

* **Módulo 2: Atenciones Médicas (`/atenciones-medicas`)**
  * Concentra exclusivamente toda la **Primera atención clínica y primeros auxilios**.
  * Registro independiente con su propio identificador (`idAtencion`).
  * Cálculo automático de días de descanso médico entre fechas de inicio y fin.
  * Manejo de estados de atención: *En seguimiento*, *Alta / reincorporado* y *Cerrado*.
  * Vinculación técnica opcional con el evento SST mediante `idAccidente` y `codigoAccidente`.

---

### 2. REGLA FUNDAMENTAL DE ARQUITECTURA
* **1 Accidente = 1 Registro en Accidentes de Trabajo.**
* **1 Atención Médica = 1 Registro independiente en Atenciones Médicas.**
* Si un trabajador tiene múltiples atenciones o controles sucesivos por el mismo evento SST, cada atención se registra como una fila independiente vinculada por `idAccidente`.
* En Estadísticas SST, los indicadores de accidentabilidad (IF, IA) se rigen por la regla estricta: **1 accidente = 1 evento**, sumando los días de descanso acumulados de todas sus atenciones sin duplicar la frecuencia de eventos.

---

### 3. RELACIÓN BIDIRECCIONAL ENTRE MÓDULOS
* **Desde Accidentes → Atenciones Médicas:**
  * Acción **"Registrar atención médica"** (visible si `necesidadAtencion = SI`): Transfiere automáticamente el código del caso, trabajador, empresa, cargo, área y turno.
  * Acción **"Ver atenciones"**: Abre el historial de Atenciones Médicas filtrando automáticamente por el caso del accidente.
* **Desde Atenciones Médicas → Accidentes:**
  * En cada atención vinculada a un evento SST, el botón **"Ver evento SST"** permite abrir el Módulo 1 posicionando y filtrando el caso correspondiente.

---

### 4. ESTRUCTURA DE HOJAS EN GOOGLE SHEETS

#### Hoja: `SSOMA_Accidentes`
| Columna | Tipo | Descripción |
|---|---|---|
| `id` / `codigoCaso` | String | Correlativo único (ej. ACC-2026-0001) |
| `empresa` | String | PERPOL o TR3 |
| `fecha` | Date | Fecha del suceso SST (YYYY-MM-DD) |
| `hora` | String | Hora del suceso (HH:mm) |
| `trabajadorDni` | String | DNI (8 dígitos) o C.E. (hasta 12 caracteres) |
| `trabajadorNombre` | String | Apellidos y Nombres completos |
| `cargo` | String | Puesto o cargo del trabajador |
| `area` | String | Área de trabajo |
| `turno` | String | Mañana, Tarde o Noche |
| `lugarExacto` | String | Ubicación circunstanciada |
| `responsableArea` | String | Jefe o supervisor inmediato |
| `tipoEvento` | String | Incidente potencial, Incidente, Accidente leve, Accidente incapacitante, Accidente mortal |
| `danoMaterial` | String | SI / NO |
| `detalleDano` | String | Especificación del daño a equipos/proceso |
| `necesidadAtencion` | String | SI / NO (Indicador SST) |
| `partesCuerpoAfectadas` | Array / JSON | Cabeza, Ojos, Tronco, Brazo, Mano, Dedos, Pierna, Pie, Otros |
| `partesCuerpoOtros` | String | Detalle si se seleccionó Otros |
| `mecanismoEvento` | Array / JSON | Golpes, Caídas, Cortes, Quemaduras, Atrapamientos, Atropellamientos, Sobre esfuerzo, Intoxicación, Otros |
| `mecanismoEventoOtros` | String | Detalle si se seleccionó Otros |
| `agenteEvento` | Array / JSON | Calor, Químicos, Metales, Eléctricos, Vidrio, Escaleras, Madera, Herramienta manual, Otros |
| `agenteEventoOtros` | String | Detalle si se seleccionó Otros |
| `lesionReferida` | Array / JSON | Amputación, Pérdida de visión, Quemadura, Electrocución, Raspadura, Laceración, Fractura, Luxación, Contusión, Envenenamiento, Lesiones múltiples, Muerte, Otros |
| `lesionReferidaOtros` | String | Detalle si se seleccionó Otros |
| `descripcion` | String | Descripción detallada y circunstanciada |
| `causaInmediata` | String | Acto subestándar / Condición subestándar |
| `fotoUrl` | String | Enlace oficial al archivo en Google Drive |
| `estadoCaso` | String | Abierto, En investigación, Con medidas correctivas, Cerrado |
| `medidasCorrectivas` | String | Plan de acción correctivo y preventivo |
| `responsableSeguimiento` | String | Responsable de implementación |
| `fechaCompromiso` | Date | Fecha límite |
| `fechaCierre` | Date | Fecha de cierre efectivo |

#### Hoja: `SSOMA_AtencionesMedicas`
| Columna | Tipo | Descripción |
|---|---|---|
| `id` / `idAtencion` | String | Correlativo clínico (ej. ATN-2026-0001) |
| `codigoAccidente` | String | Código de caso SST vinculado (Opcional) |
| `idAccidente` | String | ID técnico de accidente vinculado |
| `empresa` | String | PERPOL o TR3 |
| `fechaAtencion` | Date | Fecha de atención clínica (YYYY-MM-DD) |
| `horaAtencion` | String | Hora de atención (HH:mm) |
| `trabajadorDni` | String | DNI / C.E. del paciente |
| `trabajadorNombre` | String | Apellidos y nombres |
| `puesto` | String | Puesto laboral |
| `area` | String | Área de adscripción |
| `turno` | String | Turno laboral |
| `lugarAtencion` | String | Tópico de planta, clínica, policlínico, etc. |
| `diagnostico` | String | Diagnóstico clínico y tratamiento |
| `generaDescanso` | String | SI / NO |
| `fechaInicioDescanso` | Date | Inicio del reposo médico |
| `fechaFinDescanso` | Date | Fin del reposo médico |
| `diasDescanso` | Number | Días de descanso médico calculados |
| `proximaCita` | Date | Fecha de control médico (Opcional) |
| `estado` | String | En seguimiento, Alta / reincorporado, Cerrado |
| `medicoTratante` | String | Profesional de la salud tratante |
| `observaciones` | String | Recomendaciones de aptitud y reincorporación |

---

### 5. MIGRACIÓN AUTOMÁTICA DE DATOS
El sistema ejecuta de forma transparente en el cliente (`appStore.ts: onRehydrateStorage`) la migración de estructuras previas:
1. Detecta si algún accidente en almacenamiento local contiene la propiedad obsoleta `atenciones: []`.
2. Genera un registro independiente en `atencionesMedicas` copiando los datos médicos y asignándole `idAccidente = acc.id`.
3. Elimina la propiedad `atenciones` del objeto del accidente para garantizar el estándar arquitectónico.
