# CHECKLIST DE ENTREGA OPERATIVA Y PROTOCOLO DE VALIDACIÓN EN PRODUCCIÓN
## Sistema Integrado SSOMA — PERPOL IDEAS S.A.C. & TR3 ALIMENTOS S.A.C.

---

### 1. ESTADO DE MIGRACIÓN Y CONTINUIDAD DE OPERACIONES
* **Almacenamiento Local y Caché de Navegadores:** Validado. El script `onRehydrateStorage` migra automáticamente las atenciones médicas que existían en versiones previas sin pérdida de historial.
* **Separación Funcional Garantizada:**
  * `Módulo 1: Accidentes de Trabajo` registra única y exclusivamente el evento SST (`ACC-YYYY-XXXX`).
  * `Módulo 2: Atenciones Médicas` administra diagnósticos, descansos y citas médicas (`ATN-YYYY-XXXX`).
* **Integridad de Base Maestra:** Ambos módulos consumen la lista unificada de colaboradores con soporte de **DNI (8 dígitos)** y **C.E. (hasta 12 caracteres)**.

---

### 2. MATRIZ DE CASOS DE PRUEBA OPERATIVOS (VERIFICADOS)

| # | Escenario de Prueba | Comportamiento Esperado | Resultado |
|---|---|---|---|
| **CP-01** | Registro de **Incidente Potencial** | Bloqueo estricto de Daño Material ("NO") y Requerimiento de Atención Médica ("NO"). | ✅ Conforme |
| **CP-02** | Selección de opción **"Otros"** en cualquiera de las 4 listas técnicas de clasificación | Despliegue de input de texto obligatorio para especificar detalle técnico. | ✅ Conforme |
| **CP-03** | Accidente con `¿Requirió primeros auxilios? = SÍ` | Habilitación de la acción **"Registrar atención médica"** en la tabla y modal de detalle. | ✅ Conforme |
| **CP-04** | Registro de Atención Médica derivada | Herencia automática de `idAccidente`, `codigoAccidente`, trabajador, cargo, área y turno sin reescribir datos. | ✅ Conforme |
| **CP-05** | Cálculo automático de descanso médico | Al seleccionar "SÍ" e indicar fecha inicio y fin, el sistema computa los días de descanso de forma inclusiva. | ✅ Conforme |
| **CP-06** | Consulta bidireccional entre módulos | Desde Accidentes: botón **"Ver atenciones"** filtra las atenciones del caso. Desde Atenciones: botón **"Ver evento SST"** abre y filtra el caso SST. | ✅ Conforme |
| **CP-07** | Estadísticas SST (1 accidente = 1 evento) | Si un accidente posee 2 o más atenciones médicas de control, los índices IF e IA computan 1 solo evento, sumando los días perdidos para el IS. | ✅ Conforme |
| **CP-08** | Importación Masiva Excel/CSV | Validación y carga en bloque mediante `GenericImportModal` tanto para Accidentes (`SSOMA_Accidentes`) como para Atenciones (`SSOMA_AtencionesMedicas`). | ✅ Conforme |

---

### 3. PROTOCOLO OPERATIVO PARA EL EQUIPO SSOMA Y SALUD OCUPACIONAL

#### Flujo 1: Ocurrencia de un Evento SST (Accidente o Incidente)
1. Ingresar al **Módulo 1: Accidentes de Trabajo** (`/accidentes`).
2. Pulsar **"Registrar Caso Oficial"** y autocompletar el colaborador por nombre o DNI/C.E.
3. Clasificar el evento con las 4 listas técnicas normativas y adjuntar foto de evidencia si aplica.
4. Si el trabajador requirió auxilio médico, marcar `¿Requirió primeros auxilios? = SÍ`.
5. Guardar el caso (`ACC-YYYY-XXXX`).

#### Flujo 2: Registro de la Atención Médica / Primeros Auxilios
1. En la fila del accidente registrado, hacer clic en el botón verde **"Atención"** (o ingresar al **Módulo 2: Atenciones Médicas** y pulsar "Registrar").
2. Verificar los datos heredados del trabajador y del accidente.
3. Registrar el lugar de atención (Tópico de planta, clínica externa, etc.) y diagnóstico.
4. Si amerita descanso médico, seleccionar **SÍ** e ingresar las fechas: el sistema calcula automáticamente los días de descanso.
5. Indicar fecha de próxima cita de control y estado de la atención (*En seguimiento* o *Alta / reincorporado*).
6. Guardar la atención (`ATN-YYYY-XXXX`).

#### Flujo 3: Investigación y Estadísticas
* **Investigación:** Dirigirse al **Módulo 12: Investigación de Accidentes** (`/investigacion`) y vincular el código del caso (`ACC-YYYY-XXXX`) para realizar el árbol de causas.
* **Estadísticas:** El **Módulo 10: Estadísticas SST** (`/estadisticas`) actualizará en tiempo real los gráficos e índices oficiales del Comité SST.
